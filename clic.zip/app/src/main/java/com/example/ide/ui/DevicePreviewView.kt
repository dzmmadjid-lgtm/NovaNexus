package com.example.ide.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Nfc
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AppThemeMode

/**
 * شاشة المعاينة التفاعلية للتطبيق (Live Android Emulator Preview)
 * تحاكي تشغيل تطبيق الأندرويد الذي تم بناؤه داخل إطار هاتف واقعي مع دعم فوري لمعاينة واجهات OLED
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DevicePreviewView(
    onClose: () -> Unit,
    themeMode: AppThemeMode = AppThemeMode.DARK,
    isDark: Boolean = true,
    modifier: Modifier = Modifier
) {
    var clickCount by remember { mutableIntStateOf(0) }
    var selectedScreen by remember { mutableStateOf("default") }

    val effectiveMode = if (themeMode != AppThemeMode.DARK) themeMode else if (isDark) AppThemeMode.DARK else AppThemeMode.LIGHT

    val bg = when (effectiveMode) {
        AppThemeMode.OLED -> Color(0xFF000000)
        AppThemeMode.DARK -> Color(0xFF1E1F22)
        AppThemeMode.LIGHT -> Color(0xFFFFFFFF)
    }
    val headerText = if (effectiveMode == AppThemeMode.LIGHT) Color(0xFF1F2328) else Color(0xFFDFE1E5)
    val closeIconTint = if (effectiveMode == AppThemeMode.LIGHT) Color(0xFF656D76) else Color(0xFF8C9298)

    val phoneFrameBg = when (effectiveMode) {
        AppThemeMode.OLED -> Color(0xFF000000)
        AppThemeMode.DARK -> Color(0xFF0F1012)
        AppThemeMode.LIGHT -> Color(0xFF1E2024)
    }
    val phoneFrameBorder = when (effectiveMode) {
        AppThemeMode.OLED -> Color(0xFF00F0FF)
        AppThemeMode.DARK -> Color(0xFF35373C)
        AppThemeMode.LIGHT -> Color(0xFF8C95A0)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(bg)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // شريط رأس نافذة المحاكي
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "محاكي المعاينة المباشرة (Pixel 8 OLED)",
                color = headerText,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.weight(1f))
            IconButton(onClick = { clickCount = 0 }) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "إعادة ضبط",
                    tint = if (effectiveMode == AppThemeMode.OLED) Color(0xFF00F0FF) else if (isDark) Color(0xFF3574F0) else Color(0xFF0969DA)
                )
            }
            IconButton(onClick = onClose) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إغلاق",
                    tint = closeIconTint
                )
            }
        }

        // شريط اختيار شاشة المعاينة الحية
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ScreenTabChip("default", "العداد القياسي", Icons.Default.TouchApp, selectedScreen) { selectedScreen = it }
            ScreenTabChip("cyber", "⚡ سايبربنك OLED", Icons.Default.Bolt, selectedScreen) { selectedScreen = it }
            ScreenTabChip("music", "🎵 مشغل AMOLED", Icons.Default.GraphicEq, selectedScreen) { selectedScreen = it }
            ScreenTabChip("crypto", "💳 بطاقة كريبتو", Icons.Default.CreditCard, selectedScreen) { selectedScreen = it }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // هيكل الهاتف الافتراضي (Phone Mockup Frame)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(0.94f)
                .clip(RoundedCornerShape(32.dp))
                .background(phoneFrameBg)
                .border(2.5.dp, phoneFrameBorder, RoundedCornerShape(32.dp))
                .padding(6.dp),
            contentAlignment = Alignment.Center
        ) {
            // شاشة الهاتف الداخلية
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(26.dp))
                    .background(if (selectedScreen == "default") Color.White else Color(0xFF000000))
            ) {
                // شريط حالة الهاتف (Status Bar)
                val statusBg = if (selectedScreen == "default") Color(0xFFF2F4F7) else Color(0xFF050506)
                val statusContentColor = if (selectedScreen == "default") Color.Black else Color.White

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(statusBg)
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "12:30",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = statusContentColor
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    // الكاميرا الأمامية
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color.Black)
                            .border(0.5.dp, Color(0xFF222222), CircleShape)
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Icon(
                        imageVector = Icons.Default.Wifi,
                        contentDescription = null,
                        tint = statusContentColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.BatteryFull,
                        contentDescription = null,
                        tint = statusContentColor,
                        modifier = Modifier.size(14.dp)
                    )
                }

                // محتوى التطبيق التفاعلي المختار
                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    when (selectedScreen) {
                        "cyber" -> OledCyberPreview()
                        "music" -> OledMusicPreview()
                        "crypto" -> OledCryptoPreview()
                        else -> DefaultCounterPreview(clickCount, onIncrement = { clickCount++ }, onReset = { clickCount = 0 })
                    }
                }

                // شريط التنقل السفلي للهاتف (Navigation Gesture Bar)
                val navBarBg = if (selectedScreen == "default") Color.White else Color(0xFF000000)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(18.dp)
                        .background(navBarBg),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(72.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (selectedScreen == "default") Color(0xFF94A3B8) else Color(0xFF333333))
                    )
                }
            }
        }
    }
}

@Composable
private fun ScreenTabChip(
    id: String,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selectedId: String,
    onSelect: (String) -> Unit
) {
    val isSelected = id == selectedId
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (isSelected) Color(0xFF00F0FF).copy(alpha = 0.2f) else Color(0xFF14171C))
            .border(
                1.dp,
                if (isSelected) Color(0xFF00F0FF) else Color(0xFF282C34),
                RoundedCornerShape(14.dp)
            )
            .clickable { onSelect(id) }
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isSelected) Color(0xFF00F0FF) else Color(0xFF8B949E),
            modifier = Modifier.size(14.dp)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) Color.White else Color(0xFF8B949E)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DefaultCounterPreview(
    clickCount: Int,
    onIncrement: () -> Unit,
    onReset: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("MyFirstApp", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White) },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF3574F0))
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F4FF)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("مرحباً بك في تطبيقي الأول!", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B), textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("تم البناء بنجاح عبر DroidIDE مع بيئة Compose", fontSize = 11.sp, color = Color(0xFF64748B), textAlign = TextAlign.Center)
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
            Text("عدد النقرات: $clickCount", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color(0xFF3574F0))
            Spacer(modifier = Modifier.height(18.dp))
            Button(
                onClick = onIncrement,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3574F0)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().height(46.dp).testTag("preview_tap_counter_btn")
            ) {
                Text("اضغط هنا للزيادة (+1)", fontSize = 14.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedButton(onClick = onReset, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth()) {
                Text("تصفير العداد", color = Color(0xFF64748B))
            }
        }
    }
}

@Composable
private fun OledCyberPreview() {
    var boostActive by remember { mutableStateOf(false) }
    var shieldActive by remember { mutableStateOf(true) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .padding(14.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF0D1117))
                    .border(1.5.dp, Color(0xFF00F0FF).copy(alpha = glowAlpha), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Bolt, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text("CYBER CORE OS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                Text("OLED ENGINE • ACTIVE", color = Color(0xFF00FF9D), fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            }
            Spacer(modifier = Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color(0xFF00FF9D).copy(alpha = 0.15f))
                    .border(1.dp, Color(0xFF00FF9D), CircleShape)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text("120 FPS", color = Color(0xFF00FF9D), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0A0C10))
                .border(1.5.dp, Brush.horizontalGradient(listOf(Color(0xFF00F0FF), Color(0xFFBD00FF), Color(0xFFFF007F))), RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("محرك الطاقة الهجين", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.weight(1f))
                    Icon(Icons.Default.Memory, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("GPU", color = Color(0xFF6E7681), fontSize = 9.sp); Text("3.2 GHz", color = Color(0xFF00F0FF), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    Column { Text("RAM", color = Color(0xFF6E7681), fontSize = 9.sp); Text("4.1 GB", color = Color(0xFF00FF9D), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    Column { Text("TEMP", color = Color(0xFF6E7681), fontSize = 9.sp); Text("34°C", color = Color(0xFFFF007F), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = { boostActive = !boostActive },
                    colors = ButtonDefaults.buttonColors(containerColor = if (boostActive) Color(0xFF00F0FF) else Color(0xFF141923)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(40.dp)
                ) {
                    Text(if (boostActive) "⚡ Turbo مفعّل" else "تفعيل الوضع الخارق", color = if (boostActive) Color.Black else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF0A0C10))
                .border(1.dp, Color(0xFF1B2230), RoundedCornerShape(12.dp))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF00FF9D), modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("درع التشفير الفائق", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("تأمين بكسلات العرض", color = Color(0xFF8B949E), fontSize = 10.sp)
            }
            Switch(
                checked = shieldActive,
                onCheckedChange = { shieldActive = it },
                colors = SwitchDefaults.colors(checkedThumbColor = Color.Black, checkedTrackColor = Color(0xFF00FF9D))
            )
        }
    }
}

@Composable
private fun OledMusicPreview() {
    var isPlaying by remember { mutableStateOf(true) }
    var progress by remember { mutableFloatStateOf(0.45f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("AMOLED AUDIO ENGINE", color = Color(0xFF8B949E), fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(16.dp))
        Box(
            modifier = Modifier
                .size(160.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(Color(0xFF08090C))
                .border(2.dp, Brush.sweepGradient(listOf(Color(0xFF00F0FF), Color(0xFFBD00FF), Color(0xFFFF007F), Color(0xFF00F0FF))), RoundedCornerShape(26.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Color(0xFFFF007F), modifier = Modifier.size(60.dp))
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text("Cyberpunk Resonance", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Text("Neon Synth • 96kHz Lossless", color = Color(0xFF00F0FF), fontSize = 11.sp)
        Spacer(modifier = Modifier.height(14.dp))
        Slider(
            value = progress,
            onValueChange = { progress = it },
            colors = SliderDefaults.colors(thumbColor = Color(0xFF00F0FF), activeTrackColor = Color(0xFF00F0FF), inactiveTrackColor = Color(0xFF1E222B)),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(14.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {}) { Icon(Icons.Default.SkipPrevious, contentDescription = null, tint = Color.White) }
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color(0xFFFF007F), Color(0xFFBD00FF))))
                    .clickable { isPlaying = !isPlaying },
                contentAlignment = Alignment.Center
            ) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
            }
            IconButton(onClick = {}) { Icon(Icons.Default.SkipNext, contentDescription = null, tint = Color.White) }
        }
    }
}

@Composable
private fun OledCryptoPreview() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF000000))
            .padding(14.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("الرصيد المحمي", color = Color(0xFF8B949E), fontSize = 10.sp)
                Text("$48,290.50", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            }
            Box(
                modifier = Modifier.clip(CircleShape).background(Color(0xFF00FF9D).copy(alpha = 0.15f)).padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text("+14.8%", color = Color(0xFF00FF9D), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFF0A0C10))
                .border(1.5.dp, Brush.linearGradient(listOf(Color(0xFF00F0FF), Color(0xFF00FF9D))), RoundedCornerShape(18.dp))
                .padding(14.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("BLACK VAULT", color = Color(0xFF00F0FF), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    Icon(Icons.Default.Nfc, contentDescription = null, tint = Color(0xFF00FF9D), modifier = Modifier.size(18.dp))
                }
                Text("•••• •••• •••• 8842", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, letterSpacing = 2.sp)
                Text("EXP: 12/30", color = Color.White, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
