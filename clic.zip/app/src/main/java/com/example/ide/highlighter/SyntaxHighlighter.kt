package com.example.ide.highlighter

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import com.example.ide.model.FileType
import java.util.regex.Pattern

/**
 * ألوان تلوين الصياغة لكلا الوضعين الداكن (Darcula) والنهاري (IntelliJ Light)
 */
data class SyntaxPalette(
    val keyword: Color,
    val stringLiteral: Color,
    val number: Color,
    val comment: Color,
    val annotation: Color,
    val function: Color,
    val typeName: Color,
    val xmlTag: Color,
    val xmlAttribute: Color,
    val punctuation: Color
)

object SyntaxThemes {
    val Dark = SyntaxPalette(
        keyword = Color(0xFFCC7832),       // برتقالي دافئ
        stringLiteral = Color(0xFF6A8759), // أخضر هادئ
        number = Color(0xFF6897BB),        // أزرق سماوي
        comment = Color(0xFF808080),       // رمادي فاتح مائل
        annotation = Color(0xFFBBB529),    // أصفر خردلي
        function = Color(0xFFFFC66D),      // أصفر برتقالي
        typeName = Color(0xFF4EC9B0),      // فيروزي
        xmlTag = Color(0xFFE8BF6A),        // أصفر للوسوم
        xmlAttribute = Color(0xFF9876AA),  // بنفسجي للخصائص
        punctuation = Color(0xFFA9B7C6)
    )

    val Light = SyntaxPalette(
        keyword = Color(0xFF0033B3),       // أزرق ناصع كلاسيكي في استوديو
        stringLiteral = Color(0xFF067D17), // أخضر غامق ناصع للنصوص
        number = Color(0xFF1750EB),        // أزرق ملكي للأرقام
        comment = Color(0xFF8C8C8C),       // رمادي هادئ ومائل للتعليقات
        annotation = Color(0xFF9E880D),    // ذهبي زيتي للوسوم
        function = Color(0xFF00627A),      // تيل غامق للدوال
        typeName = Color(0xFF267F99),      // فيروزي أنيق للأنواع
        xmlTag = Color(0xFF0033B3),        // أزرق للوسوم
        xmlAttribute = Color(0xFF7E009B),  // بنفسجي جذاب للخصائص
        punctuation = Color(0xFF1F2328)
    )

    val Oled = SyntaxPalette(
        keyword = Color(0xFFFF007F),       // نيون وردي حاد (Neon Magenta/Pink)
        stringLiteral = Color(0xFF00FF9D), // نيون ليموني ساطع (Neon Mint)
        number = Color(0xFF00F0FF),        // نيون سماوي كهربائي (Electric Cyan)
        comment = Color(0xFF6272A4),       // بنفسجي رمادي خافت
        annotation = Color(0xFFFFE600),    // أصفر نيون (Neon Yellow)
        function = Color(0xFFBD00FF),      // بنفسجي كهربائي مشع (Electric Purple)
        typeName = Color(0xFF00E5FF),      // أزرق فيروزي نيون
        xmlTag = Color(0xFFFF007F),        // نيون وردي
        xmlAttribute = Color(0xFF00F0FF),  // نيون سماوي للخصائص
        punctuation = Color(0xFFFFFFFF)    // أبيض ساطع عالي التباين
    )
}

/**
 * محرك التلوين النحوي (Syntax Highlighter)
 * يقوم بتحليل الكود المكتوب وتحويله إلى نصوص ملونة بنمط AnnotatedString بناءً على الوضع المختار
 */
class SyntaxVisualTransformation(
    private val fileType: FileType,
    private val themeMode: com.example.ui.theme.AppThemeMode = com.example.ui.theme.AppThemeMode.DARK
) : VisualTransformation {

    // منشئ بديل للتوافق مع استدعاءات isDark: Boolean السابقة
    constructor(fileType: FileType, isDark: Boolean) : this(
        fileType = fileType,
        themeMode = if (isDark) com.example.ui.theme.AppThemeMode.DARK else com.example.ui.theme.AppThemeMode.LIGHT
    )

    override fun filter(text: AnnotatedString): TransformedText {
        val palette = when (themeMode) {
            com.example.ui.theme.AppThemeMode.DARK -> SyntaxThemes.Dark
            com.example.ui.theme.AppThemeMode.LIGHT -> SyntaxThemes.Light
            com.example.ui.theme.AppThemeMode.OLED -> SyntaxThemes.Oled
        }
        val highlighted = highlightCode(text.text, fileType, palette)
        return TransformedText(highlighted, OffsetMapping.Identity)
    }

    companion object {
        // أنماط الكلمات المفتاحية للغة كوتلن
        private val KOTLIN_KEYWORDS = listOf(
            "package", "import", "class", "interface", "object", "val", "var", "fun",
            "return", "if", "else", "when", "for", "while", "do", "break", "continue",
            "try", "catch", "finally", "throw", "null", "true", "false", "this", "super",
            "is", "as", "in", "out", "public", "private", "protected", "internal",
            "override", "abstract", "final", "open", "data", "sealed", "enum", "companion",
            "suspend", "inline", "tailrec", "operator", "infix", "const", "lateinit",
            "by", "where", "constructor", "init", "get", "set"
        )

        // أنماط الكلمات المفتاحية للغة جافا
        private val JAVA_KEYWORDS = listOf(
            "package", "import", "public", "private", "protected", "class", "interface",
            "extends", "implements", "static", "final", "void", "return", "if", "else",
            "for", "while", "do", "break", "continue", "switch", "case", "default",
            "try", "catch", "finally", "throw", "throws", "new", "this", "super",
            "instanceof", "null", "true", "false", "abstract", "synchronized", "volatile",
            "transient", "native", "strictfp", "assert"
        )

        private val PRIMITIVE_TYPES = listOf(
            "int", "long", "float", "double", "boolean", "byte", "char", "short",
            "String", "Int", "Long", "Float", "Double", "Boolean", "Char", "Byte",
            "Unit", "Any", "Nothing", "List", "Map", "Set", "Array"
        )

        private val KOTLIN_KEYWORD_PATTERN = Pattern.compile("\\b(${KOTLIN_KEYWORDS.joinToString("|")})\\b")
        private val JAVA_KEYWORD_PATTERN = Pattern.compile("\\b(${JAVA_KEYWORDS.joinToString("|")})\\b")
        private val TYPE_PATTERN = Pattern.compile("\\b(${PRIMITIVE_TYPES.joinToString("|")})\\b")
        private val NUMBER_PATTERN = Pattern.compile("\\b(0x[0-9a-fA-F]+|[0-9]+(\\.[0-9]+)?[fFL]?)\\b")
        private val STRING_PATTERN = Pattern.compile("\"(\\\\.|[^\"])*\"|'(\\\\.|[^'])*'")
        private val LINE_COMMENT_PATTERN = Pattern.compile("//.*")
        private val BLOCK_COMMENT_PATTERN = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL)
        private val ANNOTATION_PATTERN = Pattern.compile("@[a-zA-Z0-9_]+")
        private val FUNCTION_CALL_PATTERN = Pattern.compile("\\b([a-zA-Z0-9_]+)(?=\\s*\\()")

        // أنماط XML
        private val XML_COMMENT_PATTERN = Pattern.compile("<!--.*?-->", Pattern.DOTALL)
        private val XML_TAG_PATTERN = Pattern.compile("</?[a-zA-Z0-9_:-]+|/?>")
        private val XML_ATTR_NAME_PATTERN = Pattern.compile("\\b([a-zA-Z0-9_:-]+)(?=\\s*=)")
        private val XML_ATTR_VAL_PATTERN = Pattern.compile("\"[^\"]*\"|'[^']*'")

        fun highlightCode(code: String, fileType: FileType, palette: SyntaxPalette = SyntaxThemes.Dark): AnnotatedString {
            return buildAnnotatedString {
                append(code)

                when (fileType) {
                    FileType.KOTLIN, FileType.GRADLE -> highlightKotlin(code, this, palette)
                    FileType.JAVA -> highlightJava(code, this, palette)
                    FileType.XML -> highlightXml(code, this, palette)
                    FileType.JSON -> highlightJson(code, this, palette)
                    else -> highlightGeneral(code, this, palette)
                }
            }
        }

        private fun highlightKotlin(code: String, builder: AnnotatedString.Builder, palette: SyntaxPalette) {
            applyRegex(code, KOTLIN_KEYWORD_PATTERN, builder, SpanStyle(color = palette.keyword, fontWeight = FontWeight.Bold))
            applyRegex(code, TYPE_PATTERN, builder, SpanStyle(color = palette.typeName, fontWeight = FontWeight.Medium))
            applyRegex(code, FUNCTION_CALL_PATTERN, builder, SpanStyle(color = palette.function))
            applyRegex(code, NUMBER_PATTERN, builder, SpanStyle(color = palette.number))
            applyRegex(code, ANNOTATION_PATTERN, builder, SpanStyle(color = palette.annotation, fontWeight = FontWeight.SemiBold))
            applyRegex(code, STRING_PATTERN, builder, SpanStyle(color = palette.stringLiteral))
            applyRegex(code, BLOCK_COMMENT_PATTERN, builder, SpanStyle(color = palette.comment, fontStyle = FontStyle.Italic))
            applyRegex(code, LINE_COMMENT_PATTERN, builder, SpanStyle(color = palette.comment, fontStyle = FontStyle.Italic))
        }

        private fun highlightJava(code: String, builder: AnnotatedString.Builder, palette: SyntaxPalette) {
            applyRegex(code, JAVA_KEYWORD_PATTERN, builder, SpanStyle(color = palette.keyword, fontWeight = FontWeight.Bold))
            applyRegex(code, TYPE_PATTERN, builder, SpanStyle(color = palette.typeName, fontWeight = FontWeight.Medium))
            applyRegex(code, FUNCTION_CALL_PATTERN, builder, SpanStyle(color = palette.function))
            applyRegex(code, NUMBER_PATTERN, builder, SpanStyle(color = palette.number))
            applyRegex(code, ANNOTATION_PATTERN, builder, SpanStyle(color = palette.annotation, fontWeight = FontWeight.SemiBold))
            applyRegex(code, STRING_PATTERN, builder, SpanStyle(color = palette.stringLiteral))
            applyRegex(code, BLOCK_COMMENT_PATTERN, builder, SpanStyle(color = palette.comment, fontStyle = FontStyle.Italic))
            applyRegex(code, LINE_COMMENT_PATTERN, builder, SpanStyle(color = palette.comment, fontStyle = FontStyle.Italic))
        }

        private fun highlightXml(code: String, builder: AnnotatedString.Builder, palette: SyntaxPalette) {
            applyRegex(code, XML_TAG_PATTERN, builder, SpanStyle(color = palette.xmlTag, fontWeight = FontWeight.Bold))
            applyRegex(code, XML_ATTR_NAME_PATTERN, builder, SpanStyle(color = palette.xmlAttribute, fontWeight = FontWeight.Medium))
            applyRegex(code, XML_ATTR_VAL_PATTERN, builder, SpanStyle(color = palette.stringLiteral))
            applyRegex(code, XML_COMMENT_PATTERN, builder, SpanStyle(color = palette.comment, fontStyle = FontStyle.Italic))
        }

        private fun highlightJson(code: String, builder: AnnotatedString.Builder, palette: SyntaxPalette) {
            applyRegex(code, STRING_PATTERN, builder, SpanStyle(color = palette.stringLiteral))
            applyRegex(code, NUMBER_PATTERN, builder, SpanStyle(color = palette.number))
        }

        private fun highlightGeneral(code: String, builder: AnnotatedString.Builder, palette: SyntaxPalette) {
            applyRegex(code, STRING_PATTERN, builder, SpanStyle(color = palette.stringLiteral))
            applyRegex(code, NUMBER_PATTERN, builder, SpanStyle(color = palette.number))
            applyRegex(code, LINE_COMMENT_PATTERN, builder, SpanStyle(color = palette.comment, fontStyle = FontStyle.Italic))
        }

        private fun applyRegex(
            text: String,
            pattern: Pattern,
            builder: AnnotatedString.Builder,
            style: SpanStyle
        ) {
            val matcher = pattern.matcher(text)
            while (matcher.find()) {
                val start = matcher.start()
                val end = matcher.end()
                if (start in text.indices && end <= text.length) {
                    builder.addStyle(style, start, end)
                }
            }
        }
    }
}
