package com.example.ide.ui

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ide.model.BuildLog
import com.example.ide.model.BuildStatus
import com.example.ide.model.LogType

/**
 * لوحة مخرجات البناء و Gradle Console
 * تعرض مهام البناء والنتائج وتتيح معاينة التطبيق وتصدير ملف الـ APK
 */
@Composable
fun BuildConsoleView(
    buildStatus: BuildStatus,
    buildLogs: List<BuildLog>,
    onRunBuild: () -> Unit,
    onCancelBuild: () -> Unit,
    onOpenPreview: () -> Unit,
    onCloseConsole: () -> Unit,
    isDark: Boolean = true,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val listState = rememberLazyListState()

    val consoleBg = if (isDark) Color(0xFF141416) else Color(0xFFF6F8FA)
    val headerBg = if (isDark) Color(0xFF1E1F22) else Color(0xFFEAECF0)
    val headerText = if (isDark) Color(0xFFDFE1E5) else Color(0xFF1F2328)

    // تمرير تلقائي لأسفل السجل عند ظهور أسطر جديدة
    LaunchedEffect(buildLogs.size) {
        if (buildLogs.isNotEmpty()) {
            listState.animateScrollToItem(buildLogs.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(consoleBg)
    ) {
        // شريط عنوان الكونسول
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(headerBg)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Gradle Build Console",
                color = headerText,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.width(12.dp))

            when (buildStatus) {
                is BuildStatus.Building -> {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = Color(0xFF3574F0),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = buildStatus.currentTask,
                        color = Color(0xFF8C9298),
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }
                is BuildStatus.Success -> {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF36B86C),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "ناجح (${String.format("%.1f", buildStatus.durationSeconds)}s)",
                        color = Color(0xFF36B86C),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                is BuildStatus.Failed -> {
                    Icon(
                        imageVector = Icons.Default.Error,
                        contentDescription = null,
                        tint = Color(0xFFF75464),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "فشل البناء",
                        color = Color(0xFFF75464),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                BuildStatus.Idle -> {}
            }

            Spacer(modifier = Modifier.weight(1f))

            if (buildStatus is BuildStatus.Building) {
                IconButton(onClick = onCancelBuild, modifier = Modifier.size(26.dp)) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "إيقاف",
                        tint = Color(0xFFF75464),
                        modifier = Modifier.size(18.dp)
                    )
                }
            } else {
                IconButton(onClick = onRunBuild, modifier = Modifier.size(26.dp).testTag("btn_rebuild")) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "إعادة البناء",
                        tint = Color(0xFF36B86C),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            IconButton(onClick = onCloseConsole, modifier = Modifier.size(26.dp)) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إغلاق",
                    tint = Color(0xFF8C9298),
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // شريط تقدم البناء
        if (buildStatus is BuildStatus.Building) {
            LinearProgressIndicator(
                progress = { buildStatus.progress },
                modifier = Modifier.fillMaxWidth().height(3.dp),
                color = Color(0xFF3574F0),
                trackColor = Color(0xFF2B2D30)
            )
        }

        // منطقة سجل الأسطر (Terminal Output)
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (buildLogs.isEmpty()) {
                item {
                    Text(
                        text = "> جاهز لبناء المشروع. اضغط زر التشغيل (Run) لتجميع ملف الـ APK.",
                        color = if (isDark) Color(0xFF6E747A) else Color(0xFF656D76),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            } else {
                items(buildLogs) { log ->
                    LogItemView(log = log, isDark = isDark)
                }
            }
        }

        // شريط الإجراءات بعد اكتمال البناء بنجاح
        if (buildStatus is BuildStatus.Success) {
            Surface(
                color = if (isDark) Color(0xFF1E1F22) else Color(0xFFEAECF0),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onOpenPreview,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF36B86C)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).testTag("btn_open_app_preview")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Smartphone,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تشغيل في المحاكي")
                    }

                    val exportTint = if (isDark) Color(0xFF56A8F5) else Color(0xFF0969DA)
                    OutlinedButton(
                        onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/vnd.android.package-archive"
                                putExtra(Intent.EXTRA_SUBJECT, "MyFirstApp-debug.apk")
                                putExtra(Intent.EXTRA_TEXT, "تم بناء ملف APK بنجاح بواسطة DroidIDE!")
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "مشاركة ملف APK"))
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = null,
                            tint = exportTint,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("تصدير APK", color = exportTint)
                    }
                }
            }
        }
    }
}

@Composable
private fun LogItemView(log: BuildLog, isDark: Boolean = true) {
    val (color, prefix) = when (log.type) {
        LogType.TASK -> Pair(if (isDark) Color(0xFF56A8F5) else Color(0xFF0969DA), "")
        LogType.SUCCESS -> Pair(if (isDark) Color(0xFF36B86C) else Color(0xFF1A7F37), "✔ ")
        LogType.WARNING -> Pair(if (isDark) Color(0xFFF2C55C) else Color(0xFF9A6700), "⚠ ")
        LogType.ERROR -> Pair(if (isDark) Color(0xFFF75464) else Color(0xFFCF222E), "✖ ")
        LogType.INFO -> Pair(if (isDark) Color(0xFFA9B7C6) else Color(0xFF24292F), "")
    }

    Text(
        text = prefix + log.text,
        color = color,
        fontSize = 12.sp,
        fontFamily = FontFamily.Monospace,
        lineHeight = 18.sp
    )
}
