package com.example.ide.model

/**
 * بيانات قوالب واجهات Jetpack Compose المعدة خصيصاً لشاشات OLED بنمط أسود مطلق ولمسات نيون متوهجة
 */
data class OledTemplate(
    val id: String,
    val title: String,
    val description: String,
    val fileName: String,
    val code: String
)

object OledTemplatesCatalog {

    val CYBER_DASHBOARD = OledTemplate(
        id = "cyber_dashboard",
        title = "لوحة تحكم سايبربنك (Cyber OLED Dashboard)",
        description = "واجهة تحكم فائقة الجمالية بخلفية سوداء نقية 0% إضاءة مع بطاقات زجاجية ولمسات نيون سداسية ومؤشرات حيوية",
        fileName = "OledCyberDashboard.kt",
        code = """package com.example.myapp

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ألوان نيون ساطعة فائقة التباين لشاشات OLED
private val NeonCyan = Color(0xFF00F0FF)
private val NeonMint = Color(0xFF00FF9D)
private val NeonPink = Color(0xFFFF007F)
private val NeonPurple = Color(0xFFBD00FF)
private val PureBlack = Color(0xFF000000)
private val DarkSurface = Color(0xFF0A0C10)
private val NeonBorder = Color(0xFF1B2230)

@Composable
fun OledCyberDashboard() {
    var boostActive by remember { mutableStateOf(false) }
    var securityShield by remember { mutableStateOf(true) }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowAlpha"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(16.dp)
    ) {
        // ترويسة الواجهة
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0D1117))
                    .border(1.5.dp, NeonCyan.copy(alpha = glowAlpha), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Bolt, contentDescription = null, tint = NeonCyan)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = "CYBER CORE OS",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "OLED DISPLAY ENGINE • ACTIVE",
                    color = NeonMint,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(NeonMint.copy(alpha = 0.15f))
                    .border(1.dp, NeonMint, CircleShape)
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text("99.8% FPS", color = NeonMint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // بطاقة المعالجة الرئيسية بتدرج نيون متوهج
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(DarkSurface)
                .border(
                    width = 1.5.dp,
                    brush = Brush.horizontalGradient(listOf(NeonCyan, NeonPurple, NeonPink)),
                    shape = RoundedCornerShape(20.dp)
                )
                .padding(20.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "محرك الطاقة الهجين",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricItem("GPU FREQ", "3.2 GHz", NeonCyan)
                    MetricItem("RAM USE", "4.1 / 12 GB", NeonMint)
                    MetricItem("TEMP", "36°C", NeonPink)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { boostActive = !boostActive },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (boostActive) NeonCyan else Color(0xFF141923)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .border(
                            1.dp,
                            if (boostActive) NeonCyan else NeonBorder,
                            RoundedCornerShape(12.dp)
                        )
                ) {
                    Text(
                        text = if (boostActive) "⚡ وضع التعزيز فائق السرعة مفعّل" else "تفعيل الوضع الخارق (Turbo Boost)",
                        color = if (boostActive) Color.Black else Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = "الوحدات النشطة (SYSTEM MODULES)",
            color = Color(0xFF8B949E),
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )

        Spacer(modifier = Modifier.height(10.dp))

        // قائمة الوحدات والبطاقات السريعة
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                ModuleCard(
                    title = "درع الأمان التشفيري (Shield)",
                    subtitle = if (securityShield) "التشفير التام AES-256 مفعّل" else "الدرع متوقف مؤقتاً",
                    icon = Icons.Default.Security,
                    color = NeonMint,
                    isEnabled = securityShield,
                    onToggle = { securityShield = !securityShield }
                )
            }
            item {
                ModuleCard(
                    title = "شبكة البيانات الفضائية (Starlink Sync)",
                    subtitle = "تزامن فوري بزمن استجابة 12ms",
                    icon = Icons.Default.Public,
                    color = NeonCyan,
                    isEnabled = true,
                    onToggle = {}
                )
            }
            item {
                ModuleCard(
                    title = "توفير بطارية OLED الحقيقي",
                    subtitle = "إيقاف تام لوحدات البكسل السوداء",
                    icon = Icons.Default.BatteryChargingFull,
                    color = NeonPink,
                    isEnabled = true,
                    onToggle = {}
                )
            }
        }
    }
}

@Composable
private fun MetricItem(label: String, value: String, accent: Color) {
    Column {
        Text(text = label, color = Color(0xFF6E7681), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, color = accent, fontSize = 15.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun ModuleCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    isEnabled: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkSurface)
            .border(1.dp, NeonBorder, RoundedCornerShape(14.dp))
            .clickable { onToggle() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(color.copy(alpha = 0.12f))
                .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, color = Color(0xFF8B949E), fontSize = 11.sp)
        }

        Switch(
            checked = isEnabled,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = color,
                uncheckedTrackColor = Color(0xFF161B22)
            )
        )
    }
}
""".trimIndent()
    )

    val MUSIC_PLAYER = OledTemplate(
        id = "music_player",
        title = "مشغل موسيقى AMOLED أسود نقي (OLED Music Wave)",
        description = "تصميم صوتي بنمط السواد التام لشاشات AMOLED مع تموج صوتي ملون وأزرار تحكم نيون تفاعلية",
        fileName = "OledMusicPlayer.kt",
        code = """package com.example.myapp

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val PureBlack = Color(0xFF000000)
private val NeonPink = Color(0xFFFF007F)
private val NeonPurple = Color(0xFFBD00FF)
private val NeonCyan = Color(0xFF00F0FF)

@Composable
fun OledMusicPlayer() {
    var isPlaying by remember { mutableStateOf(true) }
    var progress by remember { mutableFloatStateOf(0.42f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // شريط علوي
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {}) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, tint = Color.White)
            }
            Text(
                text = "جاري التشغيل (AMOLED AUDIO)",
                color = Color(0xFF8B949E),
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = {}) {
                Icon(Icons.Default.MoreVert, contentDescription = null, tint = Color.White)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // غلاف الألبوم مع وهج نيون دائري
        Box(
            modifier = Modifier
                .size(240.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(Color(0xFF08090C))
                .border(
                    width = 2.dp,
                    brush = Brush.sweepGradient(listOf(NeonCyan, NeonPurple, NeonPink, NeonCyan)),
                    shape = RoundedCornerShape(32.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.GraphicEq,
                contentDescription = null,
                tint = NeonPink,
                modifier = Modifier.size(90.dp)
            )
        }

        Spacer(modifier = Modifier.height(30.dp))

        // معلومات المقطع الصوتي
        Text(
            text = "Cyberpunk Resonance",
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Black
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Neon Synth Orchestra • 96kHz Lossless",
            color = NeonCyan,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )

        Spacer(modifier = Modifier.height(24.dp))

        // شريط التقدم الصوتي
        Slider(
            value = progress,
            onValueChange = { progress = it },
            colors = SliderDefaults.colors(
                thumbColor = NeonCyan,
                activeTrackColor = NeonCyan,
                inactiveTrackColor = Color(0xFF1E222B)
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("01:48", color = Color(0xFF6E7681), fontSize = 11.sp)
            Text("04:12", color = Color(0xFF6E7681), fontSize = 11.sp)
        }

        Spacer(modifier = Modifier.height(28.dp))

        // أزرار التحكم
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = {}) {
                Icon(Icons.Default.SkipPrevious, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
            }

            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(NeonPink, NeonPurple)))
                    .clickable { isPlaying = !isPlaying },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }

            IconButton(onClick = {}) {
                Icon(Icons.Default.SkipNext, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }
    }
}
""".trimIndent()
    )

    val CRYPTO_WALLET = OledTemplate(
        id = "crypto_wallet",
        title = "محفظة رقمية مستقبلية (OLED Crypto Card)",
        description = "واجهة محفظة ذكية ببطاقة ائتمانية رقمية ذات إطار نيون براق مع أزرار التحويل الفوري",
        fileName = "OledCryptoCard.kt",
        code = """package com.example.myapp

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val PureBlack = Color(0xFF000000)
private val NeonLime = Color(0xFF00FF9D)
private val NeonCyan = Color(0xFF00F0FF)

@Composable
fun OledCryptoCard() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("إجمالي الرصيد المحمي", color = Color(0xFF8B949E), fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text("$48,290.50", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
            }
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(NeonLime.copy(alpha = 0.15f))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text("+14.8% اليوم", color = NeonLime, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // بطاقة نيون ذكية
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF0A0C10))
                .border(
                    width = 2.dp,
                    brush = Brush.linearGradient(listOf(NeonCyan, NeonLime)),
                    shape = RoundedCornerShape(22.dp)
                )
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("BLACK VAULT CARD", color = NeonCyan, fontSize = 13.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                    Icon(Icons.Default.Nfc, contentDescription = null, tint = NeonLime)
                }

                Text(
                    text = "•••• •••• •••• 8842",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("CARDHOLDER: DEVELOPER", color = Color(0xFF8B949E), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Text("EXP: 12/30", color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = {},
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).height(48.dp)
            ) {
                Icon(Icons.Default.ArrowUpward, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(6.dp))
                Text("إرسال", color = Color.Black, fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = {},
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF141923)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.weight(1f).height(48.dp).border(1.dp, NeonLime, RoundedCornerShape(12.dp))
            ) {
                Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = NeonLime)
                Spacer(modifier = Modifier.width(6.dp))
                Text("استلام", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}
""".trimIndent()
    )

    val ALL_TEMPLATES = listOf(CYBER_DASHBOARD, MUSIC_PLAYER, CRYPTO_WALLET)
}
