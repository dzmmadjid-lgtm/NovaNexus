package com.example.ide.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ide.compiler.GradleSimulator
import com.example.ide.model.BuildLog
import com.example.ide.model.BuildStatus
import com.example.ide.model.CompilerMessage
import com.example.ide.model.DefaultProject
import com.example.ide.model.FileType
import com.example.ide.model.LogType
import com.example.ide.model.ProjectFile
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class ToolWindow {
    PROJECT,     // متصفح ملفات المشروع
    BUILD_LOGS,  // مخرجات بناء Gradle
    PREVIEW,     // شاشة معاينة التطبيق التفاعلية
    PROBLEMS,    // قائمة الأخطاء والتحذيرات النحوية
    NONE
}

/**
 * ViewModel الرئيسي لإدارة حالة المحرر ومشروع الأندرويد وعمليات البناء
 */
class IdeViewModel : ViewModel() {

    private val _projectTree = MutableStateFlow(DefaultProject.createSampleProject())
    val projectTree: StateFlow<ProjectFile> = _projectTree.asStateFlow()

    private val _openTabs = MutableStateFlow<List<ProjectFile>>(emptyList())
    val openTabs: StateFlow<List<ProjectFile>> = _openTabs.asStateFlow()

    private val _activeFileId = MutableStateFlow<String?>(null)
    val activeFileId: StateFlow<String?> = _activeFileId.asStateFlow()

    private val _activeFileContent = MutableStateFlow("")
    val activeFileContent: StateFlow<String> = _activeFileContent.asStateFlow()

    private val _cursorPosition = MutableStateFlow(Pair(1, 1)) // line, column
    val cursorPosition: StateFlow<Pair<Int, Int>> = _cursorPosition.asStateFlow()

    private val _buildStatus = MutableStateFlow<BuildStatus>(BuildStatus.Idle)
    val buildStatus: StateFlow<BuildStatus> = _buildStatus.asStateFlow()

    private val _buildLogs = MutableStateFlow<List<BuildLog>>(emptyList())
    val buildLogs: StateFlow<List<BuildLog>> = _buildLogs.asStateFlow()

    private val _problems = MutableStateFlow<List<CompilerMessage>>(emptyList())
    val problems: StateFlow<List<CompilerMessage>> = _problems.asStateFlow()

    private val _activeToolWindow = MutableStateFlow(ToolWindow.NONE)
    val activeToolWindow: StateFlow<ToolWindow> = _activeToolWindow.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isSearchVisible = MutableStateFlow(false)
    val isSearchVisible: StateFlow<Boolean> = _isSearchVisible.asStateFlow()

    // نمط الثيم: الداكن (افتراضي) مقابل النهاري والـ OLED فائق التباين
    private val _themeMode = MutableStateFlow(com.example.ui.theme.AppThemeMode.DARK)
    val themeMode: StateFlow<com.example.ui.theme.AppThemeMode> = _themeMode.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    fun cycleThemeMode() {
        val next = when (_themeMode.value) {
            com.example.ui.theme.AppThemeMode.DARK -> com.example.ui.theme.AppThemeMode.LIGHT
            com.example.ui.theme.AppThemeMode.LIGHT -> com.example.ui.theme.AppThemeMode.OLED
            com.example.ui.theme.AppThemeMode.OLED -> com.example.ui.theme.AppThemeMode.DARK
        }
        _themeMode.value = next
        _isDarkMode.value = (next != com.example.ui.theme.AppThemeMode.LIGHT)
    }

    fun setThemeMode(mode: com.example.ui.theme.AppThemeMode) {
        _themeMode.value = mode
        _isDarkMode.value = (mode != com.example.ui.theme.AppThemeMode.LIGHT)
    }

    fun toggleTheme() {
        cycleThemeMode()
    }

    // مكدس التراجع والإعادة (Undo/Redo Stack)
    private val undoStack = mutableListOf<String>()
    private val redoStack = mutableListOf<String>()
    private var buildJob: Job? = null

    init {
        // فتح ملف MainActivity.kt تلقائياً عند بدء التشغيل
        val initialFile = findFileByName(_projectTree.value, "MainActivity.kt")
        if (initialFile != null) {
            openFile(initialFile)
        }
    }

    private fun findFileByName(root: ProjectFile, name: String): ProjectFile? {
        if (!root.isDirectory && root.name == name) return root
        for (child in root.children) {
            val found = findFileByName(child, name)
            if (found != null) return found
        }
        return null
    }

    /**
     * فتح ملف في نافذة التبويب
     */
    fun openFile(file: ProjectFile) {
        if (file.isDirectory) return

        // حفظ التغييرات للملف السابق إن وجد
        saveCurrentFile()

        val currentTabs = _openTabs.value.toMutableList()
        val existing = currentTabs.find { it.id == file.id }

        if (existing == null) {
            currentTabs.add(file)
            _openTabs.value = currentTabs
        }

        _activeFileId.value = file.id
        _activeFileContent.value = file.content
        undoStack.clear()
        redoStack.clear()
        undoStack.add(file.content)
    }

    /**
     * إغلاق تبويب ملف مفتوح
     */
    fun closeTab(fileId: String) {
        val currentTabs = _openTabs.value.toMutableList()
        val index = currentTabs.indexOfFirst { it.id == fileId }
        if (index != -1) {
            currentTabs.removeAt(index)
            _openTabs.value = currentTabs

            if (_activeFileId.value == fileId) {
                if (currentTabs.isNotEmpty()) {
                    val nextFile = if (index < currentTabs.size) currentTabs[index] else currentTabs.last()
                    openFile(nextFile)
                } else {
                    _activeFileId.value = null
                    _activeFileContent.value = ""
                }
            }
        }
    }

    /**
     * تحديث محتوى الكود أثناء الكتابة
     */
    fun onContentChange(newContent: String) {
        if (newContent != _activeFileContent.value) {
            // حفظ الحالة السابقة للتراجع
            if (undoStack.isEmpty() || undoStack.last() != _activeFileContent.value) {
                undoStack.add(_activeFileContent.value)
                if (undoStack.size > 50) undoStack.removeAt(0)
            }
            redoStack.clear()

            _activeFileContent.value = newContent

            // تحديث الشجرة
            _activeFileId.value?.let { id ->
                _projectTree.value = _projectTree.value.updateContent(id, newContent)
                _openTabs.value = _openTabs.value.map {
                    if (it.id == id) it.copy(content = newContent, isModified = true) else it
                }
            }
        }
    }

    /**
     * تراجع عن التعديل الأخير (Undo)
     */
    fun undo() {
        if (undoStack.isNotEmpty()) {
            val previous = undoStack.removeAt(undoStack.lastIndex)
            redoStack.add(_activeFileContent.value)
            _activeFileContent.value = previous
            _activeFileId.value?.let { id ->
                _projectTree.value = _projectTree.value.updateContent(id, previous)
            }
        }
    }

    /**
     * إعادة التعديل (Redo)
     */
    fun redo() {
        if (redoStack.isNotEmpty()) {
            val next = redoStack.removeAt(redoStack.lastIndex)
            undoStack.add(_activeFileContent.value)
            _activeFileContent.value = next
            _activeFileId.value?.let { id ->
                _projectTree.value = _projectTree.value.updateContent(id, next)
            }
        }
    }

    /**
     * حفظ الملف الحالي
     */
    fun saveCurrentFile() {
        val currentId = _activeFileId.value ?: return
        val content = _activeFileContent.value
        _projectTree.value = _projectTree.value.updateContent(currentId, content)
        _openTabs.value = _openTabs.value.map {
            if (it.id == currentId) it.copy(content = content, isModified = false) else it
        }
    }

    /**
     * إدراج رمز أو مسافة بادئة (Tab) في موضع المؤشر
     */
    fun insertSnippet(snippet: String) {
        val current = _activeFileContent.value
        onContentChange(current + snippet)
    }

    /**
     * تحديث موضع المؤشر
     */
    fun updateCursor(line: Int, column: Int) {
        _cursorPosition.value = Pair(line, column)
    }

    /**
     * تبديل فتح/إغلاق مجلد في الشجرة
     */
    fun toggleFolder(folderId: String) {
        _projectTree.value = _projectTree.value.toggleExpanded(folderId)
    }

    /**
     * إنشاء ملف جديد داخل مجلد
     */
    fun createNewFile(parentId: String, fileName: String, isFolder: Boolean = false) {
        val newChild = ProjectFile(
            name = fileName,
            path = fileName,
            isDirectory = isFolder,
            content = if (isFolder) "" else getStarterTemplate(fileName)
        )
        _projectTree.value = _projectTree.value.addChild(parentId, newChild)
        if (!isFolder) {
            openFile(newChild)
        }
    }

    private fun getStarterTemplate(fileName: String): String {
        return when (FileType.fromFileName(fileName)) {
            FileType.KOTLIN -> "package com.example.myapp\n\nclass ${fileName.substringBefore(".")} {\n    // كود Kotlin هنا\n}\n"
            FileType.JAVA -> "package com.example.myapp;\n\npublic class ${fileName.substringBefore(".")} {\n    // كود Java هنا\n}\n"
            FileType.XML -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n    <!-- موارد XML -->\n</resources>\n"
            else -> "// ملف جديد: $fileName\n"
        }
    }

    /**
     * حذف ملف أو مجلد من المشروع
     */
    fun deleteNode(nodeId: String) {
        _projectTree.value = _projectTree.value.removeChild(nodeId)
        closeTab(nodeId)
    }

    /**
     * تشغيل عملية البناء باستخدام محاكي Gradle
     */
    fun runBuild() {
        saveCurrentFile()
        buildJob?.cancel()

        _buildLogs.value = emptyList()
        _activeToolWindow.value = ToolWindow.BUILD_LOGS

        buildJob = viewModelScope.launch {
            GradleSimulator.buildProjectFlow(_projectTree.value).collect { (status, log) ->
                _buildStatus.value = status
                _buildLogs.value = _buildLogs.value + log

                if (status is BuildStatus.Failed) {
                    _problems.value = status.errors
                } else if (status is BuildStatus.Success) {
                    _problems.value = emptyList()
                }
            }
        }
    }

    /**
     * إلغاء عملية البناء الجارية
     */
    fun cancelBuild() {
        buildJob?.cancel()
        _buildStatus.value = BuildStatus.Idle
        _buildLogs.value = _buildLogs.value + BuildLog(
            text = "Build canceled by user",
            type = LogType.WARNING
        )
    }

    /**
     * تبديل النافذة الفرعية النشطة (Tool Window)
     */
    fun toggleToolWindow(window: ToolWindow) {
        _activeToolWindow.value = if (_activeToolWindow.value == window) ToolWindow.NONE else window
    }

    fun setToolWindow(window: ToolWindow) {
        _activeToolWindow.value = window
    }

    fun toggleSearch() {
        _isSearchVisible.value = !_isSearchVisible.value
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    /**
     * تصدير كامل شجرة المشروع الحالي إلى ملف ZIP قياسي ومشاركته
     */
    fun exportProjectAsZip(context: android.content.Context) {
        saveCurrentFile()
        com.example.ide.util.ProjectZipHelper.exportProjectToZip(context, _projectTree.value)
    }

    /**
     * استيراد مشروع من ملف ZIP تم اختياره من الهاتف
     */
    fun importProjectFromZip(context: android.content.Context, uri: android.net.Uri): Boolean {
        saveCurrentFile()
        val importedRoot = com.example.ide.util.ProjectZipHelper.importProjectFromZip(context, uri)
        return if (importedRoot != null) {
            _projectTree.value = importedRoot
            _openTabs.value = emptyList()
            _activeFileId.value = null
            _activeFileContent.value = ""

            // البحث عن أول ملف قابل للفتح (مثل MainActivity.kt أو أي ملف كود)
            val firstFile = findFirstCodeFile(importedRoot)
            if (firstFile != null) {
                openFile(firstFile)
            }
            true
        } else {
            false
        }
    }

    private fun findFirstCodeFile(node: ProjectFile): ProjectFile? {
        if (!node.isDirectory) return node
        for (child in node.children) {
            val found = findFirstCodeFile(child)
            if (found != null) return found
        }
        return null
    }

    /**
     * إضافة قالب واجهة OLED إلى حزمة المشروع وفتحه مباشرة في المحرر
     */
    fun addOledTemplate(template: com.example.ide.model.OledTemplate) {
        saveCurrentFile()
        val templateFile = ProjectFile(
            name = template.fileName,
            path = "app/src/main/java/com/example/myapp/${template.fileName}",
            fileType = FileType.KOTLIN,
            content = template.code
        )

        // البحث عن مجلد myapp أو إضافته في الجذر
        val currentTree = _projectTree.value
        val myAppFolder = findFolderByName(currentTree, "myapp")

        val targetParentId = myAppFolder?.id ?: currentTree.id
        _projectTree.value = _projectTree.value.addChild(targetParentId, templateFile)

        // فتح الملف والقالب فوراً
        openFile(templateFile)

        // تحويل الثيم تلقائياً إلى OLED للتمتع بالجمالية الكاملة
        setThemeMode(com.example.ui.theme.AppThemeMode.OLED)
    }

    private fun findFolderByName(root: ProjectFile, name: String): ProjectFile? {
        if (root.isDirectory && root.name == name) return root
        for (child in root.children) {
            if (child.isDirectory) {
                val found = findFolderByName(child, name)
                if (found != null) return found
            }
        }
        return null
    }
}
