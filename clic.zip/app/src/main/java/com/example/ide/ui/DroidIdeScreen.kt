package com.example.ide.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ide.model.BuildStatus
import com.example.ide.model.ProjectFile
import com.example.ide.viewmodel.IdeViewModel
import com.example.ide.viewmodel.ToolWindow
import com.example.ui.theme.AppThemeMode

/**
 * الواجهة الرئيسية المتكاملة لبيئة التطوير DroidIDE
 * تشبه بيئة Android Studio بنسخة مصممة ومحسنة لشاشات الهواتف المحمولة مع دعم OLED وتصدير/استيراد ZIP
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DroidIdeScreen(
    viewModel: IdeViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val projectTree by viewModel.projectTree.collectAsState()
    val openTabs by viewModel.openTabs.collectAsState()
    val activeFileId by viewModel.activeFileId.collectAsState()
    val activeFileContent by viewModel.activeFileContent.collectAsState()
    val cursorPosition by viewModel.cursorPosition.collectAsState()
    val buildStatus by viewModel.buildStatus.collectAsState()
    val buildLogs by viewModel.buildLogs.collectAsState()
    val problems by viewModel.problems.collectAsState()
    val activeToolWindow by viewModel.activeToolWindow.collectAsState()
    val isSearchVisible by viewModel.isSearchVisible.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()

    val activeFile = openTabs.find { it.id == activeFileId }

    val scaffoldBg = when (themeMode) {
        AppThemeMode.OLED -> Color(0xFF000000)
        AppThemeMode.DARK -> Color(0xFF1E1F22)
        AppThemeMode.LIGHT -> Color(0xFFFFFFFF)
    }

    Scaffold(
        topBar = {
            IdeTopAppBar(
                buildStatus = buildStatus,
                themeMode = themeMode,
                isDark = isDarkMode,
                onRunBuild = { viewModel.runBuild() },
                onUndo = { viewModel.undo() },
                onRedo = { viewModel.redo() },
                onToggleSearch = { viewModel.toggleSearch() },
                onSave = { viewModel.saveCurrentFile() },
                onToggleTheme = { viewModel.cycleThemeMode() }
            )
        },
        bottomBar = {
            IdeBottomToolWindowsBar(
                activeWindow = activeToolWindow,
                problemsCount = problems.size,
                themeMode = themeMode,
                isDark = isDarkMode,
                onSelectWindow = { viewModel.toggleToolWindow(it) }
            )
        },
        containerColor = scaffoldBg,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // شريط تبويبات الملفات المفتوحة (Editor Tabs)
            if (openTabs.isNotEmpty()) {
                EditorTabBar(
                    tabs = openTabs,
                    activeFileId = activeFileId,
                    themeMode = themeMode,
                    isDark = isDarkMode,
                    onSelectTab = { viewModel.openFile(it) },
                    onCloseTab = { viewModel.closeTab(it) }
                )
            }

            // منطقة العمل الرئيسية: المحرر ونافذة الأدوات المفتوحة
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                // محرر الأكواد الرئيسي
                Column(modifier = Modifier.fillMaxSize()) {
                    EditorView(
                        activeFile = activeFile,
                        content = activeFileContent,
                        onContentChange = { viewModel.onContentChange(it) },
                        cursorPosition = cursorPosition,
                        onCursorChange = { line, col -> viewModel.updateCursor(line, col) },
                        isSearchVisible = isSearchVisible,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                        onCloseSearch = { viewModel.toggleSearch() },
                        themeMode = themeMode,
                        isDark = isDarkMode,
                        modifier = Modifier.weight(1f)
                    )

                    // شريط الرموز البرمجية السريعة فوق لوحة المفاتيح
                    if (activeFile != null) {
                        QuickKeysBar(
                            onInsert = { viewModel.insertSnippet(it) },
                            isDark = isDarkMode
                        )
                    }
                }

                // نافذة الأدوات المنبثقة السفلية (Tool Window Drawer)
                if (activeToolWindow != ToolWindow.NONE) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(if (activeToolWindow == ToolWindow.PROJECT) 0.85f else 0.78f)
                            .align(Alignment.BottomCenter)
                    ) {
                        when (activeToolWindow) {
                            ToolWindow.PROJECT -> {
                                FileExplorerView(
                                    projectTree = projectTree,
                                    activeFileId = activeFileId,
                                    isDark = isDarkMode,
                                    onFileClick = { file ->
                                        viewModel.openFile(file)
                                        viewModel.setToolWindow(ToolWindow.NONE)
                                    },
                                    onToggleFolder = { viewModel.toggleFolder(it) },
                                    onCreateNewFile = { parentId, name, isFolder ->
                                        viewModel.createNewFile(parentId, name, isFolder)
                                    },
                                    onDeleteNode = { viewModel.deleteNode(it) },
                                    onExportZip = { viewModel.exportProjectAsZip(context) },
                                    onImportZip = { uri -> viewModel.importProjectFromZip(context, uri) },
                                    onSelectOledTemplate = { template -> viewModel.addOledTemplate(template) }
                                )
                            }
                            ToolWindow.BUILD_LOGS -> {
                                BuildConsoleView(
                                    buildStatus = buildStatus,
                                    buildLogs = buildLogs,
                                    isDark = isDarkMode,
                                    onRunBuild = { viewModel.runBuild() },
                                    onCancelBuild = { viewModel.cancelBuild() },
                                    onOpenPreview = { viewModel.setToolWindow(ToolWindow.PREVIEW) },
                                    onCloseConsole = { viewModel.setToolWindow(ToolWindow.NONE) }
                                )
                            }
                            ToolWindow.PREVIEW -> {
                                DevicePreviewView(
                                    themeMode = themeMode,
                                    isDark = isDarkMode,
                                    onClose = { viewModel.setToolWindow(ToolWindow.NONE) }
                                )
                            }
                            ToolWindow.PROBLEMS -> {
                                ProblemsView(
                                    problems = problems,
                                    isDark = isDarkMode,
                                    onClose = { viewModel.setToolWindow(ToolWindow.NONE) }
                                )
                            }
                            ToolWindow.NONE -> {}
                        }
                    }
                }
            }
        }
    }
}

/**
 * شريط العنوان العلوي بنمط Android Studio
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IdeTopAppBar(
    buildStatus: BuildStatus,
    themeMode: AppThemeMode = AppThemeMode.DARK,
    isDark: Boolean = true,
    onRunBuild: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onToggleSearch: () -> Unit,
    onSave: () -> Unit,
    onToggleTheme: () -> Unit
) {
    val topBarBg = when (themeMode) {
        AppThemeMode.OLED -> Color(0xFF000000)
        AppThemeMode.DARK -> Color(0xFF1E1F22)
        AppThemeMode.LIGHT -> Color(0xFFF6F8FA)
    }
    val titleColor = when (themeMode) {
        AppThemeMode.OLED -> Color(0xFFFFFFFF)
        AppThemeMode.DARK -> Color(0xFFDFE1E5)
        AppThemeMode.LIGHT -> Color(0xFF1F2328)
    }
    val iconTint = when (themeMode) {
        AppThemeMode.OLED -> Color(0xFFFFFFFF)
        AppThemeMode.DARK -> Color(0xFFDFE1E5)
        AppThemeMode.LIGHT -> Color(0xFF424A53)
    }

    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // أيقونة DroidIDE المصغرة
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (themeMode == AppThemeMode.OLED) Color(0xFF00F0FF) else Color(0xFF3574F0)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Android,
                        contentDescription = null,
                        tint = if (themeMode == AppThemeMode.OLED) Color.Black else Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = "DroidIDE",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = titleColor
                    )
                    Text(
                        text = when (themeMode) {
                            AppThemeMode.OLED -> "app:oled-cyber"
                            AppThemeMode.DARK -> "app:debug"
                            AppThemeMode.LIGHT -> "app:light"
                        },
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = if (themeMode == AppThemeMode.OLED) Color(0xFF00FF9D) else Color(0xFF36B86C)
                    )
                }
            }
        },
        actions = {
            // زر تبديل أوضاع الثيم الثلاثية: داكن -> نهاري -> OLED
            IconButton(
                onClick = onToggleTheme,
                modifier = Modifier.size(32.dp).testTag("btn_toggle_theme")
            ) {
                when (themeMode) {
                    AppThemeMode.DARK -> {
                        Icon(
                            imageVector = Icons.Default.LightMode,
                            contentDescription = "التبديل إلى الوضع النهاري",
                            tint = Color(0xFFF2C55C),
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    AppThemeMode.LIGHT -> {
                        Icon(
                            imageVector = Icons.Default.DarkMode,
                            contentDescription = "التبديل إلى وضع OLED",
                            tint = Color(0xFFBD00FF),
                            modifier = Modifier.size(19.dp)
                        )
                    }
                    AppThemeMode.OLED -> {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "التبديل إلى الوضع الداكن",
                            tint = Color(0xFF00F0FF),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // زر التراجع
            IconButton(onClick = onUndo, modifier = Modifier.size(32.dp).testTag("btn_undo")) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Undo,
                    contentDescription = "تراجع",
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }

            // زر الإعادة
            IconButton(onClick = onRedo, modifier = Modifier.size(32.dp).testTag("btn_redo")) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Redo,
                    contentDescription = "إعادة",
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }

            // زر البحث
            IconButton(onClick = onToggleSearch, modifier = Modifier.size(32.dp).testTag("btn_search")) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "بحث",
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }

            // زر الحفظ
            IconButton(onClick = onSave, modifier = Modifier.size(32.dp).testTag("btn_save")) {
                Icon(
                    imageVector = Icons.Default.Save,
                    contentDescription = "حفظ",
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            // زر التشغيل الأخضر الأيقوني (Run Button)
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (themeMode == AppThemeMode.OLED) Color(0xFF00FF9D) else Color(0xFF36B86C))
                    .clickable(onClick = onRunBuild)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("btn_run_build"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (buildStatus is BuildStatus.Building) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            color = if (themeMode == AppThemeMode.OLED) Color.Black else Color.White,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "تشغيل",
                            tint = if (themeMode == AppThemeMode.OLED) Color.Black else Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Run",
                        color = if (themeMode == AppThemeMode.OLED) Color.Black else Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = topBarBg
        )
    )
}

/**
 * شريط التبويبات للملفات المفتوحة
 */
@Composable
private fun EditorTabBar(
    tabs: List<ProjectFile>,
    activeFileId: String?,
    themeMode: AppThemeMode = AppThemeMode.DARK,
    isDark: Boolean = true,
    onSelectTab: (ProjectFile) -> Unit,
    onCloseTab: (String) -> Unit
) {
    val barBg = when (themeMode) {
        AppThemeMode.OLED -> Color(0xFF07080A)
        AppThemeMode.DARK -> Color(0xFF2B2D30)
        AppThemeMode.LIGHT -> Color(0xFFEAECF0)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(36.dp)
            .background(barBg)
            .horizontalScroll(rememberScrollState()),
        verticalAlignment = Alignment.CenterVertically
    ) {
        tabs.forEach { file ->
            val isActive = file.id == activeFileId
            val tabBg = if (isActive) {
                when (themeMode) {
                    AppThemeMode.OLED -> Color(0xFF000000)
                    AppThemeMode.DARK -> Color(0xFF1E1F22)
                    AppThemeMode.LIGHT -> Color(0xFFFFFFFF)
                }
            } else {
                barBg
            }
            val textColor = if (isActive) {
                when (themeMode) {
                    AppThemeMode.OLED -> Color(0xFF00F0FF)
                    AppThemeMode.DARK -> Color(0xFF56A8F5)
                    AppThemeMode.LIGHT -> Color(0xFF0969DA)
                }
            } else {
                when (themeMode) {
                    AppThemeMode.OLED -> Color(0xFF6E7681)
                    AppThemeMode.DARK -> Color(0xFF8C9298)
                    AppThemeMode.LIGHT -> Color(0xFF656D76)
                }
            }
            val closeTint = if (isActive) {
                when (themeMode) {
                    AppThemeMode.OLED -> Color(0xFFFFFFFF)
                    AppThemeMode.DARK -> Color(0xFFDFE1E5)
                    AppThemeMode.LIGHT -> Color(0xFF1F2328)
                }
            } else {
                when (themeMode) {
                    AppThemeMode.OLED -> Color(0xFF6E7681)
                    AppThemeMode.DARK -> Color(0xFF6E747A)
                    AppThemeMode.LIGHT -> Color(0xFF8C95A0)
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxHeight()
                    .background(tabBg)
                    .clickable { onSelectTab(file) }
                    .padding(start = 12.dp, end = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = file.name + if (file.isModified) " *" else "",
                    color = textColor,
                    fontSize = 12.sp,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(6.dp))
                IconButton(
                    onClick = { onCloseTab(file.id) },
                    modifier = Modifier.size(18.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق التبويب",
                        tint = closeTint,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
        }
    }
}

/**
 * شريط أدوات النوافذ الفرعية أسفل الشاشة
 */
@Composable
private fun IdeBottomToolWindowsBar(
    activeWindow: ToolWindow,
    problemsCount: Int,
    themeMode: AppThemeMode = AppThemeMode.DARK,
    isDark: Boolean = true,
    onSelectWindow: (ToolWindow) -> Unit
) {
    val bottomBg = when (themeMode) {
        AppThemeMode.OLED -> Color(0xFF000000)
        AppThemeMode.DARK -> Color(0xFF2B2D30)
        AppThemeMode.LIGHT -> Color(0xFFF6F8FA)
    }

    Surface(
        color = bottomBg,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolWindowTabItem(
                label = "Project",
                icon = Icons.Default.Folder,
                isSelected = activeWindow == ToolWindow.PROJECT,
                themeMode = themeMode,
                isDark = isDark,
                onClick = { onSelectWindow(ToolWindow.PROJECT) }
            )

            ToolWindowTabItem(
                label = "Build Output",
                icon = Icons.Default.Terminal,
                isSelected = activeWindow == ToolWindow.BUILD_LOGS,
                themeMode = themeMode,
                isDark = isDark,
                onClick = { onSelectWindow(ToolWindow.BUILD_LOGS) }
            )

            ToolWindowTabItem(
                label = "Emulator",
                icon = Icons.Default.Smartphone,
                isSelected = activeWindow == ToolWindow.PREVIEW,
                themeMode = themeMode,
                isDark = isDark,
                onClick = { onSelectWindow(ToolWindow.PREVIEW) }
            )

            ToolWindowTabItem(
                label = "Problems",
                icon = Icons.Default.BugReport,
                isSelected = activeWindow == ToolWindow.PROBLEMS,
                badgeCount = problemsCount,
                themeMode = themeMode,
                isDark = isDark,
                onClick = { onSelectWindow(ToolWindow.PROBLEMS) }
            )
        }
    }
}

@Composable
private fun ToolWindowTabItem(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    badgeCount: Int = 0,
    themeMode: AppThemeMode = AppThemeMode.DARK,
    isDark: Boolean = true,
    onClick: () -> Unit
) {
    val bg = if (isSelected) {
        when (themeMode) {
            AppThemeMode.OLED -> Color(0xFF00F0FF).copy(alpha = 0.2f)
            AppThemeMode.DARK -> Color(0xFF3574F0).copy(alpha = 0.25f)
            AppThemeMode.LIGHT -> Color(0xFFDDF4FF)
        }
    } else {
        Color.Transparent
    }
    val tint = if (isSelected) {
        when (themeMode) {
            AppThemeMode.OLED -> Color(0xFF00F0FF)
            AppThemeMode.DARK -> Color(0xFF56A8F5)
            AppThemeMode.LIGHT -> Color(0xFF0969DA)
        }
    } else {
        when (themeMode) {
            AppThemeMode.OLED -> Color(0xFF8B949E)
            AppThemeMode.DARK -> Color(0xFF8C9298)
            AppThemeMode.LIGHT -> Color(0xFF656D76)
        }
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (badgeCount > 0) {
                BadgedBox(
                    badge = {
                        Badge(containerColor = Color(0xFFF75464)) {
                            Text("$badgeCount", color = Color.White, fontSize = 10.sp)
                        }
                    }
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = tint,
                        modifier = Modifier.size(16.dp)
                    )
                }
            } else {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = tint,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Text(
                text = label,
                color = tint,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}
