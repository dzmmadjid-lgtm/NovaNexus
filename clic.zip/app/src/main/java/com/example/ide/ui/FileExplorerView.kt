package com.example.ide.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ide.model.FileType
import com.example.ide.model.OledTemplate
import com.example.ide.model.OledTemplatesCatalog
import com.example.ide.model.ProjectFile

/**
 * مستعرض شجرة ملفات المشروع (Android Project Tree View)
 * يعرض المجلدات والملفات بنمط تفرعي مشابه لنظام Android Studio
 */
@Composable
fun FileExplorerView(
    projectTree: ProjectFile,
    activeFileId: String?,
    onFileClick: (ProjectFile) -> Unit,
    onToggleFolder: (String) -> Unit,
    onCreateNewFile: (parentId: String, name: String, isFolder: Boolean) -> Unit,
    onDeleteNode: (String) -> Unit,
    isDark: Boolean = true,
    onExportZip: () -> Unit = {},
    onImportZip: (Uri) -> Unit = {},
    onSelectOledTemplate: (OledTemplate) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showCreateDialog by remember { mutableStateOf(false) }
    var createIsFolder by remember { mutableStateOf(false) }
    var targetFolderId by remember { mutableStateOf(projectTree.id) }
    var newNameInput by remember { mutableStateOf("") }
    var showOledDialog by remember { mutableStateOf(false) }

    val zipPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            onImportZip(uri)
        }
    }

    val bg = if (isDark) Color(0xFF2B2D30) else Color(0xFFFFFFFF)
    val headerBg = if (isDark) Color(0xFF1E1F22) else Color(0xFFF6F8FA)
    val headerText = if (isDark) Color(0xFFDFE1E5) else Color(0xFF1F2328)
    val addIconTint = if (isDark) Color(0xFF3574F0) else Color(0xFF0969DA)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(bg)
    ) {
        // شريط عنوان مستعرض المشروع
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(headerBg)
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Folder,
                contentDescription = null,
                tint = Color(0xFFE5A50A),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "ملفات المشروع (Project)",
                color = headerText,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.weight(1f))

            // زر إضافة ملف جديد
            IconButton(
                onClick = {
                    targetFolderId = projectTree.id
                    createIsFolder = false
                    newNameInput = ""
                    showCreateDialog = true
                },
                modifier = Modifier.size(28.dp).testTag("btn_new_file")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "ملف جديد",
                    tint = addIconTint,
                    modifier = Modifier.size(18.dp)
                )
            }

            // زر إضافة مجلد جديد
            IconButton(
                onClick = {
                    targetFolderId = projectTree.id
                    createIsFolder = true
                    newNameInput = ""
                    showCreateDialog = true
                },
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CreateNewFolder,
                    contentDescription = "مجلد جديد",
                    tint = Color(0xFFE5A50A),
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        // شريط إجراءات المشروع المتقدمة: استيراد وتصدير ZIP وقوالب OLED
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (isDark) Color(0xFF232529) else Color(0xFFECEFF3))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // زر استيراد ZIP
            OutlinedButton(
                onClick = { zipPickerLauncher.launch("*/*") },
                shape = RoundedCornerShape(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp).testTag("btn_import_zip")
            ) {
                Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(14.dp), tint = addIconTint)
                Spacer(modifier = Modifier.width(4.dp))
                Text("استيراد ZIP", fontSize = 11.sp, color = headerText)
            }

            // زر تصدير ZIP
            OutlinedButton(
                onClick = onExportZip,
                shape = RoundedCornerShape(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp).testTag("btn_export_zip")
            ) {
                Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color(0xFF36B86C))
                Spacer(modifier = Modifier.width(4.dp))
                Text("تصدير ZIP", fontSize = 11.sp, color = headerText)
            }

            // زر قوالب OLED
            Button(
                onClick = { showOledDialog = true },
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBD00FF)),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp).testTag("btn_oled_templates")
            ) {
                Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(14.dp), tint = Color.White)
                Spacer(modifier = Modifier.width(4.dp))
                Text("قوالب OLED", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }

        // شجرة الملفات القابلة للتمرير
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 6.dp)
        ) {
            item {
                FileTreeNode(
                    node = projectTree,
                    depth = 0,
                    activeFileId = activeFileId,
                    isDark = isDark,
                    onFileClick = onFileClick,
                    onToggleFolder = onToggleFolder,
                    onAddChild = { parentId, isFolder ->
                        targetFolderId = parentId
                        createIsFolder = isFolder
                        newNameInput = ""
                        showCreateDialog = true
                    },
                    onDeleteNode = onDeleteNode
                )
            }
        }
    }

    // نافذة منبثقة لإنشاء ملف أو مجلد جديد
    if (showCreateDialog) {
        val dialogBg = if (isDark) Color(0xFF2B2D30) else Color(0xFFFFFFFF)
        val dialogTitleText = if (isDark) Color.White else Color(0xFF1F2328)
        val dialogBodyText = if (isDark) Color(0xFF8C9298) else Color(0xFF656D76)
        val accentColor = if (isDark) Color(0xFF3574F0) else Color(0xFF0969DA)

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = {
                Text(
                    text = if (createIsFolder) "إنشاء مجلد جديد" else "إنشاء ملف جديد",
                    color = dialogTitleText,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = if (createIsFolder) "اسم المجلد (مثال: utils)" else "اسم الملف مع الامتداد (مثال: NewScreen.kt)",
                        color = dialogBodyText,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newNameInput,
                        onValueChange = { newNameInput = it },
                        singleLine = true,
                        placeholder = { Text(if (createIsFolder) "components" else "MyHelper.kt") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = dialogTitleText,
                            unfocusedTextColor = dialogTitleText,
                            focusedBorderColor = accentColor,
                            unfocusedBorderColor = if (isDark) Color(0xFF43454A) else Color(0xFFD0D7DE)
                        ),
                        modifier = Modifier.fillMaxWidth().testTag("input_new_file_name")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = newNameInput.trim()
                        if (trimmed.isNotBlank()) {
                            onCreateNewFile(targetFolderId, trimmed, createIsFolder)
                            showCreateDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accentColor)
                ) {
                    Text("إنشاء", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showCreateDialog = false }) {
                    Text("إلغاء", color = dialogTitleText)
                }
            },
            containerColor = dialogBg
        )
    }

    // نافذة اختيار وإدراج قوالب واجهات OLED الجاهزة
    if (showOledDialog) {
        val dialogBg = if (isDark) Color(0xFF1E1F22) else Color(0xFFFFFFFF)
        val titleText = if (isDark) Color.White else Color(0xFF1F2328)
        val bodyText = if (isDark) Color(0xFF8C9298) else Color(0xFF656D76)

        AlertDialog(
            onDismissRequest = { showOledDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = Color(0xFFBD00FF),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "قوالب واجهات OLED فائقة الجمالية",
                        color = titleText,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "اختر أحد القوالب البرمجية الجاهزة بنمط الأسود المطلق ولمسات النيون لإضافتها مباشرة إلى مشروعك:",
                        color = bodyText,
                        fontSize = 12.sp
                    )

                    OledTemplatesCatalog.ALL_TEMPLATES.forEach { template ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectOledTemplate(template)
                                    showOledDialog = false
                                },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDark) Color(0xFF2B2D30) else Color(0xFFF6F8FA)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when (template.id) {
                                                    "cyber_dashboard" -> Color(0xFF00F0FF)
                                                    "music_player" -> Color(0xFFFF007F)
                                                    else -> Color(0xFF00FF9D)
                                                }
                                            )
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = template.title,
                                        color = titleText,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = template.description,
                                    color = bodyText,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "+ إضافة ${template.fileName} إلى المشروع",
                                    color = Color(0xFF56A8F5),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                OutlinedButton(onClick = { showOledDialog = false }) {
                    Text("إغلاق", color = titleText)
                }
            },
            containerColor = dialogBg
        )
    }
}

@Composable
private fun FileTreeNode(
    node: ProjectFile,
    depth: Int,
    activeFileId: String?,
    isDark: Boolean = true,
    onFileClick: (ProjectFile) -> Unit,
    onToggleFolder: (String) -> Unit,
    onAddChild: (parentId: String, isFolder: Boolean) -> Unit,
    onDeleteNode: (String) -> Unit
) {
    val isSelected = !node.isDirectory && node.id == activeFileId
    var showMenu by remember { mutableStateOf(false) }

    val selectedBg = if (isDark) Color(0xFF3574F0).copy(alpha = 0.25f) else Color(0xFFDDF4FF)
    val selectedText = if (isDark) Color(0xFF56A8F5) else Color(0xFF0969DA)
    val unselectedText = if (isDark) Color(0xFFDFE1E5) else Color(0xFF1F2328)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isSelected) selectedBg else Color.Transparent)
            .clickable {
                if (node.isDirectory) {
                    onToggleFolder(node.id)
                } else {
                    onFileClick(node)
                }
            }
            .padding(start = (depth * 16 + 8).dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // سهم المجلد أو مسافة
        if (node.isDirectory) {
            Icon(
                imageVector = if (node.isExpanded) Icons.Default.KeyboardArrowDown else Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = if (isDark) Color(0xFF8C9298) else Color(0xFF656D76),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = if (node.isExpanded) Icons.Default.FolderOpen else Icons.Default.Folder,
                contentDescription = null,
                tint = Color(0xFFE5A50A),
                modifier = Modifier.size(18.dp)
            )
        } else {
            Spacer(modifier = Modifier.width(20.dp))
            FileTypeBadge(fileType = node.fileType)
        }

        Spacer(modifier = Modifier.width(8.dp))

        Text(
            text = node.name,
            color = if (isSelected) selectedText else unselectedText,
            fontSize = 13.sp,
            fontWeight = if (node.isDirectory) FontWeight.SemiBold else FontWeight.Normal,
            modifier = Modifier.weight(1f)
        )

        // قائمة الخيارات لكل عقدة
        Box {
            IconButton(
                onClick = { showMenu = true },
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = null,
                    tint = Color(0xFF6E747A),
                    modifier = Modifier.size(16.dp)
                )
            }

            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { showMenu = false },
                modifier = Modifier.background(if (isDark) Color(0xFF2B2D30) else Color(0xFFFFFFFF))
            ) {
                val menuTextColor = if (isDark) Color.White else Color(0xFF1F2328)
                if (node.isDirectory) {
                    DropdownMenuItem(
                        text = { Text("ملف جديد هنا", color = menuTextColor) },
                        onClick = {
                            showMenu = false
                            onAddChild(node.id, false)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("مجلد جديد هنا", color = menuTextColor) },
                        onClick = {
                            showMenu = false
                            onAddChild(node.id, true)
                        }
                    )
                }
                DropdownMenuItem(
                    text = { Text("حذف", color = Color(0xFFF75464)) },
                    onClick = {
                        showMenu = false
                        onDeleteNode(node.id)
                    }
                )
            }
        }
    }

    // رسم العناصر الفرعية إذا كان المجلد مفتوحاً
    if (node.isDirectory && node.isExpanded) {
        node.children.forEach { child ->
            FileTreeNode(
                node = child,
                depth = depth + 1,
                activeFileId = activeFileId,
                isDark = isDark,
                onFileClick = onFileClick,
                onToggleFolder = onToggleFolder,
                onAddChild = onAddChild,
                onDeleteNode = onDeleteNode
            )
        }
    }
}

/**
 * شارة ملونة لتمييز نوع الملف
 */
@Composable
private fun FileTypeBadge(fileType: FileType) {
    val (label, bg, fg) = when (fileType) {
        FileType.KOTLIN -> Triple("K", Color(0xFF7F52FF), Color.White)
        FileType.JAVA -> Triple("J", Color(0xFFEA2D2E), Color.White)
        FileType.XML -> Triple("<>", Color(0xFFE8BF6A), Color.Black)
        FileType.GRADLE, FileType.GRADLE_GROOVY -> Triple("G", Color(0xFF02303A), Color(0xFF00C853))
        FileType.JSON -> Triple("{ }", Color(0xFF2B2D30), Color(0xFFF2C55C))
        else -> Triple("T", Color(0xFF43454A), Color.White)
    }

    Box(
        modifier = Modifier
            .size(18.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(bg),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = fg,
            fontFamily = FontFamily.Monospace
        )
    }
}
