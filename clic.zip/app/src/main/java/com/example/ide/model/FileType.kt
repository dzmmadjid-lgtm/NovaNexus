package com.example.ide.model

/**
 * يمثل نوع الملف والامتداد الخاص به لدعم تلوين الصياغة والأيقونات المناسبة
 */
enum class FileType(
    val extension: String,
    val displayName: String,
    val isCode: Boolean = true
) {
    KOTLIN("kt", "Kotlin"),
    JAVA("java", "Java"),
    XML("xml", "XML"),
    GRADLE("gradle.kts", "Gradle (Kotlin)"),
    GRADLE_GROOVY("gradle", "Gradle"),
    JSON("json", "JSON"),
    PROPERTIES("properties", "Properties"),
    TXT("txt", "Text"),
    UNKNOWN("", "File");

    companion object {
        fun fromFileName(fileName: String): FileType {
            val lower = fileName.lowercase()
            return when {
                lower.endsWith(".gradle.kts") -> GRADLE
                lower.endsWith(".gradle") -> GRADLE_GROOVY
                lower.endsWith(".kt") -> KOTLIN
                lower.endsWith(".java") -> JAVA
                lower.endsWith(".xml") -> XML
                lower.endsWith(".json") -> JSON
                lower.endsWith(".properties") -> PROPERTIES
                lower.endsWith(".txt") || lower.endsWith(".md") -> TXT
                else -> UNKNOWN
            }
        }
    }
}
