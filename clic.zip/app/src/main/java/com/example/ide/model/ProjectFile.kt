package com.example.ide.model

import java.util.UUID

/**
 * يمثل عنصراً داخل شجرة مشروع الأندرويد (ملف أو مجلد)
 * يدعم التفرع الشجري (Collapsible Tree Nodes) والمسار النسبي
 */
data class ProjectFile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val path: String,
    val isDirectory: Boolean = false,
    val fileType: FileType = if (isDirectory) FileType.UNKNOWN else FileType.fromFileName(name),
    val content: String = "",
    val children: List<ProjectFile> = emptyList(),
    val isExpanded: Boolean = true,
    val isModified: Boolean = false
) {
    /**
     * البحث عن ملف بواسطة المعرف الفريد داخل الشجرة
     */
    fun findById(targetId: String): ProjectFile? {
        if (this.id == targetId) return this
        for (child in children) {
            val found = child.findById(targetId)
            if (found != null) return found
        }
        return null
    }

    /**
     * تحديث محتوى ملف معين داخل الشجرة وإرجاع شجرة محدثة
     */
    fun updateContent(targetId: String, newContent: String): ProjectFile {
        if (this.id == targetId) {
            return this.copy(content = newContent, isModified = true)
        }
        return this.copy(
            children = children.map { it.updateContent(targetId, newContent) }
        )
    }

    /**
     * تبديل حالة فتح/إغلاق المجلد
     */
    fun toggleExpanded(targetId: String): ProjectFile {
        if (this.id == targetId && isDirectory) {
            return this.copy(isExpanded = !isExpanded)
        }
        return this.copy(
            children = children.map { it.toggleExpanded(targetId) }
        )
    }

    /**
     * إضافة ملف أو مجلد جديد كابن لمجلد معين
     */
    fun addChild(parentId: String, newChild: ProjectFile): ProjectFile {
        if (this.id == parentId && isDirectory) {
            return this.copy(children = children + newChild, isExpanded = true)
        }
        return this.copy(
            children = children.map { it.addChild(parentId, newChild) }
        )
    }

    /**
     * حذف عنصر بالمعرف
     */
    fun removeChild(targetId: String): ProjectFile {
        return this.copy(
            children = children.filterNot { it.id == targetId }.map { it.removeChild(targetId) }
        )
    }
}
