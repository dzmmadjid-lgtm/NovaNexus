package com.example.ide.model

/**
 * يوفر شجرة مشروع أندرويد افتراضية متكاملة تحتوي على ملفات Kotlin و Java و XML و Gradle
 */
object DefaultProject {

    fun createSampleProject(): ProjectFile {
        val mainActivityKt = ProjectFile(
            name = "MainActivity.kt",
            path = "app/src/main/java/com/example/myapp/MainActivity.kt",
            fileType = FileType.KOTLIN,
            content = """package com.example.myapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * نقطة الانطلاق الرئيسية لتطبيق أندرويد باستخدام Jetpack Compose
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppContent()
                }
            }
        }
    }
}

@Composable
fun AppContent() {
    var count by remember { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "مرحباً بك في تطبيقي الأول!",
            style = MaterialTheme.typography.headlineMedium
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        Text(
            text = "تم الضغط: ${'$'}count مرة",
            style = MaterialTheme.typography.bodyLarge
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(onClick = { count++ }) {
            Text("اضغط هنا للزيادة (+1)")
        }
    }
}
""".trimIndent()
        )

        val calculatorHelperJava = ProjectFile(
            name = "CalculatorHelper.java",
            path = "app/src/main/java/com/example/myapp/CalculatorHelper.java",
            fileType = FileType.JAVA,
            content = """package com.example.myapp;

/**
 * كلاس تجريبي بلغة Java لاختبار تلوين الصياغة ودعم الكود
 */
public class CalculatorHelper {

    private int lastResult = 0;

    public CalculatorHelper() {
        this.lastResult = 0;
    }

    public int add(int a, int b) {
        this.lastResult = a + b;
        return this.lastResult;
    }

    public int multiply(int a, int b) {
        this.lastResult = a * b;
        return this.lastResult;
    }

    public int getLastResult() {
        return this.lastResult;
    }

    @Override
    public String toString() {
        return "CalculatorHelper{lastResult=" + lastResult + "}";
    }
}
""".trimIndent()
        )

        val activityMainXml = ProjectFile(
            name = "activity_main.xml",
            path = "app/src/main/res/layout/activity_main.xml",
            fileType = FileType.XML,
            content = """<?xml version="1.0" encoding="utf-8"?>
<!-- واجهة XML الكلاسيكية لنظام أندرويد -->
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:gravity="center"
    android:orientation="vertical"
    android:padding="24dp">

    <TextView
        android:id="@+id/tvTitle"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/welcome_message"
        android:textSize="22sp"
        android:textStyle="bold" />

    <Button
        android:id="@+id/btnClick"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="20dp"
        android:text="انقر للتفاعل" />

</LinearLayout>
""".trimIndent()
        )

        val stringsXml = ProjectFile(
            name = "strings.xml",
            path = "app/src/main/res/values/strings.xml",
            fileType = FileType.XML,
            content = """<resources>
    <string name="app_name">MyFirstApp</string>
    <string name="welcome_message">أهلاً بك في بيئة DroidIDE!</string>
</resources>
""".trimIndent()
        )

        val manifestXml = ProjectFile(
            name = "AndroidManifest.xml",
            path = "app/src/main/AndroidManifest.xml",
            fileType = FileType.XML,
            content = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.Material3.DayNight">
        
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
""".trimIndent()
        )

        val buildGradleKts = ProjectFile(
            name = "build.gradle.kts",
            path = "app/build.gradle.kts",
            fileType = FileType.GRADLE,
            content = """plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.example.myapp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.myapp"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.core.ktx)
}
""".trimIndent()
        )

        val settingsGradleKts = ProjectFile(
            name = "settings.gradle.kts",
            path = "settings.gradle.kts",
            fileType = FileType.GRADLE,
            content = """rootProject.name = "MyFirstApp"
include(":app")
""".trimIndent()
        )

        // تجميع المجلدات في هيكل شجري
        val javaPackage = ProjectFile(
            name = "myapp",
            path = "app/src/main/java/com/example/myapp",
            isDirectory = true,
            children = listOf(mainActivityKt, calculatorHelperJava)
        )

        val comExampleDir = ProjectFile(
            name = "com/example",
            path = "app/src/main/java/com/example",
            isDirectory = true,
            children = listOf(javaPackage)
        )

        val javaDir = ProjectFile(
            name = "java",
            path = "app/src/main/java",
            isDirectory = true,
            children = listOf(comExampleDir)
        )

        val layoutDir = ProjectFile(
            name = "layout",
            path = "app/src/main/res/layout",
            isDirectory = true,
            children = listOf(activityMainXml)
        )

        val valuesDir = ProjectFile(
            name = "values",
            path = "app/src/main/res/values",
            isDirectory = true,
            children = listOf(stringsXml)
        )

        val resDir = ProjectFile(
            name = "res",
            path = "app/src/main/res",
            isDirectory = true,
            children = listOf(layoutDir, valuesDir)
        )

        val mainDir = ProjectFile(
            name = "main",
            path = "app/src/main",
            isDirectory = true,
            children = listOf(manifestXml, javaDir, resDir)
        )

        val srcDir = ProjectFile(
            name = "src",
            path = "app/src",
            isDirectory = true,
            children = listOf(mainDir)
        )

        val appModuleDir = ProjectFile(
            name = "app",
            path = "app",
            isDirectory = true,
            children = listOf(buildGradleKts, srcDir)
        )

        return ProjectFile(
            name = "MyFirstApp",
            path = "",
            isDirectory = true,
            children = listOf(appModuleDir, settingsGradleKts)
        )
    }
}
