package com.example.ide.compiler

import com.example.ide.model.BuildLog
import com.example.ide.model.BuildStatus
import com.example.ide.model.CompilerMessage
import com.example.ide.model.FileType
import com.example.ide.model.LogType
import com.example.ide.model.ProjectFile
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * محاكي بناء مشاريع أندرويد و Gradle
 * يقوم بالتحقق النحوي الحقيقي من الأكواد ومحاكاة مراحل بناء الـ APK خطوة بخطوة
 */
object GradleSimulator {

    /**
     * التحقق من سلامة الأكواد المصدرية (Kotlin / Java / XML)
     */
    fun validateProject(root: ProjectFile): List<CompilerMessage> {
        val errors = mutableListOf<CompilerMessage>()
        fun scan(file: ProjectFile) {
            if (file.isDirectory) {
                file.children.forEach { scan(it) }
            } else {
                when (file.fileType) {
                    FileType.KOTLIN, FileType.JAVA -> validateBraces(file, errors)
                    FileType.XML -> validateXmlTags(file, errors)
                    else -> {}
                }
            }
        }
        scan(root)
        return errors
    }

    private fun validateBraces(file: ProjectFile, errors: MutableList<CompilerMessage>) {
        val lines = file.content.lines()
        var braceCount = 0
        var parenCount = 0

        lines.forEachIndexed { index, line ->
            // تجاهل أسطر التعليقات
            val trimmed = line.trim()
            if (trimmed.startsWith("//") || trimmed.startsWith("/*") || trimmed.startsWith("*")) {
                return@forEachIndexed
            }

            for (char in line) {
                when (char) {
                    '{' -> braceCount++
                    '}' -> {
                        braceCount--
                        if (braceCount < 0) {
                            errors.add(
                                CompilerMessage(
                                    fileName = file.name,
                                    line = index + 1,
                                    column = line.indexOf('}') + 1,
                                    message = "Unmatched closing brace '}' found without opening brace"
                                )
                            )
                            braceCount = 0
                        }
                    }
                    '(' -> parenCount++
                    ')' -> {
                        parenCount--
                        if (parenCount < 0) {
                            errors.add(
                                CompilerMessage(
                                    fileName = file.name,
                                    line = index + 1,
                                    column = line.indexOf(')') + 1,
                                    message = "Unmatched closing parenthesis ')' without opening parenthesis"
                                )
                            )
                            parenCount = 0
                        }
                    }
                }
            }
        }

        if (braceCount > 0) {
            errors.add(
                CompilerMessage(
                    fileName = file.name,
                    line = lines.size,
                    column = 1,
                    message = "Missing closing brace '}' at the end of file ($braceCount unclosed)"
                )
            )
        }
        if (parenCount > 0) {
            errors.add(
                CompilerMessage(
                    fileName = file.name,
                    line = lines.size,
                    column = 1,
                    message = "Missing closing parenthesis ')' at the end of file ($parenCount unclosed)"
                )
            )
        }
    }

    private fun validateXmlTags(file: ProjectFile, errors: MutableList<CompilerMessage>) {
        val lines = file.content.lines()
        var openTags = 0
        lines.forEachIndexed { index, line ->
            val trimmed = line.trim()
            if (trimmed.startsWith("<!--")) return@forEachIndexed
            if (trimmed.startsWith("<") && !trimmed.startsWith("</") && !trimmed.endsWith("/>") && !trimmed.startsWith("<?")) {
                openTags++
            }
            if (trimmed.startsWith("</")) {
                openTags--
                if (openTags < 0) {
                    errors.add(
                        CompilerMessage(
                            fileName = file.name,
                            line = index + 1,
                            column = 1,
                            message = "Mismatched or unexpected closing XML tag: $trimmed"
                        )
                    )
                    openTags = 0
                }
            }
        }
        if (openTags > 0) {
            errors.add(
                CompilerMessage(
                    fileName = file.name,
                    line = lines.size,
                    column = 1,
                    message = "XML markup is not well-formed: $openTags unclosed tags"
                )
            )
        }
    }

    /**
     * تدفق عملية البناء الكاملة لمشروع Gradle
     */
    fun buildProjectFlow(root: ProjectFile): Flow<Pair<BuildStatus, BuildLog>> = flow {
        val startTime = System.currentTimeMillis()

        emit(
            Pair(
                BuildStatus.Building("Starting Gradle Daemon...", 0.05f),
                BuildLog(text = "Starting Gradle Daemon (subsequent builds will be faster)", type = LogType.INFO)
            )
        )
        delay(350)

        emit(
            Pair(
                BuildStatus.Building("Evaluating project...", 0.10f),
                BuildLog(text = "> Configure project :app", type = LogType.TASK)
            )
        )
        delay(300)

        // التحقق من الأخطاء النحوية
        val validationErrors = validateProject(root)
        if (validationErrors.isNotEmpty()) {
            val duration = (System.currentTimeMillis() - startTime) / 1000f

            emit(
                Pair(
                    BuildStatus.Building("Compiling sources...", 0.35f),
                    BuildLog(text = "> Task :app:compileDebugKotlin FAILED", type = LogType.TASK)
                )
            )
            delay(200)

            validationErrors.forEach { err ->
                emit(
                    Pair(
                        BuildStatus.Building("Compiling sources...", 0.40f),
                        BuildLog(
                            text = "e: file://${err.fileName}:${err.line}:${err.column}: ${err.message}",
                            type = LogType.ERROR
                        )
                    )
                )
                delay(150)
            }

            emit(
                Pair(
                    BuildStatus.Failed(duration, validationErrors),
                    BuildLog(
                        text = "BUILD FAILED in ${String.format("%.1f", duration)}s with ${validationErrors.size} error(s)",
                        type = LogType.ERROR
                    )
                )
            )
            return@flow
        }

        // تنفيذ مهام Gradle بالتسلسل
        val tasks = listOf(
            Pair("> Task :app:preBuild UP-TO-DATE", 0.15f),
            Pair("> Task :app:preDebugBuild UP-TO-DATE", 0.20f),
            Pair("> Task :app:generateDebugBuildConfig", 0.28f),
            Pair("> Task :app:processDebugManifest", 0.36f),
            Pair("> Task :app:mergeDebugResources", 0.45f),
            Pair("> Task :app:processDebugResources", 0.55f),
            Pair("> Task :app:compileDebugKotlin", 0.68f),
            Pair("> Task :app:compileDebugJavaWithJavac", 0.78f),
            Pair("> Task :app:dexBuilderDebug", 0.85f),
            Pair("> Task :app:mergeDebugDex", 0.92f),
            Pair("> Task :app:packageDebug", 0.96f),
            Pair("> Task :app:assembleDebug", 0.99f)
        )

        for ((taskText, progress) in tasks) {
            emit(
                Pair(
                    BuildStatus.Building(taskText.substringAfter("> Task "), progress),
                    BuildLog(text = taskText, type = LogType.TASK)
                )
            )
            delay(220)
        }

        val duration = (System.currentTimeMillis() - startTime) / 1000f
        val apkPath = "app/build/outputs/apk/debug/app-debug.apk"
        val apkSize = 14.8f

        emit(
            Pair(
                BuildStatus.Building("Finalizing APK...", 1.0f),
                BuildLog(text = "APK generated: $apkPath ($apkSize MB)", type = LogType.SUCCESS)
            )
        )
        delay(200)

        emit(
            Pair(
                BuildStatus.Success(duration, apkPath, apkSize),
                BuildLog(
                    text = "BUILD SUCCESSFUL in ${String.format("%.1f", duration)}s (18 tasks executed)",
                    type = LogType.SUCCESS
                )
            )
        )
    }
}
