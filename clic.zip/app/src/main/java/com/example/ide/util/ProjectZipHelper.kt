package com.example.ide.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.ide.model.FileType
import com.example.ide.model.ProjectFile
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * فئة مساعدة لتصدير واستيراد مشاريع أندرويد بالكامل بصيغة ZIP
 * متوافقة تماماً مع بنية مشاريع Android Studio القياسية
 */
object ProjectZipHelper {

    /**
     * ضغط شجرة المشروع الحالية بالكامل في ملف ZIP ومشاركتها مع المستخدم
     */
    fun exportProjectToZip(context: Context, rootFile: ProjectFile): Uri? {
        return try {
            val exportDir = File(context.cacheDir, "project_exports").apply { mkdirs() }
            val zipFile = File(exportDir, "${rootFile.name.ifBlank { "DroidProject" }}_export.zip")
            if (zipFile.exists()) {
                zipFile.delete()
            }

            ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
                addNodeToZip(zos, rootFile, "")
            }

            val fileUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                zipFile
            )

            // فتح نافذة المشاركة الفورية مع حفظ الأذونات
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, fileUri)
                putExtra(Intent.EXTRA_SUBJECT, "تصدير مشروع أندرويد: ${rootFile.name}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(shareIntent, "مشاركة / حفظ المشروع كملف ZIP"))

            fileUri
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun addNodeToZip(zos: ZipOutputStream, node: ProjectFile, parentPath: String) {
        val currentPath = if (parentPath.isEmpty()) node.name else "$parentPath/${node.name}"

        if (node.isDirectory) {
            val dirEntryName = if (currentPath.endsWith("/")) currentPath else "$currentPath/"
            val entry = ZipEntry(dirEntryName)
            zos.putNextEntry(entry)
            zos.closeEntry()

            for (child in node.children) {
                addNodeToZip(zos, child, currentPath)
            }
        } else {
            val entry = ZipEntry(currentPath)
            zos.putNextEntry(entry)
            val bytes = node.content.toByteArray(Charsets.UTF_8)
            zos.write(bytes)
            zos.closeEntry()
        }
    }

    /**
     * استيراد وفك ضغط ملف ZIP لمشروع أندرويد وتحويله إلى شجرة ProjectFile في الذاكرة
     */
    fun importProjectFromZip(context: Context, uri: Uri): ProjectFile? {
        return try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri) ?: return null
            val entriesMap = mutableMapOf<String, String>() // path -> content
            val directoriesSet = mutableSetOf<String>()

            ZipInputStream(inputStream).use { zis ->
                var entry: ZipEntry? = zis.nextEntry
                while (entry != null) {
                    val entryName = entry.name.trimStart('/')
                    if (!entry.isDirectory) {
                        val content = zis.readBytes().toString(Charsets.UTF_8)
                        entriesMap[entryName] = content
                    } else {
                        directoriesSet.add(entryName.trimEnd('/'))
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            if (entriesMap.isEmpty()) return null

            // بناء شجرة الملفات من المسارات المستوردة
            buildProjectTreeFromEntries(entriesMap, directoriesSet)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun buildProjectTreeFromEntries(
        files: Map<String, String>,
        explicitDirs: Set<String>
    ): ProjectFile {
        val rootChildren = mutableListOf<ProjectFile>()

        // إنشاء خريطة مؤقتة للعقد
        class TempNode(
            val name: String,
            val path: String,
            val isDirectory: Boolean,
            var content: String = ""
        ) {
            val children = mutableMapOf<String, TempNode>()

            fun toProjectFile(): ProjectFile {
                return ProjectFile(
                    name = name,
                    path = path,
                    isDirectory = isDirectory,
                    fileType = if (isDirectory) FileType.KOTLIN else FileType.fromFileName(name),
                    content = content,
                    children = children.values.map { it.toProjectFile() }.sortedWith(
                        compareByDescending<ProjectFile> { it.isDirectory }.thenBy { it.name }
                    )
                )
            }
        }

        val rootNode = TempNode("ProjectRoot", "", true)

        // إضافة المجلدات
        for (dirPath in explicitDirs) {
            val parts = dirPath.split("/").filter { it.isNotEmpty() }
            var curr = rootNode
            var accumulated = ""
            for (part in parts) {
                accumulated = if (accumulated.isEmpty()) part else "$accumulated/$part"
                curr = curr.children.getOrPut(part) {
                    TempNode(part, accumulated, true)
                }
            }
        }

        // إضافة الملفات ومحتوياتها
        for ((filePath, content) in files) {
            val parts = filePath.split("/").filter { it.isNotEmpty() }
            var curr = rootNode
            var accumulated = ""
            for (i in 0 until parts.size - 1) {
                val part = parts[i]
                accumulated = if (accumulated.isEmpty()) part else "$accumulated/$part"
                curr = curr.children.getOrPut(part) {
                    TempNode(part, accumulated, true)
                }
            }
            val fileName = parts.last()
            val fullFilePath = if (accumulated.isEmpty()) fileName else "$accumulated/$fileName"
            val fileNode = TempNode(fileName, fullFilePath, false, content)
            curr.children[fileName] = fileNode
        }

        // إذا كان هناك مجلد رئيسي وحيد يحتوي على كل شيء (مثل اسم المشروع عند ضغطه)، نعتمده كجذر
        val topChildren = rootNode.children.values.toList()
        return if (topChildren.size == 1 && topChildren.first().isDirectory) {
            topChildren.first().toProjectFile()
        } else {
            ProjectFile(
                name = "ImportedProject",
                path = "app",
                isDirectory = true,
                children = rootNode.children.values.map { it.toProjectFile() }
            )
        }
    }
}
