package com.example.ide.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * شريط الرموز السريعة والمفاتيح البرمجية (Quick Coding Keys)
 * يسهل كتابة الأقواس والرموز المكررة والمسافات البادئة (Tab) على شاشة الهاتف
 */
@Composable
fun QuickKeysBar(
    onInsert: (String) -> Unit,
    isDark: Boolean = true,
    modifier: Modifier = Modifier
) {
    val quickSymbols = listOf(
        "Tab" to "    ",
        "{" to "{",
        "}" to "}",
        "(" to "(",
        ")" to ")",
        "[" to "[",
        "]" to "]",
        "<" to "<",
        ">" to ">",
        "\"" to "\"",
        "'" to "'",
        ";" to ";",
        ":" to ":",
        "=" to "=",
        "." to ".",
        "," to ", ",
        "+" to "+",
        "-" to "-",
        "*" to "*",
        "/" to "/",
        "!" to "!",
        "&" to "&",
        "|" to "|",
        "->" to "->",
        "//" to "// ",
        "fun" to "fun ",
        "val" to "val ",
        "var" to "var "
    )

    val barBg = if (isDark) Color(0xFF1E1F22) else Color(0xFFF0F2F5)

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(44.dp)
            .background(barBg)
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 8.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        quickSymbols.forEach { (label, snippet) ->
            KeyItem(
                label = label,
                isDark = isDark,
                onClick = { onInsert(snippet) }
            )
        }
    }
}

@Composable
private fun KeyItem(
    label: String,
    isDark: Boolean,
    onClick: () -> Unit
) {
    val isSpecial = label == "Tab" || label == "fun" || label == "val" || label == "var"
    val accentColor = if (isDark) Color(0xFF3574F0) else Color(0xFF0969DA)
    val defaultBg = if (isDark) Color(0xFF2B2D30) else Color(0xFFFFFFFF)
    val defaultText = if (isDark) Color(0xFFDFE1E5) else Color(0xFF1F2328)

    val bgColor = if (isSpecial) accentColor else defaultBg
    val textColor = if (isSpecial) Color.White else defaultText

    Box(
        modifier = Modifier
            .widthIn(min = 36.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            color = textColor
        )
    }
}
