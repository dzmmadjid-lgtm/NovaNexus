package com.example.ide.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ide.highlighter.SyntaxVisualTransformation
import com.example.ide.model.FileType
import com.example.ide.model.ProjectFile
import com.example.ui.theme.AppThemeMode

/**
 * محرر الأكواد الذكي مع أرقام الأسطر وتلوين الصياغة
 */
@Composable
fun EditorView(
    activeFile: ProjectFile?,
    content: String,
    onContentChange: (String) -> Unit,
    cursorPosition: Pair<Int, Int>,
    onCursorChange: (Int, Int) -> Unit,
    isSearchVisible: Boolean,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onCloseSearch: () -> Unit,
    themeMode: AppThemeMode = AppThemeMode.DARK,
    isDark: Boolean = true,
    modifier: Modifier = Modifier
) {
    val effectiveMode = if (themeMode != AppThemeMode.DARK) themeMode else if (isDark) AppThemeMode.DARK else AppThemeMode.LIGHT

    if (activeFile == null) {
        EmptyEditorState(isDark = (effectiveMode != AppThemeMode.LIGHT), modifier = modifier)
        return
    }

    val lines = remember(content) { content.lines() }
    val lineCount = lines.size
    val verticalScrollState = rememberScrollState()
    val horizontalScrollState = rememberScrollState()

    val visualTransformation = remember(activeFile.fileType, effectiveMode) {
        SyntaxVisualTransformation(activeFile.fileType, themeMode = effectiveMode)
    }

    val editorBg = when (effectiveMode) {
        AppThemeMode.OLED -> Color(0xFF000000)
        AppThemeMode.DARK -> Color(0xFF1E1F22)
        AppThemeMode.LIGHT -> Color(0xFFFFFFFF)
    }
    val gutterBg = when (effectiveMode) {
        AppThemeMode.OLED -> Color(0xFF050608)
        AppThemeMode.DARK -> Color(0xFF232529)
        AppThemeMode.LIGHT -> Color(0xFFF4F5F7)
    }
    val gutterBorder = when (effectiveMode) {
        AppThemeMode.OLED -> Color(0xFF161A22)
        AppThemeMode.DARK -> Color(0xFF2E3136)
        AppThemeMode.LIGHT -> Color(0xFFE5E7EB)
    }
    val activeGutterText = when (effectiveMode) {
        AppThemeMode.OLED -> Color(0xFF00F0FF)
        AppThemeMode.DARK -> Color(0xFFDFE1E5)
        AppThemeMode.LIGHT -> Color(0xFF1F2328)
    }
    val inactiveGutterText = when (effectiveMode) {
        AppThemeMode.OLED -> Color(0xFF4A5568)
        AppThemeMode.DARK -> Color(0xFF606366)
        AppThemeMode.LIGHT -> Color(0xFF8C95A0)
    }
    val defaultTextColor = when (effectiveMode) {
        AppThemeMode.OLED -> Color(0xFFFFFFFF)
        AppThemeMode.DARK -> Color(0xFFA9B7C6)
        AppThemeMode.LIGHT -> Color(0xFF1F2328)
    }
    val cursorColor = when (effectiveMode) {
        AppThemeMode.OLED -> Color(0xFF00F0FF)
        AppThemeMode.DARK -> Color(0xFF3574F0)
        AppThemeMode.LIGHT -> Color(0xFF0969DA)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(editorBg)
    ) {
        // شريط البحث المضمن داخل المحرر (Find in file)
        if (isSearchVisible) {
            SearchBar(
                query = searchQuery,
                onQueryChange = onSearchQueryChange,
                onClose = onCloseSearch,
                isDark = isDark,
                matchCount = if (searchQuery.isNotBlank()) lines.count { it.contains(searchQuery, ignoreCase = true) } else 0
            )
        }

        // مساحة العمل: عمود أرقام الأسطر + محرر النصوص
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(verticalScrollState)
            ) {
                // عمود أرقام الأسطر (Gutter Column)
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .background(gutterBg)
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    for (i in 1..lineCount) {
                        Text(
                            text = "$i",
                            color = if (i == cursorPosition.first) activeGutterText else inactiveGutterText,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (i == cursorPosition.first) FontWeight.Bold else FontWeight.Normal,
                            lineHeight = 20.sp,
                            textAlign = TextAlign.End
                        )
                    }
                }

                // فاصل رأسي بين رقم السطر والكود
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(1.dp)
                        .background(gutterBorder)
                )

                Spacer(modifier = Modifier.width(6.dp))

                // حقل تحرير الكود مع دعم التلوين الصياغي
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .horizontalScroll(horizontalScrollState)
                        .padding(vertical = 8.dp, horizontal = 4.dp)
                ) {
                    BasicTextField(
                        value = content,
                        onValueChange = onContentChange,
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("code_editor_field"),
                        textStyle = TextStyle(
                            color = defaultTextColor,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            lineHeight = 20.sp
                        ),
                        cursorBrush = SolidColor(cursorColor),
                        visualTransformation = visualTransformation,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Ascii,
                            autoCorrectEnabled = false
                        )
                    )
                }
            }
        }

        // شريط معلومات الملف أسفل المحرر (Status Bar)
        EditorStatusBar(
            fileName = activeFile.name,
            fileType = activeFile.fileType,
            lineCount = lineCount,
            cursorLine = cursorPosition.first,
            cursorCol = cursorPosition.second,
            isDark = isDark
        )
    }
}

@Composable
private fun SearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    onClose: () -> Unit,
    matchCount: Int,
    isDark: Boolean = true
) {
    val barBg = if (isDark) Color(0xFF2B2D30) else Color(0xFFF0F2F5)
    val inputBg = if (isDark) Color(0xFF1E1F22) else Color(0xFFFFFFFF)
    val textPrimary = if (isDark) Color.White else Color(0xFF1F2328)
    val textHint = if (isDark) Color(0xFF6E747A) else Color(0xFF8C95A0)

    Surface(
        color = barBg,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = null,
                tint = if (isDark) Color(0xFF8C9298) else Color(0xFF656D76)
            )

            Spacer(modifier = Modifier.width(8.dp))

            BasicTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier
                    .weight(1f)
                    .background(inputBg, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                textStyle = TextStyle(color = textPrimary, fontSize = 13.sp),
                cursorBrush = SolidColor(if (isDark) Color.White else Color(0xFF0969DA)),
                decorationBox = { innerTextField ->
                    if (query.isEmpty()) {
                        Text("بحث في الملف...", color = textHint, fontSize = 13.sp)
                    }
                    innerTextField()
                }
            )

            if (query.isNotBlank()) {
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "$matchCount نتائج",
                    color = if (isDark) Color(0xFF3574F0) else Color(0xFF0969DA),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            IconButton(onClick = onClose) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إغلاق البحث",
                    tint = if (isDark) Color(0xFFDFE1E5) else Color(0xFF1F2328)
                )
            }
        }
    }
}

@Composable
private fun EditorStatusBar(
    fileName: String,
    fileType: FileType,
    lineCount: Int,
    cursorLine: Int,
    cursorCol: Int,
    isDark: Boolean = true
) {
    val barBg = if (isDark) Color(0xFF2B2D30) else Color(0xFFF2F4F7)
    val textMuted = if (isDark) Color(0xFF8C9298) else Color(0xFF656D76)
    val textPrimary = if (isDark) Color(0xFFDFE1E5) else Color(0xFF1F2328)
    val accentColor = if (isDark) Color(0xFF3574F0) else Color(0xFF0969DA)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(26.dp)
            .background(barBg)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "UTF-8",
            color = textMuted,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = fileType.displayName,
            color = accentColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.weight(1f))
        Text(
            text = "الأسطر: $lineCount",
            color = textMuted,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = "السطر: $cursorLine, العمود: $cursorCol",
            color = textPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun EmptyEditorState(
    isDark: Boolean = true,
    modifier: Modifier = Modifier
) {
    val bg = if (isDark) Color(0xFF1E1F22) else Color(0xFFFFFFFF)
    val primaryText = if (isDark) Color(0xFFDFE1E5) else Color(0xFF1F2328)
    val secondaryText = if (isDark) Color(0xFF8C9298) else Color(0xFF656D76)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bg),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "لا يوجد ملف مفتوح حالياً",
                style = TextStyle(
                    color = primaryText,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "افتح قائمة المشاريع لاختيار ملف والتعديل عليه",
                style = TextStyle(color = secondaryText, fontSize = 13.sp)
            )
        }
    }
}
