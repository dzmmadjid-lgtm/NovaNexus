package com.example.ide.model

/**
 * يمثل رسالة خطأ برمجية أو تحذير أثناء البناء
 */
data class CompilerMessage(
    val fileName: String,
    val line: Int,
    val column: Int,
    val message: String,
    val isError: Boolean = true
)

/**
 * يمثل حالة بناء مشروع Gradle
 */
sealed class BuildStatus {
    object Idle : BuildStatus()
    data class Building(val currentTask: String, val progress: Float) : BuildStatus()
    data class Success(val durationSeconds: Float, val apkPath: String, val apkSizeMb: Float) : BuildStatus()
    data class Failed(val durationSeconds: Float, val errors: List<CompilerMessage>) : BuildStatus()
}

/**
 * يمثل سجلاً واحداً في لوحة معلومات Gradle
 */
data class BuildLog(
    val timestamp: Long = System.currentTimeMillis(),
    val text: String,
    val type: LogType = LogType.INFO
)

enum class LogType {
    TASK,
    INFO,
    SUCCESS,
    WARNING,
    ERROR
}
