package com.example.ide.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ide.model.CompilerMessage

/**
 * لوحة فحص الأخطاء البرمجية والتحذيرات (Problems Tool Window)
 */
@Composable
fun ProblemsView(
    problems: List<CompilerMessage>,
    onClose: () -> Unit,
    isDark: Boolean = true,
    modifier: Modifier = Modifier
) {
    val bg = if (isDark) Color(0xFF1E1F22) else Color(0xFFFFFFFF)
    val headerBg = if (isDark) Color(0xFF2B2D30) else Color(0xFFF6F8FA)
    val headerText = if (isDark) Color(0xFFDFE1E5) else Color(0xFF1F2328)
    val itemBg = if (isDark) Color(0xFF2B2D30) else Color(0xFFF6F8FA)
    val itemText = if (isDark) Color(0xFFDFE1E5) else Color(0xFF1F2328)
    val accentFileText = if (isDark) Color(0xFF56A8F5) else Color(0xFF0969DA)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(bg)
    ) {
        // شريط العنوان
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(headerBg)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (problems.isEmpty()) Icons.Default.CheckCircle else Icons.Default.Error,
                contentDescription = null,
                tint = if (problems.isEmpty()) Color(0xFF36B86C) else Color(0xFFF75464),
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "الأخطاء البرمجية (${problems.size})",
                color = headerText,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.weight(1f))
            IconButton(onClick = onClose, modifier = Modifier.size(26.dp)) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إغلاق",
                    tint = if (isDark) Color(0xFF8C9298) else Color(0xFF656D76),
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        if (problems.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF36B86C),
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "لا توجد أخطاء في الكود (No problems found)",
                        color = if (isDark) Color(0xFF8C9298) else Color(0xFF656D76),
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(problems) { problem ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(itemBg)
                            .padding(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = if (problem.isError) Icons.Default.Error else Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (problem.isError) Color(0xFFF75464) else Color(0xFFF2C55C),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "${problem.fileName} (السطر: ${problem.line}, العمود: ${problem.column})",
                                color = accentFileText,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = problem.message,
                                color = itemText,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
