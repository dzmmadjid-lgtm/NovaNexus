package com.example.service

import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.model.PlaybackState
import com.example.model.YouTubeVideo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

object PlaybackManager {

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    // Command listener connected to the active player view
    var onCommandListener: ((String) -> Unit)? = null

    fun playVideo(context: Context, video: YouTubeVideo, queue: List<YouTubeVideo> = emptyList(), expand: Boolean = true) {
        val q = if (queue.isNotEmpty()) queue else listOf(video)
        val idx = q.indexOfFirst { it.id == video.id }.coerceAtLeast(0)

        _playbackState.update {
            it.copy(
                currentVideo = video,
                isPlaying = true,
                isPlayerExpanded = expand,
                queue = q,
                queueIndex = idx,
                currentPositionSeconds = 0f,
                isBackgroundPlaybackActive = true
            )
        }

        startOrUpdateBackgroundService(context, video, isPlaying = true)
        sendCommandToPlayer("loadVideoById('${video.id}')")
    }

    fun expandPlayer() {
        _playbackState.update { it.copy(isPlayerExpanded = true) }
    }

    fun collapsePlayer() {
        _playbackState.update { it.copy(isPlayerExpanded = false) }
    }

    fun togglePlayPause(context: Context) {
        val current = _playbackState.value
        val newState = !current.isPlaying
        _playbackState.update { it.copy(isPlaying = newState) }

        if (newState) {
            sendCommandToPlayer("playVideo()")
            current.currentVideo?.let { startOrUpdateBackgroundService(context, it, isPlaying = true) }
        } else {
            sendCommandToPlayer("pauseVideo()")
            current.currentVideo?.let { startOrUpdateBackgroundService(context, it, isPlaying = false) }
        }
    }

    fun playNext(context: Context) {
        val state = _playbackState.value
        if (state.queue.isNotEmpty()) {
            val nextIdx = (state.queueIndex + 1) % state.queue.size
            val nextVideo = state.queue[nextIdx]
            playVideo(context, nextVideo, state.queue, expand = state.isPlayerExpanded)
        }
    }

    fun playPrevious(context: Context) {
        val state = _playbackState.value
        if (state.queue.isNotEmpty()) {
            val prevIdx = if (state.queueIndex - 1 < 0) state.queue.size - 1 else state.queueIndex - 1
            val prevVideo = state.queue[prevIdx]
            playVideo(context, prevVideo, state.queue, expand = state.isPlayerExpanded)
        }
    }

    fun closePlayer(context: Context) {
        _playbackState.update {
            it.copy(
                currentVideo = null,
                isPlaying = false,
                isPlayerExpanded = false
            )
        }
        sendCommandToPlayer("stopVideo()")
        stopBackgroundService(context)
    }

    fun updateProgress(currentTime: Float, duration: Float) {
        _playbackState.update {
            it.copy(
                currentPositionSeconds = currentTime,
                durationSeconds = duration
            )
        }
    }

    fun updatePlayerState(isPlaying: Boolean) {
        _playbackState.update { it.copy(isPlaying = isPlaying) }
    }

    fun seekTo(seconds: Float) {
        sendCommandToPlayer("seekTo($seconds, true)")
    }

    fun sendCommandToPlayer(cmd: String) {
        try {
            onCommandListener?.invoke(cmd)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun startOrUpdateBackgroundService(context: Context, video: YouTubeVideo, isPlaying: Boolean) {
        try {
            val intent = Intent(context, BackgroundAudioService::class.java).apply {
                action = if (isPlaying) BackgroundAudioService.ACTION_PLAY else BackgroundAudioService.ACTION_PAUSE
                putExtra(BackgroundAudioService.EXTRA_VIDEO_TITLE, video.title)
                putExtra(BackgroundAudioService.EXTRA_CHANNEL_NAME, video.channelTitle)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopBackgroundService(context: Context) {
        try {
            val intent = Intent(context, BackgroundAudioService::class.java).apply {
                action = BackgroundAudioService.ACTION_STOP
            }
            context.startService(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
