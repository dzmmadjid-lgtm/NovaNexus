package com.example.service

import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.model.PlaybackState
import com.example.model.YouTubeVideo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

object PlaybackManager {

    private val _playbackState = MutableStateFlow(PlaybackState())
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    // JS Bridge callbacks & commands
    var onCommandListener: ((String) -> Unit)? = null

    fun playVideo(context: Context, video: YouTubeVideo, queue: List<YouTubeVideo> = emptyList()) {
        val q = if (queue.isNotEmpty()) queue else listOf(video)
        val idx = q.indexOfFirst { it.id == video.id }.coerceAtLeast(0)

        _playbackState.update {
            it.copy(
                currentVideo = video,
                isPlaying = true,
                isPlayerExpanded = true,
                queue = q,
                queueIndex = idx,
                currentPositionSeconds = 0f
            )
        }

        startOrUpdateBackgroundService(context, video, isPlaying = true)
        sendCommandToPlayer("loadVideoById('${video.id}')")
    }

    fun togglePlayPause(context: Context) {
        val current = _playbackState.value
        val newState = !current.isPlaying
        _playbackState.update { it.copy(isPlaying = newState) }

        if (newState) {
            sendCommandToPlayer("playVideo()")
            current.currentVideo?.let { startOrUpdateBackgroundService(context, it, true) }
        } else {
            sendCommandToPlayer("pauseVideo()")
            current.currentVideo?.let { startOrUpdateBackgroundService(context, it, false) }
        }
    }

    fun playNext(context: Context) {
        val state = _playbackState.value
        if (state.queue.isNotEmpty()) {
            val nextIdx = (state.queueIndex + 1) % state.queue.size
            val nextVideo = state.queue[nextIdx]
            playVideo(context, nextVideo, state.queue)
        }
    }

    fun playPrevious(context: Context) {
        val state = _playbackState.value
        if (state.queue.isNotEmpty()) {
            val prevIdx = if (state.queueIndex - 1 < 0) state.queue.size - 1 else state.queueIndex - 1
            val prevVideo = state.queue[prevIdx]
            playVideo(context, prevVideo, state.queue)
        }
    }

    fun setBackgroundPlayback(context: Context, enabled: Boolean) {
        _playbackState.update { it.copy(isBackgroundPlaybackActive = enabled) }
        val current = _playbackState.value
        if (enabled && current.currentVideo != null) {
            startOrUpdateBackgroundService(context, current.currentVideo, current.isPlaying)
        } else if (!enabled && !current.isPlaying) {
            stopBackgroundService(context)
        }
    }

    fun setExpanded(expanded: Boolean) {
        _playbackState.update { it.copy(isPlayerExpanded = expanded) }
    }

    fun closePlayer(context: Context) {
        _playbackState.update {
            it.copy(
                currentVideo = null,
                isPlaying = false,
                isPlayerExpanded = false
            )
        }
        sendCommandToPlayer("stopVideo()")
        stopBackgroundService(context)
    }

    fun updateProgress(currentTime: Float, duration: Float) {
        _playbackState.update {
            it.copy(
                currentPositionSeconds = currentTime,
                durationSeconds = duration
            )
        }
    }

    fun updatePlayerState(isPlaying: Boolean) {
        _playbackState.update { it.copy(isPlaying = isPlaying) }
    }

    fun seekTo(seconds: Float) {
        sendCommandToPlayer("seekTo($seconds, true)")
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackState.update { it.copy(playbackSpeed = speed) }
        sendCommandToPlayer("setPlaybackRate($speed)")
    }

    fun toggleLoop() {
        _playbackState.update { it.copy(isLooping = !it.isLooping) }
    }

    private fun sendCommandToPlayer(cmd: String) {
        onCommandListener?.invoke(cmd)
    }

    private fun startOrUpdateBackgroundService(context: Context, video: YouTubeVideo, isPlaying: Boolean) {
        val intent = Intent(context, BackgroundAudioService::class.java).apply {
            action = if (isPlaying) BackgroundAudioService.ACTION_PLAY else BackgroundAudioService.ACTION_PAUSE
            putExtra(BackgroundAudioService.EXTRA_VIDEO_ID, video.id)
            putExtra(BackgroundAudioService.EXTRA_VIDEO_TITLE, video.title)
            putExtra(BackgroundAudioService.EXTRA_CHANNEL_NAME, video.channelTitle)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopBackgroundService(context: Context) {
        val intent = Intent(context, BackgroundAudioService::class.java).apply {
            action = BackgroundAudioService.ACTION_STOP
        }
        try {
            context.startService(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
