package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

class BackgroundAudioService : Service() {

    companion object {
        const val CHANNEL_ID = "youtube_background_audio_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_PLAY = "com.example.action.PLAY"
        const val ACTION_PAUSE = "com.example.action.PAUSE"
        const val ACTION_TOGGLE = "com.example.action.TOGGLE"
        const val ACTION_NEXT = "com.example.action.NEXT"
        const val ACTION_PREV = "com.example.action.PREV"
        const val ACTION_STOP = "com.example.action.STOP"

        const val EXTRA_VIDEO_ID = "extra_video_id"
        const val EXTRA_VIDEO_TITLE = "extra_video_title"
        const val EXTRA_CHANNEL_NAME = "extra_channel_name"
    }

    private var currentVideoId: String? = null
    private var currentTitle: String = "تشغيل في الخلفية"
    private var currentChannel: String = "PlayTube"
    private var isPlaying: Boolean = false

    private var backgroundWebView: WebView? = null
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PlayTube::AudioWakeLock").apply {
            setReferenceCounted(false)
        }

        initBackgroundWebView()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun initBackgroundWebView() {
        try {
            backgroundWebView = WebView(applicationContext).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    cacheMode = WebSettings.LOAD_DEFAULT
                    userAgentString = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        when (action) {
            ACTION_STOP -> {
                stopForegroundPlayback()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> {
                PlaybackManager.togglePlayPause(this)
            }
            ACTION_NEXT -> {
                PlaybackManager.playNext(this)
            }
            ACTION_PREV -> {
                PlaybackManager.playPrevious(this)
            }
            ACTION_PLAY, ACTION_PAUSE -> {
                val vidId = intent.getStringExtra(EXTRA_VIDEO_ID)
                val title = intent.getStringExtra(EXTRA_VIDEO_TITLE)
                val channel = intent.getStringExtra(EXTRA_CHANNEL_NAME)

                if (!title.isNullOrBlank()) currentTitle = title
                if (!channel.isNullOrBlank()) currentChannel = channel

                val shouldPlay = (action == ACTION_PLAY)
                isPlaying = shouldPlay

                if (!vidId.isNullOrBlank() && vidId != currentVideoId) {
                    currentVideoId = vidId
                    loadVideoInBackground(vidId)
                } else {
                    updateBackgroundPlayerState(shouldPlay)
                }

                startForeground(NOTIFICATION_ID, buildNotification(isPlaying))

                if (shouldPlay) {
                    try {
                        if (wakeLock?.isHeld == false) {
                            wakeLock?.acquire(3 * 60 * 60 * 1000L) // 3 hours
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                } else {
                    try {
                        if (wakeLock?.isHeld == true) wakeLock?.release()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }

        return START_STICKY
    }

    private fun loadVideoInBackground(videoId: String) {
        val htmlData = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style>body { margin:0; background-color:black; overflow:hidden; }</style>
            </head>
            <body>
                <div id="player"></div>
                <script>
                    var tag = document.createElement('script');
                    tag.src = "https://www.youtube.com/iframe_api";
                    var firstScriptTag = document.getElementsByTagName('script')[0];
                    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

                    var player;
                    function onYouTubeIframeAPIReady() {
                        player = new YT.Player('player', {
                            height: '100%',
                            width: '100%',
                            videoId: '$videoId',
                            playerVars: {
                                'autoplay': 1,
                                'playsinline': 1,
                                'controls': 0,
                                'disablekb': 1,
                                'fs': 0,
                                'rel': 0
                            },
                            events: {
                                'onReady': onPlayerReady
                            }
                        });
                    }
                    function onPlayerReady(event) {
                        event.target.playVideo();
                    }
                </script>
            </body>
            </html>
        """.trimIndent()

        backgroundWebView?.loadDataWithBaseURL("https://www.youtube.com", htmlData, "text/html", "UTF-8", null)
    }

    private fun updateBackgroundPlayerState(play: Boolean) {
        val jsCmd = if (play) "if(player && player.playVideo){ player.playVideo(); }" else "if(player && player.pauseVideo){ player.pauseVideo(); }"
        backgroundWebView?.evaluateJavascript(jsCmd, null)
    }

    private fun buildNotification(playing: Boolean): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, BackgroundAudioService::class.java).apply { action = ACTION_TOGGLE },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val nextIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, BackgroundAudioService::class.java).apply { action = ACTION_NEXT },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val prevIntent = PendingIntent.getService(
            this,
            3,
            Intent(this, BackgroundAudioService::class.java).apply { action = ACTION_PREV },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this,
            4,
            Intent(this, BackgroundAudioService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val playPauseIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseTitle = if (playing) "إيقاف مؤقت" else "تشغيل"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(currentTitle)
            .setContentText("$currentChannel • تشغيل في الخلفية 🎧")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(contentIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(playing)
            .addAction(android.R.drawable.ic_media_previous, "السابق", prevIntent)
            .addAction(playPauseIcon, playPauseTitle, toggleIntent)
            .addAction(android.R.drawable.ic_media_next, "التالي", nextIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إغلاق", stopIntent)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("$currentChannel • تشغيل الصوت في الخلفية متواصل")
            )
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "PlayTube تشغيل الصوت في الخلفية",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعارات التحكم في تشغيل الصوت في الخلفية"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun stopForegroundPlayback() {
        isPlaying = false
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        try {
            backgroundWebView?.destroy()
            backgroundWebView = null
        } catch (e: Exception) {
            e.printStackTrace()
        }

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopForegroundPlayback()
        super.onDestroy()
    }
}
