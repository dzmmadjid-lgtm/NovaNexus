package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity

class BackgroundAudioService : Service() {

    companion object {
        const val CHANNEL_ID = "youtube_background_audio_channel_v2"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.action.START"
        const val ACTION_PLAY = "com.example.action.PLAY"
        const val ACTION_PAUSE = "com.example.action.PAUSE"
        const val ACTION_TOGGLE = "com.example.action.TOGGLE"
        const val ACTION_NEXT = "com.example.action.NEXT"
        const val ACTION_PREV = "com.example.action.PREV"
        const val ACTION_STOP = "com.example.action.STOP"

        const val EXTRA_VIDEO_TITLE = "extra_video_title"
        const val EXTRA_CHANNEL_NAME = "extra_channel_name"
    }

    private var currentTitle: String = "تشغيل يوتيوب في الخلفية"
    private var currentChannel: String = "PlayTube"
    private var isPlaying: Boolean = true
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()

        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PlayTube::AudioWakeLock").apply {
                setReferenceCounted(false)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        when (action) {
            ACTION_STOP -> {
                stopForegroundPlayback()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE -> {
                PlaybackManager.togglePlayPause(this)
            }
            ACTION_NEXT -> {
                PlaybackManager.playNext(this)
            }
            ACTION_PREV -> {
                PlaybackManager.playPrevious(this)
            }
            ACTION_PLAY, ACTION_PAUSE, ACTION_START -> {
                val title = intent?.getStringExtra(EXTRA_VIDEO_TITLE)
                val channel = intent?.getStringExtra(EXTRA_CHANNEL_NAME)

                if (!title.isNullOrBlank()) currentTitle = title
                if (!channel.isNullOrBlank()) currentChannel = channel

                isPlaying = (action != ACTION_PAUSE)

                val notification = buildNotification(isPlaying)

                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        startForeground(
                            NOTIFICATION_ID,
                            notification,
                            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
                        )
                    } else {
                        startForeground(NOTIFICATION_ID, notification)
                    }
                } catch (e: Exception) {
                    try {
                        startForeground(NOTIFICATION_ID, notification)
                    } catch (ex: Exception) {
                        ex.printStackTrace()
                    }
                }

                if (isPlaying) {
                    try {
                        if (wakeLock?.isHeld == false) {
                            wakeLock?.acquire(4 * 60 * 60 * 1000L) // 4 hours max
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                } else {
                    try {
                        if (wakeLock?.isHeld == true) wakeLock?.release()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }

        return START_STICKY
    }

    private fun buildNotification(playing: Boolean): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val toggleIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, BackgroundAudioService::class.java).apply { action = ACTION_TOGGLE },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val nextIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, BackgroundAudioService::class.java).apply { action = ACTION_NEXT },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = PendingIntent.getService(
            this,
            3,
            Intent(this, BackgroundAudioService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val playPauseIcon = if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        val playPauseTitle = if (playing) "إيقاف مؤقت" else "تشغيل"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(currentTitle)
            .setContentText("$currentChannel • تشغيل الصوت في الخلفية 🎧")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(contentIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(playing)
            .addAction(playPauseIcon, playPauseTitle, toggleIntent)
            .addAction(android.R.drawable.ic_media_next, "التالي", nextIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إغلاق", stopIntent)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("$currentTitle\n$currentChannel • الصوت مستمر في الخلفية")
            )
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "تشغيل يوتيوب في الخلفية",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعار التحكم بالصوت عند الخروج من التطبيق"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun stopForegroundPlayback() {
        isPlaying = false
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }

        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopForegroundPlayback()
        super.onDestroy()
    }
}
