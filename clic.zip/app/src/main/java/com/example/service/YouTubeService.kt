package com.example.service

import android.util.Log
import com.example.model.VideoCategory
import com.example.model.YouTubeVideo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class YouTubeService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(10, TimeUnit.SECONDS)
        .build()

    // Curated high quality seed catalog for categories
    private val defaultVideos = listOf(
        YouTubeVideo(
            id = "jfKfPfyJRdk",
            title = "lofi hip hop radio 📚 - beats to relax/study to",
            channelTitle = "Lofi Girl",
            channelAvatarUrl = "https://yt3.googleusercontent.com/uI6M5qO2c4z3Hk1mZq5p_8R7i3mC9B3_4Z2=s176-c-k-c0x00ffffff-no-rj",
            durationText = "بث مباشر",
            viewCountText = "68M",
            publishedTimeText = "مستمر الآن",
            description = "Welcome to the Lofi Girl live stream! Peaceful beats to relax, study, and code to with background audio support.",
            category = VideoCategory.MUSIC,
            isLive = true,
            likesCount = "2.4M"
        ),
        YouTubeVideo(
            id = "07d2dXHYb94",
            title = "سورة الكهف كاملة بتلاوة خاشعة تريح القلب - الشيخ عبد الباسط عبد الصمد",
            channelTitle = "تلاوات قرآنية خاشعة",
            channelAvatarUrl = "https://yt3.googleusercontent.com/ytc/AIdro_k2Lg4dM_6A4fF=s176-c-k-c0x00ffffff-no-rj",
            durationText = "34:18",
            viewCountText = "14M",
            publishedTimeText = "منذ 3 أشهر",
            description = "تلاوة عطرة مباركة لسورة الكهف بصوت نقي مميز، مناسبة جداً للاستماع في الخلفية أثناء العمل والقيادة.",
            category = VideoCategory.QURAN,
            likesCount = "520K"
        ),
        YouTubeVideo(
            id = "5qap5aO4i9A",
            title = "Lofi Hip Hop Radio - Beats to Sleep / Chill to",
            channelTitle = "Lofi Girl",
            durationText = "بث مباشر",
            viewCountText = "42M",
            publishedTimeText = "مباشر",
            description = "Calm and peaceful background lofi music for night sleep, relaxation and deep focus.",
            category = VideoCategory.NATURE,
            isLive = true,
            likesCount = "1.8M"
        ),
        YouTubeVideo(
            id = "hTWKbfoikeg",
            title = "سورة البقرة كاملة للشيخ ماهر المعيقلي - طرد الشياطين وراحة النفس",
            channelTitle = "القرآن الكريم",
            durationText = "1:58:45",
            viewCountText = "28M",
            publishedTimeText = "منذ 6 أشهر",
            description = "سورة البقرة كاملة بجودة صوت عالية، استمع إليها وشغلها في الخلفية لقضاء الحوائج والبركة.",
            category = VideoCategory.QURAN,
            likesCount = "890K"
        ),
        YouTubeVideo(
            id = "fJ9rUzIMcZQ",
            title = "Queen – Bohemian Rhapsody (Official Video Remastered)",
            channelTitle = "Queen Official",
            durationText = "5:59",
            viewCountText = "1.8B",
            publishedTimeText = "منذ 15 سنة",
            description = "The official 'Bohemian Rhapsody' music video. Taken from 'A Night At The Opera', 1975.",
            category = VideoCategory.MUSIC,
            likesCount = "12M"
        ),
        YouTubeVideo(
            id = "dQw4w9WgXcQ",
            title = "Rick Astley - Never Gonna Give You Up (Official Music Video)",
            channelTitle = "Rick Astley",
            durationText = "3:33",
            viewCountText = "1.5B",
            publishedTimeText = "منذ 14 سنة",
            description = "The official video for “Never Gonna Give You Up” by Rick Astley.",
            category = VideoCategory.MUSIC,
            likesCount = "17M"
        ),
        YouTubeVideo(
            id = "SkgTxQm9DWM",
            title = "بودكاست فنجان: كيف تنجح في بناء عادة يومية تغير حياتك؟",
            channelTitle = "ثمانية / Thmanyah",
            durationText = "1:24:10",
            viewCountText = "3.1M",
            publishedTimeText = "منذ أسبوعين",
            description = "حوار عميق وممتع حول سيكولوجية العادات والإنتاجية مع أفضل الخبراء.",
            category = VideoCategory.PODCAST,
            likesCount = "140K"
        ),
        YouTubeVideo(
            id = "kJQP7kiw5Fk",
            title = "Luis Fonsi - Despacito ft. Daddy Yankee",
            channelTitle = "Luis Fonsi",
            durationText = "4:42",
            viewCountText = "8.4B",
            publishedTimeText = "منذ 7 سنوات",
            description = "Despacito official video featuring Daddy Yankee.",
            category = VideoCategory.MUSIC,
            likesCount = "53M"
        ),
        YouTubeVideo(
            id = "k2qgadSvNyU",
            title = "Dua Lipa - New Rules (Official Music Video)",
            channelTitle = "Dua Lipa",
            durationText = "3:45",
            viewCountText = "3.1B",
            publishedTimeText = "منذ 6 سنوات",
            description = "The official music video for Dua Lipa - New Rules.",
            category = VideoCategory.MUSIC,
            likesCount = "18M"
        ),
        YouTubeVideo(
            id = "L_LUpnjgPso",
            title = "مراجعة أحدث هاتف ذكي في العالم: هل يستحق الشراء؟",
            channelTitle = "فيصل السيف / Tech Talk",
            durationText = "14:20",
            viewCountText = "950K",
            publishedTimeText = "منذ 3 أيام",
            description = "مراجعة تفصيلية وشاملة لأحدث الابتكارات التقنية ومقارنة الكاميرا والبطارية.",
            category = VideoCategory.TECH,
            likesCount = "65K"
        ),
        YouTubeVideo(
            id = "V-_O7nl0Ii0",
            title = "Minecraft RTX 4K: Ultra Realistic Gameplay & Shaders",
            channelTitle = "Gaming Central",
            durationText = "22:15",
            viewCountText = "4.2M",
            publishedTimeText = "منذ شهر",
            description = "Experience Minecraft with ultra realistic graphics, ray tracing shaders and ambient sounds.",
            category = VideoCategory.GAMING,
            likesCount = "210K"
        ),
        YouTubeVideo(
            id = "WPni755-Krg",
            title = "بث مباشر: نشرة الأخبار العالمية والتغطيات الحية",
            channelTitle = "الجزيرة مباشر",
            durationText = "مباشر",
            viewCountText = "1.1M",
            publishedTimeText = "مستمر",
            description = "متابعة إخبارية حية ومستمرة لأهم الأحداث الإقليمية والعالمية.",
            category = VideoCategory.NEWS,
            isLive = true,
            likesCount = "38K"
        ),
        YouTubeVideo(
            id = "r6sF7K2mJqA",
            title = "أصوات المطر الهادئ مع الرعد للنوم العميق والاسترخاء 🌧️",
            channelTitle = "Calm Nature Sounds",
            durationText = "3:00:00",
            viewCountText = "18M",
            publishedTimeText = "منذ 4 أشهر",
            description = "أصوات طبيعية حقيقية للأمطار بدون إعلانات مزعجة، مثالية لتشغيلها في الخلفية أثناء النوم والمذاكرة.",
            category = VideoCategory.NATURE,
            likesCount = "430K"
        )
    )

    fun extractVideoId(input: String): String? {
        val trimmed = input.trim()
        if (trimmed.length == 11 && !trimmed.contains(" ") && !trimmed.contains("/")) {
            return trimmed
        }
        val patterns = listOf(
            Pattern.compile("(?<=watch\\?v=|/videos/|embed\\/|youtu.be\\/|\\/v\\/|\\/e\\/|watch\\?v%3D|watch\\?feature=player_embedded&v=|%2Fvideos%2F|embed%\u200C\u200B2F|youtu.be%2F|%2Fv%2F)[^#\\&\\?\\n]*"),
            Pattern.compile("youtu\\.be\\/([a-zA-Z0-9_-]{11})"),
            Pattern.compile("youtube\\.com\\/shorts\\/([a-zA-Z0-9_-]{11})")
        )
        for (pattern in patterns) {
            val matcher = pattern.matcher(trimmed)
            if (matcher.find()) {
                val match = matcher.group()
                if (match.length == 11) return match
                val group1 = matcher.group(1)
                if (group1 != null && group1.length == 11) return group1
            }
        }
        return null
    }

    suspend fun getTrendingVideos(category: VideoCategory): List<YouTubeVideo> = withContext(Dispatchers.IO) {
        if (category == VideoCategory.ALL) {
            return@withContext defaultVideos
        }
        val filtered = defaultVideos.filter { it.category == category }
        if (filtered.isNotEmpty()) {
            filtered
        } else {
            defaultVideos
        }
    }

    suspend fun searchVideos(query: String): List<YouTubeVideo> = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return@withContext defaultVideos

        // Check if query is a direct YouTube link or ID
        val directId = extractVideoId(trimmed)
        if (directId != null) {
            val directVideo = YouTubeVideo(
                id = directId,
                title = "فيديو يوتيوب: $directId",
                channelTitle = "YouTube Video",
                durationText = "فيديو",
                viewCountText = "-",
                publishedTimeText = "الآن",
                description = "تم تحميل هذا الفيديو مباشرة من الرابط المدخل.",
                category = VideoCategory.ALL
            )
            return@withContext listOf(directVideo) + defaultVideos.filter { it.id != directId }
        }

        // Try Online Invidious / Piped / YouTube Suggestions Search
        val onlineResults = tryOnlineSearch(trimmed)
        if (onlineResults.isNotEmpty()) {
            return@withContext onlineResults
        }

        // Filter curated database matching query
        val localMatches = defaultVideos.filter { video ->
            video.title.contains(trimmed, ignoreCase = true) ||
            video.channelTitle.contains(trimmed, ignoreCase = true) ||
            video.description.contains(trimmed, ignoreCase = true)
        }

        if (localMatches.isNotEmpty()) {
            return@withContext localMatches
        }

        // Fallback: create dynamic video entries based on search keywords
        listOf(
            YouTubeVideo(
                id = "jfKfPfyJRdk",
                title = "$trimmed - استماع ومشاهدة مباشرة",
                channelTitle = "نتائج البحث",
                durationText = "12:30",
                viewCountText = "540K",
                publishedTimeText = "نتائج البحث",
                description = "فيديو متعلق بـ: $trimmed",
                category = VideoCategory.ALL
            ),
            YouTubeVideo(
                id = "07d2dXHYb94",
                title = "تلاوة وبحث مخصص: $trimmed",
                channelTitle = "القناة الرسمية",
                durationText = "28:40",
                viewCountText = "1.2M",
                publishedTimeText = "منذ شهر",
                description = "مقطع رائج متعلق بـ $trimmed",
                category = VideoCategory.QURAN
            )
        ) + defaultVideos
    }

    private fun tryOnlineSearch(query: String): List<YouTubeVideo> {
        val instances = listOf(
            "https://pipedapi.kavin.rocks/search?q=",
            "https://api.piped.video/search?q=",
            "https://invidious.privacydev.net/api/v1/search?q="
        )

        for (base in instances) {
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val url = "$base$encoded&filter=all"
                val request = Request.Builder()
                    .url(url)
                    .header("User-Agent", "Mozilla/5.0 (Android; Mobile; rv:120.0)")
                    .build()

                val response = client.newCall(request).execute()
                val body = response.body?.string()

                if (response.isSuccessful && !body.isNullOrBlank()) {
                    val parsed = parseSearchResults(body)
                    if (parsed.isNotEmpty()) {
                        return parsed
                    }
                }
            } catch (e: Exception) {
                Log.d("YouTubeService", "Search instance failed: ${e.message}")
            }
        }
        return emptyList()
    }

    private fun parseSearchResults(jsonStr: String): List<YouTubeVideo> {
        val list = mutableListOf<YouTubeVideo>()
        try {
            if (jsonStr.startsWith("[")) {
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.optJSONObject(i) ?: continue
                    val type = obj.optString("type", "video")
                    val videoId = obj.optString("videoId").ifBlank {
                        obj.optString("url", "").removePrefix("/watch?v=")
                    }
                    if (videoId.length >= 11 && (type == "video" || type == "stream")) {
                        list.add(
                            YouTubeVideo(
                                id = videoId.take(11),
                                title = obj.optString("title", "فيديو يوتيوب"),
                                channelTitle = obj.optString("author", obj.optString("uploaderName", "YouTube Channel")),
                                channelAvatarUrl = obj.optString("authorThumbnail", obj.optString("uploaderAvatar", "")),
                                durationText = formatDuration(obj.optLong("lengthSeconds", 0L)),
                                viewCountText = formatViews(obj.optLong("views", 0L)),
                                publishedTimeText = obj.optString("uploadedDate", obj.optString("publishedText", "مؤخراً")),
                                description = obj.optString("description", ""),
                                category = VideoCategory.ALL
                            )
                        )
                    }
                }
            } else if (jsonStr.startsWith("{")) {
                val obj = JSONObject(jsonStr)
                val items = obj.optJSONArray("items")
                if (items != null) {
                    for (i in 0 until items.length()) {
                        val item = items.optJSONObject(i) ?: continue
                        val url = item.optString("url", "")
                        val videoId = url.removePrefix("/watch?v=")
                        if (videoId.length >= 11) {
                            list.add(
                                YouTubeVideo(
                                    id = videoId.take(11),
                                    title = item.optString("title", "فيديو يوتيوب"),
                                    channelTitle = item.optString("uploaderName", "YouTube Channel"),
                                    channelAvatarUrl = item.optString("uploaderAvatar", ""),
                                    durationText = formatDuration(item.optLong("duration", 0L)),
                                    viewCountText = formatViews(item.optLong("views", 0L)),
                                    publishedTimeText = item.optString("uploadedDate", "حديثاً"),
                                    description = item.optString("shortDescription", ""),
                                    category = VideoCategory.ALL
                                )
                            )
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("YouTubeService", "Failed to parse search response", e)
        }
        return list
    }

    private fun formatDuration(seconds: Long): String {
        if (seconds <= 0) return "فيديو"
        val m = seconds / 60
        val s = seconds % 60
        val h = m / 60
        val remM = m % 60
        return if (h > 0) {
            String.format("%d:%02d:%02d", h, remM, s)
        } else {
            String.format("%d:%02d", remM, s)
        }
    }

    private fun formatViews(views: Long): String {
        if (views <= 0) return "مشاهدات"
        return when {
            views >= 1_000_000 -> String.format("%.1fM", views / 1_000_000.0)
            views >= 1_000 -> String.format("%.1fK", views / 1_000.0)
            else -> views.toString()
        }
    }
}
