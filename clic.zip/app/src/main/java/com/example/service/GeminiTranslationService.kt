package com.example.service

import android.net.Uri
import android.util.Log
import com.example.BuildConfig
import com.example.model.AppLanguage
import com.example.model.TranslationResult
import com.example.model.TranslationTone
import com.example.model.VocabularyItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class GeminiTranslationService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun translate(
        text: String,
        sourceLang: AppLanguage,
        targetLang: AppLanguage,
        tone: TranslationTone,
        userApiKey: String? = null
    ): Result<TranslationResult> = withContext(Dispatchers.IO) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) {
            return@withContext Result.success(TranslationResult())
        }

        // 1. Intelligent Script & Language Direction Auto-Correction
        val detectedInputLang = detectInputLanguage(trimmed)
        var effectiveSource = sourceLang
        var effectiveTarget = targetLang

        // If user typed Arabic while source is set to EN/FR -> Auto correct source to Arabic
        if (detectedInputLang == AppLanguage.ARABIC) {
            if (effectiveSource != AppLanguage.ARABIC) {
                effectiveSource = AppLanguage.ARABIC
                if (effectiveTarget == AppLanguage.ARABIC) {
                    effectiveTarget = if (sourceLang == AppLanguage.FRENCH) AppLanguage.FRENCH else AppLanguage.ENGLISH
                }
            }
        } else if (detectedInputLang == AppLanguage.ENGLISH || detectedInputLang == AppLanguage.FRENCH) {
            // If user typed Latin/English while source is set to Arabic -> Auto correct source to English/French
            if (effectiveSource == AppLanguage.ARABIC) {
                effectiveSource = detectedInputLang
                effectiveTarget = AppLanguage.ARABIC
            }
        }

        if (effectiveTarget == effectiveSource) {
            effectiveTarget = if (effectiveSource == AppLanguage.ARABIC) AppLanguage.ENGLISH else AppLanguage.ARABIC
        }

        // 2. Check curated high-value idioms & contextual phrases first
        val curatedResult = OfflineContextualTranslator.findCuratedIdiom(trimmed, effectiveSource, effectiveTarget, tone)
        if (curatedResult != null) {
            return@withContext Result.success(curatedResult)
        }

        // 3. Try Gemini API first if API key is provided
        val apiKey = if (!userApiKey.isNullOrBlank()) {
            userApiKey.trim()
        } else {
            val envKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Throwable) { "" }
            if (envKey.isNotBlank() && envKey != "MY_GEMINI_API_KEY") envKey else ""
        }

        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            val geminiResult = tryGeminiApi(trimmed, effectiveSource, effectiveTarget, tone, apiKey)
            if (geminiResult != null && geminiResult.translatedText.isNotBlank() && !geminiResult.translatedText.equals(trimmed, ignoreCase = true)) {
                return@withContext Result.success(geminiResult)
            }
        }

        // 4. Ultra-reliable High-Speed Neural Web Translation Service (Google GTX + Contextual Enricher)
        val onlineResult = tryOnlineNeuralTranslation(trimmed, effectiveSource, effectiveTarget, tone)
        if (onlineResult != null && onlineResult.translatedText.isNotBlank() && !onlineResult.translatedText.equals(trimmed, ignoreCase = true)) {
            return@withContext Result.success(onlineResult)
        }

        // 5. Offline contextual & vocabulary dictionary fallback
        val offlineFallback = OfflineContextualTranslator.translateContextual(trimmed, effectiveSource, effectiveTarget, tone)
        return@withContext Result.success(offlineFallback)
    }

    private fun detectInputLanguage(text: String): AppLanguage {
        val trimmed = text.trim()
        val arabicChars = trimmed.count { it in '\u0600'..'\u06FF' || it in '\u0750'..'\u077F' }
        if (arabicChars > 0 && arabicChars >= trimmed.length * 0.15) {
            return AppLanguage.ARABIC
        }

        val frenchMarkers = listOf("c'est", "l'", "d'", "qu'", "est-ce", "bonjour", "salut", "merci", "oui", "pourquoi", "comment", "avec", "dans", "être", "avoir", "faire")
        val lower = trimmed.lowercase()
        if (frenchMarkers.any { lower.contains(it) } || lower.any { it in "éèêëàâôûùçîï" }) {
            return AppLanguage.FRENCH
        }

        return AppLanguage.ENGLISH
    }

    private fun tryOnlineNeuralTranslation(
        text: String,
        sourceLang: AppLanguage,
        targetLang: AppLanguage,
        tone: TranslationTone
    ): TranslationResult? {
        return try {
            val sl = if (sourceLang == AppLanguage.AUTO) "auto" else sourceLang.code
            val tl = targetLang.code
            val encodedQuery = URLEncoder.encode(text, "UTF-8")

            val url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=$tl&dt=t&dt=bd&dt=rm&q=$encodedQuery"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Android; Mobile; rv:120.0)")
                .get()
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return null

            if (!response.isSuccessful) return null

            val jsonArray = JSONArray(responseBody)
            val sentencesArray = jsonArray.optJSONArray(0) ?: return null

            val translatedBuilder = StringBuilder()
            for (i in 0 until sentencesArray.length()) {
                val sentence = sentencesArray.optJSONArray(i)
                val segment = sentence?.optString(0)
                if (!segment.isNullOrBlank() && segment != "null") {
                    translatedBuilder.append(segment)
                }
            }

            val translatedText = translatedBuilder.toString().trim()
            if (translatedText.isEmpty()) return null

            // Detected source language from response
            val detectedLangCode = jsonArray.optString(2, sourceLang.code)
            val detectedLangName = when (detectedLangCode.lowercase()) {
                "ar" -> "العربية"
                "fr" -> "الفرنسية"
                "en" -> "الإنجليزية"
                else -> sourceLang.titleAr
            }

            // Extract Dictionary alternatives & vocabulary if available (index 1)
            val dictArray = jsonArray.optJSONArray(1)
            val vocabs = mutableListOf<VocabularyItem>()
            val alternatives = mutableListOf<String>()

            if (dictArray != null) {
                for (i in 0 until dictArray.length()) {
                    val entry = dictArray.optJSONArray(i)
                    val pos = entry?.optString(0) ?: "" // part of speech (noun, verb, etc)
                    val terms = entry?.optJSONArray(1)
                    if (terms != null) {
                        for (j in 0 until terms.length()) {
                            val term = terms.optString(j)
                            if (term.isNotBlank() && term != translatedText && !alternatives.contains(term)) {
                                if (alternatives.size < 4) {
                                    alternatives.add(term)
                                }
                            }
                        }
                    }
                }
            }

            // If it's a short phrase or single word, add to vocab breakdown
            if (text.split(Regex("\\s+")).size <= 4) {
                vocabs.add(
                    VocabularyItem(
                        word = text,
                        translation = translatedText,
                        note = "المعنى السياقي المباشر"
                    )
                )
            }

            val explanation = when (tone) {
                TranslationTone.CONTEXTUAL -> "ترجمة سياقية مباشرة ومطابقة للمعنى الحقيقي في لغة الهدف."
                TranslationTone.FORMAL -> "صياغة مهنية ودقيقة تناسب السياق الرسمي."
                TranslationTone.CASUAL -> "صياغة عفوية طبيعية تناسب المحادثة والتواصل اليومي."
                TranslationTone.LITERARY -> "صياغة بليغة ومعبرة تحافظ على رونق التعبير."
                TranslationTone.SIMPLIFIED -> "ترجمة واضحة ومباشرة الفهم."
            }

            TranslationResult(
                translatedText = translatedText,
                detectedSourceLanguage = detectedLangName,
                contextExplanation = explanation,
                alternativePhrasings = alternatives,
                vocabularyBreakdown = vocabs
            )
        } catch (e: Exception) {
            Log.e("NeuralTranslation", "Online translation error", e)
            null
        }
    }

    private fun tryGeminiApi(
        text: String,
        sourceLang: AppLanguage,
        targetLang: AppLanguage,
        tone: TranslationTone,
        apiKey: String
    ): TranslationResult? {
        val models = listOf("gemini-2.5-flash", "gemini-1.5-flash", "gemini-2.0-flash")
        val prompt = buildGeminiPrompt(text, sourceLang, targetLang, tone)

        for (modelName in models) {
            val geminiUrl = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"
            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", prompt))
                        })
                    })
                }
                put("contents", contentsArray)
                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.2)
                })
            }

            try {
                val request = Request.Builder()
                    .url(geminiUrl)
                    .post(requestJson.toString().toRequestBody(jsonMediaType))
                    .build()

                val response = client.newCall(request).execute()
                val responseBody = response.body?.string()

                if (response.isSuccessful && !responseBody.isNullOrBlank()) {
                    val parsed = parseGeminiResponse(responseBody, sourceLang)
                    if (parsed != null && parsed.translatedText.isNotBlank()) {
                        return parsed
                    }
                }
            } catch (e: Exception) {
                Log.w("GeminiAPI", "Model $modelName error: ${e.message}")
            }
        }
        return null
    }

    private fun parseGeminiResponse(responseBody: String, sourceLang: AppLanguage): TranslationResult? {
        return try {
            val parsedResponse = JSONObject(responseBody)
            val candidates = parsedResponse.optJSONArray("candidates")
            val contentObj = candidates?.optJSONObject(0)?.optJSONObject("content")
            val parts = contentObj?.optJSONArray("parts")
            val rawText = parts?.optJSONObject(0)?.optString("text") ?: return null

            val cleanedJson = rawText.trim()
                .removePrefix("```json")
                .removePrefix("```JSON")
                .removePrefix("```")
                .removeSuffix("```")
                .trim()

            val resObj = JSONObject(cleanedJson)
            val translatedText = resObj.optString("translatedText", "").trim()
            val detectedSource = resObj.optString("detectedSourceLanguage", sourceLang.titleAr)
            val explanation = resObj.optString("contextExplanation").takeIf { it.isNotBlank() }

            val altArray = resObj.optJSONArray("alternativePhrasings")
            val alts = mutableListOf<String>()
            if (altArray != null) {
                for (i in 0 until altArray.length()) {
                    alts.add(altArray.getString(i))
                }
            }

            val vocabArray = resObj.optJSONArray("vocabularyBreakdown")
            val vocabs = mutableListOf<VocabularyItem>()
            if (vocabArray != null) {
                for (i in 0 until vocabArray.length()) {
                    val vObj = vocabArray.getJSONObject(i)
                    vocabs.add(
                        VocabularyItem(
                            word = vObj.optString("word"),
                            translation = vObj.optString("translation"),
                            note = vObj.optString("note")
                        )
                    )
                }
            }

            TranslationResult(
                translatedText = translatedText,
                detectedSourceLanguage = detectedSource,
                contextExplanation = explanation,
                alternativePhrasings = alts,
                vocabularyBreakdown = vocabs
            )
        } catch (e: Exception) {
            Log.e("GeminiAPI", "JSON parsing failed", e)
            null
        }
    }

    private fun buildGeminiPrompt(
        text: String,
        sourceLang: AppLanguage,
        targetLang: AppLanguage,
        tone: TranslationTone
    ): String {
        return """
        You are an expert translator between Arabic, English, and French.
        Translate the following text accurately into ${targetLang.titleNative}:
        \"\"\"
        $text
        \"\"\"

        Return JSON strictly matching:
        {
          "translatedText": "Translated text",
          "detectedSourceLanguage": "Detected source language name in Arabic",
          "contextExplanation": "1 sentence explaining the nuance or context in Arabic",
          "alternativePhrasings": ["Alternative 1", "Alternative 2"],
          "vocabularyBreakdown": [{"word": "word", "translation": "translation", "note": "note"}]
        }
        """.trimIndent()
    }
}
