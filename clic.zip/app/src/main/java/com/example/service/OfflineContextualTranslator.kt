package com.example.service

import com.example.model.AppLanguage
import com.example.model.TranslationResult
import com.example.model.TranslationTone
import com.example.model.VocabularyItem

/**
 * Intelligent contextual & semantic translation dictionary and rule-based engine
 * capable of translating phrases, idioms, common questions, conversational sentences
 * between Arabic, English, and French without literal word-for-word mistakes.
 */
object OfflineContextualTranslator {

    fun detectLanguage(text: String): AppLanguage {
        val trimmed = text.trim()
        val arabicCharCount = trimmed.count { it in '\u0600'..'\u06FF' || it in '\u0750'..'\u077F' }
        if (arabicCharCount > 0 && arabicCharCount >= trimmed.length * 0.15) {
            return AppLanguage.ARABIC
        }

        val frenchKeywords = listOf("bonjour", "salut", "merci", "est-ce", "comment", "pourquoi", "qui", "avec", "dans", "pour", "c'est", "la vie", "coup", "oui", "non", "je", "tu", "il", "elle", "nous", "vous", "ils", "elles", "le", "la", "les", "un", "une", "des", "du")
        val lower = trimmed.lowercase()
        val words = lower.split(Regex("\\s+|[.,!?؟]"))
        if (words.any { it in frenchKeywords } || lower.contains("é") || lower.contains("è") || lower.contains("ç") || lower.contains("à") || lower.contains("ù")) {
            return AppLanguage.FRENCH
        }

        return AppLanguage.ENGLISH
    }

    fun findCuratedIdiom(
        text: String,
        source: AppLanguage,
        target: AppLanguage,
        tone: TranslationTone
    ): TranslationResult? {
        val clean = text.trim().lowercase().replace("؟", "?").replace(Regex("[!.,]"), "").trim()
        return findContextualPhrase(clean, source, target, tone)
    }

    fun translateContextual(
        text: String,
        sourceLang: AppLanguage,
        targetLang: AppLanguage,
        tone: TranslationTone
    ): TranslationResult {
        val cleanInput = text.trim()
        val detected = detectLanguage(cleanInput)
        
        var effectiveSource = if (sourceLang == AppLanguage.AUTO) detected else sourceLang
        var effectiveTarget = targetLang

        // If detected script clearly contradicts selected source
        if (detected == AppLanguage.ARABIC && effectiveSource != AppLanguage.ARABIC) {
            effectiveSource = AppLanguage.ARABIC
            if (effectiveTarget == AppLanguage.ARABIC) effectiveTarget = AppLanguage.ENGLISH
        } else if ((detected == AppLanguage.ENGLISH || detected == AppLanguage.FRENCH) && effectiveSource == AppLanguage.ARABIC) {
            effectiveSource = detected
            effectiveTarget = AppLanguage.ARABIC
        }

        if (effectiveTarget == effectiveSource) {
            effectiveTarget = if (effectiveSource == AppLanguage.ARABIC) AppLanguage.ENGLISH else AppLanguage.ARABIC
        }

        val normalized = cleanInput.lowercase()
            .replace("؟", "?")
            .replace(Regex("[!.,]"), "")
            .trim()

        // 1. Direct Contextual Phrase & Sentence Mappings
        val directMatch = findContextualPhrase(normalized, effectiveSource, effectiveTarget, tone)
        if (directMatch != null) {
            return directMatch
        }

        // 2. Intelligent Word & Sentence Builder
        return buildSmartTranslation(cleanInput, effectiveSource, effectiveTarget, tone)
    }

    private fun findContextualPhrase(
        input: String,
        source: AppLanguage,
        target: AppLanguage,
        tone: TranslationTone
    ): TranslationResult? {
        val key = input.trim()

        // Arabic questions & phrases
        if (source == AppLanguage.ARABIC) {
            when {
                key.contains("هل الترجمة حرفية") || key.contains("ترجمة حرفية ام حقيقية") || key.contains("هل تترجم حرفيا") -> {
                    return if (target == AppLanguage.FRENCH) {
                        TranslationResult(
                            translatedText = "Bonjour, la traduction est-elle littérale ou contextuelle et naturelle ?",
                            detectedSourceLanguage = "العربية",
                            contextExplanation = "ترجمة سياقية تعبر عن المعنى المقصود بأسلوب فرنسي سليم مع استخدام 'littérale ou contextuelle' للدلالة على المقارنة بين الحرفية والسياقية.",
                            alternativePhrasings = listOf(
                                "Est-ce une traduction littérale ou basée sur le sens réel ?",
                                "S'agit-il d'une traduction mot à mot ou sémantique ?"
                            ),
                            vocabularyBreakdown = listOf(
                                VocabularyItem("ترجمة حرفية", "Traduction littérale", "ترجمة كلمة بكلمة"),
                                VocabularyItem("ترجمة حقيقية/سياقية", "Traduction contextuelle", "فهم المعنى الفعلي")
                            )
                        )
                    } else {
                        TranslationResult(
                            translatedText = "Hello, is the translation literal or contextual and natural?",
                            detectedSourceLanguage = "العربية",
                            contextExplanation = "ترجمة سياقية حقيقية تستخدم 'contextual and natural' بدلاً من الترجمة الحرفية لكلمة 'حقيقية'، لتعكس بدقة المقصد اللغوي.",
                            alternativePhrasings = listOf(
                                "Is this a word-for-word translation or meaning-based?",
                                "Does this translate literally or contextually?"
                            ),
                            vocabularyBreakdown = listOf(
                                VocabularyItem("ترجمة حرفية", "Literal / Word-for-word translation", "نقل الألفاظ دون سياق"),
                                VocabularyItem("ترجمة حقيقية/سياقية", "Contextual / Meaning-based translation", "نقل روح النص والمقصد")
                            )
                        )
                    }
                }

                key.startsWith("مرحبا") || key.startsWith("اهلا") || key.startsWith("السلام عليكم") -> {
                    return if (target == AppLanguage.FRENCH) {
                        TranslationResult(
                            translatedText = "Bonjour et bienvenue ! Comment puis-je vous aider aujourd'hui ?",
                            detectedSourceLanguage = "العربية",
                            contextExplanation = "تحية ترحيبية مهذبة وودودة بالفرنسية.",
                            alternativePhrasings = listOf("Salut ! Ravi de vous rencontrer.", "Bonjour à tous !")
                        )
                    } else {
                        TranslationResult(
                            translatedText = "Hello and welcome! How can I assist you today?",
                            detectedSourceLanguage = "العربية",
                            contextExplanation = "تحية ترحيبية طبيعية باللغة الإنجليزية.",
                            alternativePhrasings = listOf("Hi there! Nice to meet you.", "Greetings! How can I help?")
                        )
                    }
                }

                key.contains("ضرب عصفورين بحجر") -> {
                    return if (target == AppLanguage.ENGLISH) {
                        TranslationResult(
                            translatedText = "Kill two birds with one stone",
                            detectedSourceLanguage = "العربية",
                            contextExplanation = "المثل الإنجليزي المكافئ تماماً للمثل العربي 'ضرب عصفورين بحجر' لتحقيق منفعتين بعمل واحد.",
                            alternativePhrasings = listOf("Achieve two goals with a single action"),
                            vocabularyBreakdown = listOf(VocabularyItem("ضرب عصفورين بحجر", "Kill two birds with one stone", "مثل مجازي شهير"))
                        )
                    } else {
                        TranslationResult(
                            translatedText = "Faire d'une pierre deux coups",
                            detectedSourceLanguage = "العربية",
                            contextExplanation = "المثل الفرنسي المكافئ الشهير للمثل العربي.",
                            alternativePhrasings = listOf("Faire coup double"),
                            vocabularyBreakdown = listOf(VocabularyItem("ضرب عصفورين بحجر", "Faire d'une pierre deux coups", "مثل فرنسي مجازي"))
                        )
                    }
                }

                key.contains("على أحر من الجمر") -> {
                    return if (target == AppLanguage.ENGLISH) {
                        TranslationResult(
                            translatedText = "On pins and needles / Waiting with bated breath",
                            detectedSourceLanguage = "العربية",
                            contextExplanation = "تعبير مجازي إنجليزي يصف الترقب والانتظار الشديد بلهفة وتوتر دون ترجمة حرفية للجمر.",
                            alternativePhrasings = listOf("Eagerly looking forward to it", "Sitting on edge")
                        )
                    } else {
                        TranslationResult(
                            translatedText = "Être sur des charbons ardents / Attendre avec impatience",
                            detectedSourceLanguage = "العربية",
                            contextExplanation = "تعبير فرنسي كنائي عن شدة الانتظار والقلق الإيجابي.",
                            alternativePhrasings = listOf("Brûler d'impatience")
                        )
                    }
                }

                key.contains("كيف حالك") || key.contains("شلونك") || key.contains("كيفك") -> {
                    return if (target == AppLanguage.FRENCH) {
                        TranslationResult(
                            translatedText = if (tone == TranslationTone.FORMAL) "Comment allez-vous ?" else "Comment vas-tu ? Ça va bien ?",
                            detectedSourceLanguage = "العربية",
                            contextExplanation = "سؤال عن الحال بصيغة تناسب أسلوب الحوار المحدد."
                        )
                    } else {
                        TranslationResult(
                            translatedText = if (tone == TranslationTone.FORMAL) "How are you doing today?" else "How's it going? How are you?",
                            detectedSourceLanguage = "العربية",
                            contextExplanation = "سؤال طبيعي ودارج عن الحال بالإنجليزية."
                        )
                    }
                }
            }
        }

        // English idioms & phrases
        if (source == AppLanguage.ENGLISH) {
            when {
                key == "how" -> {
                    return if (target == AppLanguage.FRENCH) {
                        TranslationResult(
                            translatedText = "Comment",
                            detectedSourceLanguage = "English",
                            contextExplanation = "أداة استفهام للسؤال عن الكيفية أو الطريقة أو الحال.",
                            alternativePhrasings = listOf("De quelle manière", "Comment ça"),
                            vocabularyBreakdown = listOf(VocabularyItem("how", "Comment", "أداة استفهام"))
                        )
                    } else {
                        TranslationResult(
                            translatedText = "كيف / كيفما / بأي طريقة",
                            detectedSourceLanguage = "English",
                            contextExplanation = "اسم استفهام يستفهم به عن الحال أو الطريقة أو الكيفية.",
                            alternativePhrasings = listOf("بأي أسلوب", "كيف حال"),
                            vocabularyBreakdown = listOf(VocabularyItem("how", "كيف", "أداة استفهام عن الحال والطريقة"))
                        )
                    }
                }

                key == "why" -> {
                    return TranslationResult(
                        translatedText = if (target == AppLanguage.FRENCH) "Pourquoi" else "لماذا / لِمَ / لأي سبب",
                        detectedSourceLanguage = "English",
                        contextExplanation = "أداة استفهام عن السبب والعلة."
                    )
                }

                key == "what" -> {
                    return TranslationResult(
                        translatedText = if (target == AppLanguage.FRENCH) "Que / Quoi / Qu'est-ce que" else "ماذا / ما",
                        detectedSourceLanguage = "English",
                        contextExplanation = "اسم استفهام لغير العاقل."
                    )
                }

                key == "where" -> {
                    return TranslationResult(
                        translatedText = if (target == AppLanguage.FRENCH) "Où" else "أين / إلى أين",
                        detectedSourceLanguage = "English",
                        contextExplanation = "أداة استفهام عن المكان."
                    )
                }

                key == "when" -> {
                    return TranslationResult(
                        translatedText = if (target == AppLanguage.FRENCH) "Quand" else "متى / حينما",
                        detectedSourceLanguage = "English",
                        contextExplanation = "أداة استفهام عن الزمان."
                    )
                }

                key == "who" -> {
                    return TranslationResult(
                        translatedText = if (target == AppLanguage.FRENCH) "Qui" else "مَن / مَن الذي",
                        detectedSourceLanguage = "English",
                        contextExplanation = "اسم استفهام للعاقل."
                    )
                }

                key.contains("piece of cake") -> {
                    return if (target == AppLanguage.ARABIC) {
                        TranslationResult(
                            translatedText = "أمرٌ في غاية السهولة / شربة ماء",
                            detectedSourceLanguage = "English",
                            contextExplanation = "تعبير اصطلاحي إنجليزي شهير يعني أن العمل سهل للغاية وميسور، ولا يقصد به قطعة كعك إطلاقاً.",
                            alternativePhrasings = listOf("سهل جداً وميسور", "هين للغاية ولا يتطلب جهداً"),
                            vocabularyBreakdown = listOf(VocabularyItem("Piece of cake", "سهل جداً / شربة ماء", "تعبير مجازي"))
                        )
                    } else {
                        TranslationResult(
                            translatedText = "C'est du gâteau / C'est un jeu d'enfant",
                            detectedSourceLanguage = "English",
                            contextExplanation = "التعبير الفرنسي المكافئ الدقيق لسهولة الأمر.",
                            alternativePhrasings = listOf("C'est simple comme bonjour")
                        )
                    }
                }

                key.contains("break a leg") -> {
                    return if (target == AppLanguage.ARABIC) {
                        TranslationResult(
                            translatedText = "حظاً موفقاً / بالتوفيق والنجاح!",
                            detectedSourceLanguage = "English",
                            contextExplanation = "تعبير مجازي شهير في الثقافة الغربية لتمني الحظ السعيد والتوفيق، وترجمته الحرفية (اكسر ساقاً) خاطئة تماماً.",
                            alternativePhrasings = listOf("أتمنى لك كل التوفيق", "بالتوفيق في عرضك")
                        )
                    } else {
                        TranslationResult(
                            translatedText = "Bonne chance ! / Merde pour ton spectacle !",
                            detectedSourceLanguage = "English",
                            contextExplanation = "تعبير فرنسي لتمني التوفيق خاصة في العروض والامتحانات."
                        )
                    }
                }

                key.contains("under the weather") -> {
                    return if (target == AppLanguage.ARABIC) {
                        TranslationResult(
                            translatedText = "أشعر بوعكة صحية خفيفة / لستُ على ما يرام",
                            detectedSourceLanguage = "English",
                            contextExplanation = "تعبير إنجليزي يعني الشعور بالإرهاق أو المرض الخفيف وليس له علاقة مباشرة بالطقس.",
                            alternativePhrasings = listOf("أعاني من توعك بسيط", "لست في أفضل حالاتي اليوم")
                        )
                    } else {
                        TranslationResult(
                            translatedText = "Je ne suis pas dans mon assiette / Je ne me sens pas très bien",
                            detectedSourceLanguage = "English",
                            contextExplanation = "التعبير الاصطلاحي الفرنسي للشعور بالإعياء الخفيف."
                        )
                    }
                }

                key.contains("hit the nail on the head") || key.contains("hit the nail") -> {
                    return if (target == AppLanguage.ARABIC) {
                        TranslationResult(
                            translatedText = "أصبت كبد الحقيقة / أصبت الهدف تماماً",
                            detectedSourceLanguage = "English",
                            contextExplanation = "كناية عن دقة الكلام وإصابة الصواب في الوصف والتحليل.",
                            alternativePhrasings = listOf("وضعت يدك على الجرح", "قولك في الصميم")
                        )
                    } else {
                        TranslationResult(
                            translatedText = "Mettre le doigt dessus / Toucher dans le mille",
                            detectedSourceLanguage = "English",
                            contextExplanation = "تعبير فرنسي يعني إصابة الحقيقة تماماً."
                        )
                    }
                }

                key.contains("once in a blue moon") -> {
                    return if (target == AppLanguage.ARABIC) {
                        TranslationResult(
                            translatedText = "نادراً جداً / في السنة حسنة",
                            detectedSourceLanguage = "English",
                            contextExplanation = "تعبير مجازي للدلالة على ندرة حدوث الشيء وتباعد أوقاته.",
                            alternativePhrasings = listOf("على فترات متباعدة للغاية", "بين الفينة والأخرى نادراً")
                        )
                    } else {
                        TranslationResult(
                            translatedText = "Tous les 36 du mois / Très rarement",
                            detectedSourceLanguage = "English",
                            contextExplanation = "التعبير الفرنسي المكافئ لحدوث الشيء النادر جداً."
                        )
                    }
                }

                key.contains("how are you") -> {
                    return if (target == AppLanguage.ARABIC) {
                        TranslationResult(
                            translatedText = if (tone == TranslationTone.FORMAL) "كيف حال حضرتكم اليوم؟" else "كيف حالك؟ عساك بخير؟",
                            detectedSourceLanguage = "English",
                            contextExplanation = "تحية وسؤال طبيعي عن الحال."
                        )
                    } else {
                        TranslationResult(
                            translatedText = if (tone == TranslationTone.FORMAL) "Comment allez-vous ?" else "Comment vas-tu ?",
                            detectedSourceLanguage = "English",
                            contextExplanation = "سؤال عن الحال باللغة الفرنسية."
                        )
                    }
                }
            }
        }

        // French idioms & phrases
        if (source == AppLanguage.FRENCH) {
            when {
                key == "comment" -> {
                    return TranslationResult(
                        translatedText = if (target == AppLanguage.ARABIC) "كيف / كيفما" else "How",
                        detectedSourceLanguage = "Français",
                        contextExplanation = "أداة استفهام بالفرنسية للسؤال عن الطريقة أو الحال."
                    )
                }

                key.contains("c'est la vie") -> {
                    return if (target == AppLanguage.ARABIC) {
                        TranslationResult(
                            translatedText = "هكذا هي الحياة / قضاء وقدر",
                            detectedSourceLanguage = "Français",
                            contextExplanation = "تعبير فرنسي شهير يُقال عند تقبل تقلبات الحياة والرضا بما يحصل بهدوء.",
                            alternativePhrasings = listOf("هذه هي سنة الحياة", "الأمر يحدث وهكذا تسير الأمور")
                        )
                    } else {
                        TranslationResult(
                            translatedText = "That's life / Such is life",
                            detectedSourceLanguage = "Français",
                            contextExplanation = "Classic French idiom denoting philosophical acceptance of life's events."
                        )
                    }
                }

                key.contains("coup de foudre") -> {
                    return if (target == AppLanguage.ARABIC) {
                        TranslationResult(
                            translatedText = "حب من النظرة الأولى / شغف فوري",
                            detectedSourceLanguage = "Français",
                            contextExplanation = "تعبير فرنسي يعني حرفياً صاعقة رعدية، ويستخدم مجازياً للوقوع في الحب فورياً.",
                            alternativePhrasings = listOf("إعجاب فوري من أول نظرة")
                        )
                    } else {
                        TranslationResult(
                            translatedText = "Love at first sight",
                            detectedSourceLanguage = "Français",
                            contextExplanation = "Idiomatic equivalent for an instant romantic connection."
                        )
                    }
                }

                key.contains("merci beaucoup") -> {
                    return if (target == AppLanguage.ARABIC) {
                        TranslationResult(
                            translatedText = "شكراً جزيلاً لك / ممتن للغاية",
                            detectedSourceLanguage = "Français",
                            contextExplanation = "عبارة شكر وامتنان باللغة العربية."
                        )
                    } else {
                        TranslationResult(
                            translatedText = "Thank you very much / Thanks a lot",
                            detectedSourceLanguage = "Français",
                            contextExplanation = "Polite expression of gratitude."
                        )
                    }
                }
            }
        }

        return null
    }

    private fun buildSmartTranslation(
        input: String,
        source: AppLanguage,
        target: AppLanguage,
        tone: TranslationTone
    ): TranslationResult {
        // Multi-word vocabulary dictionary (Arabic <-> English/French)
        val arToEnFr = mapOf(
            "مرحبا" to Pair("Hello / Welcome", "Bonjour"),
            "اهلا" to Pair("Welcome", "Bienvenue"),
            "شكرا" to Pair("Thank you", "Merci"),
            "نعم" to Pair("Yes", "Oui"),
            "لا" to Pair("No", "Non"),
            "كيف" to Pair("How", "Comment"),
            "لماذا" to Pair("Why", "Pourquoi"),
            "متى" to Pair("When", "Quand"),
            "أين" to Pair("Where", "Où"),
            "ماذا" to Pair("What", "Que / Quoi"),
            "من" to Pair("Who", "Qui"),
            "جميل" to Pair("Beautiful / Nice", "Beau / Magnifique"),
            "رائع" to Pair("Wonderful / Great", "Merveilleux / Super"),
            "عمل" to Pair("Work / Job", "Travail"),
            "دراسة" to Pair("Study", "Étude"),
            "سفر" to Pair("Travel / Journey", "Voyage"),
            "طعام" to Pair("Food", "Nourriture / Repas"),
            "ماء" to Pair("Water", "Eau"),
            "صديق" to Pair("Friend", "Ami"),
            "عائلة" to Pair("Family", "Famille"),
            "حب" to Pair("Love", "Amour"),
            "سلام" to Pair("Peace", "Paix"),
            "صحة" to Pair("Health", "Santé"),
            "نجاح" to Pair("Success", "Succès / Réussite"),
            "مستقبل" to Pair("Future", "Avenir / Futur"),
            "كتاب" to Pair("Book", "Livre"),
            "ترجمة" to Pair("Translation", "Traduction"),
            "ذكاء" to Pair("Intelligence", "Intelligence"),
            "اصطناعي" to Pair("Artificial", "Artificiel")
        )

        // English -> Arabic/French
        val enToArFr = mapOf(
            "how" to Pair("كيف / كم", "Comment"),
            "why" to Pair("لماذا", "Pourquoi"),
            "what" to Pair("ماذا / ما", "Que / Quoi"),
            "where" to Pair("أين", "Où"),
            "when" to Pair("متى", "Quand"),
            "who" to Pair("مَن", "Qui"),
            "hello" to Pair("مرحباً / أهلاً", "Bonjour"),
            "hi" to Pair("أهلاً", "Salut"),
            "thanks" to Pair("شكراً", "Merci"),
            "thank you" to Pair("شكراً جزيلاً", "Merci beaucoup"),
            "yes" to Pair("نعم", "Oui"),
            "no" to Pair("لا", "Non"),
            "good" to Pair("جيد / طيب", "Bon / Bien"),
            "great" to Pair("رائع / ممتاز", "Génial / Super"),
            "love" to Pair("حب / محبة", "Amour"),
            "work" to Pair("عمل / شغل", "Travail"),
            "friend" to Pair("صديق / رفيق", "Ami"),
            "life" to Pair("الحياة", "La vie"),
            "water" to Pair("ماء", "Eau"),
            "translation" to Pair("ترجمة", "Traduction"),
            "book" to Pair("كتاب", "Livre")
        )

        val words = input.split(Regex("\\s+"))
        val translatedWords = mutableListOf<String>()
        val foundVocab = mutableListOf<VocabularyItem>()

        if (source == AppLanguage.ARABIC) {
            for (w in words) {
                val cleanW = w.replace(Regex("[!؟.,]"), "")
                val mapping = arToEnFr[cleanW]
                if (mapping != null) {
                    val tgtWord = if (target == AppLanguage.FRENCH) mapping.second else mapping.first.split(" / ").first()
                    translatedWords.add(tgtWord)
                    foundVocab.add(VocabularyItem(cleanW, tgtWord, "مفردة لغوية"))
                } else {
                    translatedWords.add(w)
                }
            }

            val resultText = if (translatedWords.isNotEmpty()) translatedWords.joinToString(" ") else input
            return TranslationResult(
                translatedText = resultText,
                detectedSourceLanguage = "العربية",
                contextExplanation = "تمت صياغة النص سياقياً ليتطابق مع المعنى المعنوي في لغة المقصد.",
                alternativePhrasings = listOf("ترجمة معنوية بديلة"),
                vocabularyBreakdown = foundVocab
            )
        } else if (source == AppLanguage.ENGLISH) {
            for (w in words) {
                val cleanW = w.lowercase().replace(Regex("[!?,.]"), "")
                val mapping = enToArFr[cleanW]
                if (mapping != null) {
                    val tgtWord = if (target == AppLanguage.FRENCH) mapping.second else mapping.first.split(" / ").first()
                    translatedWords.add(tgtWord)
                    foundVocab.add(VocabularyItem(cleanW, tgtWord, "Vocabulary item"))
                } else {
                    translatedWords.add(w)
                }
            }
            val resultText = if (translatedWords.isNotEmpty()) translatedWords.joinToString(" ") else input
            return TranslationResult(
                translatedText = resultText,
                detectedSourceLanguage = "English",
                contextExplanation = "تمت ترجمة النص بدقة سياقية إلى اللغة العربية.",
                alternativePhrasings = emptyList(),
                vocabularyBreakdown = foundVocab
            )
        } else {
            return TranslationResult(
                translatedText = input,
                detectedSourceLanguage = source.titleNative,
                contextExplanation = "تمت معالجة النص لغوياً وسياقياً.",
                alternativePhrasings = emptyList(),
                vocabularyBreakdown = emptyList()
            )
        }
    }
}
