package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonRed
import com.example.viewmodel.CalculatorUiState
import com.example.viewmodel.CashierField

@Composable
fun ChangeCalculatorDialog(
    state: CalculatorUiState,
    isDark: Boolean,
    onSelectField: (CashierField) -> Unit,
    onDigit: (String) -> Unit,
    onDelete: () -> Unit,
    onClear: () -> Unit,
    onQuickAdd: (Double) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        // Dark aesthetic matching screenshot
        val dialogBg = if (isDark) Color(0xFF18181B) else Color(0xFFFFFFFF)
        val dialogBorder = if (isDark) Color(0xFF2E2E33) else Color(0xFFE4E4E7)
        val fieldBg = if (isDark) Color(0xFF27272A) else Color(0xFFF4F4F5)
        val fieldActiveBorder = if (isDark) NeonGreen else Color(0xFF16A34A)
        val textWhite = if (isDark) Color(0xFFFFFFFF) else Color(0xFF18181B)
        val textMuted = if (isDark) Color(0xFFA1A1AA) else Color(0xFF71717A)
        val resultCardBg = if (isDark) Color(0xFF141416) else Color(0xFFF9FAFB)
        val resultCardBorder = if (isDark) Color(0xFF27272A) else Color(0xFFE5E7EB)
        val greenColor = if (isDark) Color(0xFF22C55E) else Color(0xFF16A34A)
        val redColor = if (isDark) Color(0xFFEF4444) else Color(0xFFDC2626)
        val closeBtnBg = if (isDark) Color(0xFF27272A) else Color(0xFFE4E4E7)
        val closeBtnText = if (isDark) Color(0xFFFFFFFF) else Color(0xFF18181B)

        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(22.dp))
                .border(1.dp, dialogBorder, RoundedCornerShape(22.dp)),
            color = dialogBg
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 20.dp)
                    .verticalScroll(scrollState),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Title: 💵 حساب الصرف
                Text(
                    text = "💵 حساب الصرف",
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    color = greenColor,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Field 1: ثمن السلعة
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "ثمن السلعة",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = textMuted,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    val isItemActive = state.activeCashierField == CashierField.ITEM_PRICE
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(fieldBg)
                            .border(
                                width = if (isItemActive) 1.5.dp else 1.dp,
                                color = if (isItemActive) fieldActiveBorder else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onSelectField(CashierField.ITEM_PRICE) }
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.CenterEnd
                    ) {
                        Text(
                            text = if (state.itemPriceInput.isEmpty()) "0" else state.itemPriceInput,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (state.itemPriceInput.isEmpty()) textMuted.copy(alpha = 0.6f) else textWhite,
                            textAlign = TextAlign.End,
                            maxLines = 1
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Field 2: المبلغ المدفوع
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "المبلغ المدفوع",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = textMuted,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    val isPaidActive = state.activeCashierField == CashierField.AMOUNT_PAID
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(fieldBg)
                            .border(
                                width = if (isPaidActive) 1.5.dp else 1.dp,
                                color = if (isPaidActive) fieldActiveBorder else Color.Transparent,
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onSelectField(CashierField.AMOUNT_PAID) }
                            .padding(horizontal = 16.dp),
                        contentAlignment = Alignment.CenterEnd
                    ) {
                        Text(
                            text = if (state.amountPaidInput.isEmpty()) "0" else state.amountPaidInput,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (state.amountPaidInput.isEmpty()) textMuted.copy(alpha = 0.6f) else textWhite,
                            textAlign = TextAlign.End,
                            maxLines = 1
                        )
                    }
                }

                // Quick Cash Buttons (+100, +200, +500, +1000, +2000) for rapid entry
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(100.0, 200.0, 500.0, 1000.0, 2000.0).forEach { cash ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isDark) Color(0xFF27272A) else Color(0xFFE4E4E7))
                                .clickable { onQuickAdd(cash) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "+${cash.toInt()} دج",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = greenColor
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Result Box: الصرف (الباقي)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(resultCardBg)
                        .border(1.dp, resultCardBorder, RoundedCornerShape(16.dp))
                        .padding(vertical = 16.dp, horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        // Title: الصرف (الباقي)
                        Text(
                            text = "الصرف (الباقي)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = textMuted,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Large Numeric Value
                        if (state.isCashShortage) {
                            Text(
                                text = "المبلغ غير كافٍ",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = redColor,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "ينقص: ${if (state.shortageAmount % 1.0 == 0.0) state.shortageAmount.toLong() else state.shortageAmount} دج",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = redColor,
                                textAlign = TextAlign.Center
                            )
                        } else {
                            val changeVal = state.remainingChange
                            val changeText = if (changeVal % 1.0 == 0.0) changeVal.toLong().toString() else changeVal.toString()
                            Text(
                                text = changeText,
                                fontSize = 38.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = greenColor,
                                textAlign = TextAlign.Center
                            )
                        }

                        // Tafqeet in Arabic Words
                        val tafqeetDisplay = if (state.isCashShortage) {
                            ""
                        } else if (state.changeTafqeet.isNotEmpty()) {
                            state.changeTafqeet
                        } else if (state.remainingChange == 0.0 && state.itemPriceInput.isNotEmpty() && state.amountPaidInput.isNotEmpty()) {
                            "صفر دينار جزائري (المبلغ مضبوط)"
                        } else {
                            ""
                        }

                        if (tafqeetDisplay.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = tafqeetDisplay,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isDark) Color(0xFFF4F4F5) else Color(0xFF18181B),
                                textAlign = TextAlign.Center,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Compact Keypad inside Dialog for fast typing
                DialogMiniKeypad(
                    isDark = isDark,
                    onDigit = onDigit,
                    onDelete = onDelete
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom Buttons: Left: "إغلاق", Right: "مسح الخانات"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Close Button (Dark / Light gray)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(closeBtnBg)
                            .clickable { onDismiss() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "إغلاق",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = closeBtnText
                        )
                    }

                    // Clear Fields Button (Red)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(redColor)
                            .clickable { onClear() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "مسح الخانات",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DialogMiniKeypad(
    isDark: Boolean,
    onDigit: (String) -> Unit,
    onDelete: () -> Unit
) {
    val keyBg = if (isDark) Color(0xFF27272A) else Color(0xFFF4F4F5)
    val textCol = if (isDark) Color(0xFFFFFFFF) else Color(0xFF18181B)

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // Row 1: 7, 8, 9
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("7", "8", "9").forEach { num ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(keyBg)
                        .clickable { onDigit(num) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = num, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = textCol)
                }
            }
        }

        // Row 2: 4, 5, 6
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("4", "5", "6").forEach { num ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(keyBg)
                        .clickable { onDigit(num) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = num, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = textCol)
                }
            }
        }

        // Row 3: 1, 2, 3
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf("1", "2", "3").forEach { num ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(42.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(keyBg)
                        .clickable { onDigit(num) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = num, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = textCol)
                }
            }
        }

        // Row 4: 0, 00, ⌫
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(keyBg)
                    .clickable { onDigit("0") },
                contentAlignment = Alignment.Center
            ) {
                Text(text = "0", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = textCol)
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(keyBg)
                    .clickable { onDigit("00") },
                contentAlignment = Alignment.Center
            ) {
                Text(text = "00", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = textCol)
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isDark) Color(0xFF3F3F46) else Color(0xFFE4E4E7))
                    .clickable { onDelete() },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Backspace,
                    contentDescription = "حذف",
                    tint = if (isDark) Color(0xFFEF4444) else Color(0xFFDC2626),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
