package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.viewmodel.MainAppViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(
    viewModel: MainAppViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.dismissSnackbar()
        }
    }

    val isDark = uiState.isDarkTheme
    val bgGradient = if (isDark) {
        Brush.verticalGradient(listOf(Color(0xFF0F172A), Color(0xFF090D16)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFFF8FAFC), Color(0xFFEDF2F7)))
    }

    val surfaceColor = if (isDark) Color(0xFF1E293B) else Color.White
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val textSecondary = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
    val accentCyan = Color(0xFF06B6D4)
    val accentEmerald = Color(0xFF10B981)
    val borderCol = if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)

    var showConfigDialog by remember { mutableStateOf(false) }
    var showWorkflowYamlDialog by remember { mutableStateOf(false) }

    val zipPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.onZipFileSelected(it) }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Brush.linearGradient(listOf(Color(0xFF3B82F6), accentCyan))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (uiState.currentSection == MainAppSection.BUILDER) Icons.Default.CloudSync else Icons.Default.Inventory2,
                                contentDescription = "Logo",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (uiState.currentSection == MainAppSection.BUILDER) "APK Cloud Builder" else "APK Extractor",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = textPrimary
                            )
                            Text(
                                text = if (uiState.currentSection == MainAppSection.BUILDER) "GitHub Actions CI/CD Runner" else "استخراج الحزم ومشاركتها",
                                style = MaterialTheme.typography.bodySmall,
                                color = textSecondary
                            )
                        }
                    }
                },
                actions = {
                    if (uiState.currentSection == MainAppSection.BUILDER) {
                        IconButton(
                            onClick = { showConfigDialog = true },
                            modifier = Modifier.testTag("github_config_btn")
                        ) {
                            Icon(
                                imageVector = if (uiState.gitHubConfig.isConfigured) Icons.Default.SettingsSuggest else Icons.Default.Settings,
                                contentDescription = "إعدادات GitHub",
                                tint = if (uiState.gitHubConfig.isConfigured) accentEmerald else textSecondary
                            )
                        }
                    }
                    IconButton(
                        onClick = { viewModel.toggleTheme() },
                        modifier = Modifier.testTag("theme_toggle_btn")
                    ) {
                        Icon(
                            imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "تبديل المظهر",
                            tint = textSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = if (isDark) Color(0xFF0F172A) else Color(0xFFF8FAFC)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = if (isDark) Color(0xFF0F172A) else Color.White,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = uiState.currentSection == MainAppSection.BUILDER,
                    onClick = { viewModel.switchSection(MainAppSection.BUILDER) },
                    icon = { Icon(Icons.Default.CloudQueue, contentDescription = "البناء السحابي") },
                    label = { Text("بناء الـ APK") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF3B82F6),
                        selectedTextColor = Color(0xFF3B82F6),
                        unselectedIconColor = textSecondary,
                        unselectedTextColor = textSecondary,
                        indicatorColor = Color(0xFF3B82F6).copy(alpha = 0.15f)
                    )
                )
                NavigationBarItem(
                    selected = uiState.currentSection == MainAppSection.EXTRACTOR,
                    onClick = { viewModel.switchSection(MainAppSection.EXTRACTOR) },
                    icon = { Icon(Icons.Default.Apps, contentDescription = "مستخرج APK") },
                    label = { Text("مستخرج الحزم") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = accentEmerald,
                        selectedTextColor = accentEmerald,
                        unselectedIconColor = textSecondary,
                        unselectedTextColor = textSecondary,
                        indicatorColor = accentEmerald.copy(alpha = 0.15f)
                    )
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(bgGradient)
                .padding(padding)
        ) {
            when (uiState.currentSection) {
                MainAppSection.BUILDER -> {
                    BuilderSectionContent(
                        uiState = uiState,
                        onSelectZip = { zipPickerLauncher.launch("application/zip") },
                        onStartBuild = { viewModel.startCloudBuild() },
                        onOpenSettings = { showConfigDialog = true },
                        onShowWorkflow = { showWorkflowYamlDialog = true },
                        onInstallApk = { file -> viewModel.installApk(file) },
                        onShareApk = { file -> viewModel.shareApk(file) }
                    )
                }
                MainAppSection.EXTRACTOR -> {
                    ExtractorSectionContent(
                        uiState = uiState,
                        onCategoryChanged = { cat -> viewModel.setExtractorCategory(cat) },
                        onSearchChanged = { q -> viewModel.onSearchQueryChanged(q) },
                        onExtractApp = { app -> viewModel.extractSingleApp(app) },
                        onInstallApk = { file -> viewModel.installApk(file) },
                        onShareApk = { file -> viewModel.shareApk(file) }
                    )
                }
            }
        }
    }

    if (showConfigDialog) {
        GitHubConfigDialog(
            currentConfig = uiState.gitHubConfig,
            isVerifying = uiState.isVerifyingRepo,
            verificationMsg = uiState.repoVerificationMessage,
            isDark = isDark,
            onDismiss = { showConfigDialog = false },
            onSave = { tok, owner, repo, wf, br ->
                viewModel.saveGitHubConfig(tok, owner, repo, wf, br)
            }
        )
    }

    if (showWorkflowYamlDialog) {
        WorkflowTemplateDialog(
            isDark = isDark,
            onDismiss = { showWorkflowYamlDialog = false }
        )
    }
}

@Composable
fun BuilderSectionContent(
    uiState: CombinedAppState,
    onSelectZip: () -> Unit,
    onStartBuild: () -> Unit,
    onOpenSettings: () -> Unit,
    onShowWorkflow: () -> Unit,
    onInstallApk: (File) -> Unit,
    onShareApk: (File) -> Unit
) {
    val scrollState = rememberScrollState()
    val isDark = uiState.isDarkTheme
    val surfaceColor = if (isDark) Color(0xFF1E293B) else Color.White
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val textSecondary = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
    val accentEmerald = Color(0xFF10B981)
    val accentCyan = Color(0xFF06B6D4)
    val borderCol = if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // GitHub Connection Status Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = surfaceColor),
            border = androidx.compose.foundation.BorderStroke(1.dp, borderCol)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(
                                if (uiState.gitHubConfig.isConfigured) accentEmerald.copy(alpha = 0.15f)
                                else Color(0xFFF59E0B).copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (uiState.gitHubConfig.isConfigured) Icons.Default.CheckCircle else Icons.Default.WarningAmber,
                            contentDescription = null,
                            tint = if (uiState.gitHubConfig.isConfigured) accentEmerald else Color(0xFFF59E0B),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (uiState.gitHubConfig.isConfigured) "متصل بـ GitHub Runner" else "GitHub غير مربوط",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = textPrimary
                        )
                        Text(
                            text = if (uiState.gitHubConfig.isConfigured) "${uiState.gitHubConfig.owner}/${uiState.gitHubConfig.repo}" else "اضغط لربط التوكن والمستودع",
                            style = MaterialTheme.typography.bodySmall,
                            color = textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                FilledTonalButton(
                    onClick = onOpenSettings,
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(if (uiState.gitHubConfig.isConfigured) "تعديل" else "ربط الآن", fontSize = 12.sp)
                }
            }
        }

        // Project ZIP Import Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = surfaceColor),
            border = androidx.compose.foundation.BorderStroke(1.dp, borderCol)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "١. اختيار ملف المشروع المضغوط (ZIP)",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = textPrimary
                )
                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isDark) Color(0xFF0F172A) else Color(0xFFF1F5F9))
                        .border(
                            width = 1.5.dp,
                            color = if (uiState.selectedZipFile != null) accentEmerald else Color(0xFF3B82F6).copy(alpha = 0.5f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .clickable { onSelectZip() }
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = if (uiState.selectedZipFile != null) Icons.Default.FolderZip else Icons.Default.CloudUpload,
                            contentDescription = "Upload ZIP",
                            tint = if (uiState.selectedZipFile != null) accentEmerald else Color(0xFF3B82F6),
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (uiState.selectedZipFile != null) uiState.zipFileName else "اضغط هنا لاختيار ملف المشروع (.ZIP)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = textPrimary,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = if (uiState.selectedZipFile != null) "الحجم: ${uiState.zipFileSizeFormatted} (اضغط للتغيير)" else "يدعم مشاريع Kotlin / Java / Flutter / React Native",
                            style = MaterialTheme.typography.bodySmall,
                            color = textSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                // Detected Project Info
                uiState.detectedProject?.let { proj ->
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(proj.projectType.badgeColorHex).copy(alpha = 0.1f))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = Color(proj.projectType.badgeColorHex),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "النوع المكتشف: ${proj.projectType.title}",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color(proj.projectType.badgeColorHex)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "محرك البناء: ${proj.buildTools}",
                                style = MaterialTheme.typography.bodySmall,
                                color = textPrimary
                            )
                        }
                    }
                }
            }
        }

        // Action Trigger Button
        Button(
            onClick = onStartBuild,
            enabled = !uiState.isBuilding && uiState.gitHubConfig.isConfigured,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("start_cloud_build_btn"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF3B82F6),
                disabledContainerColor = Color(0xFF3B82F6).copy(alpha = 0.4f)
            )
        ) {
            if (uiState.isBuilding) {
                CircularProgressIndicator(
                    color = Color.White,
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.5.dp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("جاري البناء على خادم GitHub...", color = Color.White, fontWeight = FontWeight.Bold)
            } else {
                Icon(Icons.Default.RocketLaunch, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "بدء البناء السحابي وتوليد APK جديد",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }
        }

        // Live Progress & Result Card
        if (uiState.isBuilding || uiState.builtApkFile != null || uiState.buildLogs.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = surfaceColor),
                border = androidx.compose.foundation.BorderStroke(1.dp, borderCol)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "سجل البناء السحابي (Live CI Logs)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = textPrimary
                        )
                        Text(
                            text = "${uiState.buildProgressPercent}%",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = if (uiState.builtApkFile != null) accentEmerald else Color(0xFF3B82F6)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { uiState.buildProgressPercent / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (uiState.builtApkFile != null) accentEmerald else Color(0xFF3B82F6),
                        trackColor = if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = uiState.buildStatusText,
                        style = MaterialTheme.typography.bodySmall,
                        color = textSecondary
                    )

                    // Success Install Card
                    uiState.builtApkFile?.let { apkFile ->
                        Spacer(modifier = Modifier.height(14.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(accentEmerald.copy(alpha = 0.12f))
                                .border(1.dp, accentEmerald.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                .padding(16.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = accentEmerald, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "تم بناء وتنزيل حزمة APK الأصلية بنجاح!",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                        color = accentEmerald
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "${apkFile.name} • جاهز للتثبيت المباشر كتطبيق جديد ومستقل.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = textPrimary
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { onInstallApk(apkFile) },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.buttonColors(containerColor = accentEmerald),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(Icons.Default.Android, contentDescription = null, tint = Color.White)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("تثبيت الـ APK الآن", color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                    OutlinedButton(
                                        onClick = { onShareApk(apkFile) },
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null)
                                    }
                                }
                            }
                        }
                    }

                    // Terminal Logs Box
                    Spacer(modifier = Modifier.height(14.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 200.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF090D16))
                            .padding(10.dp)
                    ) {
                        LazyColumn {
                            items(uiState.buildLogs) { log ->
                                Row(modifier = Modifier.padding(vertical = 2.dp)) {
                                    Text(
                                        text = "[${log.timestamp}] ",
                                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                        color = Color(0xFF64748B),
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = log.message,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = if (log.isStepHeader) FontWeight.Bold else FontWeight.Normal
                                        ),
                                        color = when {
                                            log.isError -> Color(0xFFEF4444)
                                            log.isSuccess -> Color(0xFF10B981)
                                            log.isStepHeader -> Color(0xFF38BDF8)
                                            else -> Color(0xFFCBD5E1)
                                        },
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Quick Workflow Helper
        TextButton(
            onClick = onShowWorkflow,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        ) {
            Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("عرض ملف GitHub Actions Workflow (.github/workflows/build-apk.yml)")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtractorSectionContent(
    uiState: CombinedAppState,
    onCategoryChanged: (AppCategory) -> Unit,
    onSearchChanged: (String) -> Unit,
    onExtractApp: (InstalledAppInfo) -> Unit,
    onInstallApk: (File) -> Unit,
    onShareApk: (File) -> Unit
) {
    val isDark = uiState.isDarkTheme
    val surfaceColor = if (isDark) Color(0xFF1E293B) else Color.White
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val textSecondary = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
    val accentEmerald = Color(0xFF10B981)
    val borderCol = if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)

    val displayedApps = when (uiState.selectedCategory) {
        AppCategory.USER_APPS -> uiState.userApps.filter {
            it.appName.contains(uiState.searchQuery, ignoreCase = true) ||
            it.packageName.contains(uiState.searchQuery, ignoreCase = true)
        }
        AppCategory.SYSTEM_APPS -> uiState.systemApps.filter {
            it.appName.contains(uiState.searchQuery, ignoreCase = true) ||
            it.packageName.contains(uiState.searchQuery, ignoreCase = true)
        }
        AppCategory.EXTRACTED_APKS -> emptyList()
    }

    val displayedExtracted = if (uiState.selectedCategory == AppCategory.EXTRACTED_APKS) {
        uiState.extractedApks.filter { it.fileName.contains(uiState.searchQuery, ignoreCase = true) }
    } else emptyList()

    Column(modifier = Modifier.fillMaxSize()) {
        // Search & Category Tabs
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (isDark) Color(0xFF0F172A) else Color(0xFFF8FAFC))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            OutlinedTextField(
                value = uiState.searchQuery,
                onValueChange = onSearchChanged,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("بحث باسم التطبيق أو اسم الحزمة...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = textSecondary) },
                trailingIcon = {
                    if (uiState.searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchChanged("") }) {
                            Icon(Icons.Default.Close, contentDescription = "مسح")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = accentEmerald,
                    unfocusedBorderColor = borderCol
                )
            )

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = uiState.selectedCategory == AppCategory.USER_APPS,
                    onClick = { onCategoryChanged(AppCategory.USER_APPS) },
                    label = { Text("تطبيقاتي (${uiState.userApps.size})") }
                )
                FilterChip(
                    selected = uiState.selectedCategory == AppCategory.SYSTEM_APPS,
                    onClick = { onCategoryChanged(AppCategory.SYSTEM_APPS) },
                    label = { Text("النظام (${uiState.systemApps.size})") }
                )
                FilterChip(
                    selected = uiState.selectedCategory == AppCategory.EXTRACTED_APKS,
                    onClick = { onCategoryChanged(AppCategory.EXTRACTED_APKS) },
                    label = { Text("المستخرجة (${uiState.extractedApks.size})") }
                )
            }
        }

        // List Content
        if (uiState.selectedCategory == AppCategory.EXTRACTED_APKS) {
            if (displayedExtracted.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("لا توجد حزم مستخرجة حتى الآن", color = textSecondary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    items(displayedExtracted) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = surfaceColor),
                            border = androidx.compose.foundation.BorderStroke(1.dp, borderCol)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.Android, contentDescription = null, tint = accentEmerald, modifier = Modifier.size(32.dp))
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(item.fileName, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = textPrimary, maxLines = 1)
                                        Text("${item.fileSizeFormatted} • ${item.lastModifiedFormatted}", style = MaterialTheme.typography.bodySmall, color = textSecondary)
                                    }
                                }
                                Row {
                                    IconButton(onClick = { onInstallApk(File(item.filePath)) }) {
                                        Icon(Icons.Default.DownloadForOffline, contentDescription = "تثبيت", tint = accentEmerald)
                                    }
                                    IconButton(onClick = { onShareApk(File(item.filePath)) }) {
                                        Icon(Icons.Default.Share, contentDescription = "مشاركة", tint = Color(0xFF3B82F6))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (displayedApps.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("لا توجد نتائج مطابقة", color = textSecondary)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 12.dp)
                ) {
                    items(displayedApps) { app ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = surfaceColor),
                            border = androidx.compose.foundation.BorderStroke(1.dp, borderCol)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFF3B82F6).copy(alpha = 0.1f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Android, contentDescription = null, tint = Color(0xFF3B82F6))
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(app.appName, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = textPrimary, maxLines = 1)
                                        Text("${app.packageName} • v${app.versionName} (${app.apkSizeFormatted})", style = MaterialTheme.typography.bodySmall, color = textSecondary, maxLines = 1)
                                    }
                                }
                                Button(
                                    onClick = { onExtractApp(app) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = accentEmerald),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.SaveAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("استخراج", fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GitHubConfigDialog(
    currentConfig: GitHubConfig,
    isVerifying: Boolean,
    verificationMsg: String?,
    isDark: Boolean,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, String) -> Unit
) {
    var token by remember { mutableStateOf(currentConfig.token) }
    var owner by remember { mutableStateOf(currentConfig.owner) }
    var repo by remember { mutableStateOf(currentConfig.repo) }
    var workflow by remember { mutableStateOf(currentConfig.workflowFileName) }
    var branch by remember { mutableStateOf(currentConfig.branch) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CloudSync, contentDescription = null, tint = Color(0xFF3B82F6))
                Spacer(modifier = Modifier.width(8.dp))
                Text("إعدادات GitHub Actions Runner", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "أدخل بيانات حسابك ومستودع البناء لتشغيل الـ Actions تلقائياً:",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF64748B)
                )

                OutlinedTextField(
                    value = token,
                    onValueChange = { token = it },
                    label = { Text("GitHub Personal Access Token (PAT)") },
                    placeholder = { Text("ghp_xxxxxxxxxxxx") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = owner,
                    onValueChange = { owner = it },
                    label = { Text("اسم المستخدم / المنظمة (Username/Org)") },
                    placeholder = { Text("مثال: myusername") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = repo,
                    onValueChange = { repo = it },
                    label = { Text("اسم المستودع (Repository Name)") },
                    placeholder = { Text("مثال: android-apk-builder") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = workflow,
                    onValueChange = { workflow = it },
                    label = { Text("اسم ملف الـ Workflow") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = branch,
                    onValueChange = { branch = it },
                    label = { Text("الفرع الافتراضي (Default Branch)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                verificationMsg?.let { msg ->
                    Text(
                        text = msg,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (msg.contains("نجاح") || msg.contains("✅")) Color(0xFF10B981) else Color(0xFFEF4444)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(token, owner, repo, workflow, branch) },
                enabled = !isVerifying
            ) {
                if (isVerifying) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White)
                } else {
                    Text("حفظ واختبار الاتصال")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}

@Composable
fun WorkflowTemplateDialog(
    isDark: Boolean,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val template = """
name: Build Android APK

on:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Make gradlew executable
        run: chmod +x ./gradlew || true

      - name: Build with Gradle
        run: ./gradlew assembleDebug || gradle assembleDebug

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: app-release-apk
          path: '**/build/outputs/apk/**/*.apk'
          retention-days: 7
""".trimIndent()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ملف GitHub Actions Workflow", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "أنشئ هذا الملف في مستودعك بالمسار:\n.github/workflows/build-apk.yml",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF3B82F6),
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF090D16))
                        .padding(10.dp)
                ) {
                    Text(
                        text = template,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                        color = Color(0xFF38BDF8),
                        fontSize = 10.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("GitHub Workflow", template)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(context, "تم نسخ كود الـ Workflow للحافظة!", Toast.LENGTH_SHORT).show()
            }) {
                Icon(Icons.Default.ContentCopy, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("نسخ الكود")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إغلاق")
            }
        }
    )
}
