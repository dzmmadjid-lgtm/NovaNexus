package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.VideoLibrary
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppThemeMode
import com.example.ui.components.ThemeSelectorDialog
import com.example.ui.components.VideoPlayerDialog
import com.example.ui.theme.TikTokCyan
import com.example.ui.theme.TikTokPink
import com.example.viewmodel.TikDownloaderViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TikDownloaderMainScreen(
    viewModel: TikDownloaderViewModel
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showThemeDialog by remember { mutableStateOf(false) }

    val currentTheme by viewModel.themeMode.collectAsState()
    val previewVideoUrl by viewModel.previewVideoUrl.collectAsState()
    val previewVideoTitle by viewModel.previewVideoTitle.collectAsState()
    val savedDownloads by viewModel.savedDownloads.collectAsState()
    val activeDownloads by viewModel.activeDownloads.collectAsState()

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Iconic TikTok glowing logo
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(TikTokPink, TikTokCyan)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "TS",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    fontSize = 14.sp
                                ),
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Text(
                            text = "TokSave",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showThemeDialog = true },
                        modifier = Modifier.testTag("theme_switch_button")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(
                                    when (currentTheme) {
                                        AppThemeMode.OLED -> Color.Black
                                        AppThemeMode.DARK -> Color(0xFF1E1E28)
                                        AppThemeMode.LIGHT -> Color(0xFFE8EAED)
                                    }
                                )
                                .border(
                                    width = 1.5.dp,
                                    color = when (currentTheme) {
                                        AppThemeMode.OLED -> TikTokCyan
                                        AppThemeMode.DARK -> TikTokPink
                                        AppThemeMode.LIGHT -> Color(0xFFB0B0B0)
                                    },
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (currentTheme) {
                                    AppThemeMode.OLED -> Icons.Default.DarkMode
                                    AppThemeMode.DARK -> Icons.Default.Palette
                                    AppThemeMode.LIGHT -> Icons.Default.LightMode
                                },
                                contentDescription = "تغيير المظهر",
                                tint = when (currentTheme) {
                                    AppThemeMode.OLED -> TikTokCyan
                                    AppThemeMode.DARK -> TikTokPink
                                    AppThemeMode.LIGHT -> Color(0xFFFFA000)
                                },
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp
            ) {
                // Tab 0: Downloader
                NavigationBarItem(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    icon = {
                        val activeCount = activeDownloads.size
                        if (activeCount > 0) {
                            BadgedBox(
                                badge = {
                                    Badge(
                                        containerColor = TikTokPink,
                                        contentColor = Color.White
                                    ) {
                                        Text(activeCount.toString())
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (selectedTabIndex == 0) Icons.Default.CloudDownload else Icons.Outlined.CloudDownload,
                                    contentDescription = "الرئيسية"
                                )
                            }
                        } else {
                            Icon(
                                imageVector = if (selectedTabIndex == 0) Icons.Default.CloudDownload else Icons.Outlined.CloudDownload,
                                contentDescription = "الرئيسية"
                            )
                        }
                    },
                    label = { Text("الرئيسية") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = TikTokPink,
                        indicatorColor = TikTokPink,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )

                // Tab 1: Library
                NavigationBarItem(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    icon = {
                        val savedCount = savedDownloads.size
                        if (savedCount > 0) {
                            BadgedBox(
                                badge = {
                                    Badge(
                                        containerColor = TikTokCyan,
                                        contentColor = Color.Black
                                    ) {
                                        Text(savedCount.toString())
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (selectedTabIndex == 1) Icons.Default.VideoLibrary else Icons.Outlined.VideoLibrary,
                                    contentDescription = "المكتبة"
                                )
                            }
                        } else {
                            Icon(
                                imageVector = if (selectedTabIndex == 1) Icons.Default.VideoLibrary else Icons.Outlined.VideoLibrary,
                                contentDescription = "المكتبة"
                            )
                        }
                    },
                    label = { Text("المكتبة") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.Black,
                        selectedTextColor = TikTokCyan,
                        indicatorColor = TikTokCyan,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )

                // Tab 2: Settings
                NavigationBarItem(
                    selected = selectedTabIndex == 2,
                    onClick = { selectedTabIndex = 2 },
                    icon = {
                        Icon(
                            imageVector = if (selectedTabIndex == 2) Icons.Default.Settings else Icons.Outlined.Settings,
                            contentDescription = "الإعدادات"
                        )
                    },
                    label = { Text("الإعدادات") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color.White,
                        selectedTextColor = MaterialTheme.colorScheme.onSurface,
                        indicatorColor = MaterialTheme.colorScheme.surfaceVariant,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTabIndex) {
                0 -> DownloaderTab(viewModel = viewModel)
                1 -> LibraryTab(viewModel = viewModel)
                2 -> SettingsTab(
                    viewModel = viewModel,
                    onOpenThemeDialog = { showThemeDialog = true }
                )
            }
        }
    }

    // Video Player Preview Dialog
    previewVideoUrl?.let { url ->
        VideoPlayerDialog(
            videoUrl = url,
            title = previewVideoTitle,
            onDismiss = { viewModel.closePreview() }
        )
    }

    // Theme Selection Dialog
    if (showThemeDialog) {
        ThemeSelectorDialog(
            currentTheme = currentTheme,
            onSelectTheme = { viewModel.setThemeMode(it) },
            onDismiss = { showThemeDialog = false }
        )
    }
}
