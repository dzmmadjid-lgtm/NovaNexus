package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AppItem
import com.example.model.AppTabFilter
import com.example.model.SortOption
import com.example.ui.components.AppCardItem
import com.example.ui.components.ExtractedApkCardItem
import com.example.viewmodel.ApkExtractorViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApkExtractorScreen(
    viewModel: ApkExtractorViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val isDark = uiState.isDarkTheme
    val focusManager = LocalFocusManager.current
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearSnackbar()
        }
    }

    val bgColor = if (isDark) Color(0xFF0A0C14) else Color(0xFFF8FAFC)
    val cardBg = if (isDark) Color(0xFF141624) else Color(0xFFFFFFFF)
    val cardBorder = if (isDark) Color(0xFF262B40) else Color(0xFFE2E8F0)
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val textSecondary = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
    val accentEmerald = Color(0xFF10B981)
    val accentCyan = Color(0xFF06B6D4)

    // Filter apps based on current tab, search query, and sort option
    val filteredApps = remember(
        uiState.allApps,
        uiState.selectedTab,
        uiState.searchQuery,
        uiState.sortOption
    ) {
        var list = when (uiState.selectedTab) {
            AppTabFilter.USER -> uiState.allApps.filter { !it.isSystemApp }
            AppTabFilter.SYSTEM -> uiState.allApps.filter { it.isSystemApp }
            AppTabFilter.EXTRACTED -> emptyList()
        }

        if (uiState.searchQuery.isNotBlank()) {
            val q = uiState.searchQuery.trim().lowercase()
            list = list.filter {
                it.appName.lowercase().contains(q) || it.packageName.lowercase().contains(q)
            }
        }

        when (uiState.sortOption) {
            SortOption.NAME_ASC -> list.sortedBy { it.appName.lowercase() }
            SortOption.SIZE_DESC -> list.sortedByDescending { it.apkSizeBytes }
            SortOption.DATE_DESC -> list.sortedByDescending { it.lastUpdatedTime }
        }
    }

    var showSortMenu by remember { mutableStateOf(false) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = bgColor
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(accentEmerald, accentCyan)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.FolderZip,
                                contentDescription = "APK Extractor",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "مستخرج APK",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = textPrimary
                            )
                            Text(
                                text = "استخراج ومشاركة ملفات الـ APK",
                                fontSize = 11.sp,
                                color = textSecondary
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Refresh button
                        IconButton(
                            onClick = { viewModel.loadApps() },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(if (isDark) Color(0xFF1E2130) else Color(0xFFF1F5F9))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "تحديث",
                                tint = textSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Theme Toggle
                        IconButton(
                            onClick = { viewModel.toggleTheme() },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(if (isDark) Color(0xFF1E2130) else Color(0xFFF1F5F9))
                        ) {
                            Icon(
                                imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = "تغيير المظهر",
                                tint = if (isDark) Color(0xFFFBBF24) else Color(0xFF6366F1),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Stats Banner
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // User Apps Stat
                    StatBadge(
                        title = "تطبيقات مثبتة",
                        count = uiState.userAppsCount,
                        color = Color(0xFF3B82F6),
                        icon = Icons.Default.Apps,
                        isSelected = uiState.selectedTab == AppTabFilter.USER,
                        onClick = { viewModel.selectTab(AppTabFilter.USER) },
                        isDark = isDark,
                        modifier = Modifier.weight(1f)
                    )

                    // System Apps Stat
                    StatBadge(
                        title = "تطبيقات النظام",
                        count = uiState.systemAppsCount,
                        color = Color(0xFFEF4444),
                        icon = Icons.Default.Smartphone,
                        isSelected = uiState.selectedTab == AppTabFilter.SYSTEM,
                        onClick = { viewModel.selectTab(AppTabFilter.SYSTEM) },
                        isDark = isDark,
                        modifier = Modifier.weight(1f)
                    )

                    // Extracted APKs Stat
                    StatBadge(
                        title = "المستخرجة",
                        count = uiState.totalExtractedCount,
                        color = accentEmerald,
                        icon = Icons.Default.Download,
                        isSelected = uiState.selectedTab == AppTabFilter.EXTRACTED,
                        onClick = { viewModel.selectTab(AppTabFilter.EXTRACTED) },
                        isDark = isDark,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Search & Sort Bar (shown for User & System tabs)
                if (uiState.selectedTab != AppTabFilter.EXTRACTED) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = uiState.searchQuery,
                            onValueChange = { viewModel.onSearchQueryChanged(it) },
                            placeholder = { Text("بحث باسم التطبيق أو الحزمة...", fontSize = 13.sp, color = textSecondary) },
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = "بحث", tint = textSecondary, modifier = Modifier.size(20.dp))
                            },
                            trailingIcon = {
                                if (uiState.searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                                        Icon(Icons.Default.Clear, contentDescription = "مسح", tint = textSecondary, modifier = Modifier.size(18.dp))
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(14.dp),
                            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = accentEmerald,
                                unfocusedBorderColor = cardBorder,
                                focusedContainerColor = cardBg,
                                unfocusedContainerColor = cardBg,
                                focusedTextColor = textPrimary,
                                unfocusedTextColor = textPrimary
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                        )

                        // Sort Menu Button
                        Box {
                            IconButton(
                                onClick = { showSortMenu = true },
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(cardBg)
                                    .border(1.dp, cardBorder, RoundedCornerShape(14.dp))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FilterList,
                                    contentDescription = "ترتيب",
                                    tint = accentEmerald,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            DropdownMenu(
                                expanded = showSortMenu,
                                onDismissRequest = { showSortMenu = false },
                                modifier = Modifier.background(if (isDark) Color(0xFF1E2130) else Color.White)
                            ) {
                                SortOption.values().forEach { option ->
                                    DropdownMenuItem(
                                        text = {
                                            Text(
                                                text = option.title,
                                                fontSize = 13.sp,
                                                fontWeight = if (uiState.sortOption == option) FontWeight.Bold else FontWeight.Normal,
                                                color = if (uiState.sortOption == option) accentEmerald else textPrimary
                                            )
                                        },
                                        onClick = {
                                            viewModel.setSortOption(option)
                                            showSortMenu = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Multi-select helpers bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "${filteredApps.size} تطبيق متوفر",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = textSecondary
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (uiState.isMultiSelectMode) {
                                Text(
                                    text = "إلغاء التحديد",
                                    fontSize = 12.sp,
                                    color = Color(0xFFEF4444),
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .clickable { viewModel.clearMultiSelect() }
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }

                            Text(
                                text = "تحديد الكل",
                                fontSize = 12.sp,
                                color = accentEmerald,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { viewModel.selectAllInCurrentTab(filteredApps) }
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Content List
                if (uiState.isLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = accentEmerald, modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("جاري فحص التطبيقات المثبتة في الهاتف...", color = textSecondary, fontSize = 13.sp)
                        }
                    }
                } else if (uiState.selectedTab == AppTabFilter.EXTRACTED) {
                    // Extracted APKs Tab
                    if (uiState.extractedApps.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, tint = textSecondary, modifier = Modifier.size(48.dp))
                                Text("لا توجد حزم APK مستخرجة بعد", color = textPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text("اختر أي تطبيق من قائمة المثبتة واضغط على أيقونة التحميل لاستخراجه", color = textSecondary, fontSize = 12.sp, textAlign = TextAlign.Center)
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = 80.dp)
                        ) {
                            items(uiState.extractedApps, key = { it.filePath }) { item ->
                                ExtractedApkCardItem(
                                    item = item,
                                    isDark = isDark,
                                    onShareClick = { viewModel.shareApk(item.filePath) },
                                    onDeleteClick = { viewModel.deleteExtractedApk(item.filePath) }
                                )
                            }
                        }
                    }
                } else {
                    // User / System Apps Tab
                    if (filteredApps.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("لا توجد تطبيقات مطابقة للبحث", color = textSecondary, fontSize = 14.sp)
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            contentPadding = PaddingValues(bottom = if (uiState.isMultiSelectMode) 90.dp else 24.dp)
                        ) {
                            items(filteredApps, key = { it.packageName }) { app ->
                                val isSelected = uiState.selectedPackagesForBatch.contains(app.packageName)
                                AppCardItem(
                                    app = app,
                                    isSelected = isSelected,
                                    isMultiSelectMode = uiState.isMultiSelectMode,
                                    isDark = isDark,
                                    onExtractClick = { viewModel.extractSingleApp(app) },
                                    onShareClick = {
                                        viewModel.extractSingleApp(app)
                                    },
                                    onOpenClick = { viewModel.openApp(app.packageName) },
                                    onSettingsClick = { viewModel.openAppSettings(app.packageName) },
                                    onToggleSelect = { viewModel.toggleSelectApp(app.packageName) }
                                )
                            }
                        }
                    }
                }
            }

            // Bottom Floating Bar for Batch Extraction
            AnimatedVisibility(
                visible = uiState.isMultiSelectMode && uiState.selectedPackagesForBatch.isNotEmpty(),
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isDark) Color(0xFF1E293B) else Color(0xFF0F172A))
                        .border(1.dp, accentEmerald, RoundedCornerShape(20.dp))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(30.dp)
                                    .clip(CircleShape)
                                    .background(accentEmerald),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${uiState.selectedPackagesForBatch.size}",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                            Text("تطبيقات محددة", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = { viewModel.extractBatchSelectedApps() },
                                colors = ButtonDefaults.buttonColors(containerColor = accentEmerald),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("استخراج الكل", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }

                            IconButton(
                                onClick = { viewModel.clearMultiSelect() },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "إلغاء", tint = Color.White)
                            }
                        }
                    }
                }
            }

            // Extracting Progress Dialog Overlay
            if (uiState.isExtracting) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.6f))
                        .clickable(enabled = false) {},
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .clip(RoundedCornerShape(20.dp))
                            .background(cardBg)
                            .border(1.dp, accentEmerald, RoundedCornerShape(20.dp))
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            CircularProgressIndicator(
                                color = accentEmerald,
                                modifier = Modifier.size(48.dp),
                                strokeWidth = 4.dp
                            )

                            Text(
                                text = "جاري استخراج ملف APK...",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = textPrimary
                            )

                            Text(
                                text = uiState.extractingProgressText ?: "يتم نسخ الحزمة الأصلية...",
                                fontSize = 12.sp,
                                color = textSecondary,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatBadge(
    title: String,
    count: Int,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    isDark: Boolean,
    modifier: Modifier = Modifier
) {
    val bg = when {
        isSelected -> color.copy(alpha = if (isDark) 0.25f else 0.15f)
        isDark -> Color(0xFF141624)
        else -> Color(0xFFFFFFFF)
    }

    val border = if (isSelected) color else if (isDark) Color(0xFF262B40) else Color(0xFFE2E8F0)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .border(if (isSelected) 1.5.dp else 1.dp, border, RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(vertical = 10.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = color,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = "$count",
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (isDark) Color.White else Color(0xFF0F172A)
            )
            Text(
                text = title,
                fontSize = 10.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) color else if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
            )
        }
    }
}
