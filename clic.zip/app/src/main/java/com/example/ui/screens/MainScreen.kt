package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ChangeCalculatorDialog
import com.example.ui.components.HistoryDialog
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.LightSurfaceBorder
import com.example.ui.theme.LightSurfaceElevated
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.LightTextSecondary
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.OledBlack
import com.example.viewmodel.CalculatorMode
import com.example.viewmodel.CalculatorViewModel

@Composable
fun MainScreen(
    viewModel: CalculatorViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    val historyList by viewModel.historyList.collectAsState()

    val isDark = uiState.isDarkTheme
    val bgCanvas = if (isDark) OledBlack else Color.White
    val textPrimary = if (isDark) DarkTextPrimary else LightTextPrimary
    val textSecondary = if (isDark) DarkTextSecondary else LightTextSecondary
    val tabBg = if (isDark) DarkSurfaceElevated else LightSurfaceElevated
    val tabBorder = if (isDark) DarkSurfaceBorder else LightSurfaceBorder

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .background(bgCanvas)
            .windowInsetsPadding(WindowInsets.statusBars)
            .windowInsetsPadding(WindowInsets.navigationBars),
        color = bgCanvas
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Top Navigation & Actions Bar (Click School Style)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Action Buttons & Offline Status Pill (Left side)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Theme Toggle Button in rounded square
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isDark) Color(0xFF141622) else Color(0xFFFFFFFF))
                            .border(1.dp, if (isDark) Color(0xFF262A3D) else Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                            .clickable { viewModel.toggleTheme() }
                            .testTag("btn_toggle_theme"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = if (isDark) "الوضع النهاري" else "الوضع الليلي",
                            tint = if (isDark) Color(0xFFFFB800) else Color(0xFF334155),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // History Button with Badge
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isDark) Color(0xFF141622) else Color(0xFFFFFFFF))
                            .border(1.dp, if (isDark) Color(0xFF262A3D) else Color(0xFFE2E8F0), RoundedCornerShape(12.dp))
                            .clickable { viewModel.setShowHistory(true) }
                            .testTag("btn_open_history"),
                        contentAlignment = Alignment.Center
                    ) {
                        BadgedBox(
                            badge = {
                                if (historyList.isNotEmpty()) {
                                    Badge(
                                        containerColor = if (isDark) Color(0xFFEF4444) else Color(0xFFDC2626)
                                    ) {
                                        Text(
                                            text = if (historyList.size > 99) "99+" else historyList.size.toString(),
                                            fontSize = 9.sp,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "السجل",
                                tint = textPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    // "جاهز دون اتصال" Pill (Matching exact screenshot badge)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isDark) Color(0xFF092416) else Color(0xFFD1FAE5))
                            .border(
                                1.dp,
                                if (isDark) Color(0xFF134E32) else Color(0xFFA7F3D0),
                                RoundedCornerShape(20.dp)
                            )
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (isDark) Color(0xFF22C55E) else Color(0xFF10B981))
                            )
                            Text(
                                text = "جاهز دون اتصال",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) Color(0xFF22C55E) else Color(0xFF047857)
                            )
                        }
                    }
                }

                // App Brand Logo & Title (Right side, RTL layout matching screenshots)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "Click Calculator",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = textPrimary
                        )
                        Text(
                            text = "منصة الحسابات الذكية",
                            fontSize = 11.sp,
                            color = textSecondary
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFEF4444)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = "Click Calculator Logo",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            // Mode Selector Segmented Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(tabBg)
                    .border(1.dp, tabBorder, RoundedCornerShape(16.dp))
                    .padding(4.dp)
            ) {
                // Standard Tab
                val isStandard = uiState.mode == CalculatorMode.STANDARD
                val standardBg = if (isStandard) {
                    if (isDark) NeonCyan.copy(alpha = 0.2f) else Color.White
                } else Color.Transparent

                val standardTextColor = if (isStandard) {
                    if (isDark) NeonCyan else Color(0xFF0284C7)
                } else textSecondary

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(standardBg)
                        .clickable { viewModel.setMode(CalculatorMode.STANDARD) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = null,
                            tint = standardTextColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "آلة حاسبة",
                            fontSize = 13.sp,
                            fontWeight = if (isStandard) FontWeight.Bold else FontWeight.Medium,
                            color = standardTextColor
                        )
                    }
                }

                // Cashier Tab
                val isCashier = uiState.mode == CalculatorMode.CHANGE
                val cashierBg = if (isCashier) {
                    if (isDark) NeonGreen.copy(alpha = 0.2f) else Color(0xFFDCFCE7)
                } else Color.Transparent

                val cashierTextColor = if (isCashier) {
                    if (isDark) NeonGreen else Color(0xFF166534)
                } else textSecondary

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(12.dp))
                        .background(cashierBg)
                        .clickable {
                            viewModel.setShowChangeDialog(true)
                        }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Payments,
                            contentDescription = null,
                            tint = cashierTextColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "حساب الصرف (دج)",
                            fontSize = 13.sp,
                            fontWeight = if (isCashier) FontWeight.Bold else FontWeight.Medium,
                            color = cashierTextColor
                        )
                    }
                }
            }

            // Main Content Screen Animated Switch
            AnimatedContent(
                targetState = uiState.mode,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenModeTransition",
                modifier = Modifier.weight(1f)
            ) { targetMode ->
                when (targetMode) {
                    CalculatorMode.STANDARD -> {
                        StandardCalculatorScreen(
                            state = uiState,
                            isDark = isDark,
                            onInput = { viewModel.onStandardInput(it) },
                            onOperator = { viewModel.onStandardInput(it) },
                            onClear = { viewModel.onStandardClear() },
                            onDelete = { viewModel.onStandardDelete() },
                            onPercentage = { viewModel.onStandardPercentage() },
                            onToggleSign = { viewModel.onStandardToggleSign() },
                            onEquals = { viewModel.onStandardEquals() },
                            onOpenChangeDialog = { viewModel.setShowChangeDialog(true) },
                            onOpenHistory = { viewModel.setShowHistory(true) }
                        )
                    }
                    CalculatorMode.CHANGE -> {
                        CashierCalculatorScreen(
                            state = uiState,
                            isDark = isDark,
                            onSelectField = { viewModel.setActiveCashierField(it) },
                            onDigit = { viewModel.onCashierDigit(it) },
                            onDelete = { viewModel.onCashierDelete() },
                            onClear = { viewModel.onCashierClear() },
                            onQuickAdd = { viewModel.onQuickCashAdd(it) },
                            onSaveTransaction = { viewModel.saveCashierTransaction() }
                        )
                    }
                }
            }
        }

        // Change Calculator Dialog (Matching exact screenshot modal)
        if (uiState.showChangeDialog) {
            ChangeCalculatorDialog(
                state = uiState,
                isDark = isDark,
                onSelectField = { viewModel.setActiveCashierField(it) },
                onDigit = { viewModel.onCashierDigit(it) },
                onDelete = { viewModel.onCashierDelete() },
                onClear = { viewModel.onCashierClear() },
                onQuickAdd = { viewModel.onQuickCashAdd(it) },
                onDismiss = {
                    // Auto save transaction if valid when dismissing
                    viewModel.saveCashierTransaction()
                    viewModel.setShowChangeDialog(false)
                }
            )
        }

        // History Dialog
        if (uiState.showHistoryDialog) {
            HistoryDialog(
                isDark = isDark,
                historyList = historyList,
                onDeleteItem = { viewModel.deleteHistoryEntry(it) },
                onClearHistory = { viewModel.clearHistory() },
                onDismiss = { viewModel.setShowHistory(false) }
            )
        }
    }
}
