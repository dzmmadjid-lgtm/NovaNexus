package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CashierKeypad
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.LightGreen
import com.example.ui.theme.LightPurple
import com.example.ui.theme.LightRed
import com.example.ui.theme.LightSurfaceBorder
import com.example.ui.theme.LightSurfaceElevated
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.LightTextSecondary
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.viewmodel.CalculatorUiState
import com.example.viewmodel.CashierField

@Composable
fun CashierCalculatorScreen(
    state: CalculatorUiState,
    isDark: Boolean,
    onSelectField: (CashierField) -> Unit,
    onDigit: (String) -> Unit,
    onDelete: () -> Unit,
    onClear: () -> Unit,
    onQuickAdd: (Double) -> Unit,
    onSaveTransaction: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val textPrimary = if (isDark) DarkTextPrimary else LightTextPrimary
    val textSecondary = if (isDark) DarkTextSecondary else LightTextSecondary
    val cardBg = if (isDark) DarkSurfaceElevated else LightSurfaceElevated
    val cardBorder = if (isDark) DarkSurfaceBorder else LightSurfaceBorder

    val canSave = (state.itemPriceInput.toDoubleOrNull() ?: 0.0) > 0 &&
            (state.amountPaidInput.toDoubleOrNull() ?: 0.0) > 0

    Column(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Input Fields Row: Item Price & Amount Paid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Item Price Card
                val isItemActive = state.activeCashierField == CashierField.ITEM_PRICE
                val activeItemBorder = if (isItemActive) {
                    if (isDark) NeonCyan else Color(0xFF0284C7)
                } else cardBorder

                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_item_price")
                        .border(if (isItemActive) 2.dp else 1.dp, activeItemBorder, RoundedCornerShape(18.dp))
                        .clickable { onSelectField(CashierField.ITEM_PRICE) }
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "ثمن السلعة",
                                fontSize = 12.sp,
                                color = if (isItemActive) (if (isDark) NeonCyan else Color(0xFF0284C7)) else textSecondary,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Default.ShoppingBag,
                                contentDescription = null,
                                tint = if (isItemActive) (if (isDark) NeonCyan else Color(0xFF0284C7)) else textSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (state.itemPriceInput.isEmpty()) "0 دج" else "${state.itemPriceInput} دج",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = textPrimary,
                            maxLines = 1
                        )
                    }
                }

                // Amount Paid Card
                val isPaidActive = state.activeCashierField == CashierField.AMOUNT_PAID
                val activePaidBorder = if (isPaidActive) {
                    if (isDark) NeonPurple else Color(0xFF7C3AED)
                } else cardBorder

                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("card_amount_paid")
                        .border(if (isPaidActive) 2.dp else 1.dp, activePaidBorder, RoundedCornerShape(18.dp))
                        .clickable { onSelectField(CashierField.AMOUNT_PAID) }
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "المبلغ المدفوع",
                                fontSize = 12.sp,
                                color = if (isPaidActive) (if (isDark) NeonPurple else Color(0xFF7C3AED)) else textSecondary,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Default.Payments,
                                contentDescription = null,
                                tint = if (isPaidActive) (if (isDark) NeonPurple else Color(0xFF7C3AED)) else textSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (state.amountPaidInput.isEmpty()) "0 دج" else "${state.amountPaidInput} دج",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = textPrimary,
                            maxLines = 1
                        )
                    }
                }
            }

            // Results & Tafqeet Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (state.isCashShortage) {
                        if (isDark) NeonRed.copy(alpha = 0.12f) else LightRed.copy(alpha = 0.08f)
                    } else {
                        if (isDark) DarkSurfaceElevated else LightSurfaceElevated
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        if (state.isCashShortage) (if (isDark) NeonRed else LightRed) else cardBorder,
                        RoundedCornerShape(20.dp)
                    )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (state.isCashShortage) Icons.Default.Warning else Icons.Default.AccountBalanceWallet,
                                contentDescription = null,
                                tint = if (state.isCashShortage) {
                                    if (isDark) NeonRed else LightRed
                                } else {
                                    if (isDark) NeonGreen else LightGreen
                                },
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (state.isCashShortage) "المبلغ غير كافٍ" else "الباقي للزبون (الصرف)",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (state.isCashShortage) {
                                    if (isDark) NeonRed else LightRed
                                } else {
                                    if (isDark) NeonGreen else LightGreen
                                }
                            )
                        }

                        if (state.changeTafqeet.isNotEmpty() && !state.isCashShortage) {
                            IconButton(
                                onClick = {
                                    val copyText = "الباقي: ${state.remainingChange} دج (${state.changeTafqeet})"
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Change", copyText))
                                    Toast.makeText(context, "تم نسخ تفاصيل الصرف", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "نسخ",
                                    tint = textSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // Change Numeric Value
                    val changeDisplay = if (state.isCashShortage) {
                        "ينقص: ${state.shortageAmount} دج"
                    } else {
                        "${state.remainingChange} دج"
                    }

                    Text(
                        text = changeDisplay,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (state.isCashShortage) (if (isDark) NeonRed else LightRed) else textPrimary
                    )

                    // Tafqeet in Arabic Words
                    if (state.changeTafqeet.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (state.isCashShortage) {
                                        if (isDark) NeonRed.copy(alpha = 0.2f) else LightRed.copy(alpha = 0.15f)
                                    } else {
                                        if (isDark) NeonOrange.copy(alpha = 0.12f) else Color(0xFFFEF3C7)
                                    }
                                )
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "✍️ " + state.changeTafqeet,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (state.isCashShortage) {
                                    if (isDark) NeonRed else LightRed
                                } else {
                                    if (isDark) NeonOrange else Color(0xFFB45309)
                                },
                                lineHeight = 18.sp
                            )
                        }
                    }

                    // Banknote & Coin suggestions breakdown
                    if (state.denominations.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            state.denominations.forEach { denom ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isDark) Color(0xFF1E293B) else Color(0xFFE2E8F0))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = "${denom.label} × ${denom.count}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = textPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Cashier Keypad
        CashierKeypad(
            isDark = isDark,
            onDigit = onDigit,
            onDelete = onDelete,
            onClear = onClear,
            onQuickAdd = onQuickAdd,
            onSaveTransaction = {
                onSaveTransaction()
                Toast.makeText(context, "تم حفظ عملية الصرف في السجل بنجاح", Toast.LENGTH_SHORT).show()
            },
            canSave = canSave
        )
    }
}
