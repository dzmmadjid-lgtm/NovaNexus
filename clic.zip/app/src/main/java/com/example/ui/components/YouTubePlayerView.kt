package com.example.ui.components

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.YouTubeVideo
import com.example.service.PlaybackManager

class YouTubeJsBridge(
    private val onStateChange: (Boolean) -> Unit,
    private val onProgress: (Float, Float) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun onPlayerStateChange(state: Int) {
        mainHandler.post {
            val isPlaying = (state == 1)
            onStateChange(isPlaying)
        }
    }

    @JavascriptInterface
    fun onProgress(currentSeconds: Float, totalSeconds: Float) {
        mainHandler.post {
            onProgress(currentSeconds, totalSeconds)
        }
    }
}

private fun setupWebViewCookies(webView: WebView) {
    try {
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)
        // Set Google EU consent cookies to completely prevent the "Before you continue to YouTube" consent wall
        cookieManager.setCookie("https://www.youtube.com", "SOCS=CAESEwgDEgk1ODEyMzgwMzg; Domain=.youtube.com; Path=/")
        cookieManager.setCookie("https://www.youtube.com", "CONSENT=YES+cb.20230531-04-p0.en+FX+999; Domain=.youtube.com; Path=/")
        cookieManager.setCookie("https://www.youtube-nocookie.com", "SOCS=CAESEwgDEgk1ODEyMzgwMzg; Domain=.youtube-nocookie.com; Path=/")
        cookieManager.setCookie("https://www.youtube-nocookie.com", "CONSENT=YES+cb.20230531-04-p0.en+FX+999; Domain=.youtube-nocookie.com; Path=/")
        cookieManager.flush()
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubePlayerView(
    video: YouTubeVideo,
    modifier: Modifier = Modifier,
    isPlaying: Boolean = true
) {
    val context = LocalContext.current

    val webView = remember {
        WebView(context).apply {
            setupWebViewCookies(this)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                loadWithOverviewMode = true
                useWideViewPort = true
                cacheMode = WebSettings.LOAD_DEFAULT
                allowFileAccess = true
                allowContentAccess = true
                databaseEnabled = true
                userAgentString = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"
            }
            setBackgroundColor(android.graphics.Color.BLACK)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript(
                        """
                        (function() {
                            var buttons = document.querySelectorAll('button, form button');
                            for (var b of buttons) {
                                if (b.innerText && (b.innerText.includes('Accept') || b.innerText.includes('قبول') || b.innerText.includes('I agree'))) {
                                    b.click();
                                }
                            }
                            if (window.player && window.player.playVideo) {
                                window.player.playVideo();
                            }
                        })();
                        """.trimIndent(),
                        null
                    )
                }
            }

            addJavascriptInterface(
                YouTubeJsBridge(
                    onStateChange = { playing ->
                        PlaybackManager.updatePlayerState(playing)
                    },
                    onProgress = { current, total ->
                        PlaybackManager.updateProgress(current, total)
                    }
                ),
                "AndroidBridge"
            )
        }
    }

    DisposableEffect(webView) {
        PlaybackManager.onCommandListener = { cmd ->
            webView.post {
                try {
                    webView.evaluateJavascript("if(player && player.$cmd){ player.$cmd; }", null)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        onDispose {
            PlaybackManager.onCommandListener = null
        }
    }

    LaunchedEffect(video.id) {
        val htmlContent = generatePlayerHtml(video.id, muted = false)
        webView.loadDataWithBaseURL("https://www.youtube-nocookie.com", htmlContent, "text/html", "UTF-8", null)
    }

    LaunchedEffect(isPlaying) {
        val jsCmd = if (isPlaying) {
            "if(player && player.playVideo){ player.playVideo(); }"
        } else {
            "if(player && player.pauseVideo){ player.pauseVideo(); }"
        }
        webView.evaluateJavascript(jsCmd, null)
    }

    Box(modifier = modifier.background(Color.Black)) {
        AndroidView(
            factory = { webView },
            modifier = Modifier.fillMaxSize()
        )
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun InlineMutedPlayerView(
    videoId: String,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val webView = remember(videoId) {
        WebView(context).apply {
            setupWebViewCookies(this)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                loadWithOverviewMode = true
                useWideViewPort = true
                cacheMode = WebSettings.LOAD_DEFAULT
                userAgentString = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36"
            }
            setBackgroundColor(android.graphics.Color.BLACK)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript(
                        """
                        (function() {
                            var buttons = document.querySelectorAll('button, form button');
                            for (var b of buttons) {
                                if (b.innerText && (b.innerText.includes('Accept') || b.innerText.includes('قبول') || b.innerText.includes('I agree'))) {
                                    b.click();
                                }
                            }
                            if (window.player) {
                                if (window.player.mute) window.player.mute();
                                if (window.player.playVideo) window.player.playVideo();
                            }
                        })();
                        """.trimIndent(),
                        null
                    )
                }
            }
            val htmlContent = generatePlayerHtml(videoId, muted = true)
            loadDataWithBaseURL("https://www.youtube-nocookie.com", htmlContent, "text/html", "UTF-8", null)
        }
    }

    Box(modifier = modifier.background(Color.Black)) {
        AndroidView(
            factory = { webView },
            modifier = Modifier.fillMaxSize()
        )
    }
}

private fun generatePlayerHtml(videoId: String, muted: Boolean): String {
    val muteParam = if (muted) "1" else "0"
    val controlsParam = if (muted) "0" else "1"

    return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                html, body { width: 100%; height: 100%; background: #000; overflow: hidden; }
                #player { width: 100%; height: 100%; position: absolute; top: 0; left: 0; border: none; }
                /* Hide cookie consent dialogs and unwanted headers */
                .consent-bump, .eom-dialog, ytd-consent-bump-v2-lightbox, #dialog, .privacy-popup { display: none !important; }
            </style>
        </head>
        <body>
            <div id="player"></div>
            <script>
                var tag = document.createElement('script');
                tag.src = "https://www.youtube-nocookie.com/iframe_api";
                var firstScriptTag = document.getElementsByTagName('script')[0];
                firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

                var player;
                var tracker;

                function onYouTubeIframeAPIReady() {
                    player = new YT.Player('player', {
                        height: '100%',
                        width: '100%',
                        videoId: '$videoId',
                        playerVars: {
                            'autoplay': 1,
                            'playsinline': 1,
                            'controls': $controlsParam,
                            'mute': $muteParam,
                            'rel': 0,
                            'fs': 1,
                            'modestbranding': 1,
                            'enablejsapi': 1,
                            'loop': ${if (muted) "1" else "0"},
                            'playlist': '$videoId',
                            'origin': 'https://www.youtube-nocookie.com'
                        },
                        events: {
                            'onReady': onPlayerReady,
                            'onStateChange': onPlayerStateChange
                        }
                    });
                }

                function onPlayerReady(event) {
                    if ($muted) {
                        event.target.mute();
                    }
                    event.target.playVideo();
                    startProgress();
                }

                function onPlayerStateChange(event) {
                    if (window.AndroidBridge && window.AndroidBridge.onPlayerStateChange) {
                        window.AndroidBridge.onPlayerStateChange(event.data);
                    }
                    if (event.data === 1) {
                        startProgress();
                    } else {
                        stopProgress();
                    }
                }

                function startProgress() {
                    stopProgress();
                    tracker = setInterval(function() {
                        if (player && player.getCurrentTime && player.getDuration) {
                            var cur = player.getCurrentTime() || 0;
                            var dur = player.getDuration() || 0;
                            if (window.AndroidBridge && window.AndroidBridge.onProgress) {
                                window.AndroidBridge.onProgress(cur, dur);
                            }
                        }
                    }, 1000);
                }

                function stopProgress() {
                    if (tracker) {
                        clearInterval(tracker);
                        tracker = null;
                    }
                }
            </script>
        </body>
        </html>
    """.trimIndent()
}
