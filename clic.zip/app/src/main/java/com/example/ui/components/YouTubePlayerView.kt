package com.example.ui.components

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.YouTubeVideo
import com.example.service.PlaybackManager

class YouTubeJsBridge(
    private val onStateChange: (Boolean) -> Unit,
    private val onProgress: (Float, Float) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun onPlayerStateChange(state: Int) {
        mainHandler.post {
            val isPlaying = (state == 1)
            onStateChange(isPlaying)
        }
    }

    @JavascriptInterface
    fun onProgress(currentSeconds: Float, totalSeconds: Float) {
        mainHandler.post {
            onProgress(currentSeconds, totalSeconds)
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubePlayerView(
    video: YouTubeVideo,
    modifier: Modifier = Modifier,
    isPlaying: Boolean = true
) {
    val context = LocalContext.current

    val webView = remember(video.id) {
        WebView(context).apply {
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )

            try {
                val cookieManager = CookieManager.getInstance()
                cookieManager.setAcceptCookie(true)
                cookieManager.setAcceptThirdPartyCookies(this, true)
                cookieManager.setCookie("https://www.youtube.com", "SOCS=CAESEwgDEgk1ODEyMzgwMzg; Domain=.youtube.com; Path=/")
                cookieManager.setCookie("https://www.youtube.com", "CONSENT=YES+cb.20230531-04-p0.en+FX+999; Domain=.youtube.com; Path=/")
                cookieManager.setCookie("https://www.youtube-nocookie.com", "SOCS=CAESEwgDEgk1ODEyMzgwMzg; Domain=.youtube-nocookie.com; Path=/")
                cookieManager.setCookie("https://www.youtube-nocookie.com", "CONSENT=YES+cb.20230531-04-p0.en+FX+999; Domain=.youtube-nocookie.com; Path=/")
                cookieManager.flush()
            } catch (e: Exception) {
                e.printStackTrace()
            }

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                loadWithOverviewMode = true
                useWideViewPort = true
                allowFileAccess = true
                allowContentAccess = true
                javaScriptCanOpenWindowsAutomatically = true
                userAgentString = "Mozilla/5.0 (Linux; Android 13; Mobile; rv:125.0) Gecko/125.0 Firefox/125.0"
            }
            setBackgroundColor(android.graphics.Color.BLACK)

            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript(
                        """
                        (function() {
                            var buttons = document.querySelectorAll('button, form button, .yt-spec-button-shape-next');
                            for (var b of buttons) {
                                if (b.innerText && (b.innerText.includes('Accept') || b.innerText.includes('قبول') || b.innerText.includes('I agree') || b.innerText.includes('Agree'))) {
                                    b.click();
                                }
                            }
                        })();
                        """.trimIndent(),
                        null
                    )
                }
            }

            addJavascriptInterface(
                YouTubeJsBridge(
                    onStateChange = { playing ->
                        PlaybackManager.updatePlayerState(playing)
                    },
                    onProgress = { current, total ->
                        PlaybackManager.updateProgress(current, total)
                    }
                ),
                "AndroidBridge"
            )

            val html = """
                <!DOCTYPE html>
                <html>
                <head>
                    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
                    <style>
                        * { margin: 0; padding: 0; box-sizing: border-box; }
                        html, body { width: 100%; height: 100%; background: #000000; overflow: hidden; display: flex; align-items: center; justify-content: center; }
                        #player-container { width: 100%; height: 100%; position: absolute; top: 0; left: 0; }
                        iframe { width: 100%; height: 100%; border: 0; }
                    </style>
                </head>
                <body>
                    <div id="player-container">
                        <iframe id="yt-iframe"
                            src="https://www.youtube.com/embed/${video.id}?autoplay=1&playsinline=1&controls=1&enablejsapi=1&fs=1&rel=0&iv_load_policy=3&origin=https://www.youtube.com"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            allowfullscreen>
                        </iframe>
                    </div>
                    <script>
                        var iframe = document.getElementById('yt-iframe');
                        function sendCommand(func, args) {
                            if (iframe && iframe.contentWindow) {
                                iframe.contentWindow.postMessage(JSON.stringify({
                                    "event": "command",
                                    "func": func,
                                    "args": args || []
                                }), "*");
                            }
                        }
                        window.playVideo = function() { sendCommand("playVideo"); };
                        window.pauseVideo = function() { sendCommand("pauseVideo"); };
                        window.stopVideo = function() { sendCommand("stopVideo"); };
                        window.seekTo = function(sec) { sendCommand("seekTo", [sec, true]); };
                        
                        window.addEventListener('message', function(event) {
                            try {
                                var data = JSON.parse(event.data);
                                if (data.event === 'onStateChange' && window.AndroidBridge) {
                                    window.AndroidBridge.onPlayerStateChange(data.info);
                                }
                            } catch(e) {}
                        });
                    </script>
                </body>
                </html>
            """.trimIndent()

            loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null)
        }
    }

    DisposableEffect(webView) {
        PlaybackManager.onCommandListener = { cmd ->
            webView.post {
                try {
                    when {
                        cmd.startsWith("loadVideoById") -> {
                            // Handled by remember(video.id)
                        }
                        cmd.contains("playVideo") -> {
                            webView.evaluateJavascript("window.playVideo();", null)
                        }
                        cmd.contains("pauseVideo") -> {
                            webView.evaluateJavascript("window.pauseVideo();", null)
                        }
                        cmd.contains("stopVideo") -> {
                            webView.evaluateJavascript("window.stopVideo();", null)
                        }
                        cmd.startsWith("seekTo") -> {
                            val sec = cmd.substringAfter("(").substringBefore(",").trim().toFloatOrNull() ?: 0f
                            webView.evaluateJavascript("window.seekTo($sec);", null)
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        onDispose {
            PlaybackManager.onCommandListener = null
            try {
                webView.destroy()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    LaunchedEffect(isPlaying) {
        val jsCmd = if (isPlaying) "window.playVideo();" else "window.pauseVideo();"
        webView.evaluateJavascript(jsCmd, null)
    }

    Box(modifier = modifier.background(Color.Black)) {
        AndroidView(
            factory = { webView },
            modifier = Modifier.fillMaxSize()
        )
    }
}
