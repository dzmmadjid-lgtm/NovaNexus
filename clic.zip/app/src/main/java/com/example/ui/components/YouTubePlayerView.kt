package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.YouTubeVideo
import com.example.service.PlaybackManager

class YouTubeJsInterface(
    private val onStateChange: (Boolean) -> Unit,
    private val onTimeUpdate: (Float, Float) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    @JavascriptInterface
    fun onPlayerStateChange(state: Int) {
        mainHandler.post {
            // 1 = playing, 2 = paused, 0 = ended, 3 = buffering
            val isPlaying = (state == 1)
            onStateChange(isPlaying)
        }
    }

    @JavascriptInterface
    fun onProgress(currentSeconds: Float, totalSeconds: Float) {
        mainHandler.post {
            onTimeUpdate(currentSeconds, totalSeconds)
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun YouTubePlayerView(
    video: YouTubeVideo,
    modifier: Modifier = Modifier,
    isPlaying: Boolean = true
) {
    val context = LocalContext.current

    val webView = remember {
        WebView(context).apply {
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                cacheMode = WebSettings.LOAD_DEFAULT
                userAgentString = "Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                allowFileAccess = true
                allowContentAccess = true
            }
            setBackgroundColor(android.graphics.Color.BLACK)
            webChromeClient = WebChromeClient()
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript("if(player && player.playVideo) { player.playVideo(); }", null)
                }
            }

            addJavascriptInterface(
                YouTubeJsInterface(
                    onStateChange = { playing ->
                        PlaybackManager.updatePlayerState(playing)
                    },
                    onTimeUpdate = { current, total ->
                        PlaybackManager.updateProgress(current, total)
                    }
                ),
                "AndroidBridge"
            )
        }
    }

    DisposableEffect(webView) {
        PlaybackManager.onCommandListener = { cmd ->
            webView.post {
                webView.evaluateJavascript("if(player && player.$cmd){ player.$cmd; }", null)
            }
        }
        onDispose {
            PlaybackManager.onCommandListener = null
            try {
                webView.evaluateJavascript("if(player && player.pauseVideo){ player.pauseVideo(); }", null)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    LaunchedEffect(video.id) {
        val htmlContent = buildPlayerHtml(video.id)
        webView.loadDataWithBaseURL("https://www.youtube.com", htmlContent, "text/html", "UTF-8", null)
    }

    LaunchedEffect(isPlaying) {
        val jsCmd = if (isPlaying) "if(player && player.playVideo){ player.playVideo(); }" else "if(player && player.pauseVideo){ player.pauseVideo(); }"
        webView.evaluateJavascript(jsCmd, null)
    }

    Box(modifier = modifier.background(Color.Black)) {
        AndroidView(
            factory = { webView },
            modifier = Modifier.fillMaxSize()
        )
    }
}

private fun buildPlayerHtml(videoId: String): String {
    return """
        <!DOCTYPE html>
        <html>
        <head>
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
            <style>
                * { margin: 0; padding: 0; box-sizing: border-box; }
                html, body { width: 100%; height: 100%; background: #000; overflow: hidden; }
                #player { width: 100%; height: 100%; position: absolute; top: 0; left: 0; }
            </style>
        </head>
        <body>
            <div id="player"></div>
            <script>
                var tag = document.createElement('script');
                tag.src = "https://www.youtube.com/iframe_api";
                var firstScriptTag = document.getElementsByTagName('script')[0];
                firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

                var player;
                var progressInterval;

                function onYouTubeIframeAPIReady() {
                    player = new YT.Player('player', {
                        height: '100%',
                        width: '100%',
                        videoId: '$videoId',
                        playerVars: {
                            'autoplay': 1,
                            'playsinline': 1,
                            'controls': 1,
                            'enablejsapi': 1,
                            'fs': 1,
                            'rel': 0,
                            'modestbranding': 1,
                            'origin': 'https://www.youtube.com'
                        },
                        events: {
                            'onReady': onPlayerReady,
                            'onStateChange': onPlayerStateChange
                        }
                    });
                }

                function onPlayerReady(event) {
                    event.target.playVideo();
                    startTracking();
                }

                function onPlayerStateChange(event) {
                    if (window.AndroidBridge && window.AndroidBridge.onPlayerStateChange) {
                        window.AndroidBridge.onPlayerStateChange(event.data);
                    }
                    if (event.data === YT.PlayerState.PLAYING) {
                        startTracking();
                    } else {
                        stopTracking();
                    }
                }

                function startTracking() {
                    stopTracking();
                    progressInterval = setInterval(function() {
                        if (player && player.getCurrentTime && player.getDuration) {
                            var current = player.getCurrentTime() || 0;
                            var duration = player.getDuration() || 0;
                            if (window.AndroidBridge && window.AndroidBridge.onProgress) {
                                window.AndroidBridge.onProgress(current, duration);
                            }
                        }
                    }, 1000);
                }

                function stopTracking() {
                    if (progressInterval) {
                        clearInterval(progressInterval);
                        progressInterval = null;
                    }
                }
            </script>
        </body>
        </html>
    """.trimIndent()
}
