package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.LightGreen
import com.example.ui.theme.LightSurfaceBorder
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple

@Composable
fun QuickCashChip(
    label: String,
    amount: Double,
    isDark: Boolean,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(14.dp)
    val bgColor = if (isDark) NeonPurple.copy(alpha = 0.15f) else NeonPurple.copy(alpha = 0.08f)
    val borderColor = if (isDark) NeonPurple.copy(alpha = 0.5f) else NeonPurple.copy(alpha = 0.3f)
    val textColor = if (isDark) Color(0xFFE9D5FF) else Color(0xFF6B21A8)

    Box(
        modifier = Modifier
            .clip(shape)
            .background(bgColor)
            .border(1.dp, borderColor, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun CashierKeypad(
    isDark: Boolean,
    onDigit: (String) -> Unit,
    onDelete: () -> Unit,
    onClear: () -> Unit,
    onQuickAdd: (Double) -> Unit,
    onSaveTransaction: () -> Unit,
    canSave: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Quick Currency shortcuts row (Algerian Banknotes)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickCashChip(label = "+100 دج", amount = 100.0, isDark = isDark) { onQuickAdd(100.0) }
            QuickCashChip(label = "+200 دج", amount = 200.0, isDark = isDark) { onQuickAdd(200.0) }
            QuickCashChip(label = "+500 دج", amount = 500.0, isDark = isDark) { onQuickAdd(500.0) }
            QuickCashChip(label = "+1000 دج", amount = 1000.0, isDark = isDark) { onQuickAdd(1000.0) }
            QuickCashChip(label = "+2000 دج", amount = 2000.0, isDark = isDark) { onQuickAdd(2000.0) }
        }

        // Row 1: 7, 8, 9, AC
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CalculatorButton(
                text = "7",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_7",
                onClick = { onDigit("7") }
            )
            CalculatorButton(
                text = "8",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_8",
                onClick = { onDigit("8") }
            )
            CalculatorButton(
                text = "9",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_9",
                onClick = { onDigit("9") }
            )
            CalculatorButton(
                text = "AC",
                type = KeypadButtonType.ACTION_CLEAR,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_ac",
                onClick = onClear
            )
        }

        // Row 2: 4, 5, 6, ⌫
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CalculatorButton(
                text = "4",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_4",
                onClick = { onDigit("4") }
            )
            CalculatorButton(
                text = "5",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_5",
                onClick = { onDigit("5") }
            )
            CalculatorButton(
                text = "6",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_6",
                onClick = { onDigit("6") }
            )
            CalculatorButton(
                text = "⌫",
                type = KeypadButtonType.ACTION_SECONDARY,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_delete",
                onClick = onDelete
            )
        }

        // Row 3: 1, 2, 3, 00
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CalculatorButton(
                text = "1",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_1",
                onClick = { onDigit("1") }
            )
            CalculatorButton(
                text = "2",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_2",
                onClick = { onDigit("2") }
            )
            CalculatorButton(
                text = "3",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_3",
                onClick = { onDigit("3") }
            )
            CalculatorButton(
                text = "00",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_00",
                onClick = { onDigit("00") }
            )
        }

        // Row 4: 0, ., حفظ في السجل (Save transaction)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CalculatorButton(
                text = "0",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_0",
                onClick = { onDigit("0") }
            )
            CalculatorButton(
                text = ".",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(58.dp),
                testTag = "cashier_btn_dot",
                onClick = { onDigit(".") }
            )
            CalculatorButton(
                text = "حفظ العملية",
                icon = Icons.Default.Check,
                type = if (canSave) KeypadButtonType.EQUALS else KeypadButtonType.ACTION_SECONDARY,
                isDark = isDark,
                modifier = Modifier.weight(2f).height(58.dp),
                testTag = "cashier_btn_save",
                onClick = onSaveTransaction
            )
        }
    }
}
