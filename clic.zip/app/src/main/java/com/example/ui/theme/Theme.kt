package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val ClickSchoolDarkColorScheme = darkColorScheme(
    primary = ClickBlue,
    onPrimary = TextPrimary,
    primaryContainer = BgCardDark,
    onPrimaryContainer = ClickBlueLight,
    secondary = ClickPurple,
    onSecondary = TextPrimary,
    secondaryContainer = BgCardHover,
    onSecondaryContainer = ClickPurpleLight,
    tertiary = ClickAmber,
    onTertiary = BgDark,
    background = BgDark,
    onBackground = TextPrimary,
    surface = BgCardDark,
    onSurface = TextPrimary,
    surfaceVariant = BgCardHover,
    onSurfaceVariant = TextSecondary,
    outline = BorderDark,
    outlineVariant = TextMuted
)

private val ClickSchoolLightColorScheme = lightColorScheme(
    primary = ClickBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF1F5F9),
    onPrimaryContainer = ClickBlueDark,
    secondary = ClickPurple,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF1F5F9),
    onSecondaryContainer = ClickPurple,
    tertiary = ClickAmber,
    onTertiary = Color.White,
    background = Color.White,
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    outlineVariant = Color(0xFF94A3B8)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) ClickSchoolDarkColorScheme else ClickSchoolLightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val insetsController = WindowCompat.getInsetsController(window, view)
                if (darkTheme) {
                    window.statusBarColor = BgDark.toArgb()
                    window.navigationBarColor = BgDark.toArgb()
                    insetsController.isAppearanceLightStatusBars = false
                    insetsController.isAppearanceLightNavigationBars = false
                } else {
                    window.statusBarColor = android.graphics.Color.WHITE
                    window.navigationBarColor = android.graphics.Color.WHITE
                    insetsController.isAppearanceLightStatusBars = true
                    insetsController.isAppearanceLightNavigationBars = true
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

