package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// سمة Android Studio Darcula الداكنة
private val StudioDarkColorScheme = darkColorScheme(
    primary = StudioAccentBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF2E436E),
    onPrimaryContainer = Color(0xFFDFE1E5),
    secondary = StudioBuildGreen,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF1D472E),
    onSecondaryContainer = Color(0xFFDFE1E5),
    tertiary = Color(0xFF56A8F5),
    onTertiary = Color.White,
    background = StudioDarkBackground,
    onBackground = StudioTextPrimary,
    surface = StudioDarkSurface,
    onSurface = StudioTextPrimary,
    surfaceVariant = StudioEditorBackground,
    onSurfaceVariant = StudioTextSecondary,
    outline = StudioBorder,
    outlineVariant = Color(0xFF2B2D30)
)

// سمة Android Studio Light النهارية الناصعة فائقة الجمالية
private val StudioLightColorScheme = lightColorScheme(
    primary = Color(0xFF0969DA),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDDF4FF),
    onPrimaryContainer = Color(0xFF0969DA),
    secondary = StudioBuildGreen,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFDAFBE8),
    onSecondaryContainer = Color(0xFF1A7F37),
    tertiary = Color(0xFF0969DA),
    onTertiary = Color.White,
    background = StudioLightBackground,
    onBackground = StudioLightTextPrimary,
    surface = StudioLightSurface,
    onSurface = StudioLightTextPrimary,
    surfaceVariant = StudioLightGutterBackground,
    onSurfaceVariant = StudioLightTextSecondary,
    outline = StudioLightBorder,
    outlineVariant = Color(0xFFE8EBF0)
)

// سمة OLED الأسود المطلق (True Pitch Black OLED Scheme)
private val StudioOledColorScheme = darkColorScheme(
    primary = StudioOledAccentNeonCyan,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF003840),
    onPrimaryContainer = StudioOledAccentNeonCyan,
    secondary = StudioOledAccentNeonMint,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF003820),
    onSecondaryContainer = StudioOledAccentNeonMint,
    tertiary = StudioOledAccentNeonMagenta,
    onTertiary = Color.White,
    background = StudioOledBackground,
    onBackground = StudioOledTextPrimary,
    surface = StudioOledSurface,
    onSurface = StudioOledTextPrimary,
    surfaceVariant = StudioOledSurface,
    onSurfaceVariant = StudioOledTextSecondary,
    outline = StudioOledBorder,
    outlineVariant = Color(0xFF141416)
)

enum class AppThemeMode {
    DARK,
    LIGHT,
    OLED
}

@Composable
fun DroidIdeTheme(
    themeMode: AppThemeMode = AppThemeMode.DARK,
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    val colorScheme = when (themeMode) {
        AppThemeMode.DARK -> StudioDarkColorScheme
        AppThemeMode.LIGHT -> StudioLightColorScheme
        AppThemeMode.OLED -> StudioOledColorScheme
    }

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val insetsController = WindowCompat.getInsetsController(window, view)
                val statusBarHex = when (themeMode) {
                    AppThemeMode.DARK -> "#1E1F22"
                    AppThemeMode.LIGHT -> "#F7F8FA"
                    AppThemeMode.OLED -> "#000000"
                }
                val navBarHex = when (themeMode) {
                    AppThemeMode.DARK -> "#2B2D30"
                    AppThemeMode.LIGHT -> "#FFFFFF"
                    AppThemeMode.OLED -> "#000000"
                }
                @Suppress("DEPRECATION")
                window.statusBarColor = android.graphics.Color.parseColor(statusBarHex)
                @Suppress("DEPRECATION")
                window.navigationBarColor = android.graphics.Color.parseColor(navBarHex)
                insetsController.isAppearanceLightStatusBars = (themeMode == AppThemeMode.LIGHT)
                insetsController.isAppearanceLightNavigationBars = (themeMode == AppThemeMode.LIGHT)
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

// زيادة توافقية للدوال السابقة
@Composable
fun DroidIdeTheme(
    isDark: Boolean,
    content: @Composable () -> Unit
) {
    DroidIdeTheme(
        themeMode = if (isDark) AppThemeMode.DARK else AppThemeMode.LIGHT,
        content = content
    )
}

