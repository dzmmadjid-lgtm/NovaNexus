package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// Accent Colors
private val PrimaryEmerald = Color(0xFF00E676)
private val PrimaryCyan = Color(0xFF00ACC1)
private val PrimaryBlue = Color(0xFF0091EA)
private val DarkCardSurface = Color(0xFF0C0E12)
private val DarkCardBorder = Color(0xFF1F242D)

// Pure OLED Dark Theme (#000000)
private val DarkColorScheme = darkColorScheme(
    primary = PrimaryEmerald,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF00381C),
    onPrimaryContainer = Color(0xFF69F0AE),
    secondary = PrimaryCyan,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF00363D),
    onSecondaryContainer = Color(0xFF80DEEA),
    tertiary = PrimaryBlue,
    onTertiary = Color.White,
    background = Color(0xFF000000), // True OLED Deep Pure Black
    onBackground = Color(0xFFEDEDED),
    surface = Color(0xFF000000), // Pure Black Surface
    onSurface = Color(0xFFEDEDED),
    surfaceVariant = Color(0xFF0F1216),
    onSurfaceVariant = Color(0xFF9E9E9E),
    surfaceContainer = Color(0xFF08090C),
    surfaceContainerHigh = Color(0xFF12151B),
    surfaceContainerLow = Color(0xFF000000),
    outline = Color(0xFF232832),
    outlineVariant = Color(0xFF161A22)
)

// Crisp Modern Light Theme
private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF00A352),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD4F8E4),
    onPrimaryContainer = Color(0xFF004D25),
    secondary = Color(0xFF00838F),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0F7FA),
    onSecondaryContainer = Color(0xFF004D40),
    tertiary = Color(0xFF0277BD),
    onTertiary = Color.White,
    background = Color(0xFFF6F8FA),
    onBackground = Color(0xFF0D1117),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0D1117),
    surfaceVariant = Color(0xFFEAEFF5),
    onSurfaceVariant = Color(0xFF57606A),
    surfaceContainer = Color(0xFFF0F3F6),
    surfaceContainerHigh = Color(0xFFE1E4E8),
    surfaceContainerLow = Color(0xFFFFFFFF),
    outline = Color(0xFFD0D7DE),
    outlineVariant = Color(0xFFE1E4E8)
)

@Composable
fun ApkBuilderTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val insetsController = WindowCompat.getInsetsController(window, view)
                if (darkTheme) {
                    window.statusBarColor = android.graphics.Color.parseColor("#000000")
                    window.navigationBarColor = android.graphics.Color.parseColor("#000000")
                    insetsController.isAppearanceLightStatusBars = false
                    insetsController.isAppearanceLightNavigationBars = false
                } else {
                    window.statusBarColor = android.graphics.Color.parseColor("#F6F8FA")
                    window.navigationBarColor = android.graphics.Color.parseColor("#F6F8FA")
                    insetsController.isAppearanceLightStatusBars = true
                    insetsController.isAppearanceLightNavigationBars = true
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
