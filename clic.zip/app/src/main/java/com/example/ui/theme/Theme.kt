package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = CyberNeonGreen,
    onPrimary = Color(0xFF0A0E17),
    primaryContainer = Color(0xFF00381C),
    onPrimaryContainer = CyberNeonGreen,
    secondary = CyberCyan,
    onSecondary = Color(0xFF0A0E17),
    secondaryContainer = Color(0xFF003644),
    onSecondaryContainer = CyberCyan,
    tertiary = PubgYellow,
    onTertiary = Color(0xFF0A0E17),
    background = CyberDarkBg,
    onBackground = TextPrimary,
    surface = CyberDarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberDarkCard,
    onSurfaceVariant = TextSecondary,
    surfaceContainer = CyberDarkCardElevated,
    surfaceContainerHigh = Color(0xFF253350),
    surfaceContainerLow = Color(0xFF0E1420),
    outline = CyberDarkBorder,
    outlineVariant = Color(0xFF1E2B40),
    error = CyberRed,
    onError = Color.White
)

@Composable
fun PubgBoosterTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = DarkColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val insetsController = WindowCompat.getInsetsController(window, view)
                window.statusBarColor = android.graphics.Color.parseColor("#0A0E17")
                window.navigationBarColor = android.graphics.Color.parseColor("#0A0E17")
                insetsController.isAppearanceLightStatusBars = false
                insetsController.isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
