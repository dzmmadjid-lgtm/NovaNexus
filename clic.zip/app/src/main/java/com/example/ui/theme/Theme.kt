package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.example.model.AppThemeMode

// True OLED Pure Black Color Scheme
private val OledColorScheme = darkColorScheme(
    primary = TikTokPink,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF4A0A17),
    onPrimaryContainer = Color(0xFFFFB2BF),
    secondary = TikTokCyan,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF003837),
    onSecondaryContainer = Color(0xFF8CF8F5),
    tertiary = PurpleAccent,
    onTertiary = Color.White,
    background = OledBackground,
    onBackground = OledTextPrimary,
    surface = OledSurface,
    onSurface = OledTextPrimary,
    surfaceVariant = OledCardSurface,
    onSurfaceVariant = OledTextSecondary,
    surfaceContainer = OledCardSurface,
    surfaceContainerHigh = OledCardSurfaceHigh,
    surfaceContainerLow = OledBackground,
    outline = OledBorder,
    outlineVariant = Color(0xFF14141B)
)

// Charcoal Dark Color Scheme
private val DarkColorScheme = darkColorScheme(
    primary = TikTokPink,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF5C1020),
    onPrimaryContainer = Color(0xFFFFB2BF),
    secondary = TikTokCyan,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF084544),
    onSecondaryContainer = Color(0xFF8CF8F5),
    tertiary = PurpleAccent,
    onTertiary = Color.White,
    background = DarkBackground,
    onBackground = DarkTextPrimary,
    surface = DarkSurface,
    onSurface = DarkTextPrimary,
    surfaceVariant = DarkCardSurface,
    onSurfaceVariant = DarkTextSecondary,
    surfaceContainer = DarkCardSurface,
    surfaceContainerHigh = DarkCardSurfaceHigh,
    surfaceContainerLow = DarkBackground,
    outline = DarkBorder,
    outlineVariant = Color(0xFF252535)
)

// Crisp Light Color Scheme
private val LightColorScheme = lightColorScheme(
    primary = TikTokPinkDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFE5EA),
    onPrimaryContainer = Color(0xFF7A001C),
    secondary = TikTokCyanDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE0FBFB),
    onSecondaryContainer = Color(0xFF004D4A),
    tertiary = PurpleAccent,
    onTertiary = Color.White,
    background = LightBackground,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightCardSurfaceHigh,
    onSurfaceVariant = LightTextSecondary,
    surfaceContainer = LightCardSurfaceHigh,
    surfaceContainerHigh = Color(0xFFE6E9EF),
    surfaceContainerLow = LightSurface,
    outline = LightBorder,
    outlineVariant = Color(0xFFD6D9E0)
)

@Composable
fun TikDownloaderTheme(
    themeMode: AppThemeMode = AppThemeMode.OLED,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        AppThemeMode.OLED -> OledColorScheme
        AppThemeMode.DARK -> DarkColorScheme
        AppThemeMode.LIGHT -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val insetsController = WindowCompat.getInsetsController(window, view)
                when (themeMode) {
                    AppThemeMode.OLED -> {
                        window.statusBarColor = android.graphics.Color.parseColor("#000000")
                        window.navigationBarColor = android.graphics.Color.parseColor("#000000")
                        insetsController.isAppearanceLightStatusBars = false
                        insetsController.isAppearanceLightNavigationBars = false
                    }
                    AppThemeMode.DARK -> {
                        window.statusBarColor = android.graphics.Color.parseColor("#121216")
                        window.navigationBarColor = android.graphics.Color.parseColor("#121216")
                        insetsController.isAppearanceLightStatusBars = false
                        insetsController.isAppearanceLightNavigationBars = false
                    }
                    AppThemeMode.LIGHT -> {
                        window.statusBarColor = android.graphics.Color.parseColor("#F7F8FA")
                        window.navigationBarColor = android.graphics.Color.parseColor("#F7F8FA")
                        insetsController.isAppearanceLightStatusBars = true
                        insetsController.isAppearanceLightNavigationBars = true
                    }
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
