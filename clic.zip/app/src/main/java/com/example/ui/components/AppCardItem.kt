package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppItem

@Composable
fun AppCardItem(
    app: AppItem,
    isSelected: Boolean,
    isMultiSelectMode: Boolean,
    isDark: Boolean,
    onExtractClick: () -> Unit,
    onShareClick: () -> Unit,
    onOpenClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onToggleSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }

    val cardBg = when {
        isSelected -> if (isDark) Color(0xFF064E3B).copy(alpha = 0.4f) else Color(0xFFD1FAE5)
        isDark -> Color(0xFF161822)
        else -> Color(0xFFFFFFFF)
    }

    val borderColor = when {
        isSelected -> Color(0xFF10B981)
        isDark -> Color(0xFF26293B)
        else -> Color(0xFFE2E8F0)
    }

    val textPrimary = if (isDark) Color(0xFFF1F5F9) else Color(0xFF0F172A)
    val textSecondary = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
    val accentEmerald = Color(0xFF10B981)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(cardBg)
            .border(if (isSelected) 1.5.dp else 1.dp, borderColor, RoundedCornerShape(16.dp))
            .clickable {
                if (isMultiSelectMode) {
                    onToggleSelect()
                } else {
                    onExtractClick()
                }
            }
            .padding(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Multi-select Checkbox / App Icon
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onToggleSelect() },
                    contentAlignment = Alignment.Center
                ) {
                    AppIconImage(
                        drawable = app.icon,
                        modifier = Modifier
                            .size(50.dp)
                            .clip(RoundedCornerShape(13.dp))
                    )

                    if (isMultiSelectMode || isSelected) {
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(
                                    if (isSelected) accentEmerald.copy(alpha = 0.85f)
                                    else Color.Black.copy(alpha = 0.4f),
                                    shape = RoundedCornerShape(13.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "محدد",
                                    tint = Color.White,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // App Info Titles
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = app.appName,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )

                        // System or User Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    if (app.isSystemApp) Color(0xFFEF4444).copy(alpha = 0.15f)
                                    else Color(0xFF3B82F6).copy(alpha = 0.15f)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (app.isSystemApp) "نظام" else "مثبت",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (app.isSystemApp) Color(0xFFEF4444) else Color(0xFF3B82F6)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = app.packageName,
                        fontSize = 11.sp,
                        color = textSecondary,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Chips: Version & Size
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isDark) Color(0xFF222638) else Color(0xFFF1F5F9))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "v${app.versionName}",
                                fontSize = 10.sp,
                                color = textSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(accentEmerald.copy(alpha = 0.12f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = app.formattedSize,
                                fontSize = 10.sp,
                                color = accentEmerald,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Quick Action Button (Extract)
                IconButton(
                    onClick = onExtractClick,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(accentEmerald.copy(alpha = 0.15f))
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "استخراج APK",
                        tint = accentEmerald,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // More Menu Button
                Box {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.OpenInNew,
                            contentDescription = "خيارات إضافية",
                            tint = textSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier.background(if (isDark) Color(0xFF1E2130) else Color.White)
                    ) {
                        DropdownMenuItem(
                            text = { Text("تشغيل التطبيق", fontSize = 13.sp, color = textPrimary) },
                            leadingIcon = { Icon(Icons.Default.OpenInNew, null, tint = Color(0xFF3B82F6), modifier = Modifier.size(18.dp)) },
                            onClick = {
                                showMenu = false
                                onOpenClick()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("إعدادات التطبيق", fontSize = 13.sp, color = textPrimary) },
                            leadingIcon = { Icon(Icons.Default.Settings, null, tint = textSecondary, modifier = Modifier.size(18.dp)) },
                            onClick = {
                                showMenu = false
                                onSettingsClick()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("مشاركة APK", fontSize = 13.sp, color = textPrimary) },
                            leadingIcon = { Icon(Icons.Default.Share, null, tint = accentEmerald, modifier = Modifier.size(18.dp)) },
                            onClick = {
                                showMenu = false
                                onShareClick()
                            }
                        )
                    }
                }
            }
        }
    }
}
