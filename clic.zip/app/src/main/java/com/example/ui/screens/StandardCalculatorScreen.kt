package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.StandardCalculatorKeypad
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.DarkTextSecondary
import com.example.ui.theme.LightSurfaceBorder
import com.example.ui.theme.LightSurfaceElevated
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.LightTextSecondary
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.NeonRed
import com.example.viewmodel.CalculatorUiState

@Composable
fun StandardCalculatorScreen(
    state: CalculatorUiState,
    isDark: Boolean,
    onInput: (String) -> Unit,
    onOperator: (String) -> Unit,
    onClear: () -> Unit,
    onDelete: () -> Unit,
    onPercentage: () -> Unit,
    onToggleSign: () -> Unit,
    onEquals: () -> Unit,
    onOpenChangeDialog: () -> Unit,
    onOpenHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val exprScrollState = rememberScrollState()

    LaunchedEffect(state.expression) {
        exprScrollState.animateScrollTo(exprScrollState.maxValue)
    }

    val displayBg = if (isDark) DarkSurfaceElevated else LightSurfaceElevated
    val displayBorder = if (isDark) DarkSurfaceBorder else LightSurfaceBorder
    val textPrimary = if (isDark) DarkTextPrimary else LightTextPrimary
    val textSecondary = if (isDark) DarkTextSecondary else LightTextSecondary
    val actionBtnBg = if (isDark) Color(0xFF27272A) else Color(0xFFF4F4F5)
    val actionBtnBorder = if (isDark) Color(0xFF3F3F46) else Color(0xFFE4E4E7)

    Column(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Display Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(displayBg)
                .border(1.dp, displayBorder, RoundedCornerShape(24.dp))
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.End
            ) {
                // Expression Line
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(exprScrollState, reverseScrolling = true),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (state.expression.isEmpty() && !state.isEvaluated) "0" else state.expression,
                        color = textSecondary,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.End,
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Error Message / Preview Result / Final Result
                if (state.errorMessage != null) {
                    Text(
                        text = state.errorMessage,
                        color = if (isDark) NeonRed else Color(0xFFDC2626),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.End
                    )
                } else if (state.isEvaluated && state.finalResult.isNotEmpty()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Result", state.finalResult))
                                Toast.makeText(context, "تم نسخ النتيجة: ${state.finalResult}", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "نسخ",
                                tint = textSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Text(
                            text = "= " + state.finalResult,
                            color = textPrimary,
                            fontSize = if (state.finalResult.length > 10) 30.sp else 40.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.End,
                            maxLines = 1
                        )
                    }
                } else if (state.previewResult.isNotEmpty()) {
                    Text(
                        text = "≈ " + state.previewResult,
                        color = if (isDark) NeonCyan.copy(alpha = 0.8f) else Color(0xFF0284C7),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.End,
                        maxLines = 1
                    )
                } else {
                    Text(
                        text = "0",
                        color = textPrimary.copy(alpha = 0.3f),
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.End
                    )
                }

                // Arabic Tafqeet line (if result evaluated)
                AnimatedVisibility(
                    visible = state.isEvaluated && state.standardTafqeet.isNotEmpty(),
                    enter = fadeIn(),
                    exit = fadeOut()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isDark) NeonOrange.copy(alpha = 0.12f) else NeonOrange.copy(alpha = 0.08f))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "✍️ " + state.standardTafqeet,
                                color = if (isDark) NeonOrange else Color(0xFFEA580C),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                textAlign = TextAlign.End
                            )
                        }
                    }
                }
            }
        }

        // Keypad
        StandardCalculatorKeypad(
            isDark = isDark,
            onInput = onInput,
            onOperator = onOperator,
            onClear = onClear,
            onDelete = onDelete,
            onPercentage = onPercentage,
            onToggleSign = onToggleSign,
            onEquals = onEquals
        )
    }
}
