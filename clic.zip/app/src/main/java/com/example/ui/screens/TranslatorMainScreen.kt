package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.viewmodel.TranslatorViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TranslatorMainScreen(
    viewModel: TranslatorViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current

    var showApiKeyDialog by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissSnackbar()
        }
    }

    val isDark = uiState.isDarkTheme
    val bgGradient = if (isDark) {
        Brush.verticalGradient(listOf(Color(0xFF0F172A), Color(0xFF020617)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFFF1F5F9), Color(0xFFE2E8F0)))
    }

    val surfaceCardColor = if (isDark) Color(0xFF1E293B) else Color.White
    val borderCol = if (isDark) Color(0xFF334155) else Color(0xFFCBD5E1)
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val textSecondary = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
    val primaryIndigo = Color(0xFF6366F1)
    val primaryCyan = Color(0xFF06B6D4)

    val quickSampleIdioms = remember {
        listOf(
            Triple("Piece of cake", AppLanguage.ENGLISH, AppLanguage.ARABIC),
            Triple("C'est la vie", AppLanguage.FRENCH, AppLanguage.ARABIC),
            Triple("Break a leg", AppLanguage.ENGLISH, AppLanguage.ARABIC),
            Triple("ضرب عصفورين بحجر", AppLanguage.ARABIC, AppLanguage.ENGLISH),
            Triple("Under the weather", AppLanguage.ENGLISH, AppLanguage.ARABIC),
            Triple("Coup de foudre", AppLanguage.FRENCH, AppLanguage.ARABIC),
            Triple("على أحر من الجمر", AppLanguage.ARABIC, AppLanguage.ENGLISH)
        )
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Brush.linearGradient(listOf(primaryIndigo, primaryCyan))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "مترجم الذكاء الاصطناعي",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = textPrimary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = primaryIndigo.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "سياقي ذكي",
                                        color = primaryIndigo,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "عربي • English • Français",
                                style = MaterialTheme.typography.labelSmall,
                                color = textSecondary
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showApiKeyDialog = true },
                        modifier = Modifier.testTag("settings_api_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Key,
                            contentDescription = "مفتاح API",
                            tint = textSecondary
                        )
                    }
                    IconButton(
                        onClick = { viewModel.toggleTheme() },
                        modifier = Modifier.testTag("theme_btn")
                    ) {
                        Icon(
                            imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "تبديل المظهر",
                            tint = if (isDark) Color(0xFFFBBF24) else textSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = if (isDark) Color(0xFF0F172A) else Color(0xFFF8FAFC)
                )
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(bgGradient)
                .padding(padding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 10.dp, bottom = 40.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Language Selector Card
                item {
                    LanguageSelectorBar(
                        sourceLang = uiState.sourceLanguage,
                        targetLang = uiState.targetLanguage,
                        isDark = isDark,
                        onSourceChange = { viewModel.setSourceLanguage(it) },
                        onTargetChange = { viewModel.setTargetLanguage(it) },
                        onSwap = { viewModel.swapLanguages() }
                    )
                }

                // Translation Tone Selector
                item {
                    ToneSelectorRow(
                        selectedTone = uiState.selectedTone,
                        onToneSelected = { viewModel.setTone(it) },
                        isDark = isDark
                    )
                }

                // Input Box Card
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .border(1.dp, borderCol, RoundedCornerShape(18.dp)),
                        colors = CardDefaults.cardColors(containerColor = surfaceCardColor),
                        shape = RoundedCornerShape(18.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "أدخل النص أو التعبير:",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = textSecondary
                                )
                                if (uiState.inputText.isNotEmpty()) {
                                    IconButton(
                                        onClick = { viewModel.clearInput() },
                                        modifier = Modifier.size(26.dp).testTag("clear_input_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "مسح",
                                            tint = textSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            OutlinedTextField(
                                value = uiState.inputText,
                                onValueChange = { viewModel.onInputTextChanged(it) },
                                placeholder = {
                                    Text(
                                        text = "اكتب كلمة أو جملة أو تعبيراً مجازياً للترجمة السياقية...",
                                        color = textSecondary.copy(alpha = 0.7f),
                                        fontSize = 14.sp
                                    )
                                },
                                minLines = 3,
                                maxLines = 6,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("translation_input_field"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = Color.Transparent,
                                    unfocusedBorderColor = Color.Transparent,
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedTextColor = textPrimary,
                                    unfocusedTextColor = textPrimary
                                ),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(onDone = {
                                    keyboardController?.hide()
                                    viewModel.translate()
                                })
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    if (uiState.inputText.isNotEmpty()) {
                                        IconButton(
                                            onClick = {
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                clipboard.setPrimaryClip(ClipData.newPlainText("Source Text", uiState.inputText))
                                                viewModel.showSnackbar("تم نسخ النص المدخل")
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.ContentCopy,
                                                contentDescription = "نسخ",
                                                tint = textSecondary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        IconButton(
                                            onClick = {
                                                viewModel.speakText(uiState.inputText, uiState.sourceLanguage.code)
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.VolumeUp,
                                                contentDescription = "نطق",
                                                tint = textSecondary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }

                                Button(
                                    onClick = {
                                        keyboardController?.hide()
                                        viewModel.translate()
                                    },
                                    enabled = uiState.inputText.isNotBlank() && !uiState.isTranslating,
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = primaryIndigo),
                                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                                    modifier = Modifier.testTag("translate_btn")
                                ) {
                                    if (uiState.isTranslating) {
                                        CircularProgressIndicator(
                                            color = Color.White,
                                            modifier = Modifier.size(16.dp),
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("جاري الفهم والترجمة...", fontSize = 13.sp, color = Color.White)
                                    } else {
                                        Icon(Icons.Default.Translate, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("ترجمة سياقية ذكية", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }

                // Quick Examples Chips
                item {
                    Column {
                        Text(
                            text = "💡 أمثلة لتعبيرات مجازية وترجمتها السياقية:",
                            style = MaterialTheme.typography.labelSmall,
                            color = textSecondary,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            items(quickSampleIdioms) { sample ->
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable {
                                            viewModel.applyPresetPhrase(sample.first, sample.second, sample.third)
                                        }
                                        .border(1.dp, borderCol, RoundedCornerShape(10.dp)),
                                    color = surfaceCardColor
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = sample.first,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = textPrimary
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "${sample.second.flag} ➔ ${sample.third.flag}",
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Translation Result Card
                uiState.translationResult?.let { result ->
                    if (result.translatedText.isNotEmpty()) {
                        item {
                            TranslationResultView(
                                result = result,
                                targetLangCode = uiState.targetLanguage.code,
                                isDark = isDark,
                                onSpeak = { text -> viewModel.speakText(text, uiState.targetLanguage.code) },
                                onCopy = { text ->
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Translated Text", text))
                                    viewModel.showSnackbar("تم نسخ الترجمة بنجاح ✨")
                                },
                                onShare = { text ->
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, "${uiState.inputText}\n\nالترجمة السياقية:\n$text")
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "مشاركة الترجمة"))
                                }
                            )
                        }
                    }
                }

                // History and Saved Translations Section
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.History,
                                contentDescription = null,
                                tint = primaryIndigo,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (uiState.favoritesOnly) "المفضلة ⭐" else "سجل الترجمات السابقة",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = textPrimary
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChip(
                                selected = uiState.favoritesOnly,
                                onClick = { viewModel.toggleFavoritesFilter() },
                                label = { Text("المفضلة ⭐", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = primaryIndigo.copy(alpha = 0.2f),
                                    selectedLabelColor = primaryIndigo
                                )
                            )
                            if (uiState.historyList.isNotEmpty() && !uiState.favoritesOnly) {
                                IconButton(
                                    onClick = { viewModel.clearAllHistory() },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.DeleteOutline,
                                        contentDescription = "مسح الكل",
                                        tint = textSecondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                val displayedHistory = if (uiState.favoritesOnly) {
                    uiState.historyList.filter { it.isFavorite }
                } else {
                    uiState.historyList
                }

                if (displayedHistory.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = surfaceCardColor.copy(alpha = 0.5f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Box(
                                modifier = Modifier.fillMaxWidth().padding(20.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = if (uiState.favoritesOnly) "لا توجد ترجمات في المفضلة بعد" else "لا يوجد سجل ترجمات حالياً",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = textSecondary
                                )
                            }
                        }
                    }
                } else {
                    items(displayedHistory, key = { it.id }) { item ->
                        HistoryCard(
                            item = item,
                            isDark = isDark,
                            onSelect = {
                                val fromLang = AppLanguage.values().find { it.code == item.sourceLangCode } ?: AppLanguage.AUTO
                                val toLang = AppLanguage.values().find { it.code == item.targetLangCode } ?: AppLanguage.ARABIC
                                viewModel.applyPresetPhrase(item.sourceText, fromLang, toLang)
                            },
                            onToggleFavorite = { viewModel.toggleFavorite(item) },
                            onDelete = { viewModel.deleteHistoryItem(item) },
                            onSpeak = { viewModel.speakText(item.translatedText, item.targetLangCode) },
                            onCopy = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                clipboard.setPrimaryClip(ClipData.newPlainText("Translated Text", item.translatedText))
                                viewModel.showSnackbar("تم نسخ النص")
                            }
                        )
                    }
                }
            }
        }
    }

    if (showApiKeyDialog) {
        ApiKeySettingsDialog(
            currentKey = uiState.customApiKey,
            isDark = isDark,
            onDismiss = { showApiKeyDialog = false },
            onSave = {
                viewModel.setCustomApiKey(it)
                showApiKeyDialog = false
            }
        )
    }
}

@Composable
fun LanguageSelectorBar(
    sourceLang: AppLanguage,
    targetLang: AppLanguage,
    isDark: Boolean,
    onSourceChange: (AppLanguage) -> Unit,
    onTargetChange: (AppLanguage) -> Unit,
    onSwap: () -> Unit
) {
    val surfaceColor = if (isDark) Color(0xFF1E293B) else Color.White
    val borderCol = if (isDark) Color(0xFF334155) else Color(0xFFCBD5E1)
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val textSecondary = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)

    var showSourceMenu by remember { mutableStateOf(false) }
    var showTargetMenu by remember { mutableStateOf(false) }

    var rotationAngle by remember { mutableFloatStateOf(0f) }
    val animatedRotation by animateFloatAsState(
        targetValue = rotationAngle,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "SwapRotation"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, borderCol, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = surfaceColor),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Source Language Selector
            Box(modifier = Modifier.weight(1f)) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { showSourceMenu = true }
                        .padding(horizontal = 6.dp, vertical = 6.dp)
                        .testTag("source_lang_selector"),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "مِن (المصدر)", fontSize = 10.sp, color = textSecondary)
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(text = sourceLang.flag, fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = sourceLang.titleAr,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = textPrimary, modifier = Modifier.size(18.dp))
                    }
                }

                DropdownMenu(
                    expanded = showSourceMenu,
                    onDismissRequest = { showSourceMenu = false }
                ) {
                    AppLanguage.values().forEach { lang ->
                        DropdownMenuItem(
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(lang.flag)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("${lang.titleAr} (${lang.titleNative})")
                                }
                            },
                            onClick = {
                                onSourceChange(lang)
                                showSourceMenu = false
                            }
                        )
                    }
                }
            }

            // Swap Button
            IconButton(
                onClick = {
                    rotationAngle += 180f
                    onSwap()
                },
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF6366F1).copy(alpha = 0.15f))
                    .rotate(animatedRotation)
                    .testTag("swap_languages_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.SwapHoriz,
                    contentDescription = "تبديل اللغات",
                    tint = Color(0xFF6366F1),
                    modifier = Modifier.size(22.dp)
                )
            }

            // Target Language Selector
            Box(modifier = Modifier.weight(1f)) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { showTargetMenu = true }
                        .padding(horizontal = 6.dp, vertical = 6.dp)
                        .testTag("target_lang_selector"),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "إلَى (الهدف)", fontSize = 10.sp, color = textSecondary)
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(text = targetLang.flag, fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = targetLang.titleAr,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = textPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = textPrimary, modifier = Modifier.size(18.dp))
                    }
                }

                DropdownMenu(
                    expanded = showTargetMenu,
                    onDismissRequest = { showTargetMenu = false }
                ) {
                    AppLanguage.values().filter { it != AppLanguage.AUTO }.forEach { lang ->
                        DropdownMenuItem(
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(lang.flag)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("${lang.titleAr} (${lang.titleNative})")
                                }
                            },
                            onClick = {
                                onTargetChange(lang)
                                showTargetMenu = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ToneSelectorRow(
    selectedTone: TranslationTone,
    onToneSelected: (TranslationTone) -> Unit,
    isDark: Boolean
) {
    val borderCol = if (isDark) Color(0xFF334155) else Color(0xFFCBD5E1)
    val primaryIndigo = Color(0xFF6366F1)

    Column {
        Text(
            text = "أسلوب وسياق الترجمة:",
            style = MaterialTheme.typography.labelSmall,
            color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B),
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 2.dp)
        ) {
            items(TranslationTone.values()) { tone ->
                val isSelected = selectedTone == tone
                FilterChip(
                    selected = isSelected,
                    onClick = { onToneSelected(tone) },
                    label = {
                        Text(
                            text = "${tone.icon} ${tone.titleAr}",
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = primaryIndigo.copy(alpha = 0.25f),
                        selectedLabelColor = primaryIndigo
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = if (isSelected) primaryIndigo else borderCol
                    )
                )
            }
        }
    }
}

@Composable
fun TranslationResultView(
    result: TranslationResult,
    targetLangCode: String,
    isDark: Boolean,
    onSpeak: (String) -> Unit,
    onCopy: (String) -> Unit,
    onShare: (String) -> Unit
) {
    val cardBg = if (isDark) Color(0xFF1E293B) else Color.White
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val textSecondary = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
    val primaryCyan = Color(0xFF06B6D4)
    val primaryIndigo = Color(0xFF6366F1)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.5.dp, primaryIndigo.copy(alpha = 0.6f), RoundedCornerShape(18.dp)),
        colors = CardDefaults.cardColors(containerColor = cardBg),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(primaryCyan)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "الترجمة السياقية الحقيقية ✨",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = primaryIndigo
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(
                        onClick = { onSpeak(result.translatedText) },
                        modifier = Modifier.size(32.dp).testTag("speak_result_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "نطق الترجمة",
                            tint = primaryIndigo,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(
                        onClick = { onCopy(result.translatedText) },
                        modifier = Modifier.size(32.dp).testTag("copy_result_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ContentCopy,
                            contentDescription = "نسخ",
                            tint = textSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    IconButton(
                        onClick = { onShare(result.translatedText) },
                        modifier = Modifier.size(32.dp).testTag("share_result_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "مشاركة",
                            tint = textSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Main Translated Text
            Text(
                text = result.translatedText,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
                color = textPrimary,
                lineHeight = 32.sp
            )

            // Context / Idiom Explanation Card
            result.contextExplanation?.let { explanation ->
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = primaryCyan.copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, primaryCyan.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lightbulb,
                            contentDescription = null,
                            tint = Color(0xFF0284C7),
                            modifier = Modifier.size(20.dp).padding(top = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "شرح المعنى والسياق الدقيق:",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFF0284C7)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = explanation,
                                style = MaterialTheme.typography.bodySmall,
                                color = textPrimary,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }

            // Alternative Phrasings
            if (result.alternativePhrasings.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "صياغات وبدائل أخرى لنفس المعنى:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = textSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    result.alternativePhrasings.forEach { alt ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDark) Color(0xFF0F172A) else Color(0xFFF1F5F9),
                            modifier = Modifier.fillMaxWidth().clickable { onCopy(alt) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "• $alt",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = textPrimary
                                )
                                Icon(
                                    imageVector = Icons.Outlined.ContentCopy,
                                    contentDescription = null,
                                    tint = textSecondary.copy(alpha = 0.6f),
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Key Vocabulary Breakdown
            if (result.vocabularyBreakdown.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "المفردات المفتاحية:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = textSecondary
                )
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(result.vocabularyBreakdown) { vocab ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isDark) Color(0xFF0F172A) else Color(0xFFF1F5F9),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0))
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text(
                                    text = vocab.word,
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = primaryIndigo
                                )
                                Text(
                                    text = "➔ ${vocab.translation}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = textPrimary
                                )
                                if (vocab.note.isNotBlank()) {
                                    Text(
                                        text = vocab.note,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = textSecondary,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryCard(
    item: TranslationHistoryItem,
    isDark: Boolean,
    onSelect: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit,
    onSpeak: () -> Unit,
    onCopy: () -> Unit
) {
    val cardColor = if (isDark) Color(0xFF1E293B) else Color.White
    val textPrimary = if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
    val textSecondary = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
    val borderCol = if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0)

    val dateFormat = remember { SimpleDateFormat("MM/dd HH:mm", Locale.getDefault()) }
    val formattedDate = remember(item.timestamp) { dateFormat.format(Date(item.timestamp)) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onSelect() }
            .border(1.dp, borderCol, RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val fromFlag = AppLanguage.values().find { it.code == item.sourceLangCode }?.flag ?: "🌐"
                    val toFlag = AppLanguage.values().find { it.code == item.targetLangCode }?.flag ?: "🇸🇦"
                    Text(text = "$fromFlag ➔ $toFlag", fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = formattedDate, fontSize = 10.sp, color = textSecondary)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    IconButton(onClick = onToggleFavorite, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = if (item.isFavorite) Icons.Default.Star else Icons.Outlined.StarBorder,
                            contentDescription = "مفضلة",
                            tint = if (item.isFavorite) Color(0xFFFBBF24) else textSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    IconButton(onClick = onSpeak, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "نطق",
                            tint = textSecondary,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    IconButton(onClick = onCopy, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Outlined.ContentCopy,
                            contentDescription = "نسخ",
                            tint = textSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "حذف",
                            tint = textSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = item.sourceText,
                style = MaterialTheme.typography.bodyMedium,
                color = textSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = item.translatedText,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = textPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun ApiKeySettingsDialog(
    currentKey: String,
    isDark: Boolean,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var key by remember { mutableStateOf(currentKey) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = if (isDark) Color(0xFF0F172A) else Color.White,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Key, contentDescription = null, tint = Color(0xFF6366F1))
                Spacer(modifier = Modifier.width(8.dp))
                Text("إعدادات محرك الترجمة الذكي", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "يستخدم هذا التطبيق محرك Gemini 3.5 Flash للترجمة السياقية الفورية وفهم المعنى والتعبيرات الدارجة.",
                    fontSize = 13.sp,
                    color = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
                )

                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    label = { Text("Gemini API Key (اختياري)") },
                    placeholder = { Text("AIzaSy...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "ملاحظة: إذا تركت الحقل فارغاً، سيتم استخدام مفتاح بيئة AI Studio التلقائي مع دعم القواميس السياقية الذكية.",
                    fontSize = 11.sp,
                    color = if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(key) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6366F1))
            ) {
                Text("حفظ", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
