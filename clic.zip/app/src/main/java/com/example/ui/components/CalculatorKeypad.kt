package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkButtonNumber
import com.example.ui.theme.DarkButtonNumberPressed
import com.example.ui.theme.DarkSurfaceBorder
import com.example.ui.theme.DarkTextPrimary
import com.example.ui.theme.LightButtonNumber
import com.example.ui.theme.LightButtonNumberPressed
import com.example.ui.theme.LightGreen
import com.example.ui.theme.LightOrange
import com.example.ui.theme.LightPurple
import com.example.ui.theme.LightRed
import com.example.ui.theme.LightSurfaceBorder
import com.example.ui.theme.LightTextPrimary
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonOrange
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed

enum class KeypadButtonType {
    NUMBER,
    OPERATOR,
    EQUALS,
    ACTION_CLEAR,
    ACTION_SECONDARY
}

@Composable
fun CalculatorButton(
    text: String? = null,
    icon: ImageVector? = null,
    type: KeypadButtonType = KeypadButtonType.NUMBER,
    isDark: Boolean = true,
    modifier: Modifier = Modifier,
    testTag: String = "calc_btn_${text ?: "icon"}",
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val (bgColor, textColor, borderColor) = when (type) {
        KeypadButtonType.NUMBER -> {
            if (isDark) {
                val bg = if (isPressed) Color(0xFF26293D) else Color(0xFF161826)
                Triple(bg, Color(0xFFFFFFFF), Color(0xFF26293D))
            } else {
                val bg = if (isPressed) Color(0xFFF1F5F9) else Color(0xFFFFFFFF)
                Triple(bg, Color(0xFF0F172A), Color(0xFFE2E8F0))
            }
        }
        KeypadButtonType.OPERATOR -> {
            if (isDark) {
                val bg = if (isPressed) Color(0xFF3D2714) else Color(0xFF2B1B0E)
                Triple(bg, Color(0xFFF59E0B), Color(0xFF523214))
            } else {
                val bg = if (isPressed) Color(0xFFFEEBC8) else Color(0xFFFFFBEB)
                Triple(bg, Color(0xFFD97706), Color(0xFFFED7AA))
            }
        }
        KeypadButtonType.EQUALS -> {
            if (isDark) {
                val bg = if (isPressed) Color(0xFF16A34A) else Color(0xFF22C55E)
                Triple(bg, Color(0xFF000000), Color(0xFF22C55E))
            } else {
                val bg = if (isPressed) Color(0xFF15803D) else Color(0xFF16A34A)
                Triple(bg, Color(0xFFFFFFFF), Color(0xFF16A34A))
            }
        }
        KeypadButtonType.ACTION_CLEAR -> {
            if (isDark) {
                val bg = if (isPressed) Color(0xFF451923) else Color(0xFF33141C)
                Triple(bg, Color(0xFFEF4444), Color(0xFF5C1F2D))
            } else {
                val bg = if (isPressed) Color(0xFFFEE2E2) else Color(0xFFFEF2F2)
                Triple(bg, Color(0xFFDC2626), Color(0xFFFECACA))
            }
        }
        KeypadButtonType.ACTION_SECONDARY -> {
            if (isDark) {
                val bg = if (isPressed) Color(0xFF1C273C) else Color(0xFF141D2E)
                Triple(bg, Color(0xFF38BDF8), Color(0xFF223659))
            } else {
                val bg = if (isPressed) Color(0xFFE0F2FE) else Color(0xFFF0F9FF)
                Triple(bg, Color(0xFF0284C7), Color(0xFFBAE6FD))
            }
        }
    }

    val shape = RoundedCornerShape(22.dp)

    Box(
        modifier = modifier
            .testTag(testTag)
            .clip(shape)
            .background(bgColor)
            .border(1.dp, borderColor, shape)
            .clickable(
                interactionSource = interactionSource,
                indication = ripple(bounded = true, color = textColor.copy(alpha = 0.2f)),
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onClick()
                }
            )
            .padding(horizontal = 4.dp, vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = text ?: "Button",
                tint = textColor,
                modifier = Modifier.size(28.dp)
            )
        } else if (text != null) {
            Text(
                text = text,
                color = textColor,
                fontSize = if (type == KeypadButtonType.NUMBER) 26.sp else if (text.length > 2) 20.sp else 24.sp,
                fontWeight = if (type == KeypadButtonType.EQUALS || type == KeypadButtonType.OPERATOR) FontWeight.Bold else FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun StandardCalculatorKeypad(
    isDark: Boolean,
    onInput: (String) -> Unit,
    onOperator: (String) -> Unit,
    onClear: () -> Unit,
    onDelete: () -> Unit,
    onPercentage: () -> Unit,
    onToggleSign: () -> Unit,
    onEquals: () -> Unit,
    modifier: Modifier = Modifier
) {
    val btnHeight = 70.dp

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Row 1: AC, ⌫, ±, ÷
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CalculatorButton(
                text = "AC",
                type = KeypadButtonType.ACTION_CLEAR,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_ac",
                onClick = onClear
            )
            CalculatorButton(
                text = "⌫",
                type = KeypadButtonType.ACTION_CLEAR,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_backspace",
                onClick = onDelete
            )
            CalculatorButton(
                text = "±",
                type = KeypadButtonType.ACTION_SECONDARY,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_toggle_sign",
                onClick = onToggleSign
            )
            CalculatorButton(
                text = "÷",
                type = KeypadButtonType.OPERATOR,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_divide",
                onClick = { onOperator("÷") }
            )
        }

        // Row 2: 7, 8, 9, ×
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CalculatorButton(
                text = "7",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_7",
                onClick = { onInput("7") }
            )
            CalculatorButton(
                text = "8",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_8",
                onClick = { onInput("8") }
            )
            CalculatorButton(
                text = "9",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_9",
                onClick = { onInput("9") }
            )
            CalculatorButton(
                text = "×",
                type = KeypadButtonType.OPERATOR,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_multiply",
                onClick = { onOperator("×") }
            )
        }

        // Row 3: 4, 5, 6, −
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CalculatorButton(
                text = "4",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_4",
                onClick = { onInput("4") }
            )
            CalculatorButton(
                text = "5",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_5",
                onClick = { onInput("5") }
            )
            CalculatorButton(
                text = "6",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_6",
                onClick = { onInput("6") }
            )
            CalculatorButton(
                text = "−",
                type = KeypadButtonType.OPERATOR,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_minus",
                onClick = { onOperator("−") }
            )
        }

        // Row 4: 1, 2, 3, +
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CalculatorButton(
                text = "1",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_1",
                onClick = { onInput("1") }
            )
            CalculatorButton(
                text = "2",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_2",
                onClick = { onInput("2") }
            )
            CalculatorButton(
                text = "3",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_3",
                onClick = { onInput("3") }
            )
            CalculatorButton(
                text = "+",
                type = KeypadButtonType.OPERATOR,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_plus",
                onClick = { onOperator("+") }
            )
        }

        // Row 5: 0, 00, ., = (00 is placed right next to 0)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            CalculatorButton(
                text = "0",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_0",
                onClick = { onInput("0") }
            )
            CalculatorButton(
                text = "00",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_00",
                onClick = { onInput("00") }
            )
            CalculatorButton(
                text = ".",
                type = KeypadButtonType.NUMBER,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_dot",
                onClick = { onInput(".") }
            )
            CalculatorButton(
                text = "=",
                type = KeypadButtonType.EQUALS,
                isDark = isDark,
                modifier = Modifier.weight(1f).height(btnHeight),
                testTag = "btn_equals",
                onClick = onEquals
            )
        }
    }
}

