package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.YouTubeVideo
import com.example.ui.components.DirectUrlDialog
import com.example.ui.components.FullPlayerSheet
import com.example.ui.components.MiniPlayerBar
import com.example.viewmodel.MainTab
import com.example.viewmodel.YouTubeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YouTubeMainScreen(
    viewModel: YouTubeViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val playbackState by viewModel.playbackState.collectAsState()
    val context = LocalContext.current

    // Request notification permission for background playback controls on Android 13+
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { /* Handled */ }
    )

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // YouTube Red Logo Icon
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFFF0000),
                                modifier = Modifier.size(width = 34.dp, height = 24.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "PlayTube",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = (-0.5).sp
                                )
                            )
                            if (playbackState.isBackgroundPlaybackActive) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = Color(0xFFE8F5E9),
                                    shape = CircleShape,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Headphones,
                                            contentDescription = "الخلفية نشطة",
                                            tint = Color(0xFF2E7D32),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    },
                    actions = {
                        // Direct URL Button
                        FilledTonalIconButton(
                            onClick = { viewModel.setShowUrlDialog(true) },
                            modifier = Modifier
                                .size(38.dp)
                                .testTag("paste_url_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Link,
                                contentDescription = "تشغيل رابط يوتيوب",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Search tab toggle
                        IconButton(
                            onClick = { viewModel.selectTab(MainTab.SEARCH) },
                            modifier = Modifier.size(38.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "بحث",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                Column {
                    // Floating Mini-Player bar above the Navigation bar
                    MiniPlayerBar(
                        playbackState = playbackState,
                        onExpandClick = { viewModel.setExpanded(true) },
                        onTogglePlayPause = { viewModel.togglePlayPause() },
                        onSkipNext = { viewModel.playNext() },
                        onCloseClick = { viewModel.closePlayer() }
                    )

                    // Navigation Bar
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surfaceContainer,
                        tonalElevation = 4.dp
                    ) {
                        NavigationBarItem(
                            selected = uiState.selectedTab == MainTab.HOME,
                            onClick = { viewModel.selectTab(MainTab.HOME) },
                            icon = { Icon(Icons.Default.Home, contentDescription = "الرئيسية") },
                            label = { Text("الرئيسية") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color(0xFFFF0000),
                                indicatorColor = Color(0xFFFF0000).copy(alpha = 0.15f)
                            )
                        )

                        NavigationBarItem(
                            selected = uiState.selectedTab == MainTab.SEARCH,
                            onClick = { viewModel.selectTab(MainTab.SEARCH) },
                            icon = { Icon(Icons.Default.Search, contentDescription = "بحث") },
                            label = { Text("بحث") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color(0xFFFF0000),
                                indicatorColor = Color(0xFFFF0000).copy(alpha = 0.15f)
                            )
                        )

                        NavigationBarItem(
                            selected = uiState.selectedTab == MainTab.FAVORITES,
                            onClick = { viewModel.selectTab(MainTab.FAVORITES) },
                            icon = { Icon(Icons.Default.Bookmark, contentDescription = "المفضلة") },
                            label = { Text("المفضلة") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color(0xFFFF0000),
                                indicatorColor = Color(0xFFFF0000).copy(alpha = 0.15f)
                            )
                        )

                        NavigationBarItem(
                            selected = uiState.selectedTab == MainTab.HISTORY,
                            onClick = { viewModel.selectTab(MainTab.HISTORY) },
                            icon = { Icon(Icons.Default.History, contentDescription = "السجل") },
                            label = { Text("السجل") },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color(0xFFFF0000),
                                indicatorColor = Color(0xFFFF0000).copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (uiState.selectedTab) {
                    MainTab.HOME -> {
                        HomeScreen(
                            uiState = uiState,
                            onSelectCategory = { viewModel.selectCategory(it) },
                            onVideoClick = { video -> viewModel.playVideo(video) },
                            onBackgroundPlayClick = { video ->
                                viewModel.playVideo(video)
                                viewModel.toggleBackgroundPlayback()
                            },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onRefresh = { viewModel.loadTrendingVideos(uiState.selectedCategory) }
                        )
                    }

                    MainTab.SEARCH -> {
                        SearchScreen(
                            uiState = uiState,
                            onQueryChanged = { viewModel.onSearchQueryChanged(it) },
                            onSearch = { viewModel.performSearch(it) },
                            onClearSearch = { viewModel.clearSearch() },
                            onVideoClick = { video -> viewModel.playVideo(video, uiState.searchResults) },
                            onBackgroundPlayClick = { video ->
                                viewModel.playVideo(video, uiState.searchResults)
                                viewModel.toggleBackgroundPlayback()
                            },
                            onToggleFavorite = { viewModel.toggleFavorite(it) }
                        )
                    }

                    MainTab.FAVORITES -> {
                        FavoritesScreen(
                            uiState = uiState,
                            onVideoClick = { video -> viewModel.playVideo(video, uiState.favoriteVideos) },
                            onBackgroundPlayClick = { video ->
                                viewModel.playVideo(video, uiState.favoriteVideos)
                                viewModel.toggleBackgroundPlayback()
                            },
                            onToggleFavorite = { viewModel.toggleFavorite(it) }
                        )
                    }

                    MainTab.HISTORY -> {
                        HistoryScreen(
                            uiState = uiState,
                            onVideoClick = { video -> viewModel.playVideo(video, uiState.historyVideos) },
                            onBackgroundPlayClick = { video ->
                                viewModel.playVideo(video, uiState.historyVideos)
                                viewModel.toggleBackgroundPlayback()
                            },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onClearHistory = { viewModel.clearHistory() }
                        )
                    }
                }
            }
        }

        // Direct URL / ID input dialog
        if (uiState.showUrlDialog) {
            DirectUrlDialog(
                onDismiss = { viewModel.setShowUrlDialog(false) },
                onPlayUrl = { input -> viewModel.playFromDirectInput(input) }
            )
        }

        // Fullscreen / Expanded Player Overlay Sheet
        AnimatedVisibility(
            visible = playbackState.isPlayerExpanded && playbackState.currentVideo != null,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            val currentVid = playbackState.currentVideo
            if (currentVid != null) {
                FullPlayerSheet(
                    playbackState = playbackState,
                    isFavorite = viewModel.isFavorite(currentVid.id),
                    onCollapse = { viewModel.setExpanded(false) },
                    onTogglePlayPause = { viewModel.togglePlayPause() },
                    onSkipNext = { viewModel.playNext() },
                    onSkipPrevious = { viewModel.playPrevious() },
                    onSeekTo = { seconds -> viewModel.seekTo(seconds) },
                    onToggleBackgroundPlayback = { viewModel.toggleBackgroundPlayback() },
                    onToggleFavorite = { viewModel.toggleFavorite(currentVid) },
                    onSetSpeed = { speed -> viewModel.setPlaybackSpeed(speed) },
                    onToggleLoop = { viewModel.toggleLoop() },
                    onSelectQueueVideo = { qVideo -> viewModel.playVideo(qVideo, playbackState.queue) }
                )
            }
        }
    }
}
