package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.model.YouTubeVideo
import com.example.ui.theme.YouTubeRed

@Composable
fun YouTubeFeedVideoCard(
    video: YouTubeVideo,
    isInlinePlaying: Boolean,
    isAudioPlayingThis: Boolean,
    onVideoClick: () -> Unit,
    onInlineToggleMute: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onVideoClick() }
            .testTag("feed_card_${video.id}")
    ) {
        // Full Width 16:9 Thumbnail / Inline Player
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .background(Color.Black)
        ) {
            if (isInlinePlaying) {
                InlineMutedPlayerView(
                    videoId = video.id,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(video.thumbnailUrl)
                        .crossfade(true)
                        .build(),
                    contentDescription = video.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Top-Left Overlays (Mute button & CC button like YouTube inline preview)
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = CircleShape,
                    color = Color.Black.copy(alpha = 0.65f),
                    modifier = Modifier.size(34.dp)
                ) {
                    IconButton(
                        onClick = {
                            if (isInlinePlaying) {
                                onVideoClick()
                            } else {
                                onInlineToggleMute()
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Icon(
                            imageVector = if (isAudioPlayingThis) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = "كتم/تشغيل الصوت",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = 0.65f),
                    modifier = Modifier.size(width = 34.dp, height = 34.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = "CC",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Bottom-Left Duration Badge (exact style from user's screenshot)
            Surface(
                color = if (video.isLive) YouTubeRed else Color.Black.copy(alpha = 0.82f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
            ) {
                Text(
                    text = video.durationText,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                )
            }

            // Playing Audio In Background indicator on card
            if (isAudioPlayingThis) {
                Surface(
                    color = YouTubeRed.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(bottomStart = 8.dp),
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Headphones,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "شغال بالخلفية",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Details Section Under Thumbnail (Matching exact layout from screenshot)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.Top
        ) {
            // Left: 3-dots Menu Button
            Box {
                IconButton(
                    onClick = { isMenuExpanded = true },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "خيارات إضافية",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                DropdownMenu(
                    expanded = isMenuExpanded,
                    onDismissRequest = { isMenuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("تشغيل بصوت عالي") },
                        onClick = {
                            isMenuExpanded = false
                            onVideoClick()
                        },
                        leadingIcon = {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = YouTubeRed)
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("تشغيل في الخلفية 🎧") },
                        onClick = {
                            isMenuExpanded = false
                            onVideoClick()
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Headphones, contentDescription = null)
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Center: Title + Channel Metadata (Arabic RTL align)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = video.title,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.5.sp,
                        lineHeight = 20.sp
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Metadata: "توب تكنولوجي _ 5.5 ألف مشاهدة • قبل 7 أيام"
                Text(
                    text = "${video.channelTitle} • ${video.viewCountText} مشاهدة • ${video.publishedTimeText}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Right: Channel Avatar
            ChannelAvatar(
                channelTitle = video.channelTitle,
                avatarUrl = video.channelAvatarUrl,
                modifier = Modifier.size(38.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))
        // Divider space between cards
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
        )
    }
}

@Composable
fun ChannelAvatar(
    channelTitle: String,
    avatarUrl: String,
    modifier: Modifier = Modifier
) {
    if (avatarUrl.isNotBlank()) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(avatarUrl)
                .crossfade(true)
                .build(),
            contentDescription = channelTitle,
            contentScale = ContentScale.Crop,
            modifier = modifier
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceVariant)
        )
    } else {
        // Fallback stylish letter avatar
        val firstChar = channelTitle.trim().take(1).uppercase()
        val bgGradient = remember(channelTitle) {
            when (channelTitle.hashCode() % 4) {
                0 -> Brush.linearGradient(listOf(Color(0xFFE91E63), Color(0xFFFF5722)))
                1 -> Brush.linearGradient(listOf(Color(0xFF2196F3), Color(0xFF00BCD4)))
                2 -> Brush.linearGradient(listOf(Color(0xFF4CAF50), Color(0xFF8BC34A)))
                else -> Brush.linearGradient(listOf(Color(0xFF9C27B0), Color(0xFF673AB7)))
            }
        }
        Box(
            modifier = modifier
                .clip(CircleShape)
                .background(bgGradient),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = if (firstChar.isNotBlank()) firstChar else "Y",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }
    }
}
