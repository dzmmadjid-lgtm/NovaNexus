package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MainAppSection
import com.example.network.GitHubBuilderService
import com.example.viewmodel.ApkBuilderViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApkBuilderMainScreen(
    viewModel: ApkBuilderViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                navigationIcon = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(start = 12.dp)
                    ) {
                        IconButton(
                            onClick = { viewModel.setShowConfigDialog(true) },
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("top_github_config_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "إعدادات GitHub",
                                tint = Color(0xFF00ACC1),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        IconButton(
                            onClick = { viewModel.setShowWorkflowTemplateDialog(true) },
                            modifier = Modifier
                                .size(40.dp)
                                .testTag("top_workflow_template_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = "مسار العمل",
                                tint = Color(0xFF00E676),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                },
                title = {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Cloud APK Builder",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 19.sp
                            ),
                            color = Color.White
                        )
                        Text(
                            text = "محرك البناء السحابي المباشر",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = Color.Gray
                        )
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF00E676),
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Build,
                                contentDescription = null,
                                tint = Color(0xFF0F172A),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F172A)
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0F172A),
                tonalElevation = 4.dp
            ) {
                NavigationBarItem(
                    selected = uiState.currentSection == MainAppSection.EXTRACTOR,
                    onClick = { viewModel.setSection(MainAppSection.EXTRACTOR) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Apps,
                            contentDescription = "التطبيقات"
                        )
                    },
                    label = {
                        Text(
                            text = "التطبيقات",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF00E676),
                        indicatorColor = Color(0xFF00E676).copy(alpha = 0.2f),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray,
                        selectedTextColor = Color(0xFF00E676)
                    ),
                    modifier = Modifier.testTag("nav_extractor_tab")
                )

                NavigationBarItem(
                    selected = uiState.currentSection == MainAppSection.BUILDER,
                    onClick = { viewModel.setSection(MainAppSection.BUILDER) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Build,
                            contentDescription = "البناء السحابي"
                        )
                    },
                    label = {
                        Text(
                            text = "البناء السحابي",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF0F172A),
                        indicatorColor = Color(0xFF00E676),
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray,
                        selectedTextColor = Color(0xFF00E676)
                    ),
                    modifier = Modifier.testTag("nav_builder_tab")
                )
            }
        },
        modifier = modifier.fillMaxSize()
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (uiState.currentSection) {
                MainAppSection.BUILDER -> {
                    CloudBuilderTab(
                        uiState = uiState,
                        onOpenConfig = { viewModel.setShowConfigDialog(true) },
                        onOpenWorkflowTemplate = { viewModel.setShowWorkflowTemplateDialog(true) },
                        onTriggerBuild = { viewModel.triggerCloudBuild() },
                        onRefreshRuns = { viewModel.refreshWorkflowRuns() },
                        onZipSelected = { uri -> viewModel.onZipFileSelected(uri) }
                    )
                }

                MainAppSection.EXTRACTOR -> {
                    ApkExtractorTab(
                        uiState = uiState,
                        onSearchChanged = { viewModel.setSearchQuery(it) },
                        onTabSelected = { viewModel.setSelectedAppTab(it) },
                        onExtractApk = { viewModel.extractApk(it) },
                        onShareApk = { viewModel.shareApk(it) },
                        onOpenApp = { viewModel.openApp(it) },
                        onOpenAppSettings = { viewModel.openAppSettings(it) },
                        onDeleteExtracted = { viewModel.deleteExtractedApk(it) },
                        onRefresh = { viewModel.loadInstalledApps() }
                    )
                }
            }
        }

        // GitHub Config Dialog
        if (uiState.showConfigDialog) {
            GitHubConfigDialog(
                config = uiState.gitHubConfig,
                isVerifying = uiState.isVerifyingRepo,
                verificationMessage = uiState.repoVerificationMessage,
                isRepoVerified = uiState.isRepoVerified,
                onSave = { token, owner, repo, branch, workflow ->
                    viewModel.saveGitHubConfig(token, owner, repo, branch, workflow)
                },
                onVerify = { viewModel.verifyRepository() },
                onDismiss = { viewModel.setShowConfigDialog(false) }
            )
        }

        // Workflow Template Dialog
        if (uiState.showWorkflowTemplateDialog) {
            val templateYaml = remember {
                GitHubBuilderService(context)
            }
            WorkflowTemplateDialog(
                templateYaml = """
name: Build Android APK

on:
  workflow_dispatch:
    inputs:
      project_name:
        description: 'Name of the project'
        required: false
        default: 'app'

jobs:
  build:
    name: Build APK Package
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Make gradlew executable
        run: chmod +x ./gradlew || true

      - name: Build with Gradle
        run: |
          if [ -f "./gradlew" ]; then
            ./gradlew assembleRelease || ./gradlew assembleDebug || gradle assembleDebug
          else
            gradle assembleDebug || gradle build
          fi

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: app-release-apk
          path: |
            **/build/outputs/apk/**/*.apk
          retention-days: 7
""".trimIndent(),
                onDismiss = { viewModel.setShowWorkflowTemplateDialog(false) },
                onCopied = {
                    viewModel.setShowWorkflowTemplateDialog(false)
                }
            )
        }
    }
}
