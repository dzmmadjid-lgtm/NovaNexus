package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MainAppSection
import com.example.network.GitHubBuilderService
import com.example.viewmodel.ApkBuilderViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApkBuilderMainScreen(
    viewModel: ApkBuilderViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    LaunchedEffect(uiState.snackbarMessage) {
        uiState.snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    val isDark = uiState.isDarkTheme
    val barBackgroundColor = if (isDark) Color(0xFF000000) else MaterialTheme.colorScheme.surface
    val barContentColor = if (isDark) Color.White else MaterialTheme.colorScheme.onSurface

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                navigationIcon = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(start = 8.dp)
                    ) {
                        // Settings Gear Icon
                        IconButton(
                            onClick = { viewModel.setShowConfigDialog(true) },
                            modifier = Modifier
                                .size(38.dp)
                                .testTag("top_github_config_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "إعدادات GitHub",
                                tint = Color(0xFF00ACC1),
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Day / Night (OLED) Toggle
                        IconButton(
                            onClick = { viewModel.toggleTheme() },
                            modifier = Modifier
                                .size(38.dp)
                                .testTag("top_theme_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                                contentDescription = if (isDark) "الوضع النهاري" else "الوضع الليلي",
                                tint = Color(0xFF00ACC1),
                                modifier = Modifier.size(23.dp)
                            )
                        }

                        // Workflow YAML Code Dialog
                        IconButton(
                            onClick = { viewModel.setShowWorkflowTemplateDialog(true) },
                            modifier = Modifier
                                .size(38.dp)
                                .testTag("top_workflow_template_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = "مسار العمل",
                                tint = Color(0xFF00E676),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                },
                title = {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Cloud APK Builder",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            ),
                            color = barContentColor
                        )
                        Text(
                            text = "محرك البناء السحابي المباشر",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = if (isDark) Color.Gray else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFF00E676),
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Build,
                                contentDescription = null,
                                tint = Color(0xFF000000),
                                modifier = Modifier.size(19.dp)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = barBackgroundColor
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = barBackgroundColor,
                tonalElevation = 2.dp
            ) {
                NavigationBarItem(
                    selected = uiState.currentSection == MainAppSection.EXTRACTOR,
                    onClick = { viewModel.setSection(MainAppSection.EXTRACTOR) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Apps,
                            contentDescription = "التطبيقات"
                        )
                    },
                    label = {
                        Text(
                            text = "التطبيقات",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = if (isDark) Color.Black else Color.White,
                        indicatorColor = Color(0xFF00E676),
                        unselectedIconColor = if (isDark) Color.Gray else Color(0xFF64748B),
                        unselectedTextColor = if (isDark) Color.Gray else Color(0xFF64748B),
                        selectedTextColor = if (isDark) Color(0xFF00E676) else Color(0xFF00A352)
                    ),
                    modifier = Modifier.testTag("nav_extractor_tab")
                )

                NavigationBarItem(
                    selected = uiState.currentSection == MainAppSection.BUILDER,
                    onClick = { viewModel.setSection(MainAppSection.BUILDER) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Build,
                            contentDescription = "البناء السحابي"
                        )
                    },
                    label = {
                        Text(
                            text = "البناء السحابي",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = if (isDark) Color.Black else Color.White,
                        indicatorColor = Color(0xFF00E676),
                        unselectedIconColor = if (isDark) Color.Gray else Color(0xFF64748B),
                        unselectedTextColor = if (isDark) Color.Gray else Color(0xFF64748B),
                        selectedTextColor = if (isDark) Color(0xFF00E676) else Color(0xFF00A352)
                    ),
                    modifier = Modifier.testTag("nav_builder_tab")
                )
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (uiState.currentSection) {
                MainAppSection.BUILDER -> {
                    CloudBuilderTab(
                        uiState = uiState,
                        onOpenConfig = { viewModel.setShowConfigDialog(true) },
                        onOpenWorkflowTemplate = { viewModel.setShowWorkflowTemplateDialog(true) },
                        onTriggerBuild = { viewModel.triggerCloudBuild() },
                        onRefreshRuns = { viewModel.refreshWorkflowRuns() },
                        onZipSelected = { uri -> viewModel.onZipFileSelected(uri) }
                    )
                }

                MainAppSection.EXTRACTOR -> {
                    ApkExtractorTab(
                        uiState = uiState,
                        onSearchChanged = { query -> viewModel.setSearchQuery(query) },
                        onTabSelected = { tab -> viewModel.setSelectedAppTab(tab) },
                        onExtractApk = { app -> viewModel.extractApk(app) },
                        onShareApk = { path -> viewModel.shareApk(path) },
                        onOpenApp = { pkg -> viewModel.openApp(pkg) },
                        onOpenAppSettings = { pkg -> viewModel.openAppSettings(pkg) },
                        onDeleteExtracted = { path -> viewModel.deleteExtractedApk(path) },
                        onRefresh = {
                            viewModel.loadInstalledApps()
                            viewModel.refreshExtractedList()
                        }
                    )
                }
            }

            // GitHub Settings Dialog
            if (uiState.showConfigDialog) {
                GitHubConfigDialog(
                    config = uiState.gitHubConfig,
                    isVerifying = uiState.isVerifyingRepo,
                    verificationMessage = uiState.repoVerificationMessage,
                    isRepoVerified = uiState.isRepoVerified,
                    onSave = { token, owner, repo, branch, workflowFileName ->
                        viewModel.saveGitHubConfig(token, owner, repo, branch, workflowFileName)
                    },
                    onVerify = { viewModel.verifyRepository() },
                    onDismiss = { viewModel.setShowConfigDialog(false) }
                )
            }

            // Workflow YAML Dialog
            if (uiState.showWorkflowTemplateDialog) {
                WorkflowTemplateDialog(
                    templateYaml = """
name: Build Android APK

on:
  workflow_dispatch:
    inputs:
      project_name:
        description: 'Name of the project'
        required: false
        default: 'app'

jobs:
  build:
    name: Build APK Package
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Make gradlew executable
        run: chmod +x ./gradlew || true

      - name: Build with Gradle
        run: |
          if [ -f "./gradlew" ]; then
            ./gradlew assembleRelease || ./gradlew assembleDebug || gradle assembleDebug
          else
            gradle assembleDebug || gradle build
          fi

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: app-release-apk
          path: |
            **/build/outputs/apk/**/*.apk
          retention-days: 7
""".trimIndent(),
                    onDismiss = { viewModel.setShowWorkflowTemplateDialog(false) },
                    onCopied = {
                        viewModel.setShowWorkflowTemplateDialog(false)
                    }
                )
            }
        }
    }
}
