package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BuildStatus
import com.example.model.ProjectType
import com.example.viewmodel.ApkBuilderViewModel

@Composable
fun ApkBuilderMainScreen(
    viewModel: ApkBuilderViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    val isDark = uiState.isDarkTheme

    // Document folder picker launcher
    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.onFolderSelected(uri)
        }
    }

    // Direct ZIP and Project File Picker Launcher (System File Manager - No special permissions required)
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.onFolderSelected(uri)
        }
    }

    val bgColor = if (isDark) Color(0xFF090A10) else Color(0xFFF8FAFC)
    val cardBg = if (isDark) Color(0xFF141624) else Color(0xFFFFFFFF)
    val cardBorder = if (isDark) Color(0xFF262B40) else Color(0xFFE2E8F0)
    val textPrimary = if (isDark) Color(0xFFF1F5F9) else Color(0xFF0F172A)
    val textSecondary = if (isDark) Color(0xFF94A3B8) else Color(0xFF64748B)
    val accentCyan = Color(0xFF00E5FF)
    val accentGreen = Color(0xFF10B981)
    val accentOrange = Color(0xFFFF9100)

    Scaffold(
        containerColor = bgColor,
        topBar = {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Theme Switch & Status
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(cardBg)
                            .border(1.dp, cardBorder, RoundedCornerShape(12.dp))
                            .clickable { viewModel.toggleTheme() }
                            .testTag("btn_toggle_theme"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isDark) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "تبديل المظهر",
                            tint = if (isDark) Color(0xFFFFB800) else Color(0xFF334155),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Cloud Engine status pill
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isDark) Color(0xFF0C2417) else Color(0xFFD1FAE5))
                            .border(1.dp, if (isDark) Color(0xFF165B37) else Color(0xFFA7F3D0), RoundedCornerShape(20.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(accentGreen)
                            )
                            Text(
                                text = "محرك البناء جاهز ⚡",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isDark) accentGreen else Color(0xFF047857)
                            )
                        }
                    }
                }

                // Brand Right Title
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "APK Builder",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = textPrimary
                        )
                        Text(
                            text = "بناء فوري بدون أوامر",
                            fontSize = 11.sp,
                            color = textSecondary
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF00E5FF), Color(0xFF2563EB)))),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.RocketLaunch,
                            contentDescription = "App Logo",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            // STEP 1: Folder Selection Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = cardBg),
                    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(cardBorder, cardBorder)))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF00E5FF).copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("الخطوة 1", color = accentCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(
                                text = "اختيار مجلد المشروع",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = textPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Choice 1: Select ZIP Archive file (Recommended)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isDark) Color(0xFF1B1E32) else Color(0xFFF1F5F9))
                                .border(1.dp, if (uiState.projectInfo != null) accentCyan else cardBorder, RoundedCornerShape(16.dp))
                                .clickable {
                                    try {
                                        filePickerLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*"))
                                    } catch (e: Exception) {
                                        viewModel.selectPresetSample(ProjectType.FLUTTER)
                                    }
                                }
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(accentCyan.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FolderOpen,
                                        contentDescription = "اختيار ZIP",
                                        tint = accentCyan,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = uiState.selectedFolderName ?: "اختيار ملف المشروع المضغوط (.zip)",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (uiState.projectInfo != null) accentCyan else textPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "يفتح مدير ملفات الهاتف مباشرة للوصول إلى ملفات الـ ZIP",
                                        fontSize = 11.sp,
                                        color = textSecondary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Choice 2: Select Full Project Folder
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (isDark) Color(0xFF121422) else Color(0xFFF8FAFC))
                                .border(1.dp, cardBorder, RoundedCornerShape(14.dp))
                                .clickable {
                                    try {
                                        folderPickerLauncher.launch(null)
                                    } catch (e: Exception) {
                                        viewModel.selectPresetSample(ProjectType.FLUTTER)
                                    }
                                }
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderOpen,
                                    contentDescription = "مجلد كامل",
                                    tint = textSecondary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Text(
                                    text = "أو اختيار مجلد مفتوح بالكامل من ذاكرة الهاتف",
                                    fontSize = 12.sp,
                                    color = textSecondary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Quick Test Samples Row
                        Text(
                            text = "أو اختر مشروع تجريبي سريع للتجربة:",
                            fontSize = 12.sp,
                            color = textSecondary,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            PresetButton(
                                label = "Flutter 🎯",
                                isDark = isDark,
                                isSelected = uiState.projectInfo?.type == ProjectType.FLUTTER,
                                modifier = Modifier.weight(1f)
                            ) { viewModel.selectPresetSample(ProjectType.FLUTTER) }

                            PresetButton(
                                label = "React Native ⚛️",
                                isDark = isDark,
                                isSelected = uiState.projectInfo?.type == ProjectType.REACT_NATIVE,
                                modifier = Modifier.weight(1f)
                            ) { viewModel.selectPresetSample(ProjectType.REACT_NATIVE) }

                            PresetButton(
                                label = "Android 🤖",
                                isDark = isDark,
                                isSelected = uiState.projectInfo?.type == ProjectType.ANDROID_KOTLIN_JAVA,
                                modifier = Modifier.weight(1f)
                            ) { viewModel.selectPresetSample(ProjectType.ANDROID_KOTLIN_JAVA) }
                        }
                    }
                }
            }

            // STEP 2: Automatic Project Detection Card
            if (uiState.projectInfo != null) {
                item {
                    val info = uiState.projectInfo!!
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = cardBg),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(cardBorder, cardBorder)))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(accentGreen.copy(alpha = 0.15f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("الخطوة 2", color = accentGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Text(
                                    text = "التعرف التلقائي على المشروع",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = textPrimary
                                )
                            }

                            // Detected Type Badge
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isDark) Color(0xFF101C24) else Color(0xFFE0F2FE))
                                    .border(1.dp, if (isDark) Color(0xFF0284C7) else Color(0xFF38BDF8), RoundedCornerShape(14.dp))
                                    .padding(14.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text(info.type.icon, fontSize = 28.sp)
                                    Column {
                                        Text(
                                            text = info.type.displayName,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isDark) Color(0xFF38BDF8) else Color(0xFF0369A1)
                                        )
                                        Text(
                                            text = info.type.description,
                                            fontSize = 11.sp,
                                            color = textSecondary
                                        )
                                    }
                                }
                            }

                            // Project Details List
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isDark) Color(0xFF0C0E17) else Color(0xFFF1F5F9))
                                    .padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                DetailRow("اسم المشروع:", info.name, textPrimary, textSecondary)
                                DetailRow("Package ID:", info.packageOrBundleId, accentCyan, textSecondary)
                                DetailRow("أدوات البناء:", info.buildTool, textPrimary, textSecondary)
                                DetailRow("إصدار البيئة:", info.sdkVersion, textPrimary, textSecondary)
                                DetailRow("الملفات المكتشفة:", info.keyFilesFound.joinToString(", "), textPrimary, textSecondary)
                            }
                        }
                    }
                }
            }

            // STEP 3: One-Click Build Action & Progress
            if (uiState.projectInfo != null) {
                item {
                    val isBuilding = uiState.buildStatus == BuildStatus.BUILDING ||
                            uiState.buildStatus == BuildStatus.CONFIGURING ||
                            uiState.buildStatus == BuildStatus.ANALYZING
                    val isCompleted = uiState.buildStatus == BuildStatus.COMPLETED

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = cardBg),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(cardBorder, cardBorder)))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(accentOrange.copy(alpha = 0.15f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("الخطوة 3", color = accentOrange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Text(
                                    text = "بناء وتوليد الـ APK",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = textPrimary
                                )
                            }

                            // Big One-Click Build Button
                            if (!isCompleted) {
                                Button(
                                    onClick = { viewModel.startOneClickBuild() },
                                    enabled = !isBuilding,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(56.dp)
                                        .testTag("btn_start_build"),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF10B981),
                                        disabledContainerColor = Color(0xFF10B981).copy(alpha = 0.5f)
                                    )
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        if (isBuilding) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(22.dp),
                                                color = Color.White,
                                                strokeWidth = 2.dp
                                            )
                                        } else {
                                            Icon(
                                                imageVector = Icons.Default.PlayArrow,
                                                contentDescription = "بدء البناء",
                                                tint = Color.White
                                            )
                                        }
                                        Text(
                                            text = if (isBuilding) "جاري بناء الـ APK..." else "⚡ اضغط للبناء بنقرة واحدة",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }

                            // Progress Indicator
                            if (isBuilding || isCompleted) {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = uiState.activeStepText,
                                            fontSize = 12.sp,
                                            color = textSecondary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${(uiState.buildProgressPercent * 100).toInt()}%",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isCompleted) accentGreen else accentCyan
                                        )
                                    }
                                    LinearProgressIndicator(
                                        progress = { uiState.buildProgressPercent },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(8.dp)
                                            .clip(RoundedCornerShape(4.dp)),
                                        color = if (isCompleted) accentGreen else accentCyan,
                                        trackColor = if (isDark) Color(0xFF1E2235) else Color(0xFFE2E8F0),
                                    )
                                }
                            }

                            // Completed Action Area (Install & Share)
                            if (isCompleted) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(if (isDark) Color(0xFF0C2417) else Color(0xFFD1FAE5))
                                        .border(1.dp, if (isDark) Color(0xFF165B37) else Color(0xFFA7F3D0), RoundedCornerShape(16.dp))
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = "نجاح",
                                            tint = accentGreen,
                                            modifier = Modifier.size(32.dp)
                                        )
                                        Column {
                                            Text(
                                                text = "تم تجهيز ملف الـ APK بنجاح!",
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isDark) Color(0xFF34D399) else Color(0xFF065F46)
                                            )
                                            Text(
                                                text = "الملف جاهز للتثبيت على هذا الهاتف مباشرة",
                                                fontSize = 11.sp,
                                                color = textSecondary
                                            )
                                        }
                                    }

                                    // Action Buttons: Install APK & Share
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Button(
                                            onClick = { viewModel.installBuiltApk() },
                                            modifier = Modifier
                                                .weight(1.3f)
                                                .height(48.dp)
                                                .testTag("btn_install_apk"),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                        ) {
                                            Icon(imageVector = Icons.Default.Android, contentDescription = "تثبيت", tint = Color.White)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("تثبيت الـ APK الآن", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                        }

                                        Button(
                                            onClick = { viewModel.shareApk() },
                                            modifier = Modifier
                                                .weight(0.9f)
                                                .height(48.dp)
                                                .testTag("btn_share_apk"),
                                            shape = RoundedCornerShape(12.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = if (isDark) Color(0xFF1E293B) else Color(0xFFE2E8F0))
                                        ) {
                                            Icon(imageVector = Icons.Default.Share, contentDescription = "مشاركة", tint = textPrimary)
                                            Spacer(modifier = Modifier.width(49.dp.takeIf { false } ?: 4.dp))
                                            Text("مشاركة", color = textPrimary, fontSize = 13.sp)
                                        }
                                    }

                                    if (uiState.errorMessage != null) {
                                        Text(
                                            text = uiState.errorMessage!!,
                                            color = Color(0xFFF87171),
                                            fontSize = 12.sp,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                    }

                                    // Re-build Button
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.resetBuild() }
                                            .padding(top = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(imageVector = Icons.Default.Refresh, contentDescription = "إعادة", tint = textSecondary, modifier = Modifier.size(16.dp))
                                            Text("بناء مشروع آخر أو إعادة المحاولة", fontSize = 12.sp, color = textSecondary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Live Build Console & Logs
            if (uiState.buildLogs.isNotEmpty()) {
                item {
                    val listState = rememberLazyListState()
                    LaunchedEffect(uiState.buildLogs.size) {
                        if (uiState.buildLogs.isNotEmpty()) {
                            listState.animateScrollToItem(uiState.buildLogs.size - 1)
                        }
                    }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = if (isDark) Color(0xFF06070B) else Color(0xFF1E293B)),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(cardBorder, cardBorder)))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFEF4444)))
                                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFF59E0B)))
                                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF10B981)))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "سجل البناء المباشر (Build Logs)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF94A3B8)
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.Terminal,
                                    contentDescription = "Console",
                                    tint = Color(0xFF64748B),
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF000000).copy(alpha = 0.4f))
                                    .padding(8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                LazyColumn(
                                    state = listState,
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    items(uiState.buildLogs) { log ->
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                                            verticalAlignment = Alignment.Top
                                        ) {
                                            Text(
                                                text = "[${log.timestamp}]",
                                                color = Color(0xFF64748B),
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = log.message,
                                                color = if (log.isSuccess) Color(0xFF34D399) else if (log.isError) Color(0xFFF87171) else Color(0xFFE2E8F0),
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PresetButton(
    label: String,
    isDark: Boolean,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val bg = if (isSelected) {
        if (isDark) Color(0xFF00E5FF).copy(alpha = 0.2f) else Color(0xFFE0F2FE)
    } else {
        if (isDark) Color(0xFF141724) else Color(0xFFFFFFFF)
    }

    val border = if (isSelected) Color(0xFF00E5FF) else if (isDark) Color(0xFF262B40) else Color(0xFFE2E8F0)

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bg)
            .border(1.dp, border, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 8.dp, horizontal = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) Color(0xFF00E5FF) else if (isDark) Color(0xFFE2E8F0) else Color(0xFF1E293B),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun DetailRow(
    label: String,
    value: String,
    valueColor: Color,
    labelColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            color = labelColor
        )
    }
}
