package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// TikTok Signature Colors
val TikTokPink = Color(0xFFFE2C55)          // Iconic Hot Pink / Magenta
val TikTokCyan = Color(0xFF25F4EE)          // Iconic Electric Cyan
val TikTokCyanDark = Color(0xFF00B5B0)
val TikTokPinkDark = Color(0xFFE61C48)
val TikTokDarkBlack = Color(0xFF121216)      // Standard Dark Mode
val TikTokOledBlack = Color(0xFF000000)      // Pure 100% OLED Pitch Black

// Accent & Status Colors
val EmeraldSuccess = Color(0xFF00E676)
val OrangeWarning = Color(0xFFFF9100)
val PurpleAccent = Color(0xFF7C4DFF)

// OLED Palette (True #000000 with glowing neon borders)
val OledBackground = Color(0xFF000000)
val OledSurface = Color(0xFF000000)
val OledCardSurface = Color(0xFF0A0A0E)
val OledCardSurfaceHigh = Color(0xFF14141A)
val OledBorder = Color(0xFF202028)
val OledTextPrimary = Color(0xFFFFFFFF)
val OledTextSecondary = Color(0xFFA0A0AB)
val OledTextMuted = Color(0xFF6B6B78)

// Dark Palette (Charcoal / Deep Slate)
val DarkBackground = Color(0xFF121216)
val DarkSurface = Color(0xFF181820)
val DarkCardSurface = Color(0xFF20202C)
val DarkCardSurfaceHigh = Color(0xFF282838)
val DarkBorder = Color(0xFF2F2F40)
val DarkTextPrimary = Color(0xFFF5F5F7)
val DarkTextSecondary = Color(0xFFA6A6B8)
val DarkTextMuted = Color(0xFF757588)

// Light Palette (Crisp & Clean)
val LightBackground = Color(0xFFF7F8FA)
val LightSurface = Color(0xFFFFFFFF)
val LightCardSurface = Color(0xFFFFFFFF)
val LightCardSurfaceHigh = Color(0xFFF0F2F5)
val LightBorder = Color(0xFFE2E4E8)
val LightTextPrimary = Color(0xFF111217)
val LightTextSecondary = Color(0xFF5A5F6E)
val LightTextMuted = Color(0xFF8A90A0)
