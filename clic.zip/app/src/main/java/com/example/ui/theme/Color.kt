package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Click School - Modern Educational & PDF Studio Palette
val ClickBlue = Color(0xFF2563EB)
val ClickBlueDark = Color(0xFF1D4ED8)
val ClickBlueLight = Color(0xFF60A5FA)
val ClickPurple = Color(0xFF7C3AED)
val ClickPurpleLight = Color(0xFFA78BFA)
val ClickAmber = Color(0xFFF59E0B)
val ClickAmberHover = Color(0xFFD97706)
val ClickGreen = Color(0xFF10B981)
val ClickRed = Color(0xFFEF4444)

val BgDark = Color(0xFF000000)
val BgCardDark = Color(0xFF0A0A0A)
val BgCardHover = Color(0xFF161616)
val BorderDark = Color(0x33FFFFFF)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFCBD5E1)
val TextMuted = Color(0xFF94A3B8)

// Gradients
val ClickBrandGradient = Brush.linearGradient(
    colors = listOf(ClickBlue, ClickPurple)
)

val ClickAccentGradient = Brush.horizontalGradient(
    colors = listOf(ClickBlue, ClickPurple, ClickAmber)
)

