package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// لوحة ألوان الوضع الداكن (Studio Darcula Dark Mode)
val StudioDarkBackground = Color(0xFF1E1F22)
val StudioDarkSurface = Color(0xFF2B2D30)
val StudioEditorBackground = Color(0xFF1E1F22)
val StudioGutterBackground = Color(0xFF232529)
val StudioAccentBlue = Color(0xFF3574F0)
val StudioBuildGreen = Color(0xFF36B86C)
val StudioWarningYellow = Color(0xFFF2C55C)
val StudioErrorRed = Color(0xFFF75464)
val StudioTextPrimary = Color(0xFFDFE1E5)
val StudioTextSecondary = Color(0xFF8C9298)
val StudioBorder = Color(0xFF35373C)

// لوحة ألوان الوضع النهاري الأنيق (IntelliJ / Studio Light Mode)
val StudioLightBackground = Color(0xFFF7F8FA)
val StudioLightSurface = Color(0xFFFFFFFF)
val StudioLightEditorBackground = Color(0xFFFFFFFF)
val StudioLightGutterBackground = Color(0xFFF0F2F5)
val StudioLightGutterText = Color(0xFF8C95A0)
val StudioLightBorder = Color(0xFFD6D9DF)
val StudioLightTextPrimary = Color(0xFF1F2328)
val StudioLightTextSecondary = Color(0xFF656D76)
val StudioLightTabActive = Color(0xFFFFFFFF)
val StudioLightTabInactive = Color(0xFFE8EBF0)
val StudioLightQuickKeyBg = Color(0xFFEAECEF)
val StudioLightQuickKeyText = Color(0xFF24292F)

// ألوان تلوين الصياغة للوضع الداكن (Dark Syntax)
val DarkSyntaxKeyword = Color(0xFFCC7832)
val DarkSyntaxString = Color(0xFF6A8759)
val DarkSyntaxNumber = Color(0xFF6897BB)
val DarkSyntaxComment = Color(0xFF808080)
val DarkSyntaxAnnotation = Color(0xFFBBB529)
val DarkSyntaxFunction = Color(0xFFFFC66D)
val DarkSyntaxType = Color(0xFF4EC9B0)
val DarkSyntaxXmlTag = Color(0xFFE8BF6A)
val DarkSyntaxXmlAttr = Color(0xFF9876AA)
val DarkSyntaxPunctuation = Color(0xFFA9B7C6)

// ألوان تلوين الصياغة للوضع النهاري (Light Syntax - عالية الوضوح والجمالية)
val LightSyntaxKeyword = Color(0xFF0033B3)      // أزرق كلاسيكي ناصع للكلمات المفتاحية
val LightSyntaxString = Color(0xFF067D17)       // أخضر زمردي جميل للنصوص
val LightSyntaxNumber = Color(0xFF1750EB)       // أزرق ملكي للأرقام
val LightSyntaxComment = Color(0xFF8C8C8C)      // رمادي هادئ ومائل للتعليقات
val LightSyntaxAnnotation = Color(0xFF9E880D)   // ذهبي خردلي للوسوم
val LightSyntaxFunction = Color(0xFF00627A)     // تيل غامق للدوال
val LightSyntaxType = Color(0xFF267F99)         // فيروزي أنيق للأنواع
val LightSyntaxXmlTag = Color(0xFF0033B3)       // أزرق للوسوم
val LightSyntaxXmlAttr = Color(0xFF7E009B)      // بنفسجي أنيق لخصائص XML
val LightSyntaxPunctuation = Color(0xFF1F2328)  // كحلي/فحمي للأقواس

// لوحة ألوان وضع OLED الأسود المطلق (Pitch Black OLED Mode)
val StudioOledBackground = Color(0xFF000000)
val StudioOledSurface = Color(0xFF08080A)
val StudioOledEditorBackground = Color(0xFF000000)
val StudioOledGutterBackground = Color(0xFF050506)
val StudioOledGutterText = Color(0xFF555B63)
val StudioOledBorder = Color(0xFF1A1D24)
val StudioOledAccentNeonCyan = Color(0xFF00F0FF)
val StudioOledAccentNeonMint = Color(0xFF00FF9D)
val StudioOledAccentNeonMagenta = Color(0xFFFF007F)
val StudioOledAccentNeonPurple = Color(0xFFBD00FF)
val StudioOledTextPrimary = Color(0xFFFFFFFF)
val StudioOledTextSecondary = Color(0xFF9E9E9E)
val StudioOledTabActive = Color(0xFF0F1115)
val StudioOledQuickKeyBg = Color(0xFF101216)

// ألوان تلوين الصياغة لوضع OLED (Electric Neon High Contrast)
val OledSyntaxKeyword = Color(0xFFFF007F)      // نيون ماجنتا/وردي
val OledSyntaxString = Color(0xFF00FF9D)       // نيون ليموني ساطع
val OledSyntaxNumber = Color(0xFF00F0FF)       // نيون سماوي كهربائي
val OledSyntaxComment = Color(0xFF6272A4)      // بنفسجي رمادي خافت
val OledSyntaxAnnotation = Color(0xFFFFE600)   // أصفر نيون متوهج
val OledSyntaxFunction = Color(0xFFBD00FF)     // بنفسجي كهربائي مشع
val OledSyntaxType = Color(0xFF00E5FF)         // تركواز نيون
val OledSyntaxXmlTag = Color(0xFFFF007F)       // نيون ماجنتا للوسوم
val OledSyntaxXmlAttr = Color(0xFF00F0FF)      // نيون سماوي للخصائص
val OledSyntaxPunctuation = Color(0xFFFFFFFF)   // أبيض ساطع عالي التباين


