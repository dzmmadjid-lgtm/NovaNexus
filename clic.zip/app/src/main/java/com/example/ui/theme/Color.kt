package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- Dark Mode Palette (Click School Inspired) ---
val OledBlack = Color(0xFF000000)
val DarkBackground = Color(0xFF07080A)
val DarkSurface = Color(0xFF0F1017)
val DarkSurfaceElevated = Color(0xFF141620)
val DarkSurfaceBorder = Color(0xFF222538)
val DarkButtonNumber = Color(0xFF181A26)
val DarkButtonNumberPressed = Color(0xFF26293D)

// Brand & Accent Colors (Dark)
val BrandRed = Color(0xFFEF4444)
val DarkOfflinePillBg = Color(0xFF092416)
val DarkOfflinePillBorder = Color(0xFF134E32)
val DarkOfflinePillText = Color(0xFF22C55E)

val NeonCyan = Color(0xFF38BDF8)
val NeonOrange = Color(0xFFF59E0B)
val NeonGreen = Color(0xFF22C55E)
val NeonPurple = Color(0xFFA855F7)
val NeonRed = Color(0xFFEF4444)

// --- Light Mode Palette (Click School Inspired) ---
val LightWhite = Color(0xFFFFFFFF)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF8FAFC)
val LightSurfaceBorder = Color(0xFFE2E8F0)
val LightButtonNumber = Color(0xFFFFFFFF)
val LightButtonNumberPressed = Color(0xFFE2E8F0)

// Brand & Accent Colors (Light)
val LightOfflinePillBg = Color(0xFFD1FAE5)
val LightOfflinePillBorder = Color(0xFFA7F3D0)
val LightOfflinePillText = Color(0xFF047857)

val LightBlue = Color(0xFF0284C7)
val LightOrange = Color(0xFFD97706)
val LightGreen = Color(0xFF16A34A)
val LightPurple = Color(0xFF7C3AED)
val LightRed = Color(0xFFDC2626)

// --- Typography Colors ---
val DarkTextPrimary = Color(0xFFFFFFFF)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkTextMuted = Color(0xFF64748B)

val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightTextMuted = Color(0xFF94A3B8)

