package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// YouTube Brand Accent
val YouTubeRed = Color(0xFFFF0000)
val YouTubeRedDark = Color(0xFFCC0000)

// Dark Palette
val DarkBackground = Color(0xFF0F0F0F)
val DarkSurface = Color(0xFF181818)
val DarkSurfaceVariant = Color(0xFF272727)
val DarkSurfaceElevated = Color(0xFF212121)
val DarkTextPrimary = Color(0xFFF1F1F1)
val DarkTextSecondary = Color(0xFFAAAAAA)
val DarkTextMuted = Color(0xFF717171)

// Light Palette
val LightBackground = Color(0xFFF9F9F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF2F2F2)
val LightSurfaceElevated = Color(0xFFE5E5E5)
val LightTextPrimary = Color(0xFF0F0F0F)
val LightTextSecondary = Color(0xFF606060)
val LightTextMuted = Color(0xFF909090)
