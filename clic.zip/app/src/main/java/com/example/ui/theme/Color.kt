package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Click School - Modern Educational & PDF Studio Palette
val ClickBlue = Color(0xFF2563EB)
val ClickBlueDark = Color(0xFF1D4ED8)
val ClickBlueLight = Color(0xFF60A5FA)
val ClickPurple = Color(0xFF7C3AED)
val ClickPurpleLight = Color(0xFFA78BFA)
val ClickAmber = Color(0xFFF59E0B)
val ClickAmberHover = Color(0xFFD97706)
val ClickGreen = Color(0xFF10B981)
val ClickRed = Color(0xFFEF4444)

val BgDark = Color(0xFF0F172A)
val BgCardDark = Color(0xFF1E293B)
val BgCardHover = Color(0xFF334155)
val BorderDark = Color(0x33FFFFFF)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Gradients
val ClickBrandGradient = Brush.linearGradient(
    colors = listOf(ClickBlue, ClickPurple)
)

val ClickAccentGradient = Brush.horizontalGradient(
    colors = listOf(ClickBlue, ClickPurple, ClickAmber)
)

