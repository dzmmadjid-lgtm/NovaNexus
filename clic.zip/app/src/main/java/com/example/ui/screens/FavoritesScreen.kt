package com.example.ui.screens

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.YouTubeVideo
import com.example.ui.components.VideoCard
import com.example.viewmodel.YouTubeUiState

@Composable
fun FavoritesScreen(
    uiState: YouTubeUiState,
    onVideoClick: (YouTubeVideo) -> Unit,
    onBackgroundPlayClick: (YouTubeVideo) -> Unit,
    onToggleFavorite: (YouTubeVideo) -> Unit,
    modifier: Modifier = Modifier
) {
    if (uiState.favoriteVideos.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.BookmarkBorder,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "قائمة المفضلة فارغة",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "انقر على علامة المرجعية لحفظ الفيديوهات التي تود العودة إليها لاحقاً",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    } else {
        LazyColumn(
            modifier = modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp)
        ) {
            item {
                Text(
                    text = "مقاطع الفيديو المفضلة (${uiState.favoriteVideos.size})",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(bottom = 12.dp, start = 4.dp)
                )
            }

            items(uiState.favoriteVideos, key = { it.id }) { video ->
                VideoCard(
                    video = video,
                    isFavorite = true,
                    onVideoClick = { onVideoClick(video) },
                    onBackgroundPlayClick = { onBackgroundPlayClick(video) },
                    onToggleFavorite = { onToggleFavorite(video) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(90.dp))
            }
        }
    }
}
