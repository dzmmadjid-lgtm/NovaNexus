package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaScannerConnection
import android.os.Environment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.TimeUnit

object PhotoVideoProcessor {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private const val VIDEO_WIDTH = 720
    private const val VIDEO_HEIGHT = 1280
    private const val FRAME_RATE = 30
    private const val BIT_RATE = 2_500_000
    private const val SECONDS_PER_PHOTO = 2.5f

    suspend fun generateSlideshowVideo(
        context: Context,
        imageUrls: List<String>,
        audioUrl: String?,
        title: String,
        author: String,
        onProgress: (progress: Float, statusText: String) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        if (imageUrls.isEmpty()) {
            return@withContext Result.failure(Exception("قائمة الصور فارغة"))
        }

        val sanitizedAuthor = author.replace(Regex("[^a-zA-Z0-9_\\-\\u0600-\\u06FF]"), "_").take(20).ifBlank { "TikTok" }
        val outputFileName = "TikTok_Photos_${sanitizedAuthor}_${System.currentTimeMillis()}.mp4"
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val outputFile = File(downloadsDir, outputFileName)
        val tempAudioFile = File(context.cacheDir, "temp_audio_${System.currentTimeMillis()}.raw")

        try {
            onProgress(0.05f, "جاري تنزيل صور المنشور (${imageUrls.size} صور)...")

            // 1. Download images
            val downloadedBitmaps = mutableListOf<Bitmap>()
            for ((index, url) in imageUrls.withIndex()) {
                val req = Request.Builder().url(url).build()
                val response = httpClient.newCall(req).execute()
                val bytes = response.body?.bytes()
                response.close()
                if (bytes != null && bytes.isNotEmpty()) {
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bmp != null) {
                        downloadedBitmaps.add(bmp)
                    }
                }
                val stepProgress = 0.05f + (0.25f * (index + 1) / imageUrls.size)
                onProgress(stepProgress, "تم تحميل ${index + 1} من ${imageUrls.size} صورة")
            }

            if (downloadedBitmaps.isEmpty()) {
                return@withContext Result.failure(Exception("تعذر تحميل صور المنشور"))
            }

            // 2. Download audio if present
            var hasAudio = false
            if (!audioUrl.isNullOrBlank()) {
                try {
                    onProgress(0.32f, "جاري جلب المقطع الصوتي للمنشور...")
                    val audioReq = Request.Builder().url(audioUrl).build()
                    val audioResp = httpClient.newCall(audioReq).execute()
                    if (audioResp.isSuccessful && audioResp.body != null) {
                        FileOutputStream(tempAudioFile).use { out ->
                            audioResp.body!!.byteStream().copyTo(out)
                        }
                        hasAudio = tempAudioFile.exists() && tempAudioFile.length() > 0
                    }
                    audioResp.close()
                } catch (_: Exception) {
                    hasAudio = false
                }
            }

            // 3. Setup MediaCodec & MediaMuxer
            onProgress(0.38f, "جاري إعداد مشفر الفيديو (MediaCodec H.264)...")
            val mimeType = MediaFormat.MIMETYPE_VIDEO_AVC
            val mediaFormat = MediaFormat.createVideoFormat(mimeType, VIDEO_WIDTH, VIDEO_HEIGHT).apply {
                setInteger(MediaFormat.KEY_BIT_RATE, BIT_RATE)
                setInteger(MediaFormat.KEY_FRAME_RATE, FRAME_RATE)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            val colorFormat = selectColorFormat(mimeType)
            mediaFormat.setInteger(MediaFormat.KEY_COLOR_FORMAT, colorFormat)

            val codec = MediaCodec.createEncoderByType(mimeType)
            codec.configure(mediaFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var videoTrackIndex = -1
            var audioTrackIndex = -1
            var muxerStarted = false

            var audioExtractor: MediaExtractor? = null
            if (hasAudio) {
                try {
                    audioExtractor = MediaExtractor().apply { setDataSource(tempAudioFile.absolutePath) }
                    for (i in 0 until audioExtractor.trackCount) {
                        val format = audioExtractor.getTrackFormat(i)
                        val trackMime = format.getString(MediaFormat.KEY_MIME) ?: ""
                        if (trackMime.startsWith("audio/")) {
                            audioExtractor.selectTrack(i)
                            audioTrackIndex = muxer.addTrack(format)
                            break
                        }
                    }
                } catch (_: Exception) {
                    audioTrackIndex = -1
                    audioExtractor?.release()
                    audioExtractor = null
                }
            }

            // 4. Pre-render frames on Canvas & encode to YUV
            val framesPerPhoto = (SECONDS_PER_PHOTO * FRAME_RATE).toInt()
            val totalFrames = downloadedBitmaps.size * framesPerPhoto
            val bufferInfo = MediaCodec.BufferInfo()

            var currentFrame = 0L

            for ((photoIdx, bmp) in downloadedBitmaps.withIndex()) {
                val frameBitmap = renderPhotoFrame(bmp, VIDEO_WIDTH, VIDEO_HEIGHT)
                val argbPixels = IntArray(VIDEO_WIDTH * VIDEO_HEIGHT)
                frameBitmap.getPixels(argbPixels, 0, VIDEO_WIDTH, 0, 0, VIDEO_WIDTH, VIDEO_HEIGHT)
                frameBitmap.recycle()

                val yuvBytes = ByteArray(VIDEO_WIDTH * VIDEO_HEIGHT * 3 / 2)
                if (colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar) {
                    encodeYUV420P(yuvBytes, argbPixels, VIDEO_WIDTH, VIDEO_HEIGHT)
                } else {
                    encodeYUV420SP(yuvBytes, argbPixels, VIDEO_WIDTH, VIDEO_HEIGHT)
                }

                // Push repeated frames for this photo
                for (f in 0 until framesPerPhoto) {
                    val inputBufIdx = codec.dequeueInputBuffer(10_000)
                    if (inputBufIdx >= 0) {
                        val inputBuffer = codec.getInputBuffer(inputBufIdx)
                        if (inputBuffer != null) {
                            inputBuffer.clear()
                            inputBuffer.put(yuvBytes)
                            val ptsUs = currentFrame * 1_000_000L / FRAME_RATE
                            val isLast = (photoIdx == downloadedBitmaps.size - 1) && (f == framesPerPhoto - 1)
                            val flags = if (isLast) MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0
                            codec.queueInputBuffer(inputBufIdx, 0, yuvBytes.size, ptsUs, flags)
                        }
                    }
                    currentFrame++

                    // Drain encoder output
                    val result = drainEncoder(codec, muxer, bufferInfo, videoTrackIndex, muxerStarted)
                    videoTrackIndex = result.first
                    muxerStarted = result.second

                    if (currentFrame % 15 == 0L) {
                        val encodingProgress = 0.40f + (0.50f * currentFrame / totalFrames)
                        onProgress(encodingProgress, "جاري تحويل ومعالجة الفيديو (${(encodingProgress * 100).toInt()}%)")
                    }
                }
            }

            // Finish draining remaining video output
            var isEos = false
            while (!isEos) {
                val outIdx = codec.dequeueOutputBuffer(bufferInfo, 10_000)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (videoTrackIndex < 0) {
                        videoTrackIndex = muxer.addTrack(codec.outputFormat)
                        if (!muxerStarted) {
                            muxer.start()
                            muxerStarted = true
                        }
                    }
                } else if (outIdx >= 0) {
                    val encodedData = codec.getOutputBuffer(outIdx)
                    if (encodedData != null && muxerStarted && videoTrackIndex >= 0 && bufferInfo.size > 0) {
                        encodedData.position(bufferInfo.offset)
                        encodedData.limit(bufferInfo.offset + bufferInfo.size)
                        muxer.writeSampleData(videoTrackIndex, encodedData, bufferInfo)
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        isEos = true
                    }
                } else if (outIdx == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    break
                }
            }

            // 5. Mux Audio Track (muxVideoAndAudio)
            if (audioExtractor != null && audioTrackIndex >= 0 && muxerStarted) {
                onProgress(0.92f, "جاري دمج الصوت مع الفيديو (muxVideoAndAudio)...")
                val totalVideoUs = totalFrames * 1_000_000L / FRAME_RATE
                val audioBuf = ByteBuffer.allocate(64 * 1024)
                val audioInfo = MediaCodec.BufferInfo()

                while (true) {
                    val sampleSize = audioExtractor.readSampleData(audioBuf, 0)
                    if (sampleSize < 0) break
                    val sampleTime = audioExtractor.sampleTime
                    if (sampleTime > totalVideoUs) break

                    audioInfo.offset = 0
                    audioInfo.size = sampleSize
                    audioInfo.presentationTimeUs = sampleTime
                    audioInfo.flags = audioExtractor.sampleFlags

                    muxer.writeSampleData(audioTrackIndex, audioBuf, audioInfo)
                    audioExtractor.advance()
                }
            }

            // Clean up codec and muxer
            try { codec.stop() } catch (_: Exception) {}
            try { codec.release() } catch (_: Exception) {}
            try { audioExtractor?.release() } catch (_: Exception) {}

            if (muxerStarted) {
                try { muxer.stop() } catch (_: Exception) {}
                try { muxer.release() } catch (_: Exception) {}
            }

            // Clean up temporary bitmaps
            downloadedBitmaps.forEach {
                try { it.recycle() } catch (_: Exception) {}
            }
            tempAudioFile.delete()

            // Scan in Android MediaScanner
            MediaScannerConnection.scanFile(
                context,
                arrayOf(outputFile.absolutePath),
                arrayOf("video/mp4"),
                null
            )

            onProgress(1.0f, "تم إنتاج الفيديو بنجاح! جاهز في المعرض")
            Result.success(outputFile)
        } catch (e: Exception) {
            tempAudioFile.delete()
            outputFile.delete()
            Result.failure(Exception("تعذر تحويل الصور إلى فيديو: ${e.localizedMessage ?: e.message}"))
        }
    }

    private fun drainEncoder(
        codec: MediaCodec,
        muxer: MediaMuxer,
        bufferInfo: MediaCodec.BufferInfo,
        videoTrackIndex: Int,
        muxerStarted: Boolean
    ): Pair<Int, Boolean> {
        var currentVTrack = videoTrackIndex
        var started = muxerStarted
        var isDraining = true
        while (isDraining) {
            val outIndex = codec.dequeueOutputBuffer(bufferInfo, 0)
            if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (currentVTrack < 0) {
                    currentVTrack = muxer.addTrack(codec.outputFormat)
                    if (!started) {
                        muxer.start()
                        started = true
                    }
                }
            } else if (outIndex >= 0) {
                val encodedData = codec.getOutputBuffer(outIndex)
                if (encodedData != null && started && currentVTrack >= 0 && bufferInfo.size > 0) {
                    encodedData.position(bufferInfo.offset)
                    encodedData.limit(bufferInfo.offset + bufferInfo.size)
                    muxer.writeSampleData(currentVTrack, encodedData, bufferInfo)
                }
                codec.releaseOutputBuffer(outIndex, false)
            } else {
                isDraining = false
            }
        }
        return Pair(currentVTrack, started)
    }

    private fun selectColorFormat(mimeType: String): Int {
        val codecList = MediaCodecList(MediaCodecList.REGULAR_CODECS)
        for (info in codecList.codecInfos) {
            if (!info.isEncoder) continue
            val types = info.supportedTypes
            for (type in types) {
                if (type.equals(mimeType, ignoreCase = true)) {
                    val caps = info.getCapabilitiesForType(type)
                    val formats = caps.colorFormats
                    if (formats.contains(MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar)) {
                        return MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
                    }
                    if (formats.contains(MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar)) {
                        return MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar
                    }
                }
            }
        }
        return MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
    }

    private fun renderPhotoFrame(src: Bitmap, targetWidth: Int, targetHeight: Int): Bitmap {
        val output = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)

        // OLED friendly dark background
        canvas.drawColor(android.graphics.Color.parseColor("#0A0A0E"))

        val srcW = src.width.toFloat()
        val srcH = src.height.toFloat()
        val scale = (targetWidth.toFloat() / srcW).coerceAtMost(targetHeight.toFloat() / srcH)
        val drawW = srcW * scale
        val drawH = srcH * scale
        val left = (targetWidth - drawW) / 2f
        val top = (targetHeight - drawH) / 2f

        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val destRect = RectF(left, top, left + drawW, top + drawH)
        canvas.drawBitmap(src, null, destRect, paint)

        return output
    }

    private fun encodeYUV420SP(yuv420sp: ByteArray, argb: IntArray, width: Int, height: Int) {
        val frameSize = width * height
        var yIndex = 0
        var uvIndex = frameSize
        var index = 0

        for (j in 0 until height) {
            for (i in 0 until width) {
                val color = argb[index]
                val r = (color and 0xff0000) shr 16
                val g = (color and 0xff00) shr 8
                val b = color and 0xff

                val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128

                yuv420sp[yIndex++] = y.coerceIn(0, 255).toByte()

                if (j % 2 == 0 && index % 2 == 0) {
                    yuv420sp[uvIndex++] = u.coerceIn(0, 255).toByte()
                    yuv420sp[uvIndex++] = v.coerceIn(0, 255).toByte()
                }
                index++
            }
        }
    }

    private fun encodeYUV420P(yuv420p: ByteArray, argb: IntArray, width: Int, height: Int) {
        val frameSize = width * height
        val qFrameSize = frameSize / 4
        var yIndex = 0
        var uIndex = frameSize
        var vIndex = frameSize + qFrameSize
        var index = 0

        for (j in 0 until height) {
            for (i in 0 until width) {
                val color = argb[index]
                val r = (color and 0xff0000) shr 16
                val g = (color and 0xff00) shr 8
                val b = color and 0xff

                val y = ((66 * r + 129 * g + 25 * b + 128) shr 8) + 16
                val u = ((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128
                val v = ((112 * r - 94 * g - 18 * b + 128) shr 8) + 128

                yuv420p[yIndex++] = y.coerceIn(0, 255).toByte()

                if (j % 2 == 0 && index % 2 == 0) {
                    yuv420p[uIndex++] = u.coerceIn(0, 255).toByte()
                    yuv420p[vIndex++] = v.coerceIn(0, 255).toByte()
                }
                index++
            }
        }
    }

    suspend fun downloadPhotoAlbum(
        context: Context,
        imageUrls: List<String>,
        author: String,
        onProgress: (progress: Float, statusText: String) -> Unit
    ): Result<List<File>> = withContext(Dispatchers.IO) {
        val sanitizedAuthor = author.replace(Regex("[^a-zA-Z0-9_\\-\\u0600-\\u06FF]"), "_").take(20).ifBlank { "TikTok" }
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val savedFiles = mutableListOf<File>()

        try {
            for ((index, url) in imageUrls.withIndex()) {
                val fileName = "TikTok_Photo_${sanitizedAuthor}_${System.currentTimeMillis()}_${index + 1}.jpg"
                val file = File(downloadsDir, fileName)

                val req = Request.Builder().url(url).build()
                val resp = httpClient.newCall(req).execute()
                if (resp.isSuccessful && resp.body != null) {
                    FileOutputStream(file).use { out ->
                        resp.body!!.byteStream().copyTo(out)
                    }
                    savedFiles.add(file)
                    MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf("image/jpeg"), null)
                }
                resp.close()

                val p = (index + 1).toFloat() / imageUrls.size
                onProgress(p, "تم حفظ الصورة ${index + 1} من ${imageUrls.size}")
            }
            Result.success(savedFiles)
        } catch (e: Exception) {
            Result.failure(Exception("تعذر تنزيل جميع الصور: ${e.localizedMessage ?: e.message}"))
        }
    }
}
