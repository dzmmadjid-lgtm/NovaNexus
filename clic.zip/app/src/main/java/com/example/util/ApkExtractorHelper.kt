package com.example.util

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.example.model.AppItem
import com.example.model.ExtractionResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.DecimalFormat
import java.util.Locale

object ApkExtractorHelper {

    suspend fun getInstalledApps(context: Context): List<AppItem> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val appsList = mutableListOf<AppItem>()

        val packages: List<PackageInfo> = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledPackages(0)
            }
        } catch (_: Exception) {
            emptyList()
        }

        for (pkg in packages) {
            val appInfo = pkg.applicationInfo ?: continue
            val apkPath = appInfo.sourceDir ?: continue
            val apkFile = File(apkPath)
            if (!apkFile.exists()) continue

            val appName = try {
                pm.getApplicationLabel(appInfo).toString()
            } catch (_: Exception) {
                pkg.packageName
            }

            val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 ||
                    (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0

            val sizeBytes = apkFile.length()
            val formattedSize = formatFileSize(sizeBytes)

            val vName = pkg.versionName ?: "1.0"
            val vCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkg.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                pkg.versionCode.toLong()
            }

            val icon = try {
                pm.getApplicationIcon(appInfo)
            } catch (_: Exception) {
                null
            }

            val minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                appInfo.minSdkVersion
            } else 21

            appsList.add(
                AppItem(
                    appName = appName,
                    packageName = pkg.packageName,
                    versionName = vName,
                    versionCode = vCode,
                    isSystemApp = isSystem,
                    apkSourcePath = apkPath,
                    apkSizeBytes = sizeBytes,
                    formattedSize = formattedSize,
                    targetSdk = appInfo.targetSdkVersion,
                    minSdk = minSdk,
                    lastUpdatedTime = pkg.lastUpdateTime,
                    icon = icon
                )
            )
        }

        appsList.sortedBy { it.appName.lowercase() }
    }

    suspend fun extractApk(context: Context, app: AppItem): ExtractionResult? = withContext(Dispatchers.IO) {
        try {
            val srcFile = File(app.apkSourcePath)
            if (!srcFile.exists() || !srcFile.canRead()) return@withContext null

            // Destination directory
            val outputDir = File(context.getExternalFilesDir(null), "Extracted_APKs")
            if (!outputDir.exists()) outputDir.mkdirs()

            val cleanAppName = app.appName.replace(Regex("[^a-zA-Z0-9_\\-\\u0600-\\u06FF]"), "_")
            val fileName = "${cleanAppName}_v${app.versionName}.apk"
            val destFile = File(outputDir, fileName)

            FileInputStream(srcFile).use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }

            ExtractionResult(
                appName = app.appName,
                packageName = app.packageName,
                fileName = fileName,
                filePath = destFile.absolutePath,
                fileSizeFormatted = formatFileSize(destFile.length())
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    fun shareApk(context: Context, filePath: String) {
        val file = File(filePath)
        if (!file.exists()) return

        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_STREAM, uri)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        context.startActivity(Intent.createChooser(intent, "مشاركة ملف الـ APK").apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        })
    }

    fun openApp(context: Context, packageName: String): Boolean {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        return true
    }

    fun openAppSettings(context: Context, packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.parse("package:$packageName")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun getExtractedApkFiles(context: Context): List<ExtractionResult> {
        val outputDir = File(context.getExternalFilesDir(null), "Extracted_APKs")
        if (!outputDir.exists()) return emptyList()

        return outputDir.listFiles()
            ?.filter { it.extension.equals("apk", ignoreCase = true) }
            ?.map { file ->
                ExtractionResult(
                    appName = file.nameWithoutExtension.substringBefore("_v"),
                    packageName = "com.extracted.${file.nameWithoutExtension}",
                    fileName = file.name,
                    filePath = file.absolutePath,
                    fileSizeFormatted = formatFileSize(file.length()),
                    timestamp = file.lastModified()
                )
            }?.sortedByDescending { it.timestamp } ?: emptyList()
    }

    private fun formatFileSize(size: Long): String {
        if (size <= 0) return "0 MB"
        val df = DecimalFormat("#.##")
        val kb = size / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0

        return when {
            gb >= 1.0 -> "${df.format(gb)} GB"
            mb >= 1.0 -> "${df.format(mb)} MB"
            kb >= 1.0 -> "${df.format(kb)} KB"
            else -> "$size B"
        }
    }
}
