package com.example.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.model.DetectedProjectInfo
import com.example.model.ProjectType

object ProjectDetectorHelper {

    fun analyzeUri(context: Context, uri: Uri): DetectedProjectInfo {
        var displayName = uri.lastPathSegment ?: "Selected_Project"

        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        val name = cursor.getString(nameIndex)
                        if (!name.isNullOrBlank()) {
                            displayName = name
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        return detectFromNames(displayName, listOf(displayName))
    }

    fun detectFromNames(folderName: String, fileNames: List<String>): DetectedProjectInfo {
        val lowerNames = fileNames.map { it.lowercase() }
        val lowerFolder = folderName.lowercase()

        // 1. Flutter Detection
        val isFlutter = lowerNames.any { it.contains("pubspec") || it.contains("flutter") } ||
                lowerFolder.contains("flutter")

        if (isFlutter) {
            return DetectedProjectInfo(
                name = folderName.replace(".zip", ""),
                type = ProjectType.FLUTTER,
                packageOrBundleId = "com.app.${folderName.lowercase().replace(Regex("[^a-z0-9]"), "")}",
                buildTool = "Flutter SDK + Gradle Wrapper",
                sdkVersion = "Flutter 3.24.x / Dart 3.5.x",
                keyFilesFound = listOf("pubspec.yaml", "android/app/build.gradle", "lib/main.dart"),
                estimatedBuildTimeMinutes = 2
            )
        }

        // 2. React Native Detection
        val isReactNative = lowerNames.any { it.contains("package.json") || it.contains("react") || it.contains("metro") } ||
                lowerFolder.contains("react") || lowerFolder.contains("expo")

        if (isReactNative) {
            return DetectedProjectInfo(
                name = folderName.replace(".zip", ""),
                type = ProjectType.REACT_NATIVE,
                packageOrBundleId = "com.${folderName.lowercase().replace(Regex("[^a-z0-9]"), "")}.app",
                buildTool = "Node 20 + Metro + Gradle",
                sdkVersion = "React Native 0.74+ / Android SDK 34",
                keyFilesFound = listOf("package.json", "android/", "App.tsx"),
                estimatedBuildTimeMinutes = 3
            )
        }

        // 3. Native Android Detection
        val isNativeAndroid = lowerNames.any { it.contains("gradle") || it.contains("android") || it.contains("manifest") } ||
                lowerFolder.contains("android") || lowerFolder.contains("kotlin")

        if (isNativeAndroid) {
            return DetectedProjectInfo(
                name = folderName.replace(".zip", ""),
                type = ProjectType.ANDROID_KOTLIN_JAVA,
                packageOrBundleId = "com.example.${folderName.lowercase().replace(Regex("[^a-z0-9]"), "")}",
                buildTool = "Android Gradle Plugin + AAPT2",
                sdkVersion = "JDK 17 + Android API 34",
                keyFilesFound = listOf("build.gradle.kts", "app/src/main/AndroidManifest.xml"),
                estimatedBuildTimeMinutes = 1
            )
        }

        // Fallback Auto Detection
        return DetectedProjectInfo(
            name = folderName.replace(".zip", "").ifBlank { "MobileApp_Project" },
            type = ProjectType.UNKNOWN,
            packageOrBundleId = "com.build.${folderName.lowercase().replace(Regex("[^a-z0-9]"), "").ifBlank { "apk" }}",
            buildTool = "Auto-Detect Builder CI/CD",
            sdkVersion = "Auto Gradle / Cloud Engine",
            keyFilesFound = if (fileNames.isNotEmpty()) fileNames.take(3) else listOf("src/", "assets/"),
            estimatedBuildTimeMinutes = 2
        )
    }
}

