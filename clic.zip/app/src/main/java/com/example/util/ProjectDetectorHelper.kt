package com.example.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.model.DetectedProjectInfo
import com.example.model.ProjectType
import java.io.InputStream
import java.util.zip.ZipInputStream

object ProjectDetectorHelper {

    fun analyzeUri(context: Context, uri: Uri): DetectedProjectInfo {
        var displayName = "Selected_Project.zip"

        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        val name = cursor.getString(nameIndex)
                        if (!name.isNullOrBlank()) {
                            displayName = name
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        val foundZipFiles = mutableListOf<String>()

        // Attempt reading zip contents directly if it's a zip/archive
        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                ZipInputStream(inputStream).use { zis ->
                    var entry = zis.nextEntry
                    var count = 0
                    while (entry != null && count < 60) {
                        foundZipFiles.add(entry.name)
                        count++
                        entry = zis.nextEntry
                    }
                }
            }
        } catch (_: Exception) {}

        return detectFromNames(displayName, foundZipFiles.ifEmpty { listOf(displayName) })
    }

    fun detectFromNames(folderName: String, fileNames: List<String>): DetectedProjectInfo {
        val lowerNames = fileNames.map { it.lowercase() }
        val lowerFolder = folderName.lowercase()

        // 1. Flutter Detection (pubspec.yaml, pubspec.lock, lib/main.dart)
        val isFlutter = lowerNames.any { it.contains("pubspec.yaml") || it.contains("pubspec.lock") || it.contains("main.dart") } ||
                lowerFolder.contains("flutter")

        if (isFlutter) {
            val keyFiles = mutableListOf("pubspec.yaml")
            if (lowerNames.any { it.contains("main.dart") }) keyFiles.add("lib/main.dart")
            if (lowerNames.any { it.contains("android") }) keyFiles.add("android/build.gradle")

            return DetectedProjectInfo(
                name = folderName.replace(Regex("(?i)\\.zip$"), ""),
                type = ProjectType.FLUTTER,
                packageOrBundleId = "com.app.${folderName.lowercase().replace(Regex("[^a-z0-9]"), "")}",
                buildTool = "Flutter SDK + Gradle Wrapper",
                sdkVersion = "Flutter 3.24.x / Dart 3.5.x",
                keyFilesFound = keyFiles,
                estimatedBuildTimeMinutes = 2
            )
        }

        // 2. React Native Detection (package.json, metro.config.js, App.tsx/js)
        val isReactNative = lowerNames.any { it.contains("package.json") || it.contains("metro.config") || it.contains("app.json") || it.contains("app.tsx") || it.contains("app.js") } ||
                lowerFolder.contains("react") || lowerFolder.contains("expo")

        if (isReactNative) {
            val keyFiles = mutableListOf("package.json")
            if (lowerNames.any { it.contains("metro") }) keyFiles.add("metro.config.js")
            if (lowerNames.any { it.contains("app.tsx") || it.contains("app.js") }) keyFiles.add("App.tsx")

            return DetectedProjectInfo(
                name = folderName.replace(Regex("(?i)\\.zip$"), ""),
                type = ProjectType.REACT_NATIVE,
                packageOrBundleId = "com.${folderName.lowercase().replace(Regex("[^a-z0-9]"), "")}.app",
                buildTool = "Node 20 + Metro + Gradle",
                sdkVersion = "React Native 0.74+ / Android SDK 34",
                keyFilesFound = keyFiles,
                estimatedBuildTimeMinutes = 3
            )
        }

        // 3. Native Android Detection (build.gradle, AndroidManifest.xml, settings.gradle)
        val isNativeAndroid = lowerNames.any { it.contains("build.gradle") || it.contains("androidmanifest.xml") || it.contains("settings.gradle") } ||
                lowerFolder.contains("android") || lowerFolder.contains("kotlin")

        if (isNativeAndroid) {
            val keyFiles = mutableListOf<String>()
            if (lowerNames.any { it.contains("build.gradle") }) keyFiles.add("build.gradle.kts")
            if (lowerNames.any { it.contains("androidmanifest") }) keyFiles.add("AndroidManifest.xml")
            if (keyFiles.isEmpty()) keyFiles.addAll(listOf("build.gradle", "src/main/"))

            return DetectedProjectInfo(
                name = folderName.replace(Regex("(?i)\\.zip$"), ""),
                type = ProjectType.ANDROID_KOTLIN_JAVA,
                packageOrBundleId = "com.example.${folderName.lowercase().replace(Regex("[^a-z0-9]"), "")}",
                buildTool = "Android Gradle Plugin + AAPT2",
                sdkVersion = "JDK 17 + Android API 34",
                keyFilesFound = keyFiles,
                estimatedBuildTimeMinutes = 1
            )
        }

        // Fallback Auto Detection
        return DetectedProjectInfo(
            name = folderName.replace(Regex("(?i)\\.zip$"), "").ifBlank { "MobileApp_Project" },
            type = ProjectType.UNKNOWN,
            packageOrBundleId = "com.build.${folderName.lowercase().replace(Regex("[^a-z0-9]"), "").ifBlank { "apk" }}",
            buildTool = "Auto-Detect Builder CI/CD",
            sdkVersion = "Auto Gradle / Cloud Engine",
            keyFilesFound = if (fileNames.isNotEmpty()) fileNames.take(3) else listOf("src/", "assets/"),
            estimatedBuildTimeMinutes = 2
        )
    }
}

