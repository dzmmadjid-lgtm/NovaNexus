package com.example.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object MediaHelper {

    fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1.0 -> String.format(Locale.US, "%.2f جيجابايت", gb)
            mb >= 1.0 -> String.format(Locale.US, "%.1f ميجابايت", mb)
            kb >= 1.0 -> String.format(Locale.US, "%.0f كيلوبايت", kb)
            else -> "$bytes بايت"
        }
    }

    fun formatDuration(seconds: Int): String {
        if (seconds <= 0) return "00:00"
        val m = seconds / 60
        val s = seconds % 60
        return String.format(Locale.US, "%02d:%02d", m, s)
    }

    fun formatCompactNumber(count: Long): String {
        if (count < 1000) return count.toString()
        val exp = (Math.log(count.toDouble()) / Math.log(1000.0)).toInt()
        val format = String.format(Locale.US, "%.1f", count / Math.pow(1000.0, exp.toDouble()))
        val suffix = "KMGTPE"[exp - 1]
        return "$format$suffix"
    }

    fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun openMediaFile(context: Context, filePath: String, isAudio: Boolean) {
        try {
            val file = File(filePath)
            if (!file.exists()) {
                Toast.makeText(context, "الملف غير موجود في الذاكرة", Toast.LENGTH_SHORT).show()
                return
            }

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val mimeType = if (isAudio) "audio/*" else "video/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "تشغيل بواسطة"))
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر تشغيل الملف: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareMediaFile(context: Context, filePath: String, title: String, isAudio: Boolean) {
        try {
            val file = File(filePath)
            if (!file.exists()) {
                Toast.makeText(context, "الملف غير موجود للمشاركة", Toast.LENGTH_SHORT).show()
                return
            }

            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )

            val mimeType = if (isAudio) "audio/mpeg" else "video/mp4"
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "$title\nتم التنزيل عبر TikDownloader")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "مشاركة الملف"))
        } catch (e: Exception) {
            Toast.makeText(context, "تعذر المشاركة: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }
}
