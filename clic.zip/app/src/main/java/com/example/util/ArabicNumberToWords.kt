package com.example.util

import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Robust Arabic number to words converter (Tafqeet) tailored for Algerian Dinar (دج).
 */
object ArabicNumberToWords {

    private val ones = arrayOf(
        "", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة",
        "عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر",
        "سبعة عشر", "ثمانية عشر", "تسعة عشر"
    )

    private val onesFeminine = arrayOf(
        "", "واحدة", "اثنتان", "ثلاث", "أربع", "خمس", "ست", "سبع", "ثمان", "تسع",
        "عشر", "إحدى عشرة", "اثنتا عشرة", "ثلاث عشرة", "أربع عشرة", "خمس عشرة", "ست عشرة",
        "سبع عشرة", "ثماني عشرة", "تسع عشرة"
    )

    private val tens = arrayOf(
        "", "", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"
    )

    private val hundreds = arrayOf(
        "", "مائة", "مائتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسعمائة"
    )

    /**
     * Converts a number to Algerian Dinars written out in Arabic.
     * Example: 250.0 -> "مائتان وخمسون ديناراً جزائرياً"
     * Example: 30.50 -> "ثلاثون ديناراً جزائرياً وخمسون سنتیماً"
     */
    fun convertToDinarWords(amount: Double): String {
        if (amount < 0) {
            return "سالب " + convertToDinarWords(-amount)
        }
        if (amount == 0.0) {
            return "صفر دينار جزائري"
        }

        val bd = BigDecimal(amount.toString()).setScale(2, RoundingMode.HALF_UP)
        val dinarsPart = bd.toBigInteger().toLong()
        val centimesPart = bd.remainder(BigDecimal.ONE).multiply(BigDecimal(100)).toInt()

        val dinarText = if (dinarsPart > 0) {
            val words = convertNumber(dinarsPart)
            val currencySuffix = getDinarCurrencyName(dinarsPart)
            "$words $currencySuffix"
        } else ""

        val centimeText = if (centimesPart > 0) {
            val words = convertNumber(centimesPart.toLong())
            val centimeSuffix = getCentimeName(centimesPart)
            "$words $centimeSuffix"
        } else ""

        return when {
            dinarText.isNotEmpty() && centimeText.isNotEmpty() -> "$dinarText و$centimeText"
            dinarText.isNotEmpty() -> dinarText
            centimeText.isNotEmpty() -> centimeText
            else -> "صفر دينار جزائري"
        }
    }

    private fun getDinarCurrencyName(number: Long): String {
        val lastTwo = (number % 100).toInt()
        val lastOne = (number % 10).toInt()

        return when {
            number == 1L -> "دينار جزائري"
            number == 2L -> "ديناران جزائريان"
            lastTwo in 3..10 -> "دنانير جزائرية"
            lastTwo in 11..99 -> "ديناراً جزائرياً"
            else -> "دينار جزائري"
        }
    }

    private fun getCentimeName(number: Int): String {
        return when {
            number == 1 -> "سنتيم واحد"
            number == 2 -> "سنتيمان"
            number in 3..10 -> "سنتيمات"
            else -> "سنتيماً"
        }
    }

    fun convertNumber(number: Long): String {
        if (number == 0L) return "صفر"
        if (number < 0L) return "سالب " + convertNumber(-number)

        var n = number
        val parts = mutableListOf<String>()

        // Billions
        val billions = n / 1_000_000_000L
        if (billions > 0) {
            parts.add(when (billions) {
                1L -> "مليار"
                2L -> "ملياران"
                in 3L..10L -> "${convertThreeDigits(billions.toInt())} مليارات"
                else -> "${convertThreeDigits(billions.toInt())} مليار"
            })
            n %= 1_000_000_000L
        }

        // Millions
        val millions = n / 1_000_000L
        if (millions > 0) {
            parts.add(when (millions) {
                1L -> "مليون"
                2L -> "مليونان"
                in 3L..10L -> "${convertThreeDigits(millions.toInt())} ملايين"
                else -> "${convertThreeDigits(millions.toInt())} مليون"
            })
            n %= 1_000_000L
        }

        // Thousands
        val thousands = n / 1_000L
        if (thousands > 0) {
            parts.add(when (thousands) {
                1L -> "ألف"
                2L -> "ألفان"
                in 3L..10L -> "${convertThreeDigits(thousands.toInt())} آلاف"
                else -> "${convertThreeDigits(thousands.toInt())} ألف"
            })
            n %= 1_000L
        }

        // Remainder (< 1000)
        if (n > 0) {
            parts.add(convertThreeDigits(n.toInt()))
        }

        return parts.joinToString(" و")
    }

    private fun convertThreeDigits(num: Int): String {
        if (num == 0) return ""

        val parts = mutableListOf<String>()
        val h = num / 100
        val remainder = num % 100

        if (h > 0) {
            parts.add(hundreds[h])
        }

        if (remainder > 0) {
            if (remainder < 20) {
                parts.add(ones[remainder])
            } else {
                val unit = remainder % 10
                val ten = remainder / 10
                if (unit > 0) {
                    parts.add("${ones[unit]} و${tens[ten]}")
                } else {
                    parts.add(tens[ten])
                }
            }
        }

        return parts.joinToString(" و")
    }
}
