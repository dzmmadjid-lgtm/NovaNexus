package com.example.util

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import java.util.Stack

object CalculatorEvaluator {

    sealed class EvaluationResult {
        data class Success(val value: Double, val formattedText: String) : EvaluationResult()
        data class Error(val message: String) : EvaluationResult()
    }

    /**
     * Evaluates a mathematical string like "150 + 25 × 4 - 50"
     */
    fun evaluate(expression: String): EvaluationResult {
        if (expression.isBlank()) return EvaluationResult.Success(0.0, "0")

        try {
            val sanitized = sanitizeExpression(expression)
            if (sanitized.isEmpty()) return EvaluationResult.Success(0.0, "0")

            val tokens = tokenize(sanitized)
            if (tokens.isEmpty()) return EvaluationResult.Success(0.0, "0")

            val postfix = infixToPostfix(tokens)
            val result = evaluatePostfix(postfix)

            if (result.isInfinite() || result.isNaN()) {
                return EvaluationResult.Error("لا يمكن القسمة على صفر")
            }

            return EvaluationResult.Success(result, formatResult(result))
        } catch (e: ArithmeticException) {
            return EvaluationResult.Error(e.message ?: "خطأ حسابي")
        } catch (e: Exception) {
            return EvaluationResult.Error("تعبير غير صالح")
        }
    }

    fun formatResult(value: Double): String {
        if (value.isNaN()) return "خطأ"
        if (value.isInfinite()) return "غير محدد"

        // Format to max 10 decimal places, omit trailing zeroes
        val symbols = DecimalFormatSymbols(Locale.US)
        val df = if (Math.abs(value) >= 1e12 || (Math.abs(value) > 0 && Math.abs(value) < 1e-6)) {
            DecimalFormat("0.######E0", symbols)
        } else {
            DecimalFormat("#,##0.########", symbols).apply {
                isGroupingUsed = false
            }
        }
        return df.format(value)
    }

    private fun sanitizeExpression(expr: String): String {
        return expr
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .replace(",", ".")
            .replace(" ", "")
    }

    private fun tokenize(expr: String): List<String> {
        val tokens = mutableListOf<String>()
        var i = 0
        val n = expr.length

        while (i < n) {
            val c = expr[i]

            // Numbers
            if (c.isDigit() || c == '.') {
                val sb = StringBuilder()
                while (i < n && (expr[i].isDigit() || expr[i] == '.')) {
                    sb.append(expr[i])
                    i++
                }
                tokens.add(sb.toString())
                continue
            }

            // Operators & Parentheses
            if (c in listOf('+', '-', '*', '/', '%', '(', ')')) {
                // Check for unary minus (e.g. at start or after operator/open paren)
                if (c == '-' && (tokens.isEmpty() || tokens.last() in listOf("+", "-", "*", "/", "(", "%"))) {
                    // Peek if next is number
                    if (i + 1 < n && (expr[i + 1].isDigit() || expr[i + 1] == '.')) {
                        val sb = StringBuilder("-")
                        i++
                        while (i < n && (expr[i].isDigit() || expr[i] == '.')) {
                            sb.append(expr[i])
                            i++
                        }
                        tokens.add(sb.toString())
                        continue
                    }
                }
                tokens.add(c.toString())
                i++
                continue
            }

            i++
        }
        return tokens
    }

    private fun precedence(op: String): Int {
        return when (op) {
            "+", "-" -> 1
            "*", "/", "%" -> 2
            else -> 0
        }
    }

    private fun infixToPostfix(tokens: List<String>): List<String> {
        val output = mutableListOf<String>()
        val stack = Stack<String>()

        for (token in tokens) {
            if (token.toDoubleOrNull() != null) {
                output.add(token)
            } else if (token == "(") {
                stack.push(token)
            } else if (token == ")") {
                while (stack.isNotEmpty() && stack.peek() != "(") {
                    output.add(stack.pop())
                }
                if (stack.isNotEmpty() && stack.peek() == "(") {
                    stack.pop()
                }
            } else if (token in listOf("+", "-", "*", "/", "%")) {
                while (stack.isNotEmpty() && stack.peek() != "(" && precedence(stack.peek()) >= precedence(token)) {
                    output.add(stack.pop())
                }
                stack.push(token)
            }
        }

        while (stack.isNotEmpty()) {
            val top = stack.pop()
            if (top != "(" && top != ")") {
                output.add(top)
            }
        }

        return output
    }

    private fun evaluatePostfix(postfix: List<String>): Double {
        val stack = Stack<Double>()

        for (token in postfix) {
            val num = token.toDoubleOrNull()
            if (num != null) {
                stack.push(num)
            } else {
                if (token == "%") {
                    if (stack.isEmpty()) continue
                    val a = stack.pop()
                    if (stack.isNotEmpty()) {
                        // percentage of previous number, e.g. a % of b
                        val base = stack.peek()
                        stack.push(base * (a / 100.0))
                    } else {
                        stack.push(a / 100.0)
                    }
                } else if (stack.size >= 2) {
                    val b = stack.pop()
                    val a = stack.pop()
                    val res = when (token) {
                        "+" -> a + b
                        "-" -> a - b
                        "*" -> a * b
                        "/" -> {
                            if (b == 0.0) throw ArithmeticException("لا يمكن القسمة على صفر")
                            a / b
                        }
                        else -> 0.0
                    }
                    stack.push(res)
                }
            }
        }

        return if (stack.isNotEmpty()) stack.pop() else 0.0
    }
}
