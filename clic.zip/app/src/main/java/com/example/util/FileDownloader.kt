package com.example.util

import android.app.DownloadManager
import android.content.Context
import android.database.Cursor
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import com.example.model.ActiveDownload
import com.example.model.DownloadStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.File

class FileDownloader(private val context: Context) {

    private val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    fun downloadFile(
        downloadId: String,
        url: String,
        title: String,
        author: String,
        thumbnailUrl: String,
        isAudio: Boolean = false
    ): Flow<ActiveDownload> = flow {
        var currentDownload = ActiveDownload(
            downloadId = downloadId,
            title = title,
            thumbnailUrl = thumbnailUrl,
            status = DownloadStatus.PREPARING,
            progress = 0.05f,
            isAudioOnly = isAudio
        )
        emit(currentDownload)

        val extension = if (isAudio) "mp3" else "mp4"
        val sanitizedAuthor = author.replace(Regex("[^a-zA-Z0-9_\\-\\u0600-\\u06FF]"), "_").take(20).ifBlank { "TikTok" }
        val fileName = "TikTok_${sanitizedAuthor}_${System.currentTimeMillis()}.$extension"

        val enqueueId: Long
        try {
            val uri = Uri.parse(url)
            val request = DownloadManager.Request(uri).apply {
                setTitle(title.ifBlank { "فيديو تيك توك بدون علامة مائية" })
                setDescription(if (isAudio) "تحميل صوت MP3 بجودة عالية" else "تحميل فيديو MP4 بدون علامة مائية")
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI or DownloadManager.Request.NETWORK_MOBILE)
                setAllowedOverRoaming(true)
                setMimeType(if (isAudio) "audio/mpeg" else "video/mp4")
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                addRequestHeader("User-Agent", "Mozilla/5.0 (Linux; Android 13; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
                addRequestHeader("Referer", "https://www.tikwm.com/")
            }

            enqueueId = downloadManager.enqueue(request)
            currentDownload = currentDownload.copy(
                downloadManagerId = enqueueId,
                status = DownloadStatus.DOWNLOADING
            )
            emit(currentDownload)
        } catch (e: Exception) {
            emit(
                currentDownload.copy(
                    status = DownloadStatus.FAILED,
                    errorMessage = "تعذر بدء التحميل عبر نظام التنزيل: ${e.localizedMessage ?: e.message}"
                )
            )
            return@flow
        }

        var isFinished = false
        val targetFile = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            fileName
        )

        while (!isFinished) {
            val query = DownloadManager.Query().setFilterById(enqueueId)
            var cursor: Cursor? = null
            try {
                cursor = downloadManager.query(query)
                if (cursor != null && cursor.moveToFirst()) {
                    val status = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    val bytesDownloaded = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                    val bytesTotal = cursor.getLong(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))

                    when (status) {
                        DownloadManager.STATUS_RUNNING -> {
                            val progress = if (bytesTotal > 0) {
                                (bytesDownloaded.toFloat() / bytesTotal.toFloat()).coerceIn(0.01f, 0.99f)
                            } else {
                                0.5f
                            }
                            emit(
                                currentDownload.copy(
                                    status = DownloadStatus.DOWNLOADING,
                                    progress = progress,
                                    downloadedBytes = bytesDownloaded,
                                    totalBytes = bytesTotal
                                )
                            )
                        }

                        DownloadManager.STATUS_PENDING -> {
                            emit(
                                currentDownload.copy(
                                    status = DownloadStatus.PREPARING,
                                    progress = 0.08f
                                )
                            )
                        }

                        DownloadManager.STATUS_PAUSED -> {
                            emit(
                                currentDownload.copy(
                                    status = DownloadStatus.DOWNLOADING,
                                    progress = if (bytesTotal > 0) (bytesDownloaded.toFloat() / bytesTotal.toFloat()).coerceIn(0f, 0.99f) else 0.1f
                                )
                            )
                        }

                        DownloadManager.STATUS_SUCCESSFUL -> {
                            isFinished = true
                            val finalPath = if (targetFile.exists()) {
                                targetFile.absolutePath
                            } else {
                                val localUriStr = cursor.getString(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
                                Uri.parse(localUriStr)?.path ?: targetFile.absolutePath
                            }

                            // Tell MediaScanner about the new media file
                            try {
                                MediaScannerConnection.scanFile(
                                    context,
                                    arrayOf(finalPath),
                                    arrayOf(if (isAudio) "audio/mpeg" else "video/mp4"),
                                    null
                                )
                            } catch (_: Exception) {}

                            val fileSize = if (targetFile.exists()) targetFile.length() else bytesDownloaded
                            emit(
                                currentDownload.copy(
                                    status = DownloadStatus.COMPLETED,
                                    progress = 1.0f,
                                    downloadedBytes = fileSize,
                                    totalBytes = fileSize,
                                    localFilePath = finalPath
                                )
                            )
                        }

                        DownloadManager.STATUS_FAILED -> {
                            isFinished = true
                            val reason = cursor.getInt(cursor.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON))
                            val reasonMsg = mapDownloadError(reason)
                            emit(
                                currentDownload.copy(
                                    status = DownloadStatus.FAILED,
                                    errorMessage = reasonMsg
                                )
                            )
                        }
                    }
                }
            } catch (_: Exception) {
                // Ignore transient query failure
            } finally {
                cursor?.close()
            }

            if (!isFinished) {
                delay(350)
            }
        }
    }.flowOn(Dispatchers.IO)

    private fun mapDownloadError(reason: Int): String {
        return when (reason) {
            DownloadManager.ERROR_CANNOT_RESUME -> "تعذر استئناف التحميل"
            DownloadManager.ERROR_DEVICE_NOT_FOUND -> "وحدة التخزين غير متوفرة"
            DownloadManager.ERROR_FILE_ALREADY_EXISTS -> "الملف موجود مسبقاً"
            DownloadManager.ERROR_FILE_ERROR -> "خطأ في كتابة ملف الفيديو في الذاكرة"
            DownloadManager.ERROR_HTTP_DATA_ERROR -> "خطأ في استقبال بيانات الفيديو"
            DownloadManager.ERROR_INSUFFICIENT_SPACE -> "المساحة المتبقية على الهاتف غير كافية"
            DownloadManager.ERROR_TOO_MANY_REDIRECTS -> "تجاوز عدد التوجيهات المسموح بها"
            DownloadManager.ERROR_UNHANDLED_HTTP_CODE -> "خطأ في سيرفر التنزيل"
            else -> "فشل التحميل (رمز الخطأ: $reason)"
        }
    }

    fun cancelDownload(downloadManagerId: Long) {
        if (downloadManagerId > 0) {
            try {
                downloadManager.remove(downloadManagerId)
            } catch (_: Exception) {}
        }
    }
}
