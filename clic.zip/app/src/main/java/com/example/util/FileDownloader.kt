package com.example.util

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import com.example.model.ActiveDownload
import com.example.model.DownloadStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class FileDownloader(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun downloadFile(
        downloadId: String,
        url: String,
        title: String,
        author: String,
        thumbnailUrl: String,
        isAudio: Boolean = false
    ): Flow<ActiveDownload> = flow {
        var currentDownload = ActiveDownload(
            downloadId = downloadId,
            title = title,
            thumbnailUrl = thumbnailUrl,
            status = DownloadStatus.PREPARING,
            progress = 0.02f,
            isAudioOnly = isAudio
        )
        emit(currentDownload)

        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .header("Accept", "*/*")
                .header("Referer", "https://www.tiktok.com/")
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                emit(
                    currentDownload.copy(
                        status = DownloadStatus.FAILED,
                        errorMessage = "فشل بدء التحميل من السيرفر (${response.code})"
                    )
                )
                return@flow
            }

            val body = response.body
            if (body == null) {
                emit(
                    currentDownload.copy(
                        status = DownloadStatus.FAILED,
                        errorMessage = "محتوى الملف فارغ"
                    )
                )
                return@flow
            }

            val totalBytes = body.contentLength()
            val extension = if (isAudio) "mp3" else "mp4"
            val sanitizedAuthor = author.replace(Regex("[^a-zA-Z0-9_\\-\\u0600-\\u06FF]"), "_").take(20)
            val fileName = "TikTok_${sanitizedAuthor}_${System.currentTimeMillis()}.$extension"

            // Target directory: Public Downloads/TikDownloader or Movies/TikDownloader
            val targetDir = getDestinationDirectory(isAudio)
            if (!targetDir.exists()) {
                targetDir.mkdirs()
            }
            val destinationFile = File(targetDir, fileName)

            currentDownload = currentDownload.copy(
                status = DownloadStatus.DOWNLOADING,
                totalBytes = totalBytes
            )
            emit(currentDownload)

            val inputStream = body.byteStream()
            val outputStream = FileOutputStream(destinationFile)
            val buffer = ByteArray(8 * 1024)
            var bytesRead: Int
            var downloadedBytes: Long = 0
            var lastEmittedTime = System.currentTimeMillis()

            try {
                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    outputStream.write(buffer, 0, bytesRead)
                    downloadedBytes += bytesRead

                    val now = System.currentTimeMillis()
                    if (now - lastEmittedTime > 250 || downloadedBytes == totalBytes) {
                        lastEmittedTime = now
                        val calcProgress = if (totalBytes > 0) {
                            (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 0.99f)
                        } else {
                            0.5f
                        }
                        emit(
                            currentDownload.copy(
                                progress = calcProgress,
                                downloadedBytes = downloadedBytes,
                                totalBytes = totalBytes
                            )
                        )
                    }
                }
                outputStream.flush()
            } finally {
                outputStream.close()
                inputStream.close()
            }

            // Tell MediaScanner about the new media file
            try {
                MediaScannerConnection.scanFile(
                    context,
                    arrayOf(destinationFile.absolutePath),
                    arrayOf(if (isAudio) "audio/mpeg" else "video/mp4"),
                    null
                )
            } catch (_: Exception) {}

            emit(
                currentDownload.copy(
                    status = DownloadStatus.COMPLETED,
                    progress = 1.0f,
                    downloadedBytes = destinationFile.length(),
                    totalBytes = destinationFile.length(),
                    localFilePath = destinationFile.absolutePath
                )
            )
        } catch (e: Exception) {
            emit(
                currentDownload.copy(
                    status = DownloadStatus.FAILED,
                    errorMessage = e.localizedMessage ?: "حدث خطأ أثناء تنزيل الملف"
                )
            )
        }
    }.flowOn(Dispatchers.IO)

    private fun getDestinationDirectory(isAudio: Boolean): File {
        return try {
            val publicDir = if (isAudio) {
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
            } else {
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
            }
            val subFolder = File(publicDir, "TikDownloader")
            if (subFolder.exists() || subFolder.mkdirs()) {
                subFolder
            } else {
                // Fallback to external files dir
                val fallback = context.getExternalFilesDir(if (isAudio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES)
                fallback ?: context.filesDir
            }
        } catch (e: Exception) {
            context.filesDir
        }
    }
}
