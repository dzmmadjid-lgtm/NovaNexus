package com.example.network

import com.example.model.TikTokVideo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class TikTokExtractor {

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    companion object {
        private val TIKTOK_URL_PATTERN = Pattern.compile(
            "https?://(?:[a-zA-Z0-9_-]+\\.)?tiktok\\.com/[^\\s\"'<>]+",
            Pattern.CASE_INSENSITIVE
        )

        fun extractUrlFromText(text: String): String? {
            val matcher = TIKTOK_URL_PATTERN.matcher(text.trim())
            return if (matcher.find()) {
                var url = matcher.group()
                // Strip trailing punctuation if accidentally matched
                url = url.trimEnd(')', ']', '}', '.', ',', '!', '?')
                url
            } else if (text.trim().startsWith("http://") || text.trim().startsWith("https://")) {
                text.trim()
            } else {
                null
            }
        }

        fun isValidVideoUrl(url: String?): Boolean {
            if (url.isNullOrBlank()) return false
            val lower = url.lowercase()

            // Crucial check: Ensure link does not contain audio tags
            val audioIndicators = listOf(
                "audio_mpeg",
                "audio_mp4",
                "mime_type=audio",
                "mime_type=audio%2f",
                "mime_type=audio%2F",
                "mime_type=audio_mp4",
                "format=mp3",
                "audio_only",
                "is_audio=1",
                "audio_channel",
                "/music/",
                ".mp3"
            )
            for (indicator in audioIndicators) {
                if (lower.contains(indicator)) {
                    return false
                }
            }
            return true
        }

        fun findVideoUrl(data: JSONObject): String? {
            val hdplay = data.optString("hdplay", "").trim()
            val play = data.optString("play", "").trim()
            val wmplay = data.optString("wmplay", "").trim()

            // Priority: hdplay then play then wmplay
            val candidates = listOf(hdplay, play, wmplay)
            for (raw in candidates) {
                if (isValidVideoUrl(raw)) {
                    var candidate = raw
                    if (candidate.startsWith("/")) {
                        candidate = "https://www.tikwm.com$candidate"
                    }
                    return candidate
                }
            }
            return null
        }
    }

    suspend fun fetchVideoDetails(rawInput: String): Result<TikTokVideo> = withContext(Dispatchers.IO) {
        try {
            val cleanUrl = extractUrlFromText(rawInput)
                ?: return@withContext Result.failure(Exception("لم يتم العثور على رابط تيك توك صحيح. يرجى التأكد من الرابط."))

            // Try Primary API: TikWM with hd=1
            val tikwmResult = fetchFromTikWM(cleanUrl)
            if (tikwmResult.isSuccess) {
                return@withContext tikwmResult
            }

            // Fallback: Resolve redirect first if it is vm.tiktok.com or vt.tiktok.com
            val resolvedUrl = resolveRedirectUrl(cleanUrl)
            if (resolvedUrl != cleanUrl) {
                val resolvedResult = fetchFromTikWM(resolvedUrl)
                if (resolvedResult.isSuccess) {
                    return@withContext resolvedResult
                }
            }

            // Return meaningful error
            val originalErr = tikwmResult.exceptionOrNull()?.message ?: "تعذر استخراج بيانات الفيديو من تيك توك"
            Result.failure(Exception(originalErr))
        } catch (e: Exception) {
            Result.failure(Exception("فشل الاتصال: ${e.localizedMessage ?: e.message}"))
        }
    }

    private fun resolveRedirectUrl(url: String): String {
        return try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
                .head()
                .build()

            val response = client.newCall(request).execute()
            val finalUrl = response.request.url.toString()
            response.close()
            finalUrl
        } catch (e: Exception) {
            url
        }
    }

    private fun fetchFromTikWM(url: String): Result<TikTokVideo> {
        return try {
            val requestBody = FormBody.Builder()
                .add("url", url)
                .add("hd", "1")
                .build()

            val request = Request.Builder()
                .url("https://www.tikwm.com/api/")
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                .header("Accept", "application/json")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful || responseBody.isBlank()) {
                return Result.failure(Exception("استجابة غير صالحة من السيرفر (${response.code})"))
            }

            val json = JSONObject(responseBody)
            val code = json.optInt("code", -1)
            val msg = json.optString("msg", "")

            if (code != 0) {
                val errorDesc = when {
                    msg.contains("url invalid", ignoreCase = true) -> "رابط التيك توك غير صالح أو الفيديو خاص/محذوف"
                    msg.isNotBlank() -> msg
                    else -> "فشل جلب الفيديو، قد يكون خاصاً أو مقيداً"
                }
                return Result.failure(Exception(errorDesc))
            }

            val data = json.optJSONObject("data")
                ?: return Result.failure(Exception("لم يتم العثور على بيانات الفيديو"))

            val id = data.optString("id", "")
            val title = data.optString("title", "فيديو تيك توك").ifBlank { "فيديو تيك توك" }
            val cover = data.optString("cover", "")
            val originCover = data.optString("origin_cover", cover)
            val duration = data.optInt("duration", 0)

            // Extract Photo Mode images if present
            val imagesList = mutableListOf<String>()
            val imagesArray = data.optJSONArray("images")
            if (imagesArray != null) {
                for (i in 0 until imagesArray.length()) {
                    val img = imagesArray.optString(i, "").trim()
                    if (img.isNotBlank()) {
                        imagesList.add(img)
                    }
                }
            }
            val isPhotoMode = imagesList.isNotEmpty()

            // Find valid video URL using strict audio-exclusion filter
            val validVideoUrl = findVideoUrl(data) ?: ""

            var hdplay = data.optString("hdplay", "").trim()
            var play = data.optString("play", "").trim()
            val wmplay = data.optString("wmplay", "").trim()
            var music = data.optString("music", "").trim()

            if (hdplay.startsWith("/")) hdplay = "https://www.tikwm.com$hdplay"
            if (play.startsWith("/")) play = "https://www.tikwm.com$play"
            if (music.startsWith("/")) music = "https://www.tikwm.com$music"

            val effectiveHd = if (isValidVideoUrl(hdplay)) hdplay else validVideoUrl
            val effectiveNoWatermark = if (isValidVideoUrl(play)) play else (effectiveHd.ifBlank { validVideoUrl })

            // For regular videos, ensure we have a valid video stream and not an audio-only file
            if (!isPhotoMode && effectiveNoWatermark.isBlank()) {
                return Result.failure(Exception("لم يتم العثور على مسار فيديو صالح بدون علامة مائية (الرابط يحتوي على بث صوتي فقط)"))
            }

            val authorObj = data.optJSONObject("author")
            val authorName = authorObj?.optString("nickname", "")?.ifBlank { "مستخدم تيك توك" } ?: "مستخدم تيك توك"
            val authorUsername = authorObj?.optString("unique_id", "") ?: ""
            val authorAvatar = authorObj?.optString("avatar", "") ?: ""

            val musicObj = data.optJSONObject("music_info")
            val musicTitle = musicObj?.optString("title", "الصوت الأصلي") ?: "الصوت الأصلي"
            val musicAuthor = musicObj?.optString("author", authorName) ?: authorName

            val views = data.optLong("play_count", 0L)
            val likes = data.optLong("digg_count", 0L)
            val comments = data.optLong("comment_count", 0L)
            val shares = data.optLong("share_count", 0L)

            val primaryCover = if (isPhotoMode && imagesList.isNotEmpty()) {
                imagesList.first()
            } else {
                originCover.ifBlank { cover }
            }

            val video = TikTokVideo(
                id = id.ifBlank { System.currentTimeMillis().toString() },
                title = title,
                coverUrl = primaryCover,
                originCoverUrl = originCover,
                duration = duration,
                videoNoWatermarkUrl = effectiveNoWatermark,
                videoHdUrl = effectiveHd,
                videoWatermarkUrl = if (isValidVideoUrl(wmplay)) wmplay else "",
                audioUrl = music,
                audioTitle = musicTitle,
                audioAuthor = musicAuthor,
                authorName = authorName,
                authorUsername = authorUsername,
                authorAvatar = authorAvatar,
                viewsCount = views,
                likesCount = likes,
                commentsCount = comments,
                sharesCount = shares,
                originalSourceUrl = url,
                images = imagesList,
                isPhotoMode = isPhotoMode
            )

            Result.success(video)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
