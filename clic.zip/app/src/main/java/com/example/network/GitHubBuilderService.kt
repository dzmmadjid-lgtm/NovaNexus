package com.example.network

import android.content.Context
import android.util.Base64
import com.example.model.GitHubArtifact
import com.example.model.GitHubConfig
import com.example.model.GitHubWorkflowRun
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

class GitHubBuilderService(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun verifyRepository(config: GitHubConfig): Result<String> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.github.com/repos/${config.owner}/${config.repo}"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "token ${config.token}")
                .addHeader("Accept", "application/vnd.github.v3+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "{}")
                val fullName = json.optString("full_name", "${config.owner}/${config.repo}")
                Result.success(fullName)
            } else {
                val err = response.body?.string() ?: ""
                Result.failure(Exception("فشل الاتصال بمستودع GitHub (${response.code}): $err"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getWorkflowTemplate(): String {
        return """
name: Build Android APK

on:
  workflow_dispatch:
    inputs:
      project_name:
        description: 'Name of the project'
        required: false
        default: 'app'

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Make gradlew executable
        run: chmod +x ./gradlew || true

      - name: Build with Gradle
        run: ./gradlew assembleRelease || ./gradlew assembleDebug || gradle assembleDebug

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: app-release-apk
          path: |
            **/build/outputs/apk/**/*.apk
          retention-days: 7
""".trimIndent()
    }

    suspend fun triggerWorkflow(config: GitHubConfig, ref: String = config.branch): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.github.com/repos/${config.owner}/${config.repo}/actions/workflows/${config.workflowFileName}/dispatches"
            val payload = JSONObject().apply {
                put("ref", ref)
            }

            val body = payload.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "token ${config.token}")
                .addHeader("Accept", "application/vnd.github.v3+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            if (response.code in 200..204) {
                Result.success(true)
            } else {
                val err = response.body?.string() ?: ""
                Result.failure(Exception("خطأ في تشغيل مسار البناء (${response.code}): $err"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getLatestWorkflowRuns(config: GitHubConfig): Result<List<GitHubWorkflowRun>> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.github.com/repos/${config.owner}/${config.repo}/actions/runs?per_page=10"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "token ${config.token}")
                .addHeader("Accept", "application/vnd.github.v3+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "{}")
                val runsArray = json.optJSONArray("workflow_runs") ?: return@withContext Result.success(emptyList())
                val list = mutableListOf<GitHubWorkflowRun>()
                for (i in 0 until runsArray.length()) {
                    val obj = runsArray.getJSONObject(i)
                    list.add(
                        GitHubWorkflowRun(
                            id = obj.optLong("id"),
                            status = obj.optString("status", "queued"),
                            conclusion = if (obj.isNull("conclusion")) null else obj.optString("conclusion"),
                            htmlUrl = obj.optString("html_url", ""),
                            runNumber = obj.optInt("run_number", 1),
                            event = obj.optString("event", "workflow_dispatch"),
                            createdAt = obj.optString("created_at", ""),
                            updatedAt = obj.optString("updated_at", "")
                        )
                    )
                }
                Result.success(list)
            } else {
                Result.failure(Exception("فشل جلب مسارات البناء (${response.code})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getRunArtifacts(config: GitHubConfig, runId: Long): Result<List<GitHubArtifact>> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.github.com/repos/${config.owner}/${config.repo}/actions/runs/$runId/artifacts"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "token ${config.token}")
                .addHeader("Accept", "application/vnd.github.v3+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "{}")
                val artifactsArray = json.optJSONArray("artifacts") ?: return@withContext Result.success(emptyList())
                val list = mutableListOf<GitHubArtifact>()
                for (i in 0 until artifactsArray.length()) {
                    val obj = artifactsArray.getJSONObject(i)
                    list.add(
                        GitHubArtifact(
                            id = obj.optLong("id"),
                            name = obj.optString("name", "app-release-apk"),
                            sizeInBytes = obj.optLong("size_in_bytes", 0L),
                            archiveDownloadUrl = obj.optString("archive_download_url", ""),
                            expired = obj.optBoolean("expired", false)
                        )
                    )
                }
                Result.success(list)
            } else {
                Result.failure(Exception("فشل جلب ملفات الـ Artifacts (${response.code})"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun downloadAndExtractApk(
        config: GitHubConfig,
        downloadUrl: String,
        outputFileName: String,
        onProgress: (Int, String) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            onProgress(10, "بدء تنزيل حزمة الـ APK من سيرفر GitHub...")
            val request = Request.Builder()
                .url(downloadUrl)
                .addHeader("Authorization", "token ${config.token}")
                .addHeader("Accept", "application/vnd.github.v3+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception("خطأ أثناء تنزيل الـ APK (${response.code})"))
            }

            val body = response.body ?: return@withContext Result.failure(Exception("محتوى التنزيل فارغ"))
            val outputDir = File(context.getExternalFilesDir(null), "downloaded_apks").apply { mkdirs() }
            val finalApkFile = File(outputDir, if (outputFileName.endsWith(".apk")) outputFileName else "$outputFileName.apk")

            onProgress(40, "فك ضغط حزمة الـ Artifact واستخراج ملف الـ APK...")
            var foundApk = false

            ZipInputStream(body.byteStream()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.endsWith(".apk", ignoreCase = true)) {
                        FileOutputStream(finalApkFile).use { fos ->
                            zis.copyTo(fos)
                        }
                        foundApk = true
                        break
                    }
                    entry = zis.nextEntry
                }
            }

            if (foundApk && finalApkFile.exists() && finalApkFile.length() > 0) {
                onProgress(100, "تم استخراج ملف الـ APK وتجهيزه للتثبيت بنجاح! 🚀")
                Result.success(finalApkFile)
            } else {
                Result.failure(Exception("لم يتم العثور على ملف بصيغة .apk داخل الـ Artifact"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
