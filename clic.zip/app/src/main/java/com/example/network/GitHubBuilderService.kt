package com.example.network

import android.content.Context
import android.util.Base64
import com.example.model.GitHubArtifact
import com.example.model.GitHubConfig
import com.example.model.GitHubWorkflowRun
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GitHubBuilderService(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun verifyRepository(config: GitHubConfig): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (config.token.isBlank()) {
                return@withContext Result.failure(Exception("يرجى إدخال رمز الوصول الشخصي (Personal Access Token)"))
            }
            if (config.owner.isBlank() || config.repo.isBlank()) {
                return@withContext Result.failure(Exception("يرجى إدخال اسم المالك واسم المستودع"))
            }

            val url = "https://api.github.com/repos/${config.owner.trim()}/${config.repo.trim()}"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer ${config.token.trim()}")
                .addHeader("Accept", "application/vnd.github+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "{}")
                val fullName = json.optString("full_name", "${config.owner}/${config.repo}")
                val defaultBranch = json.optString("default_branch", "main")
                Result.success("$fullName (الفرع الافتراضي: $defaultBranch)")
            } else {
                val err = response.body?.string() ?: ""
                Result.failure(Exception("فشل الاتصال بمستودع GitHub (${response.code}): $err"))
            }
        } catch (e: Exception) {
            Result.failure(Exception("خطأ في الاتصال بالسيرفر: ${e.localizedMessage ?: e.message}"))
        }
    }

    suspend fun getRepoDefaultBranch(config: GitHubConfig): String = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.github.com/repos/${config.owner.trim()}/${config.repo.trim()}"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer ${config.token.trim()}")
                .addHeader("Accept", "application/vnd.github+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "{}")
                return@withContext json.optString("default_branch", config.branch.ifBlank { "main" })
            }
        } catch (_: Exception) {}
        return@withContext config.branch.ifBlank { "main" }
    }

    suspend fun getWorkflowTemplate(): String {
        return """
name: Build Android APK

on:
  workflow_dispatch:
    inputs:
      project_name:
        description: 'Name of the project'
        required: false
        default: 'app'

jobs:
  build:
    name: Build APK Package
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Make gradlew executable
        run: chmod +x ./gradlew || true

      - name: Build with Gradle
        run: |
          if [ -f "./gradlew" ]; then
            ./gradlew assembleRelease || ./gradlew assembleDebug || gradle assembleDebug
          else
            gradle assembleDebug || gradle build
          fi

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: app-release-apk
          path: |
            **/build/outputs/apk/**/*.apk
          retention-days: 7
""".trimIndent()
    }

    /**
     * Automatically creates or updates the workflow file in the target GitHub repository
     * using GitHub Contents API (PUT /repos/{owner}/{repo}/contents/.github/workflows/{workflowFileName})
     */
    suspend fun ensureWorkflowFileExists(config: GitHubConfig, targetBranch: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val fileName = config.workflowFileName.trim().ifBlank { "build-apk.yml" }
            val path = ".github/workflows/$fileName"
            val checkUrl = "https://api.github.com/repos/${config.owner.trim()}/${config.repo.trim()}/contents/$path?ref=$targetBranch"

            // Check if file already exists
            val checkReq = Request.Builder()
                .url(checkUrl)
                .addHeader("Authorization", "Bearer ${config.token.trim()}")
                .addHeader("Accept", "application/vnd.github+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .get()
                .build()

            val checkRes = client.newCall(checkReq).execute()
            var existingSha: String? = null
            if (checkRes.isSuccessful) {
                val json = JSONObject(checkRes.body?.string() ?: "{}")
                existingSha = json.optString("sha", "")
                if (existingSha.isNotBlank()) {
                    return@withContext Result.success("الملف موجود بالفعل")
                }
            }

            // Create or update file
            val yamlContent = getWorkflowTemplate()
            val base64Content = Base64.encodeToString(yamlContent.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)

            val payload = JSONObject().apply {
                put("message", "Add GitHub Actions APK Build Workflow")
                put("content", base64Content)
                put("branch", targetBranch)
                if (!existingSha.isNullOrBlank()) {
                    put("sha", existingSha)
                }
            }

            val putUrl = "https://api.github.com/repos/${config.owner.trim()}/${config.repo.trim()}/contents/$path"
            val putBody = payload.toString().toRequestBody("application/json".toMediaType())
            val putReq = Request.Builder()
                .url(putUrl)
                .addHeader("Authorization", "Bearer ${config.token.trim()}")
                .addHeader("Accept", "application/vnd.github+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .put(putBody)
                .build()

            val putRes = client.newCall(putReq).execute()
            if (putRes.isSuccessful || putRes.code in 200..201) {
                Result.success("تم إنشاء ملف المسار ($path) في المستودع بنجاح!")
            } else {
                val err = putRes.body?.string() ?: ""
                Result.failure(Exception("تعذر إنشاء ملف الـ Workflow تلقائياً (${putRes.code}): $err"))
            }
        } catch (e: Exception) {
            Result.failure(Exception("خطأ في إنشاء ملف المسار: ${e.localizedMessage ?: e.message}"))
        }
    }

    /**
     * Checks repository workflows and attempts to find a matching workflow or create it.
     */
    suspend fun triggerWorkflow(config: GitHubConfig, ref: String = config.branch): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            // Determine actual default branch if ref is blank or main/master
            val actualBranch = if (ref.isNotBlank() && ref != "main" && ref != "master") {
                ref.trim()
            } else {
                getRepoDefaultBranch(config)
            }

            val workflowName = config.workflowFileName.trim().ifBlank { "build-apk.yml" }
            val url = "https://api.github.com/repos/${config.owner.trim()}/${config.repo.trim()}/actions/workflows/$workflowName/dispatches"
            val payload = JSONObject().apply {
                put("ref", actualBranch)
            }

            val body = payload.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer ${config.token.trim()}")
                .addHeader("Accept", "application/vnd.github+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            if (response.code in 200..204) {
                return@withContext Result.success(true)
            }

            // If 404 (Not Found), it means the workflow file does not exist in .github/workflows/
            // or the token lacks workflow scope. Let's attempt auto-creation!
            if (response.code == 404) {
                val createRes = ensureWorkflowFileExists(config, actualBranch)
                if (createRes.isSuccess) {
                    // Wait 2 seconds for GitHub to register the workflow
                    kotlinx.coroutines.delay(2500)

                    // Retry dispatch
                    val retryReq = Request.Builder()
                        .url(url)
                        .addHeader("Authorization", "Bearer ${config.token.trim()}")
                        .addHeader("Accept", "application/vnd.github+json")
                        .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                        .post(payload.toString().toRequestBody("application/json".toMediaType()))
                        .build()

                    val retryRes = client.newCall(retryReq).execute()
                    if (retryRes.code in 200..204) {
                        return@withContext Result.success(true)
                    }
                }

                // If still failed or creation failed, provide helpful explanation
                return@withContext Result.failure(
                    Exception(
                        "ملف مسار البناء ($workflowName) غير موجود في مجلد (.github/workflows/) في المستودع!\n" +
                        "يرجى الضغط على زر الكود </> في الأعلى لنسخ كود الـ Workflow ووضعه في مستودعك، أو التأكد من إعطاء التوكن صلاحية (workflow & repo)."
                    )
                )
            }

            val err = response.body?.string() ?: ""
            Result.failure(Exception("خطأ في تشغيل مسار البناء (${response.code}): $err"))
        } catch (e: Exception) {
            Result.failure(Exception("تعذر إرسال طلب البناء: ${e.localizedMessage ?: e.message}"))
        }
    }

    suspend fun getLatestWorkflowRuns(config: GitHubConfig): Result<List<GitHubWorkflowRun>> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.github.com/repos/${config.owner.trim()}/${config.repo.trim()}/actions/runs?per_page=10"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer ${config.token.trim()}")
                .addHeader("Accept", "application/vnd.github+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "{}")
                val runsArray = json.optJSONArray("workflow_runs") ?: return@withContext Result.success(emptyList())
                val list = mutableListOf<GitHubWorkflowRun>()
                for (i in 0 until runsArray.length()) {
                    val obj = runsArray.getJSONObject(i)
                    list.add(
                        GitHubWorkflowRun(
                            id = obj.optLong("id"),
                            status = obj.optString("status", "queued"),
                            conclusion = if (obj.isNull("conclusion")) null else obj.optString("conclusion"),
                            htmlUrl = obj.optString("html_url", "https://github.com/${config.owner}/${config.repo}/actions"),
                            runNumber = obj.optInt("run_number", 1),
                            event = obj.optString("event", "workflow_dispatch"),
                            createdAt = obj.optString("created_at", ""),
                            updatedAt = obj.optString("updated_at", "")
                        )
                    )
                }
                Result.success(list)
            } else {
                Result.failure(Exception("فشل جلب مسارات البناء (${response.code})"))
            }
        } catch (e: Exception) {
            Result.failure(Exception("خطأ في فحص حالة البناء: ${e.localizedMessage ?: e.message}"))
        }
    }

    suspend fun getRunArtifacts(config: GitHubConfig, runId: Long): Result<List<GitHubArtifact>> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.github.com/repos/${config.owner.trim()}/${config.repo.trim()}/actions/runs/$runId/artifacts"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer ${config.token.trim()}")
                .addHeader("Accept", "application/vnd.github+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "{}")
                val artifactsArray = json.optJSONArray("artifacts") ?: return@withContext Result.success(emptyList())
                val list = mutableListOf<GitHubArtifact>()
                for (i in 0 until artifactsArray.length()) {
                    val obj = artifactsArray.getJSONObject(i)
                    list.add(
                        GitHubArtifact(
                            id = obj.optLong("id"),
                            name = obj.optString("name", "app-release-apk"),
                            sizeInBytes = obj.optLong("size_in_bytes", 0L),
                            archiveDownloadUrl = obj.optString("archive_download_url", ""),
                            expired = obj.optBoolean("expired", false)
                        )
                    )
                }
                Result.success(list)
            } else {
                Result.failure(Exception("فشل جلب ملفات الـ Artifacts (${response.code})"))
            }
        } catch (e: Exception) {
            Result.failure(Exception("تعذر استرجاع ملفات الـ Artifacts: ${e.localizedMessage ?: e.message}"))
        }
    }
}
