package com.example.network

import android.content.Context
import com.example.model.GitHubArtifact
import com.example.model.GitHubConfig
import com.example.model.GitHubWorkflowRun
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GitHubBuilderService(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun verifyRepository(config: GitHubConfig): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (config.token.isBlank()) {
                return@withContext Result.failure(Exception("يرجى إدخال رمز الوصول الشخصي (Personal Access Token)"))
            }
            if (config.owner.isBlank() || config.repo.isBlank()) {
                return@withContext Result.failure(Exception("يرجى إدخال اسم المالك واسم المستودع"))
            }

            val url = "https://api.github.com/repos/${config.owner.trim()}/${config.repo.trim()}"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer ${config.token.trim()}")
                .addHeader("Accept", "application/vnd.github+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "{}")
                val fullName = json.optString("full_name", "${config.owner}/${config.repo}")
                val defaultBranch = json.optString("default_branch", "main")
                Result.success("$fullName (الفرع الافتراضي: $defaultBranch)")
            } else {
                val err = response.body?.string() ?: ""
                Result.failure(Exception("فشل الاتصال بمستودع GitHub (${response.code}): $err"))
            }
        } catch (e: Exception) {
            Result.failure(Exception("خطأ في الاتصال بالسيرفر: ${e.localizedMessage ?: e.message}"))
        }
    }

    suspend fun getWorkflowTemplate(): String {
        return """
name: Build Android APK

on:
  workflow_dispatch:
    inputs:
      project_name:
        description: 'Name of the project'
        required: false
        default: 'app'

jobs:
  build:
    name: Build APK Package
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Make gradlew executable
        run: chmod +x ./gradlew || true

      - name: Build with Gradle
        run: |
          if [ -f "./gradlew" ]; then
            ./gradlew assembleRelease || ./gradlew assembleDebug || gradle assembleDebug
          else
            gradle assembleDebug || gradle build
          fi

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: app-release-apk
          path: |
            **/build/outputs/apk/**/*.apk
          retention-days: 7
""".trimIndent()
    }

    suspend fun triggerWorkflow(config: GitHubConfig, ref: String = config.branch): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val workflowName = config.workflowFileName.trim().ifBlank { "build.yml" }
            val targetBranch = ref.trim().ifBlank { config.branch.ifBlank { "main" } }
            val url = "https://api.github.com/repos/${config.owner.trim()}/${config.repo.trim()}/actions/workflows/$workflowName/dispatches"
            val payload = JSONObject().apply {
                put("ref", targetBranch)
            }

            val body = payload.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer ${config.token.trim()}")
                .addHeader("Accept", "application/vnd.github+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            if (response.code in 200..204) {
                return@withContext Result.success(true)
            }

            val err = response.body?.string() ?: ""
            Result.failure(Exception("خطأ في تشغيل مسار البناء (${response.code}): $err"))
        } catch (e: Exception) {
            Result.failure(Exception("تعذر إرسال طلب البناء: ${e.localizedMessage ?: e.message}"))
        }
    }

    suspend fun getLatestWorkflowRuns(config: GitHubConfig): Result<List<GitHubWorkflowRun>> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.github.com/repos/${config.owner.trim()}/${config.repo.trim()}/actions/runs?per_page=10"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer ${config.token.trim()}")
                .addHeader("Accept", "application/vnd.github+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "{}")
                val runsArray = json.optJSONArray("workflow_runs") ?: return@withContext Result.success(emptyList())
                val list = mutableListOf<GitHubWorkflowRun>()
                for (i in 0 until runsArray.length()) {
                    val obj = runsArray.getJSONObject(i)
                    list.add(
                        GitHubWorkflowRun(
                            id = obj.optLong("id"),
                            status = obj.optString("status", "queued"),
                            conclusion = if (obj.isNull("conclusion")) null else obj.optString("conclusion"),
                            htmlUrl = obj.optString("html_url", "https://github.com/${config.owner}/${config.repo}/actions"),
                            runNumber = obj.optInt("run_number", 1),
                            event = obj.optString("event", "workflow_dispatch"),
                            createdAt = obj.optString("created_at", ""),
                            updatedAt = obj.optString("updated_at", "")
                        )
                    )
                }
                Result.success(list)
            } else {
                Result.failure(Exception("فشل جلب مسارات البناء (${response.code})"))
            }
        } catch (e: Exception) {
            Result.failure(Exception("خطأ في فحص حالة البناء: ${e.localizedMessage ?: e.message}"))
        }
    }

    suspend fun getRunArtifacts(config: GitHubConfig, runId: Long): Result<List<GitHubArtifact>> = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.github.com/repos/${config.owner.trim()}/${config.repo.trim()}/actions/runs/$runId/artifacts"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer ${config.token.trim()}")
                .addHeader("Accept", "application/vnd.github+json")
                .addHeader("User-Agent", "Android-APK-Cloud-Builder")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val json = JSONObject(response.body?.string() ?: "{}")
                val artifactsArray = json.optJSONArray("artifacts") ?: return@withContext Result.success(emptyList())
                val list = mutableListOf<GitHubArtifact>()
                for (i in 0 until artifactsArray.length()) {
                    val obj = artifactsArray.getJSONObject(i)
                    list.add(
                        GitHubArtifact(
                            id = obj.optLong("id"),
                            name = obj.optString("name", "app-release-apk"),
                            sizeInBytes = obj.optLong("size_in_bytes", 0L),
                            archiveDownloadUrl = obj.optString("archive_download_url", ""),
                            expired = obj.optBoolean("expired", false)
                        )
                    )
                }
                Result.success(list)
            } else {
                Result.failure(Exception("فشل جلب ملفات الـ Artifacts (${response.code})"))
            }
        } catch (e: Exception) {
            Result.failure(Exception("تعذر استرجاع ملفات الـ Artifacts: ${e.localizedMessage ?: e.message}"))
        }
    }
}
