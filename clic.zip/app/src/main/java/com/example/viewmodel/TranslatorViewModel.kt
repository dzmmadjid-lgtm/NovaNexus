package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.service.GeminiTranslationService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

data class TranslatorUiState(
    val inputText: String = "",
    val sourceLanguage: AppLanguage = AppLanguage.ENGLISH,
    val targetLanguage: AppLanguage = AppLanguage.ARABIC,
    val selectedTone: TranslationTone = TranslationTone.CONTEXTUAL,
    val isTranslating: Boolean = false,
    val translationResult: TranslationResult? = null,
    val historyList: List<TranslationHistoryItem> = emptyList(),
    val favoritesOnly: Boolean = false,
    val isDarkTheme: Boolean = true,
    val customApiKey: String = "",
    val isSpeaking: Boolean = false,
    val errorMessage: String? = null,
    val snackbarMessage: String? = null
)

class TranslatorViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val _uiState = MutableStateFlow(TranslatorUiState())
    val uiState: StateFlow<TranslatorUiState> = _uiState.asStateFlow()

    private val translationService = GeminiTranslationService()
    private val prefs = application.getSharedPreferences("ai_translator_prefs", Context.MODE_PRIVATE)

    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false
    private var translationJob: Job? = null

    init {
        tts = TextToSpeech(application, this)
        loadSavedData()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true
            tts?.language = Locale.ENGLISH
        } else {
            Log.e("TTS", "TextToSpeech initialization failed.")
        }
    }

    private fun loadSavedData() {
        val savedCustomKey = prefs.getString("custom_api_key", "") ?: ""
        val isDark = prefs.getBoolean("is_dark_theme", true)
        val historyJson = prefs.getString("history_json", null)

        val history = mutableListOf<TranslationHistoryItem>()
        if (!historyJson.isNullOrBlank()) {
            try {
                val array = JSONArray(historyJson)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    history.add(
                        TranslationHistoryItem(
                            id = obj.optString("id"),
                            sourceText = obj.optString("sourceText"),
                            translatedText = obj.optString("translatedText"),
                            sourceLangCode = obj.optString("sourceLangCode", "en"),
                            targetLangCode = obj.optString("targetLangCode", "ar"),
                            toneKey = obj.optString("toneKey", "contextual"),
                            contextExplanation = obj.optString("contextExplanation").takeIf { it.isNotBlank() },
                            isFavorite = obj.optBoolean("isFavorite", false),
                            timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e("TranslatorVM", "Failed to parse history", e)
            }
        }

        _uiState.update {
            it.copy(
                customApiKey = savedCustomKey,
                isDarkTheme = isDark,
                historyList = history.sortedByDescending { h -> h.timestamp }
            )
        }
    }

    private fun saveHistory() {
        val array = JSONArray()
        for (item in _uiState.value.historyList.take(50)) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("sourceText", item.sourceText)
                put("translatedText", item.translatedText)
                put("sourceLangCode", item.sourceLangCode)
                put("targetLangCode", item.targetLangCode)
                put("toneKey", item.toneKey)
                put("contextExplanation", item.contextExplanation ?: "")
                put("isFavorite", item.isFavorite)
                put("timestamp", item.timestamp)
            }
            array.put(obj)
        }
        prefs.edit().putString("history_json", array.toString()).apply()
    }

    fun onInputTextChanged(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun swapLanguages() {
        val currentSource = _uiState.value.sourceLanguage
        val currentTarget = _uiState.value.targetLanguage

        if (currentSource == AppLanguage.AUTO) {
            // Swap auto to target and target to Arabic or English
            val newTarget = if (currentTarget == AppLanguage.ARABIC) AppLanguage.ENGLISH else AppLanguage.ARABIC
            _uiState.update {
                it.copy(
                    sourceLanguage = currentTarget,
                    targetLanguage = newTarget
                )
            }
        } else {
            val currentTranslated = _uiState.value.translationResult?.translatedText ?: ""
            val currentInput = _uiState.value.inputText

            _uiState.update {
                it.copy(
                    sourceLanguage = currentTarget,
                    targetLanguage = currentSource,
                    inputText = if (currentTranslated.isNotEmpty()) currentTranslated else currentInput,
                    translationResult = null
                )
            }
        }
    }

    fun setSourceLanguage(lang: AppLanguage) {
        _uiState.update { it.copy(sourceLanguage = lang) }
    }

    fun setTargetLanguage(lang: AppLanguage) {
        if (lang == AppLanguage.AUTO) return // Target cannot be auto
        _uiState.update { it.copy(targetLanguage = lang) }
    }

    fun setTone(tone: TranslationTone) {
        _uiState.update { it.copy(selectedTone = tone) }
        if (_uiState.value.inputText.isNotBlank() && _uiState.value.translationResult != null) {
            translate()
        }
    }

    fun applyPresetPhrase(text: String, fromLang: AppLanguage, toLang: AppLanguage) {
        _uiState.update {
            it.copy(
                inputText = text,
                sourceLanguage = fromLang,
                targetLanguage = toLang
            )
        }
        translate()
    }

    fun translate() {
        val input = _uiState.value.inputText.trim()
        if (input.isEmpty()) return

        translationJob?.cancel()
        translationJob = viewModelScope.launch {
            _uiState.update { it.copy(isTranslating = true, errorMessage = null) }

            val sourceLang = _uiState.value.sourceLanguage
            val targetLang = _uiState.value.targetLanguage
            val tone = _uiState.value.selectedTone
            val customKey = _uiState.value.customApiKey

            val result = translationService.translate(
                text = input,
                sourceLang = sourceLang,
                targetLang = targetLang,
                tone = tone,
                userApiKey = customKey
            )

            result.onSuccess { translation ->
                _uiState.update { state ->
                    val newHistoryItem = TranslationHistoryItem(
                        sourceText = input,
                        translatedText = translation.translatedText,
                        sourceLangCode = sourceLang.code,
                        targetLangCode = targetLang.code,
                        toneKey = tone.key,
                        contextExplanation = translation.contextExplanation
                    )
                    val updatedHistory = listOf(newHistoryItem) + state.historyList.filter { it.sourceText != input }
                    state.copy(
                        isTranslating = false,
                        translationResult = translation,
                        historyList = updatedHistory
                    )
                }
                saveHistory()
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isTranslating = false,
                        errorMessage = "تعذر إكمال الترجمة: ${err.localizedMessage ?: "خطأ في الشبكة"}"
                    )
                }
            }
        }
    }

    fun clearInput() {
        _uiState.update { it.copy(inputText = "", translationResult = null) }
    }

    fun speakText(text: String, langCode: String) {
        if (!isTtsInitialized || tts == null || text.isBlank()) return

        val locale = when (langCode.lowercase()) {
            "ar" -> Locale("ar")
            "fr" -> Locale.FRENCH
            else -> Locale.ENGLISH
        }

        try {
            tts?.language = locale
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "UtteranceId_${System.currentTimeMillis()}")
            _uiState.update { it.copy(isSpeaking = true) }
            viewModelScope.launch {
                delay(3000)
                _uiState.update { it.copy(isSpeaking = false) }
            }
        } catch (e: Exception) {
            Log.e("TTS", "Error in speakText", e)
        }
    }

    fun toggleFavorite(historyItem: TranslationHistoryItem) {
        val updated = _uiState.value.historyList.map {
            if (it.id == historyItem.id) it.copy(isFavorite = !it.isFavorite) else it
        }
        _uiState.update { it.copy(historyList = updated) }
        saveHistory()
    }

    fun deleteHistoryItem(historyItem: TranslationHistoryItem) {
        val updated = _uiState.value.historyList.filter { it.id != historyItem.id }
        _uiState.update { it.copy(historyList = updated) }
        saveHistory()
    }

    fun clearAllHistory() {
        _uiState.update { it.copy(historyList = emptyList()) }
        saveHistory()
        showSnackbar("تم مسح سجل الترجمة")
    }

    fun toggleFavoritesFilter() {
        _uiState.update { it.copy(favoritesOnly = !it.favoritesOnly) }
    }

    fun toggleTheme() {
        val newDark = !_uiState.value.isDarkTheme
        prefs.edit().putBoolean("is_dark_theme", newDark).apply()
        _uiState.update { it.copy(isDarkTheme = newDark) }
    }

    fun setCustomApiKey(key: String) {
        prefs.edit().putString("custom_api_key", key.trim()).apply()
        _uiState.update { it.copy(customApiKey = key.trim(), snackbarMessage = "تم حفظ مفتاح API") }
    }

    fun showSnackbar(msg: String) {
        _uiState.update { it.copy(snackbarMessage = msg) }
    }

    fun dismissSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
    }
}
