package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.*
import com.example.network.GitHubBuilderService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipFile

class MainAppViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(CombinedAppState())
    val uiState: StateFlow<CombinedAppState> = _uiState.asStateFlow()

    private val context: Context get() = getApplication<Application>().applicationContext
    private val gitHubService = GitHubBuilderService(context)
    private var pollingJob: Job? = null

    init {
        loadSavedGitHubConfig()
        loadInstalledApps()
    }

    private fun getPrefs() = context.getSharedPreferences("app_builder_config", Context.MODE_PRIVATE)

    private fun loadSavedGitHubConfig() {
        val prefs = getPrefs()
        val token = prefs.getString("gh_token", "") ?: ""
        val owner = prefs.getString("gh_owner", "") ?: ""
        val repo = prefs.getString("gh_repo", "") ?: ""
        val workflow = prefs.getString("gh_workflow", "build-apk.yml") ?: "build-apk.yml"
        val branch = prefs.getString("gh_branch", "main") ?: "main"
        val isConfigured = token.isNotBlank() && owner.isNotBlank() && repo.isNotBlank()

        val config = GitHubConfig(
            token = token,
            owner = owner,
            repo = repo,
            workflowFileName = workflow,
            branch = branch,
            isConfigured = isConfigured
        )
        _uiState.update { it.copy(gitHubConfig = config, isRepoVerified = isConfigured) }
    }

    fun saveGitHubConfig(token: String, owner: String, repo: String, workflow: String, branch: String) {
        val trimmedToken = token.trim()
        val trimmedOwner = owner.trim()
        val trimmedRepo = repo.trim()
        val trimmedWorkflow = if (workflow.isBlank()) "build-apk.yml" else workflow.trim()
        val trimmedBranch = if (branch.isBlank()) "main" else branch.trim()

        getPrefs().edit()
            .putString("gh_token", trimmedToken)
            .putString("gh_owner", trimmedOwner)
            .putString("gh_repo", trimmedRepo)
            .putString("gh_workflow", trimmedWorkflow)
            .putString("gh_branch", trimmedBranch)
            .apply()

        val config = GitHubConfig(
            token = trimmedToken,
            owner = trimmedOwner,
            repo = trimmedRepo,
            workflowFileName = trimmedWorkflow,
            branch = trimmedBranch,
            isConfigured = trimmedToken.isNotBlank() && trimmedOwner.isNotBlank() && trimmedRepo.isNotBlank()
        )
        _uiState.update { it.copy(gitHubConfig = config) }
        verifyGitHubRepository()
    }

    fun verifyGitHubRepository() {
        val config = _uiState.value.gitHubConfig
        if (config.token.isBlank() || config.owner.isBlank() || config.repo.isBlank()) {
            _uiState.update {
                it.copy(
                    isVerifyingRepo = false,
                    isRepoVerified = false,
                    repoVerificationMessage = "يرجى تعبئة التوكن واسم المستخدم واسم المستودع أولاً"
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isVerifyingRepo = true, repoVerificationMessage = "جاري التحقق من الاتصال بـ GitHub API...") }
            val result = gitHubService.verifyRepository(config)
            result.onSuccess { repoFullName ->
                _uiState.update {
                    it.copy(
                        isVerifyingRepo = false,
                        isRepoVerified = true,
                        repoVerificationMessage = "تم الاتصال بنجاح مع المستودع: $repoFullName ✅"
                    )
                }
                fetchRecentWorkflowRuns()
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isVerifyingRepo = false,
                        isRepoVerified = false,
                        repoVerificationMessage = err.message ?: "فشل الاتصال بـ GitHub"
                    )
                }
            }
        }
    }

    fun fetchRecentWorkflowRuns() {
        val config = _uiState.value.gitHubConfig
        if (!config.isConfigured) return

        viewModelScope.launch {
            val result = gitHubService.getLatestWorkflowRuns(config)
            result.onSuccess { runs ->
                _uiState.update { it.copy(recentWorkflowRuns = runs) }
            }
        }
    }

    fun switchSection(section: MainAppSection) {
        _uiState.update { it.copy(currentSection = section) }
    }

    fun toggleTheme() {
        _uiState.update { it.copy(isDarkTheme = !it.isDarkTheme) }
    }

    // Process Selected Project Zip
    fun onZipFileSelected(uri: Uri) {
        viewModelScope.launch {
            try {
                val fileName = getFileNameFromUri(uri) ?: "project.zip"
                val tempDir = File(context.cacheDir, "project_import").apply { mkdirs() }
                val targetFile = File(tempDir, fileName)

                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(targetFile).use { output ->
                        input.copyTo(output)
                    }
                }

                val sizeBytes = targetFile.length()
                val sizeFormatted = formatFileSize(sizeBytes)
                val detectionResult = detectProjectFromZip(targetFile)

                _uiState.update {
                    it.copy(
                        selectedZipFile = targetFile,
                        zipFileName = fileName,
                        zipFileSizeFormatted = sizeFormatted,
                        detectedProject = detectionResult,
                        snackbarMessage = "تم تحميل المشروع: $fileName ($sizeFormatted)"
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(snackbarMessage = "خطأ في قراءة ملف الـ ZIP: ${e.message}") }
            }
        }
    }

    // Generate Ready Sample Project with Unique Package Name
    fun generateSampleProject(appName: String): File {
        val uniqueSuffix = (1000..9999).random()
        val cleanId = appName.lowercase().replace("[^a-z0-9]".toRegex(), "")
        val uniquePackageId = "com.sample.testapp${cleanId}$uniqueSuffix"
        val sampleDir = File(context.cacheDir, "sample_${cleanId}_$uniqueSuffix").apply { mkdirs() }
        
        // Build simple standalone project structure for zip
        val srcDir = File(sampleDir, "app/src/main/java/com/sample/testapp${cleanId}$uniqueSuffix").apply { mkdirs() }
        val resDir = File(sampleDir, "app/src/main/res/values").apply { mkdirs() }

        // AndroidManifest.xml
        File(sampleDir, "app/src/main/AndroidManifest.xml").writeText(
            """
            <?xml version="1.0" encoding="utf-8"?>
            <manifest xmlns:android="http://schemas.android.com/apk/res/android">
                <application
                    android:allowBackup="true"
                    android:icon="@android:drawable/sym_def_app_icon"
                    android:label="$appName"
                    android:supportsRtl="true"
                    android:theme="@android:style/Theme.Material.Light.NoActionBar">
                    <activity
                        android:name=".MainActivity"
                        android:exported="true">
                        <intent-filter>
                            <action android:name="android.intent.action.MAIN" />
                            <category android:name="android.intent.category.LAUNCHER" />
                        </intent-filter>
                    </activity>
                </application>
            </manifest>
            """.trimIndent()
        )

        // MainActivity.kt
        File(srcDir, "MainActivity.kt").writeText(
            """
            package $uniquePackageId
            
            import android.app.Activity
            import android.os.Bundle
            import android.widget.TextView
            import android.view.Gravity
            import android.graphics.Color
            
            class MainActivity : Activity() {
                override fun onCreate(savedInstanceState: Bundle?) {
                    super.onCreate(savedInstanceState)
                    val tv = TextView(this).apply {
                        text = "🎉 مرحباً بك في $appName!\n\nتم البناء بنجاح عبر GitHub CI/CD\nاسم الحزمة: $uniquePackageId"
                        textSize = 20f
                        gravity = Gravity.CENTER
                        setTextColor(Color.parseColor("#0F172A"))
                    }
                    setContentView(tv)
                }
            }
            """.trimIndent()
        )

        // strings.xml
        File(resDir, "strings.xml").writeText(
            """
            <resources>
                <string name="app_name">$appName</string>
            </resources>
            """.trimIndent()
        )

        // build.gradle.kts
        File(sampleDir, "app/build.gradle.kts").writeText(
            """
            plugins {
                id("com.android.application")
                kotlin("android")
            }
            android {
                namespace = "$uniquePackageId"
                compileSdk = 34
                defaultConfig {
                    applicationId = "$uniquePackageId"
                    minSdk = 24
                    targetSdk = 34
                    versionCode = 1
                    versionName = "1.0.0"
                }
            }
            """.trimIndent()
        )

        // Zip it up
        val zipOutputFile = File(context.cacheDir, "${appName}_v${uniqueSuffix}.zip")
        val outZip = java.util.zip.ZipOutputStream(FileOutputStream(zipOutputFile))
        
        sampleDir.walkTopDown().forEach { file ->
            if (!file.isDirectory) {
                val relPath = file.relativeTo(sampleDir).path
                val entry = java.util.zip.ZipEntry(relPath)
                outZip.putNextEntry(entry)
                file.inputStream().use { it.copyTo(outZip) }
                outZip.closeEntry()
            }
        }
        outZip.close()

        val sizeFormatted = formatFileSize(zipOutputFile.length())
        val detection = ProjectDetectionResult(
            projectName = "${appName}_TestApp",
            projectType = ProjectKind.NATIVE_ANDROID,
            packageId = uniquePackageId,
            buildTools = "Android Gradle Plugin + AAPT2",
            detectedFiles = listOf("AndroidManifest.xml", "MainActivity.kt", "build.gradle.kts")
        )

        _uiState.update {
            it.copy(
                selectedZipFile = zipOutputFile,
                zipFileName = zipOutputFile.name,
                zipFileSizeFormatted = sizeFormatted,
                detectedProject = detection,
                snackbarMessage = "تم توليد مشروع تجريبي فريد: $uniquePackageId"
            )
        }

        return zipOutputFile
    }

    private fun detectProjectFromZip(zipFile: File): ProjectDetectionResult {
        var hasGradle = false
        var hasPubspec = false
        var hasPackageJson = false
        var hasAndroidManifest = false
        val detectedFiles = mutableListOf<String>()
        var foundPackageId = "com.example.project"
        val projName = zipFile.nameWithoutExtension

        try {
            ZipFile(zipFile).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    val name = entry.name.lowercase()

                    if (name.endsWith("build.gradle.kts") || name.endsWith("build.gradle") || name.endsWith("settings.gradle")) {
                        hasGradle = true
                        if (detectedFiles.size < 5) detectedFiles.add(entry.name)
                    }
                    if (name.endsWith("pubspec.yaml")) {
                        hasPubspec = true
                        if (detectedFiles.size < 5) detectedFiles.add("pubspec.yaml")
                    }
                    if (name.endsWith("package.json")) {
                        hasPackageJson = true
                        if (detectedFiles.size < 5) detectedFiles.add("package.json")
                    }
                    if (name.endsWith("androidmanifest.xml")) {
                        hasAndroidManifest = true
                        if (detectedFiles.size < 5) detectedFiles.add("AndroidManifest.xml")
                    }
                }
            }
        } catch (_: Exception) {}

        val kind = when {
            hasPubspec -> ProjectKind.FLUTTER
            hasPackageJson -> ProjectKind.REACT_NATIVE
            hasAndroidManifest && hasGradle -> ProjectKind.NATIVE_ANDROID
            hasGradle -> ProjectKind.GENERIC_GRADLE
            else -> ProjectKind.NATIVE_ANDROID
        }

        val buildTools = when (kind) {
            ProjectKind.FLUTTER -> "Flutter SDK + Gradle Runner"
            ProjectKind.REACT_NATIVE -> "React Native CLI + Gradle"
            ProjectKind.NATIVE_ANDROID -> "Android Gradle Plugin + AAPT2"
            ProjectKind.GENERIC_GRADLE -> "Gradle Multi-module Builder"
            ProjectKind.CORDOVA_CAPACITOR -> "Capacitor Android Core"
        }

        return ProjectDetectionResult(
            projectName = projName,
            projectType = kind,
            packageId = "com.cloud.app.${projName.lowercase().replace("[^a-z0-9]".toRegex(), "")}",
            buildTools = buildTools,
            detectedFiles = if (detectedFiles.isEmpty()) listOf("build.gradle.kts", "AndroidManifest.xml") else detectedFiles
        )
    }

    // Start GitHub Actions Cloud Build
    fun startCloudBuild() {
        val state = _uiState.value
        val config = state.gitHubConfig

        if (!config.isConfigured) {
            _uiState.update { it.copy(snackbarMessage = "يرجى ضبط وتوثيق حساب GitHub ومستودع البناء أولاً!") }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isBuilding = true,
                    buildProgressPercent = 5,
                    buildStatusText = "بدء الاتصال بخوادم GitHub Actions...",
                    buildLogs = listOf(
                        BuildLogEntry(getCurrentTime(), "🚀 بدء جلسة البناء السحابي التلقائي عبر GitHub CI/CD", isStepHeader = true),
                        BuildLogEntry(getCurrentTime(), "⚙️ التحقق من صلاحيات GitHub Access Token ومستودع البناء...")
                    ),
                    builtApkFile = null
                )
            }

            delay(1000)
            addLog("📡 إرسال أمر تشغيل الـ Workflow (${config.workflowFileName}) إلى مسار البناء...")
            val triggerResult = gitHubService.triggerWorkflow(config)

            if (triggerResult.isFailure) {
                val err = triggerResult.exceptionOrNull()?.message ?: "خطأ غير متوقع"
                addLog("❌ فشل تشغيل مسار البناء: $err", isError = true)
                _uiState.update { it.copy(isBuilding = false, buildStatusText = "فشل تشغيل الـ Workflow") }
                return@launch
            }

            addLog("✅ تم إرسال أمر البناء إلى GitHub Runner بنجاح!", isSuccess = true)
            _uiState.update { it.copy(buildProgressPercent = 20, buildStatusText = "خادم GitHub يقوم الآن بتهيئة البيئة (Ubuntu + JDK 17)...") }

            // Polling and live updates
            pollWorkflowUntilComplete(config)
        }
    }

    private fun pollWorkflowUntilComplete(config: GitHubConfig) {
        pollingJob?.cancel()
        pollingJob = viewModelScope.launch {
            var attempts = 0
            var matchedRunId: Long? = null
            val maxAttempts = 60 // 5 minutes max

            while (attempts < maxAttempts) {
                delay(5000)
                attempts++

                val runsResult = gitHubService.getLatestWorkflowRuns(config)
                if (runsResult.isSuccess) {
                    val runs = runsResult.getOrNull() ?: emptyList()
                    _uiState.update { it.copy(recentWorkflowRuns = runs) }

                    val latestRun = runs.firstOrNull()
                    if (latestRun != null) {
                        matchedRunId = latestRun.id
                        _uiState.update { it.copy(activeRunId = latestRun.id) }

                        when (latestRun.status) {
                            "queued" -> {
                                _uiState.update { it.copy(buildProgressPercent = 25, buildStatusText = "في قائمة الانتظار على خوادم GitHub...") }
                                addLog("⏳ المسار في الانتظار (Queued) - حجز بيئة التشغيل...")
                            }
                            "in_progress" -> {
                                val progress = minOf(30 + (attempts * 3), 85)
                                _uiState.update { it.copy(buildProgressPercent = progress, buildStatusText = "جاري تجميع وترجمة الكود المصنعي بواسطة Gradle...") }
                                addLog("⚡ خادم GitHub يعمل الآن: [Gradle assembleRelease / assembleDebug]...")
                            }
                            "completed" -> {
                                if (latestRun.conclusion == "success") {
                                    _uiState.update { it.copy(buildProgressPercent = 90, buildStatusText = "اكتمل البناء بنجاح! جاري جلب وتنزيل ملف الـ APK...") }
                                    addLog("🎉 اكتمل البناء السحابي على GitHub بنجاح! جلب الـ Artifacts...", isSuccess = true)
                                    downloadArtifactAndFinish(config, latestRun.id)
                                } else {
                                    addLog("❌ فشل البناء على السيرفر (النتيجة: ${latestRun.conclusion}). تفقد تقرير الأخطاء على GitHub.", isError = true)
                                    _uiState.update { it.copy(isBuilding = false, buildStatusText = "فشل البناء على GitHub") }
                                }
                                break
                            }
                        }
                    }
                }
            }

            if (attempts >= maxAttempts) {
                addLog("⏱️ استغرق البناء وقتاً طويلاً. يمكنك تفقد حالة المستودع على GitHub مباشرة.")
                _uiState.update { it.copy(isBuilding = false) }
            }
        }
    }

    private suspend fun downloadArtifactAndFinish(config: GitHubConfig, runId: Long) {
        addLog("📦 البحث عن حزمة الـ APK المصنوعة داخل الـ Artifacts...")
        val artifactsResult = gitHubService.getRunArtifacts(config, runId)
        
        val artifacts = artifactsResult.getOrNull() ?: emptyList()
        val apkArtifact = artifacts.firstOrNull { it.name.contains("apk", ignoreCase = true) } ?: artifacts.firstOrNull()

        if (apkArtifact == null) {
            addLog("⚠️ لم يتم العثور على ملفات APK في مخرجات الـ Action", isError = true)
            _uiState.update { it.copy(isBuilding = false, buildStatusText = "لم يتم العثور على Artifact") }
            return
        }

        addLog("📥 بدء تنزيل: ${apkArtifact.name} (${formatFileSize(apkArtifact.sizeInBytes)})...")
        val downloadResult = gitHubService.downloadAndExtractApk(
            config = config,
            downloadUrl = apkArtifact.archiveDownloadUrl,
            outputFileName = "${_uiState.value.detectedProject?.projectName ?: "app"}-release.apk",
            onProgress = { percent, msg ->
                _uiState.update { it.copy(buildProgressPercent = percent, buildStatusText = msg) }
                addLog("🔹 $msg")
            }
        )

        downloadResult.onSuccess { apkFile ->
            addLog("✨ تم تنزيل وحفظ ملف الـ APK بنجاح: ${apkFile.name} (${formatFileSize(apkFile.length())})", isSuccess = true)
            _uiState.update {
                it.copy(
                    isBuilding = false,
                    buildProgressPercent = 100,
                    buildStatusText = "تم إنشاء وتنزيل ملف الـ APK بنجاح! جاهز للتثبيت 🚀",
                    builtApkFile = apkFile,
                    snackbarMessage = "تم بناء وتنزيل الـ APK بنجاح!"
                )
            }
            loadInstalledApps() // refresh extracted list
        }.onFailure { err ->
            addLog("❌ فشل تنزيل ملف الـ APK: ${err.message}", isError = true)
            _uiState.update { it.copy(isBuilding = false, buildStatusText = "فشل تنزيل ملف الـ APK") }
        }
    }

    private fun addLog(message: String, isError: Boolean = false, isSuccess: Boolean = false, isStepHeader: Boolean = false) {
        val entry = BuildLogEntry(
            timestamp = getCurrentTime(),
            message = message,
            isError = isError,
            isSuccess = isSuccess,
            isStepHeader = isStepHeader
        )
        _uiState.update { it.copy(buildLogs = it.buildLogs + entry) }
    }

    // Install Built or Extracted APK
    fun installApk(apkFile: File) {
        if (!apkFile.exists()) {
            _uiState.update { it.copy(snackbarMessage = "ملف الـ APK غير موجود!") }
            return
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (!context.packageManager.canRequestPackageInstalls()) {
                val intent = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES).apply {
                    data = Uri.parse("package:${context.packageName}")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                _uiState.update { it.copy(snackbarMessage = "يرجى منح إذن تثبيت التطبيقات من مصادر غير معروفة") }
                return
            }
        }

        try {
            val apkUri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apkFile)
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(apkUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(installIntent)
        } catch (e: Exception) {
            _uiState.update { it.copy(snackbarMessage = "خطأ أثناء محاولة التثبيت: ${e.message}") }
        }
    }

    // Share APK
    fun shareApk(apkFile: File) {
        if (!apkFile.exists()) return
        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", apkFile)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "مشاركة حزمة APK").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            _uiState.update { it.copy(snackbarMessage = "خطأ في مشاركة الملف: ${e.message}") }
        }
    }

    // APK Extractor Functions
    fun loadInstalledApps() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingApps = true) }
            val pm = context.packageManager
            val packages = pm.getInstalledPackages(PackageManager.GET_META_DATA)

            val userList = mutableListOf<InstalledAppInfo>()
            val sysList = mutableListOf<InstalledAppInfo>()

            for (pkg in packages) {
                try {
                    val appInfo = pkg.applicationInfo ?: continue
                    val appName = pm.getApplicationLabel(appInfo).toString()
                    val isSys = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    val sourceApk = appInfo.sourceDir ?: ""
                    val size = if (sourceApk.isNotBlank()) File(sourceApk).length() else 0L
                    val vCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pkg.longVersionCode else @Suppress("DEPRECATION") pkg.versionCode.toLong()

                    val info = InstalledAppInfo(
                        appName = appName,
                        packageName = pkg.packageName,
                        versionName = pkg.versionName ?: "1.0",
                        versionCode = vCode,
                        isSystemApp = isSys,
                        sourceApkPath = sourceApk,
                        apkSizeFormatted = formatFileSize(size),
                        apkSizeBytes = size,
                        lastUpdateTime = pkg.lastUpdateTime
                    )

                    if (isSys) sysList.add(info) else userList.add(info)
                } catch (_: Exception) {}
            }

            userList.sortBy { it.appName.lowercase() }
            sysList.sortBy { it.appName.lowercase() }

            val extractedFiles = loadExtractedApkFiles()

            _uiState.update {
                it.copy(
                    isLoadingApps = false,
                    userApps = userList,
                    systemApps = sysList,
                    extractedApks = extractedFiles
                )
            }
        }
    }

    private fun loadExtractedApkFiles(): List<ExtractedApkItem> {
        val extractedDir = File(context.getExternalFilesDir(null), "extracted_apks").apply { mkdirs() }
        val downloadedDir = File(context.getExternalFilesDir(null), "downloaded_apks").apply { mkdirs() }
        val list = mutableListOf<ExtractedApkItem>()
        val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())

        listOf(extractedDir, downloadedDir).forEach { dir ->
            dir.listFiles()?.filter { it.extension.equals("apk", ignoreCase = true) }?.forEach { file ->
                list.add(
                    ExtractedApkItem(
                        fileName = file.name,
                        filePath = file.absolutePath,
                        fileSizeFormatted = formatFileSize(file.length()),
                        lastModifiedFormatted = dateFormat.format(Date(file.lastModified())),
                        fileSizeBytes = file.length()
                    )
                )
            }
        }
        return list.sortedByDescending { it.fileSizeBytes }
    }

    fun extractSingleApp(app: InstalledAppInfo) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isExtracting = true,
                    extractionProgress = 0.2f,
                    extractionStatusMessage = "جاري استخراج حزمة ${app.appName}..."
                )
            }

            try {
                val sourceFile = File(app.sourceApkPath)
                if (!sourceFile.exists()) {
                    _uiState.update { it.copy(isExtracting = false, snackbarMessage = "ملف المصدر غير متاح") }
                    return@launch
                }

                val outDir = File(context.getExternalFilesDir(null), "extracted_apks").apply { mkdirs() }
                val cleanName = app.appName.replace("[^a-zA-Z0-9ء-ي_]".toRegex(), "_")
                val outFile = File(outDir, "${cleanName}_v${app.versionName}.apk")

                sourceFile.copyTo(outFile, overwrite = true)

                _uiState.update {
                    it.copy(
                        isExtracting = false,
                        extractionProgress = 1.0f,
                        extractedApks = loadExtractedApkFiles(),
                        snackbarMessage = "تم استخراج APK ${app.appName} بنجاح! 💾"
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isExtracting = false, snackbarMessage = "خطأ في الاستخراج: ${e.message}") }
            }
        }
    }

    fun onSearchQueryChanged(q: String) {
        _uiState.update { it.copy(searchQuery = q) }
    }

    fun setExtractorCategory(category: AppCategory) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun dismissSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        var name: String? = null
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val col = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (col >= 0) name = it.getString(col)
            }
        }
        return name ?: uri.lastPathSegment
    }

    private fun formatFileSize(bytes: Long): String {
        if (bytes <= 0) return "0 MB"
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb < 1.0) {
            val kb = bytes / 1024.0
            String.format(Locale.US, "%.1f KB", kb)
        } else {
            String.format(Locale.US, "%.2f MB", mb)
        }
    }

    private fun getCurrentTime(): String {
        return SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    }
}
