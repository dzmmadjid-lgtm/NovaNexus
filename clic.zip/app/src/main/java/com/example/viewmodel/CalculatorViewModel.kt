package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.HistoryDataStore
import com.example.model.HistoryEntry
import com.example.util.ArabicNumberToWords
import com.example.util.CalculatorEvaluator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode

enum class CalculatorMode {
    STANDARD,
    CHANGE
}

enum class CashierField {
    ITEM_PRICE,
    AMOUNT_PAID
}

data class CashDenomination(
    val value: Int,
    val label: String,
    val count: Int
)

data class CalculatorUiState(
    val mode: CalculatorMode = CalculatorMode.STANDARD,
    val isDarkTheme: Boolean = true,
    val showHistoryDialog: Boolean = false,
    val showChangeDialog: Boolean = false,
    val showCopyToast: Boolean = false,

    // Standard Calculator
    val expression: String = "",
    val previewResult: String = "",
    val finalResult: String = "",
    val standardTafqeet: String = "",
    val isEvaluated: Boolean = false,
    val errorMessage: String? = null,

    // Change / Cashier Calculator
    val itemPriceInput: String = "",
    val amountPaidInput: String = "",
    val activeCashierField: CashierField = CashierField.ITEM_PRICE,
    val remainingChange: Double = 0.0,
    val changeTafqeet: String = "",
    val isCashShortage: Boolean = false,
    val shortageAmount: Double = 0.0,
    val denominations: List<CashDenomination> = emptyList()
)

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = HistoryDataStore(application.applicationContext)

    private val _uiState = MutableStateFlow(CalculatorUiState())
    val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

    val historyList: StateFlow<List<HistoryEntry>> = repository.historyFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.isDarkTheme.collect { isDark ->
                _uiState.update { it.copy(isDarkTheme = isDark) }
            }
        }
    }

    fun toggleTheme() {
        val nextTheme = !_uiState.value.isDarkTheme
        viewModelScope.launch {
            repository.saveTheme(nextTheme)
            _uiState.update { it.copy(isDarkTheme = nextTheme) }
        }
    }

    fun setMode(mode: CalculatorMode) {
        _uiState.update { it.copy(mode = mode) }
    }

    fun setShowHistory(show: Boolean) {
        _uiState.update { it.copy(showHistoryDialog = show) }
    }

    fun setShowChangeDialog(show: Boolean) {
        _uiState.update { it.copy(showChangeDialog = show) }
    }

    fun deleteHistoryEntry(id: Long) {
        viewModelScope.launch {
            repository.deleteHistoryEntry(id)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    // ==========================================
    // STANDARD CALCULATOR LOGIC
    // ==========================================

    fun onStandardInput(input: String) {
        _uiState.update { state ->
            if (state.isEvaluated && input !in listOf("+", "−", "×", "÷", "%")) {
                // If just evaluated and user types a digit or paren, start fresh
                val newExpr = when (input) {
                    "." -> "0."
                    "00" -> "0"
                    else -> input
                }
                state.copy(
                    expression = newExpr,
                    isEvaluated = false,
                    errorMessage = null,
                    finalResult = "",
                    previewResult = calculatePreview(newExpr),
                    standardTafqeet = ""
                )
            } else if (state.isEvaluated && input in listOf("+", "−", "×", "÷", "%")) {
                // User wants to chain operations on previous result
                val base = state.finalResult.ifEmpty { "0" }
                val newExpr = "$base $input "
                state.copy(
                    expression = newExpr,
                    isEvaluated = false,
                    errorMessage = null,
                    finalResult = "",
                    previewResult = calculatePreview(newExpr),
                    standardTafqeet = ""
                )
            } else {
                val current = state.expression
                val newExpr = when (input) {
                    "+", "−", "×", "÷" -> {
                        if (current.isEmpty()) {
                            if (input == "−") "-" else ""
                        } else if (current.trimEnd().endsWith("+") ||
                            current.trimEnd().endsWith("−") ||
                            current.trimEnd().endsWith("×") ||
                            current.trimEnd().endsWith("÷")
                        ) {
                            current.trimEnd().dropLast(1) + "$input "
                        } else {
                            "$current $input "
                        }
                    }
                    "." -> {
                        val lastToken = current.split(" ", "+", "−", "×", "÷", "(", ")").lastOrNull() ?: ""
                        if (lastToken.contains(".")) current else if (lastToken.isEmpty()) "${current}0." else "$current."
                    }
                    "00" -> {
                        val lastToken = current.split(" ", "+", "−", "×", "÷", "(", ")").lastOrNull() ?: ""
                        if (current.isEmpty() || current.endsWith(" ")) {
                            "${current}0"
                        } else if (lastToken == "0") {
                            current
                        } else {
                            current + "00"
                        }
                    }
                    "0" -> {
                        val lastToken = current.split(" ", "+", "−", "×", "÷", "(", ")").lastOrNull() ?: ""
                        if (lastToken == "0") current else current + "0"
                    }
                    else -> {
                        val lastToken = current.split(" ", "+", "−", "×", "÷", "(", ")").lastOrNull() ?: ""
                        if (lastToken == "0") {
                            current.dropLast(1) + input
                        } else {
                            current + input
                        }
                    }
                }

                state.copy(
                    expression = newExpr,
                    errorMessage = null,
                    previewResult = calculatePreview(newExpr)
                )
            }
        }
    }

    fun onStandardPercentage() {
        val current = _uiState.value.expression
        if (current.isNotEmpty() && !current.endsWith("%") && !current.endsWith(" ")) {
            val newExpr = "$current%"
            _uiState.update {
                it.copy(
                    expression = newExpr,
                    previewResult = calculatePreview(newExpr)
                )
            }
        }
    }

    fun onStandardToggleSign() {
        val current = _uiState.value.expression
        if (current.isEmpty()) return
        val tokens = current.split(" ").toMutableList()
        val last = tokens.lastOrNull() ?: return
        if (last.isEmpty()) return

        val toggled = if (last.startsWith("-")) {
            last.drop(1)
        } else {
            "-$last"
        }
        tokens[tokens.size - 1] = toggled
        val newExpr = tokens.joinToString(" ")
        _uiState.update {
            it.copy(
                expression = newExpr,
                previewResult = calculatePreview(newExpr)
            )
        }
    }

    fun onStandardDelete() {
        _uiState.update { state ->
            if (state.expression.isEmpty()) return@update state
            val trimmed = state.expression.trimEnd()
            val newExpr = if (trimmed.length > 1) {
                if (state.expression.endsWith(" ")) {
                    trimmed.dropLast(1).trimEnd()
                } else {
                    state.expression.dropLast(1)
                }
            } else ""

            state.copy(
                expression = newExpr,
                errorMessage = null,
                isEvaluated = false,
                previewResult = if (newExpr.isEmpty()) "" else calculatePreview(newExpr)
            )
        }
    }

    fun onStandardClear() {
        _uiState.update {
            it.copy(
                expression = "",
                previewResult = "",
                finalResult = "",
                standardTafqeet = "",
                errorMessage = null,
                isEvaluated = false
            )
        }
    }

    fun onStandardEquals() {
        val expr = _uiState.value.expression
        if (expr.isBlank()) return

        when (val result = CalculatorEvaluator.evaluate(expr)) {
            is CalculatorEvaluator.EvaluationResult.Success -> {
                val tafqeetText = if (result.value >= 0 && result.value <= 999_999_999_999.0) {
                    try {
                        ArabicNumberToWords.convertToDinarWords(result.value)
                    } catch (e: Exception) {
                        ""
                    }
                } else ""

                _uiState.update {
                    it.copy(
                        finalResult = result.formattedText,
                        previewResult = "",
                        standardTafqeet = tafqeetText,
                        isEvaluated = true,
                        errorMessage = null
                    )
                }

                // Save to history
                val entry = HistoryEntry(
                    type = "STANDARD",
                    expression = expr,
                    result = result.formattedText,
                    tafqeet = tafqeetText
                )
                viewModelScope.launch {
                    repository.addHistoryEntry(entry)
                }
            }
            is CalculatorEvaluator.EvaluationResult.Error -> {
                _uiState.update {
                    it.copy(
                        errorMessage = result.message,
                        previewResult = "",
                        isEvaluated = false
                    )
                }
            }
        }
    }

    private fun calculatePreview(expr: String): String {
        if (expr.isBlank()) return ""
        return when (val res = CalculatorEvaluator.evaluate(expr)) {
            is CalculatorEvaluator.EvaluationResult.Success -> res.formattedText
            is CalculatorEvaluator.EvaluationResult.Error -> ""
        }
    }

    // ==========================================
    // CHANGE / CASHIER CALCULATOR LOGIC
    // ==========================================

    fun setActiveCashierField(field: CashierField) {
        _uiState.update { it.copy(activeCashierField = field) }
    }

    fun onCashierDigit(digit: String) {
        _uiState.update { state ->
            val isItem = state.activeCashierField == CashierField.ITEM_PRICE
            val currentVal = if (isItem) state.itemPriceInput else state.amountPaidInput

            val newVal = when (digit) {
                "." -> {
                    if (currentVal.contains(".")) currentVal
                    else if (currentVal.isEmpty()) "0."
                    else "$currentVal."
                }
                "00" -> {
                    if (currentVal.isEmpty() || currentVal == "0") "0"
                    else currentVal + "00"
                }
                else -> {
                    if (currentVal == "0") digit else currentVal + digit
                }
            }

            val updatedState = if (isItem) {
                state.copy(itemPriceInput = newVal)
            } else {
                state.copy(amountPaidInput = newVal)
            }

            computeCashierChange(updatedState)
        }
    }

    fun onCashierDelete() {
        _uiState.update { state ->
            val isItem = state.activeCashierField == CashierField.ITEM_PRICE
            val currentVal = if (isItem) state.itemPriceInput else state.amountPaidInput
            val newVal = if (currentVal.isNotEmpty()) currentVal.dropLast(1) else ""

            val updatedState = if (isItem) {
                state.copy(itemPriceInput = newVal)
            } else {
                state.copy(amountPaidInput = newVal)
            }

            computeCashierChange(updatedState)
        }
    }

    fun onCashierClear() {
        _uiState.update { state ->
            val updatedState = state.copy(
                itemPriceInput = "",
                amountPaidInput = "",
                remainingChange = 0.0,
                changeTafqeet = "",
                isCashShortage = false,
                shortageAmount = 0.0,
                denominations = emptyList()
            )
            updatedState
        }
    }

    fun onQuickCashAdd(amount: Double) {
        _uiState.update { state ->
            val currentPaid = state.amountPaidInput.toDoubleOrNull() ?: 0.0
            val newPaid = currentPaid + amount
            val formatted = if (newPaid % 1.0 == 0.0) newPaid.toLong().toString() else newPaid.toString()

            val updatedState = state.copy(
                amountPaidInput = formatted,
                activeCashierField = CashierField.AMOUNT_PAID
            )
            computeCashierChange(updatedState)
        }
    }

    fun onSetExactAmountPaid(amount: Double) {
        _uiState.update { state ->
            val formatted = if (amount % 1.0 == 0.0) amount.toLong().toString() else amount.toString()
            val updatedState = state.copy(
                amountPaidInput = formatted,
                activeCashierField = CashierField.AMOUNT_PAID
            )
            computeCashierChange(updatedState)
        }
    }

    fun saveCashierTransaction() {
        val state = _uiState.value
        val price = state.itemPriceInput.toDoubleOrNull() ?: return
        val paid = state.amountPaidInput.toDoubleOrNull() ?: return
        if (price <= 0 || paid <= 0) return

        val change = paid - price
        val expr = "ثمن السلعة: ${formatCurrency(price)} | المدفوع: ${formatCurrency(paid)}"
        val resultStr = if (change >= 0) "الباقي: ${formatCurrency(change)}" else "ينقص: ${formatCurrency(-change)}"
        val tafqeet = if (change >= 0) state.changeTafqeet else "المبلغ غير كافٍ"

        val entry = HistoryEntry(
            type = "CHANGE",
            expression = expr,
            result = resultStr,
            tafqeet = tafqeet
        )

        viewModelScope.launch {
            repository.addHistoryEntry(entry)
        }
    }

    private fun computeCashierChange(state: CalculatorUiState): CalculatorUiState {
        val price = state.itemPriceInput.toDoubleOrNull() ?: 0.0
        val paid = state.amountPaidInput.toDoubleOrNull() ?: 0.0

        if (price <= 0.0 && paid <= 0.0) {
            return state.copy(
                remainingChange = 0.0,
                changeTafqeet = "",
                isCashShortage = false,
                shortageAmount = 0.0,
                denominations = emptyList()
            )
        }

        val diff = paid - price

        return if (diff >= 0.0) {
            val tafqeet = if (paid > 0 && price > 0) {
                ArabicNumberToWords.convertToDinarWords(diff)
            } else ""

            val denoms = if (paid > 0 && price > 0 && diff > 0) {
                calculateAlgerianDenominations(diff)
            } else emptyList()

            state.copy(
                remainingChange = diff,
                changeTafqeet = tafqeet,
                isCashShortage = false,
                shortageAmount = 0.0,
                denominations = denoms
            )
        } else {
            val shortage = -diff
            state.copy(
                remainingChange = 0.0,
                changeTafqeet = "المبلغ المدفوع غير كافٍ، ينقص " + formatCurrency(shortage),
                isCashShortage = true,
                shortageAmount = shortage,
                denominations = emptyList()
            )
        }
    }

    private fun calculateAlgerianDenominations(amount: Double): List<CashDenomination> {
        val list = mutableListOf<CashDenomination>()
        var remaining = amount.toInt()
        val bills = listOf(2000, 1000, 500, 200, 100, 50, 20, 10, 5)

        for (bill in bills) {
            if (remaining >= bill) {
                val count = remaining / bill
                remaining %= bill
                list.add(CashDenomination(bill, "$bill دج", count))
            }
        }
        return list
    }

    fun formatCurrency(amount: Double): String {
        return if (amount % 1.0 == 0.0) {
            "${amount.toLong()} دج"
        } else {
            BigDecimal(amount.toString()).setScale(2, RoundingMode.HALF_UP).toString() + " دج"
        }
    }
}
