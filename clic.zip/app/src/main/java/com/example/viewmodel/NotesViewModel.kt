package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.NoteCategory
import com.example.model.NoteItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

data class NotesUiState(
    val notes: List<NoteItem> = emptyList(),
    val searchQuery: String = "",
    val selectedCategory: NoteCategory = NoteCategory.ALL,
    val isDarkTheme: Boolean = true,
    val selectedNote: NoteItem? = null,
    val isEditing: Boolean = false,
    val message: String? = null
)

class NotesViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(NotesUiState())
    val uiState: StateFlow<NotesUiState> = _uiState.asStateFlow()

    private val prefs = application.getSharedPreferences("swift_notes_prefs", Context.MODE_PRIVATE)

    init {
        loadNotes()
    }

    private fun loadNotes() {
        viewModelScope.launch {
            val jsonString = prefs.getString("saved_notes_json", null)
            if (jsonString != null) {
                try {
                    val array = JSONArray(jsonString)
                    val list = mutableListOf<NoteItem>()
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        list.add(
                            NoteItem(
                                id = obj.optString("id"),
                                title = obj.optString("title"),
                                content = obj.optString("content"),
                                category = obj.optString("category", "عام"),
                                colorHex = obj.optLong("colorHex", 0xFF1E293B),
                                isPinned = obj.optBoolean("isPinned", false),
                                timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                            )
                        )
                    }
                    _uiState.update { it.copy(notes = list.sortedWith(compareByDescending<NoteItem> { it.isPinned }.thenByDescending { it.timestamp })) }
                } catch (_: Exception) {
                    insertDefaultNotes()
                }
            } else {
                insertDefaultNotes()
            }
        }
    }

    private fun insertDefaultNotes() {
        val defaults = listOf(
            NoteItem(
                title = "مرحباً بك في تطبيق الملاحظات الجديد! 🚀",
                content = "هذا تطبيق ملاحظات سريع ومستقل تماماً.\nيمكنك إضافة ملاحظات جديدة، وتثبيت الملاحظات المهمة بالأعلى، وتلوينها والتنظيم حسب التصنيفات.",
                category = "عام",
                colorHex = 0xFF1E3A8A,
                isPinned = true
            ),
            NoteItem(
                title = "أفكار لتطوير المشاريع 💡",
                content = "• بناء التطبيقات عبر خوادم السحاب.\n• تجربة تصدير حزم الـ APK مباشرة.\n• تنظيم الكود والواجهات باستخدام Jetpack Compose الحديثة.",
                category = "أفكار",
                colorHex = 0xFF78350F,
                isPinned = false
            ),
            NoteItem(
                title = "قائمة المهام اليومية ✅",
                content = "1. مراجعة إعدادات المستودع.\n2. تجربة تثبيت التطبيق الجديد على الهاتف.\n3. تدوين الملاحظات السريعة.",
                category = "عمل",
                colorHex = 0xFF064E3B,
                isPinned = false
            )
        )
        saveNotesToStorage(defaults)
        _uiState.update { it.copy(notes = defaults) }
    }

    private fun saveNotesToStorage(notesList: List<NoteItem>) {
        val array = JSONArray()
        for (note in notesList) {
            val obj = JSONObject().apply {
                put("id", note.id)
                put("title", note.title)
                put("content", note.content)
                put("category", note.category)
                put("colorHex", note.colorHex)
                put("isPinned", note.isPinned)
                put("timestamp", note.timestamp)
            }
            array.put(obj)
        }
        prefs.edit().putString("saved_notes_json", array.toString()).apply()
    }

    fun saveNote(id: String?, title: String, content: String, category: String, colorHex: Long, isPinned: Boolean) {
        val currentList = _uiState.value.notes.toMutableList()
        val trimmedTitle = title.trim()
        val trimmedContent = content.trim()

        if (trimmedTitle.isEmpty() && trimmedContent.isEmpty()) {
            _uiState.update { it.copy(isEditing = false, selectedNote = null) }
            return
        }

        if (id != null) {
            val index = currentList.indexOfFirst { it.id == id }
            if (index >= 0) {
                currentList[index] = currentList[index].copy(
                    title = trimmedTitle,
                    content = trimmedContent,
                    category = category,
                    colorHex = colorHex,
                    isPinned = isPinned,
                    timestamp = System.currentTimeMillis()
                )
            }
        } else {
            val newNote = NoteItem(
                title = trimmedTitle,
                content = trimmedContent,
                category = category,
                colorHex = colorHex,
                isPinned = isPinned,
                timestamp = System.currentTimeMillis()
            )
            currentList.add(0, newNote)
        }

        val sorted = currentList.sortedWith(compareByDescending<NoteItem> { it.isPinned }.thenByDescending { it.timestamp })
        saveNotesToStorage(sorted)
        _uiState.update {
            it.copy(
                notes = sorted,
                isEditing = false,
                selectedNote = null,
                message = "تم حفظ الملاحظة بنجاح ✨"
            )
        }
    }

    fun deleteNote(note: NoteItem) {
        val updated = _uiState.value.notes.filter { it.id != note.id }
        saveNotesToStorage(updated)
        _uiState.update {
            it.copy(
                notes = updated,
                isEditing = false,
                selectedNote = null,
                message = "تم حذف الملاحظة 🗑️"
            )
        }
    }

    fun togglePin(note: NoteItem) {
        val updated = _uiState.value.notes.map {
            if (it.id == note.id) it.copy(isPinned = !it.isPinned) else it
        }.sortedWith(compareByDescending<NoteItem> { it.isPinned }.thenByDescending { it.timestamp })
        
        saveNotesToStorage(updated)
        _uiState.update { it.copy(notes = updated) }
    }

    fun openNoteForEdit(note: NoteItem?) {
        _uiState.update { it.copy(selectedNote = note, isEditing = true) }
    }

    fun closeEditDialog() {
        _uiState.update { it.copy(isEditing = false, selectedNote = null) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setCategory(category: NoteCategory) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun toggleTheme() {
        _uiState.update { it.copy(isDarkTheme = !it.isDarkTheme) }
    }

    fun dismissMessage() {
        _uiState.update { it.copy(message = null) }
    }
}
