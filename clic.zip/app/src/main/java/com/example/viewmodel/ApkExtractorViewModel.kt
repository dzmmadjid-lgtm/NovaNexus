package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.AppItem
import com.example.model.AppTabFilter
import com.example.model.ExtractionResult
import com.example.model.SortOption
import com.example.util.ApkExtractorHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

data class ApkExtractorUiState(
    val allApps: List<AppItem> = emptyList(),
    val extractedApps: List<ExtractionResult> = emptyList(),
    val selectedTab: AppTabFilter = AppTabFilter.USER,
    val searchQuery: String = "",
    val sortOption: SortOption = SortOption.NAME_ASC,
    val isLoading: Boolean = true,
    val isExtracting: Boolean = false,
    val extractingProgressText: String? = null,
    val lastExtractedResult: ExtractionResult? = null,
    val snackbarMessage: String? = null,
    val isDarkTheme: Boolean = true,
    val selectedPackagesForBatch: Set<String> = emptySet(),
    val isMultiSelectMode: Boolean = false,
    val userAppsCount: Int = 0,
    val systemAppsCount: Int = 0,
    val totalExtractedCount: Int = 0
)

class ApkExtractorViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(ApkExtractorUiState())
    val uiState: StateFlow<ApkExtractorUiState> = _uiState.asStateFlow()

    private val context: Context get() = getApplication<Application>().applicationContext

    init {
        loadApps()
    }

    fun loadApps() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true) }
            val apps = ApkExtractorHelper.getInstalledApps(context)
            val extracted = ApkExtractorHelper.getExtractedApkFiles(context)

            val userCount = apps.count { !it.isSystemApp }
            val sysCount = apps.count { it.isSystemApp }

            _uiState.update {
                it.copy(
                    allApps = apps,
                    extractedApps = extracted,
                    userAppsCount = userCount,
                    systemAppsCount = sysCount,
                    totalExtractedCount = extracted.size,
                    isLoading = false
                )
            }
        }
    }

    fun selectTab(tab: AppTabFilter) {
        _uiState.update { it.copy(selectedTab = tab, selectedPackagesForBatch = emptySet()) }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setSortOption(sort: SortOption) {
        _uiState.update { it.copy(sortOption = sort) }
    }

    fun toggleTheme() {
        _uiState.update { it.copy(isDarkTheme = !it.isDarkTheme) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null, lastExtractedResult = null) }
    }

    fun toggleSelectApp(packageName: String) {
        _uiState.update { current ->
            val updatedSet = current.selectedPackagesForBatch.toMutableSet()
            if (updatedSet.contains(packageName)) {
                updatedSet.remove(packageName)
            } else {
                updatedSet.add(packageName)
            }
            current.copy(
                selectedPackagesForBatch = updatedSet,
                isMultiSelectMode = updatedSet.isNotEmpty()
            )
        }
    }

    fun clearMultiSelect() {
        _uiState.update { it.copy(selectedPackagesForBatch = emptySet(), isMultiSelectMode = false) }
    }

    fun selectAllInCurrentTab(currentList: List<AppItem>) {
        val allPkgs = currentList.map { it.packageName }.toSet()
        _uiState.update { it.copy(selectedPackagesForBatch = allPkgs, isMultiSelectMode = true) }
    }

    fun extractSingleApp(app: AppItem) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isExtracting = true,
                    extractingProgressText = "جاري استخراج حزمة APK لتطبيق ${app.appName}..."
                )
            }

            val result = ApkExtractorHelper.extractApk(context, app)
            val updatedExtracted = ApkExtractorHelper.getExtractedApkFiles(context)

            _uiState.update {
                it.copy(
                    isExtracting = false,
                    extractingProgressText = null,
                    extractedApps = updatedExtracted,
                    totalExtractedCount = updatedExtracted.size,
                    lastExtractedResult = result,
                    snackbarMessage = if (result != null) "تم استخراج ملف APK بنجاح: ${result.fileName}" else "تعذر استخراج ملف APK"
                )
            }
        }
    }

    fun extractBatchSelectedApps() {
        val selectedPkgs = _uiState.value.selectedPackagesForBatch
        if (selectedPkgs.isEmpty()) return

        val appsToExtract = _uiState.value.allApps.filter { selectedPkgs.contains(it.packageName) }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isExtracting = true,
                    extractingProgressText = "جاري استخراج ${appsToExtract.size} تطبيقات..."
                )
            }

            var successCount = 0
            for ((index, app) in appsToExtract.withIndex()) {
                _uiState.update {
                    it.copy(extractingProgressText = "استخراج (${index + 1}/${appsToExtract.size}): ${app.appName}...")
                }
                val res = ApkExtractorHelper.extractApk(context, app)
                if (res != null) successCount++
            }

            val updatedExtracted = ApkExtractorHelper.getExtractedApkFiles(context)
            _uiState.update {
                it.copy(
                    isExtracting = false,
                    extractingProgressText = null,
                    extractedApps = updatedExtracted,
                    totalExtractedCount = updatedExtracted.size,
                    selectedPackagesForBatch = emptySet(),
                    isMultiSelectMode = false,
                    snackbarMessage = "تم استخراج $successCount من ${appsToExtract.size} تطبيقات بنجاح 🎉"
                )
            }
        }
    }

    fun shareApk(filePath: String) {
        ApkExtractorHelper.shareApk(context, filePath)
    }

    fun openApp(packageName: String) {
        val success = ApkExtractorHelper.openApp(context, packageName)
        if (!success) {
            _uiState.update { it.copy(snackbarMessage = "هذا التطبيق ليس له واجهة تشغيل مباشرة") }
        }
    }

    fun openAppSettings(packageName: String) {
        ApkExtractorHelper.openAppSettings(context, packageName)
    }

    fun deleteExtractedApk(filePath: String) {
        try {
            val file = File(filePath)
            if (file.exists()) {
                file.delete()
            }
            val updated = ApkExtractorHelper.getExtractedApkFiles(context)
            _uiState.update {
                it.copy(
                    extractedApps = updated,
                    totalExtractedCount = updated.size,
                    snackbarMessage = "تم حذف ملف الـ APK"
                )
            }
        } catch (_: Exception) {}
    }
}
