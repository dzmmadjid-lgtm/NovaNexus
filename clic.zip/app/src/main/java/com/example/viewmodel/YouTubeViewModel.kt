package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.PlaybackState
import com.example.model.YouTubeVideo
import com.example.service.PlaybackManager
import com.example.service.YouTubeService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class YouTubeUiState(
    val isSearchBarVisible: Boolean = false,
    val searchQuery: String = "",
    val isSearching: Boolean = false,
    val isLoading: Boolean = false,
    val trendingVideos: List<YouTubeVideo> = emptyList(),
    val searchResults: List<YouTubeVideo> = emptyList(),
    val errorMessage: String? = null
)

class YouTubeViewModel(application: Application) : AndroidViewModel(application) {

    private val youTubeService = YouTubeService()

    private val _uiState = MutableStateFlow(YouTubeUiState())
    val uiState: StateFlow<YouTubeUiState> = _uiState.asStateFlow()

    val playbackState: StateFlow<PlaybackState> = PlaybackManager.playbackState
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PlaybackState())

    private var searchJob: Job? = null

    init {
        loadFeedVideos()
    }

    fun toggleSearchBar() {
        _uiState.update {
            val nextVisible = !it.isSearchBarVisible
            if (!nextVisible) {
                it.copy(isSearchBarVisible = false, searchQuery = "", isSearching = false)
            } else {
                it.copy(isSearchBarVisible = true)
            }
        }
    }

    fun hideSearchBar() {
        _uiState.update {
            it.copy(
                isSearchBarVisible = false,
                searchQuery = "",
                isSearching = false
            )
        }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        searchJob?.cancel()
        if (query.isBlank()) {
            _uiState.update { it.copy(searchResults = emptyList(), isSearching = false) }
            return
        }
        searchJob = viewModelScope.launch {
            delay(400)
            performSearch(query)
        }
    }

    fun performSearch(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return

        _uiState.update { state ->
            state.copy(
                isSearching = true,
                isLoading = true,
                errorMessage = null
            )
        }

        viewModelScope.launch {
            try {
                val results = youTubeService.searchVideos(trimmed)
                _uiState.update {
                    it.copy(
                        searchResults = results,
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = "تعذر تحميل نتائج البحث: ${e.message}"
                    )
                }
            }
        }
    }

    fun clearSearch() {
        _uiState.update {
            it.copy(
                searchQuery = "",
                searchResults = emptyList(),
                isSearching = false
            )
        }
    }

    fun loadFeedVideos() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            try {
                val videos = youTubeService.getAllFeedVideos()
                _uiState.update {
                    it.copy(
                        trendingVideos = videos,
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = "تعذر تحميل الفيديوهات: ${e.message}"
                    )
                }
            }
        }
    }

    fun playVideo(video: YouTubeVideo, queue: List<YouTubeVideo> = emptyList()) {
        val context = getApplication<Application>().applicationContext
        val effectiveQueue = if (queue.isNotEmpty()) queue else _uiState.value.trendingVideos
        PlaybackManager.playVideo(context, video, effectiveQueue, expand = true)
    }

    fun expandPlayer() {
        PlaybackManager.expandPlayer()
    }

    fun collapsePlayer() {
        PlaybackManager.collapsePlayer()
    }

    fun togglePlayPause() {
        val context = getApplication<Application>().applicationContext
        PlaybackManager.togglePlayPause(context)
    }

    fun playNext() {
        val context = getApplication<Application>().applicationContext
        PlaybackManager.playNext(context)
    }

    fun playPrevious() {
        val context = getApplication<Application>().applicationContext
        PlaybackManager.playPrevious(context)
    }

    fun closePlayer() {
        val context = getApplication<Application>().applicationContext
        PlaybackManager.closePlayer(context)
    }

    fun playFromDirectInput(input: String) {
        val extractedId = youTubeService.extractVideoId(input)
        if (extractedId != null) {
            val directVideo = YouTubeVideo(
                id = extractedId,
                title = "فيديو يوتيوب ($extractedId)",
                channelTitle = "تشغيل مباشر",
                durationText = "فيديو",
                viewCountText = "-",
                publishedTimeText = "الآن",
                description = "تشغيل مباشر لرابط يوتيوب.",
            )
            playVideo(directVideo)
        } else {
            performSearch(input)
        }
    }
}
