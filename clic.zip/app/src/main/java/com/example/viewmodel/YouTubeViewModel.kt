package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.PlaybackState
import com.example.model.VideoCategory
import com.example.model.YouTubeVideo
import com.example.service.PlaybackManager
import com.example.service.YouTubeService
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class YouTubeUiState(
    val selectedCategory: VideoCategory = VideoCategory.ALL,
    val searchQuery: String = "",
    val isSearching: Boolean = false,
    val isLoading: Boolean = false,
    val trendingVideos: List<YouTubeVideo> = emptyList(),
    val searchResults: List<YouTubeVideo> = emptyList(),
    val searchHistory: List<String> = listOf("قرآن كريم", "lofi beats", "بودكاست فنجان", "أصوات المطر", "تقنية"),
    val favoriteVideos: List<YouTubeVideo> = emptyList(),
    val historyVideos: List<YouTubeVideo> = emptyList(),
    val selectedTab: MainTab = MainTab.HOME,
    val errorMessage: String? = null,
    val showUrlDialog: Boolean = false
)

enum class MainTab(val titleAr: String, val titleEn: String) {
    HOME("الرئيسية", "Home"),
    SEARCH("البحث", "Search"),
    FAVORITES("المفضلة", "Favorites"),
    HISTORY("السجل", "History")
}

class YouTubeViewModel(application: Application) : AndroidViewModel(application) {

    private val youTubeService = YouTubeService()

    private val _uiState = MutableStateFlow(YouTubeUiState())
    val uiState: StateFlow<YouTubeUiState> = _uiState.asStateFlow()

    val playbackState: StateFlow<PlaybackState> = PlaybackManager.playbackState
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PlaybackState())

    private var searchJob: Job? = null

    init {
        loadTrendingVideos(VideoCategory.ALL)
    }

    fun selectCategory(category: VideoCategory) {
        _uiState.update { it.copy(selectedCategory = category) }
        loadTrendingVideos(category)
    }

    fun selectTab(tab: MainTab) {
        _uiState.update { it.copy(selectedTab = tab) }
        if (tab == MainTab.HOME && _uiState.value.trendingVideos.isEmpty()) {
            loadTrendingVideos(_uiState.value.selectedCategory)
        }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        searchJob?.cancel()
        if (query.isBlank()) {
            _uiState.update { it.copy(searchResults = emptyList(), isSearching = false) }
            return
        }
        searchJob = viewModelScope.launch {
            delay(400) // Debounce
            performSearch(query)
        }
    }

    fun performSearch(query: String) {
        val trimmed = query.trim()
        if (trimmed.isEmpty()) return

        // Add to search history if not present
        _uiState.update { state ->
            val updatedHistory = (listOf(trimmed) + state.searchHistory.filter { it != trimmed }).take(10)
            state.copy(
                isSearching = true,
                isLoading = true,
                searchHistory = updatedHistory,
                errorMessage = null
            )
        }

        viewModelScope.launch {
            try {
                val results = youTubeService.searchVideos(trimmed)
                _uiState.update {
                    it.copy(
                        searchResults = results,
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = "تعذر تحميل نتائج البحث: ${e.message}"
                    )
                }
            }
        }
    }

    fun clearSearch() {
        _uiState.update {
            it.copy(
                searchQuery = "",
                searchResults = emptyList(),
                isSearching = false
            )
        }
    }

    fun loadTrendingVideos(category: VideoCategory) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            try {
                val videos = youTubeService.getTrendingVideos(category)
                _uiState.update {
                    it.copy(
                        trendingVideos = videos,
                        isLoading = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = "تعذر تحميل الفيديوهات: ${e.message}"
                    )
                }
            }
        }
    }

    fun playVideo(video: YouTubeVideo, queue: List<YouTubeVideo> = emptyList()) {
        val context = getApplication<Application>().applicationContext
        val effectiveQueue = if (queue.isNotEmpty()) queue else _uiState.value.trendingVideos
        PlaybackManager.playVideo(context, video, effectiveQueue)

        // Add to history
        _uiState.update { state ->
            val updatedHistory = (listOf(video) + state.historyVideos.filter { it.id != video.id }).take(30)
            state.copy(historyVideos = updatedHistory)
        }
    }

    fun togglePlayPause() {
        val context = getApplication<Application>().applicationContext
        PlaybackManager.togglePlayPause(context)
    }

    fun playNext() {
        val context = getApplication<Application>().applicationContext
        PlaybackManager.playNext(context)
    }

    fun playPrevious() {
        val context = getApplication<Application>().applicationContext
        PlaybackManager.playPrevious(context)
    }

    fun toggleBackgroundPlayback() {
        val context = getApplication<Application>().applicationContext
        val current = playbackState.value.isBackgroundPlaybackActive
        PlaybackManager.setBackgroundPlayback(context, !current)
    }

    fun setExpanded(expanded: Boolean) {
        PlaybackManager.setExpanded(expanded)
    }

    fun closePlayer() {
        val context = getApplication<Application>().applicationContext
        PlaybackManager.closePlayer(context)
    }

    fun seekTo(seconds: Float) {
        PlaybackManager.seekTo(seconds)
    }

    fun setPlaybackSpeed(speed: Float) {
        PlaybackManager.setPlaybackSpeed(speed)
    }

    fun toggleLoop() {
        PlaybackManager.toggleLoop()
    }

    fun toggleFavorite(video: YouTubeVideo) {
        _uiState.update { state ->
            val exists = state.favoriteVideos.any { it.id == video.id }
            val newFavorites = if (exists) {
                state.favoriteVideos.filter { it.id != video.id }
            } else {
                listOf(video) + state.favoriteVideos
            }
            state.copy(favoriteVideos = newFavorites)
        }
    }

    fun isFavorite(videoId: String): Boolean {
        return _uiState.value.favoriteVideos.any { it.id == videoId }
    }

    fun playFromDirectInput(input: String) {
        val extractedId = youTubeService.extractVideoId(input)
        if (extractedId != null) {
            val directVideo = YouTubeVideo(
                id = extractedId,
                title = "فيديو يوتيوب ($extractedId)",
                channelTitle = "تشغيل مباشر",
                durationText = "مباشر",
                viewCountText = "-",
                publishedTimeText = "الآن",
                description = "تم تحميل هذا الفيديو بواسطة رابط مباشر.",
                category = VideoCategory.ALL
            )
            playVideo(directVideo)
            _uiState.update { it.copy(showUrlDialog = false) }
        } else {
            performSearch(input)
            _uiState.update { it.copy(showUrlDialog = false, selectedTab = MainTab.SEARCH) }
        }
    }

    fun setShowUrlDialog(show: Boolean) {
        _uiState.update { it.copy(showUrlDialog = show) }
    }

    fun clearHistory() {
        _uiState.update { it.copy(historyVideos = emptyList()) }
    }
}
