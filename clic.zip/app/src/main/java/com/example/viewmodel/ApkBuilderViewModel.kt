package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.AppItem
import com.example.model.AppTabFilter
import com.example.model.BuildLogEntry
import com.example.model.CombinedAppState
import com.example.model.ExtractionResult
import com.example.model.GitHubConfig
import com.example.model.MainAppSection
import com.example.network.GitHubBuilderService
import com.example.util.ApkExtractorHelper
import com.example.util.ProjectDetectorHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ApkBuilderViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context get() = getApplication<Application>().applicationContext
    private val gitHubService = GitHubBuilderService(context)
    private val prefs = context.getSharedPreferences("apk_builder_prefs", Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(CombinedAppState())
    val uiState: StateFlow<CombinedAppState> = _uiState.asStateFlow()

    private var pollingJob: Job? = null

    init {
        loadSavedConfig()
        loadInstalledApps()
        refreshExtractedList()
    }

    private fun loadSavedConfig() {
        val token = prefs.getString("gh_token", "") ?: ""
        val owner = prefs.getString("gh_owner", "") ?: ""
        val repo = prefs.getString("gh_repo", "") ?: ""
        val branch = prefs.getString("gh_branch", "main") ?: "main"
        val workflow = prefs.getString("gh_workflow", "build-apk.yml") ?: "build-apk.yml"
        val isDark = prefs.getBoolean("is_dark_theme", true)

        val config = GitHubConfig(
            token = token,
            owner = owner,
            repo = repo,
            branch = branch,
            workflowFileName = workflow,
            isConfigured = token.isNotBlank() && owner.isNotBlank() && repo.isNotBlank()
        )

        _uiState.update { it.copy(gitHubConfig = config, isDarkTheme = isDark) }

        if (config.isConfigured) {
            refreshWorkflowRuns()
        }
    }

    fun setSection(section: MainAppSection) {
        _uiState.update { it.copy(currentSection = section) }
        if (section == MainAppSection.BUILDER && _uiState.value.gitHubConfig.isConfigured) {
            refreshWorkflowRuns()
        } else if (section == MainAppSection.EXTRACTOR) {
            if (_uiState.value.installedApps.isEmpty()) {
                loadInstalledApps()
            }
            refreshExtractedList()
        }
    }

    fun saveGitHubConfig(token: String, owner: String, repo: String, branch: String, workflowFileName: String) {
        val cleanToken = token.trim()
        val cleanOwner = owner.trim()
        val cleanRepo = repo.trim()
        val cleanBranch = branch.trim().ifBlank { "main" }
        val cleanWorkflow = workflowFileName.trim().ifBlank { "build-apk.yml" }

        prefs.edit()
            .putString("gh_token", cleanToken)
            .putString("gh_owner", cleanOwner)
            .putString("gh_repo", cleanRepo)
            .putString("gh_branch", cleanBranch)
            .putString("gh_workflow", cleanWorkflow)
            .apply()

        val config = GitHubConfig(
            token = cleanToken,
            owner = cleanOwner,
            repo = cleanRepo,
            branch = cleanBranch,
            workflowFileName = cleanWorkflow,
            isConfigured = cleanToken.isNotBlank() && cleanOwner.isNotBlank() && cleanRepo.isNotBlank()
        )

        _uiState.update {
            it.copy(
                gitHubConfig = config,
                showConfigDialog = false,
                snackbarMessage = "تم حفظ إعدادات GitHub بنجاح ✅"
            )
        }

        if (config.isConfigured) {
            verifyRepository()
            refreshWorkflowRuns()
        }
    }

    fun verifyRepository() {
        val config = _uiState.value.gitHubConfig
        if (!config.isConfigured) {
            _uiState.update { it.copy(showConfigDialog = true) }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isVerifyingRepo = true,
                    repoVerificationMessage = "جاري الاتصال بمستودع GitHub والتحقق من الصلاحيات..."
                )
            }

            val result = gitHubService.verifyRepository(config)
            result.onSuccess { info ->
                _uiState.update {
                    it.copy(
                        isVerifyingRepo = false,
                        isRepoVerified = true,
                        repoVerificationMessage = "تم التحقق بنجاح من المستودع: $info ✅",
                        snackbarMessage = "تم الاتصال بالمستودع بنجاح!"
                    )
                }
                refreshWorkflowRuns()
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isVerifyingRepo = false,
                        isRepoVerified = false,
                        repoVerificationMessage = "فشل التحقق: ${err.message} ⚠️"
                    )
                }
            }
        }
    }

    fun onZipFileSelected(uri: Uri) {
        viewModelScope.launch {
            try {
                val detected = ProjectDetectorHelper.analyzeUri(context, uri)
                _uiState.update {
                    it.copy(
                        detectedProject = detected,
                        zipFileName = detected.name,
                        snackbarMessage = "تم تحليل ملف المشروع: ${detected.name} (${detected.type.displayName}) 📦"
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(snackbarMessage = "تعذر قراءة ملف المشروع: ${e.message}")
                }
            }
        }
    }

    fun triggerCloudBuild() {
        val config = _uiState.value.gitHubConfig
        if (!config.isConfigured) {
            _uiState.update {
                it.copy(
                    showConfigDialog = true,
                    snackbarMessage = "يرجى ضبط إعدادات مستودع GitHub أولاً ⚙️"
                )
            }
            return
        }

        pollingJob?.cancel()
        pollingJob = viewModelScope.launch {
            val startTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            val initialLogs = mutableListOf(
                BuildLogEntry(startTime, "بدء إرسال طلب بناء الـ APK إلى خوادم GitHub Actions سحابياً...", isStepHeader = true),
                BuildLogEntry(startTime, "المستودع: ${config.owner}/${config.repo} على الفرع (${config.branch})")
            )

            _uiState.update {
                it.copy(
                    isBuilding = true,
                    buildProgressPercent = 15,
                    buildStatusText = "جاري تشغيل مسار البناء في GitHub...",
                    buildLogs = initialLogs,
                    activeRunId = null,
                    activeRunStatus = "queued",
                    activeRunConclusion = null,
                    activeArtifacts = emptyList(),
                    downloadWebPageUrl = "https://github.com/${config.owner}/${config.repo}/actions"
                )
            }

            val triggerResult = gitHubService.triggerWorkflow(config)
            if (triggerResult.isFailure) {
                val errTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                val errorMsg = triggerResult.exceptionOrNull()?.message ?: "خطأ غير معروف"
                initialLogs.add(BuildLogEntry(errTime, "فشل تشغيل المسار: $errorMsg", isError = true))
                _uiState.update {
                    it.copy(
                        isBuilding = false,
                        buildProgressPercent = 0,
                        buildStatusText = "فشل بدء البناء السحابي",
                        buildLogs = initialLogs,
                        snackbarMessage = "فشل في تشغيل مسار البناء: $errorMsg"
                    )
                }
                return@launch
            }

            val sentTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            initialLogs.add(BuildLogEntry(sentTime, "تم تشغيل Workflow بنجاح! جاري انتظار بدء المهمة على سيرفرات GitHub..."))
            _uiState.update {
                it.copy(
                    buildProgressPercent = 30,
                    buildStatusText = "قيد المعالجة في طابور GitHub...",
                    buildLogs = initialLogs
                )
            }

            // Poll for run status
            pollActiveWorkflowRun(config, initialLogs)
        }
    }

    private suspend fun pollActiveWorkflowRun(config: GitHubConfig, logs: MutableList<BuildLogEntry>) {
        var attempts = 0
        val maxAttempts = 60 // 60 * 5s = 5 minutes max
        var foundRunId: Long? = null

        while (attempts < maxAttempts) {
            delay(4000)
            attempts++

            val runsResult = gitHubService.getLatestWorkflowRuns(config)
            if (runsResult.isSuccess) {
                val runs = runsResult.getOrNull() ?: emptyList()
                _uiState.update { it.copy(recentWorkflowRuns = runs) }

                val latestRun = runs.firstOrNull()
                if (latestRun != null) {
                    foundRunId = latestRun.id
                    val now = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                    val runUrl = latestRun.htmlUrl.ifBlank { "https://github.com/${config.owner}/${config.repo}/actions/runs/${latestRun.id}" }

                    when {
                        latestRun.status == "in_progress" -> {
                            val pct = (40 + (attempts * 2)).coerceAtMost(85)
                            _uiState.update {
                                it.copy(
                                    buildProgressPercent = pct,
                                    buildStatusText = "جاري بناء ملف APK وتجميع موارد Gradle على السيرفر... ($pct%)",
                                    activeRunId = latestRun.id,
                                    activeRunUrl = runUrl,
                                    activeRunStatus = "in_progress",
                                    downloadWebPageUrl = runUrl
                                )
                            }
                        }

                        latestRun.status == "completed" -> {
                            if (latestRun.conclusion == "success") {
                                logs.add(BuildLogEntry(now, "اكتمل بناء الـ APK على سيرفر GitHub بنجاح 100%! 🎉", isSuccess = true))
                                logs.add(BuildLogEntry(now, "تم رفع حزمة الـ APK (Artifacts) وهي جاهزة للتحميل المباشر من الموقع."))

                                // Fetch artifacts for info
                                val artifactsRes = gitHubService.getRunArtifacts(config, latestRun.id)
                                val artifacts = artifactsRes.getOrDefault(emptyList())

                                _uiState.update {
                                    it.copy(
                                        isBuilding = false,
                                        buildProgressPercent = 100,
                                        buildStatusText = "اكتمل البناء بنجاح 100%! جاهز للتحميل من الموقع 🚀",
                                        buildLogs = logs,
                                        activeRunId = latestRun.id,
                                        activeRunUrl = runUrl,
                                        activeRunStatus = "completed",
                                        activeRunConclusion = "success",
                                        activeArtifacts = artifacts,
                                        downloadWebPageUrl = runUrl,
                                        snackbarMessage = "نجح بناء الـ APK! اضغط على زر التحميل لفتحه في المتصفح 🚀"
                                    )
                                }
                            } else {
                                val conclusionText = latestRun.conclusion ?: "فشل"
                                logs.add(BuildLogEntry(now, "انتهى البناء بنتيجة: $conclusionText ❌", isError = true))
                                logs.add(BuildLogEntry(now, "يمكنك فتح صفحة الـ Logs على GitHub لمعرفة سبب فشل الـ Gradle."))
                                _uiState.update {
                                    it.copy(
                                        isBuilding = false,
                                        buildProgressPercent = 0,
                                        buildStatusText = "فشل البناء على GitHub ($conclusionText)",
                                        buildLogs = logs,
                                        activeRunId = latestRun.id,
                                        activeRunUrl = runUrl,
                                        activeRunStatus = "completed",
                                        activeRunConclusion = conclusionText,
                                        downloadWebPageUrl = runUrl,
                                        snackbarMessage = "فشل البناء: يرجى مراجعة سجلات الخطأ في GitHub"
                                    )
                                }
                            }
                            return
                        }

                        else -> {
                            // queued / waiting
                            _uiState.update {
                                it.copy(
                                    buildProgressPercent = 35,
                                    buildStatusText = "في قائمة انتظار تشغيل GitHub Actions...",
                                    activeRunId = latestRun.id,
                                    activeRunUrl = runUrl,
                                    activeRunStatus = latestRun.status,
                                    downloadWebPageUrl = runUrl
                                )
                            }
                        }
                    }
                }
            }
        }

        // Timeout fallback
        val timeoutTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        logs.add(BuildLogEntry(timeoutTime, "استغرق البناء وقتاً طويلاً. يمكنك متابعة الحالة مباشرة في متصفح الويب."))
        val fallbackUrl = "https://github.com/${config.owner}/${config.repo}/actions"
        _uiState.update {
            it.copy(
                isBuilding = false,
                buildStatusText = "يمكنك فتح صفحة GitHub Actions لمعاينة البناء وتحميل الـ APK فور اكتماله",
                buildLogs = logs,
                downloadWebPageUrl = fallbackUrl
            )
        }
    }

    fun refreshWorkflowRuns() {
        val config = _uiState.value.gitHubConfig
        if (!config.isConfigured) return

        viewModelScope.launch {
            _uiState.update { it.copy(isPollingWorkflow = true) }
            val res = gitHubService.getLatestWorkflowRuns(config)
            res.onSuccess { runs ->
                _uiState.update {
                    it.copy(
                        recentWorkflowRuns = runs,
                        isPollingWorkflow = false
                    )
                }
            }.onFailure {
                _uiState.update { it.copy(isPollingWorkflow = false) }
            }
        }
    }

    // Extractor Logic
    fun loadInstalledApps() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingApps = true) }
            try {
                val apps = ApkExtractorHelper.getInstalledApps(context)
                _uiState.update {
                    it.copy(
                        installedApps = apps,
                        isLoadingApps = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isLoadingApps = false,
                        snackbarMessage = "تعذر تحميل قائمة التطبيقات: ${e.message}"
                    )
                }
            }
        }
    }

    fun extractApk(app: AppItem) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isExtracting = true,
                    extractionProgress = 0.2f,
                    extractionStatusMessage = "جاري استخراج ملف APK لتطبيق ${app.appName}..."
                )
            }

            val result = ApkExtractorHelper.extractApk(context, app)
            if (result != null) {
                refreshExtractedList()
                _uiState.update {
                    it.copy(
                        isExtracting = false,
                        extractionProgress = 1f,
                        extractionStatusMessage = "",
                        snackbarMessage = "تم استخراج ملف ${result.fileName} بنجاح وحفظه في مجلد الهاتف! 📦"
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isExtracting = false,
                        extractionProgress = 0f,
                        extractionStatusMessage = "",
                        snackbarMessage = "تعذر استخراج حزمة APK للتطبيق المحدد."
                    )
                }
            }
        }
    }

    fun refreshExtractedList() {
        val extracted = ApkExtractorHelper.getExtractedApkFiles(context)
        _uiState.update { it.copy(extractedApks = extracted) }
    }

    fun shareApk(filePath: String) {
        ApkExtractorHelper.shareApk(context, filePath)
    }

    fun openApp(packageName: String) {
        val success = ApkExtractorHelper.openApp(context, packageName)
        if (!success) {
            _uiState.update { it.copy(snackbarMessage = "تعذر تشغيل التطبيق على الهاتف") }
        }
    }

    fun openAppSettings(packageName: String) {
        ApkExtractorHelper.openAppSettings(context, packageName)
    }

    fun deleteExtractedApk(filePath: String) {
        try {
            val file = File(filePath)
            if (file.exists()) {
                file.delete()
                refreshExtractedList()
                _uiState.update { it.copy(snackbarMessage = "تم حذف ملف الـ APK المستخرج") }
            }
        } catch (e: Exception) {
            _uiState.update { it.copy(snackbarMessage = "تعذر حذف الملف: ${e.message}") }
        }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setSelectedAppTab(tab: AppTabFilter) {
        _uiState.update { it.copy(selectedAppTab = tab) }
    }

    fun setShowConfigDialog(show: Boolean) {
        _uiState.update { it.copy(showConfigDialog = show) }
    }

    fun setShowWorkflowTemplateDialog(show: Boolean) {
        _uiState.update { it.copy(showWorkflowTemplateDialog = show) }
    }

    fun toggleTheme() {
        val newTheme = !_uiState.value.isDarkTheme
        prefs.edit().putBoolean("is_dark_theme", newTheme).apply()
        _uiState.update { it.copy(isDarkTheme = newTheme) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
