package com.example.viewmodel

import android.app.Application
import android.content.ClipboardManager
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.DownloadEntity
import com.example.data.repository.DownloadRepository
import com.example.model.ActiveDownload
import com.example.model.AppThemeMode
import com.example.model.DownloadStatus
import com.example.model.TikTokVideo
import com.example.network.TikTokExtractor
import com.example.util.FileDownloader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class TikDownloaderViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("tik_downloader_prefs", Context.MODE_PRIVATE)
    private val database = AppDatabase.getDatabase(application)
    private val repository = DownloadRepository(database.downloadDao())
    private val extractor = TikTokExtractor()
    private val fileDownloader = FileDownloader(application)

    // UI Input & State
    private val _inputUrl = MutableStateFlow("")
    val inputUrl: StateFlow<String> = _inputUrl.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _analyzedVideo = MutableStateFlow<TikTokVideo?>(null)
    val analyzedVideo: StateFlow<TikTokVideo?> = _analyzedVideo.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _isError = MutableStateFlow(false)
    val isError: StateFlow<Boolean> = _isError.asStateFlow()

    // Active Downloads Map (key = downloadId)
    private val _activeDownloads = MutableStateFlow<Map<String, ActiveDownload>>(emptyMap())
    val activeDownloads: StateFlow<Map<String, ActiveDownload>> = _activeDownloads.asStateFlow()

    // Preview video (either streaming URL or local file path)
    private val _previewVideoUrl = MutableStateFlow<String?>(null)
    val previewVideoUrl: StateFlow<String?> = _previewVideoUrl.asStateFlow()

    private val _previewVideoTitle = MutableStateFlow<String>("")
    val previewVideoTitle: StateFlow<String> = _previewVideoTitle.asStateFlow()

    // Search Query in Library
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Theme Mode (OLED by default as requested)
    private val _themeMode = MutableStateFlow(loadSavedTheme())
    val themeMode: StateFlow<AppThemeMode> = _themeMode.asStateFlow()

    // Auto paste preference
    private val _autoPasteEnabled = MutableStateFlow(prefs.getBoolean("auto_paste", true))
    val autoPasteEnabled: StateFlow<Boolean> = _autoPasteEnabled.asStateFlow()

    // Saved Downloads from Room DB filtered by search query
    val savedDownloads: StateFlow<List<DownloadEntity>> = repository.allDownloads
        .combine(_searchQuery) { list, query ->
            if (query.isBlank()) {
                list
            } else {
                list.filter {
                    it.title.contains(query, ignoreCase = true) ||
                            it.authorName.contains(query, ignoreCase = true) ||
                            it.authorUsername.contains(query, ignoreCase = true)
                }
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    init {
        // Check clipboard on startup if auto paste enabled
        if (_autoPasteEnabled.value) {
            checkClipboardOnStartup()
        }
    }

    fun onUrlChange(newUrl: String) {
        _inputUrl.value = newUrl
        _statusMessage.value = null
        _isError.value = false
    }

    fun clearInput() {
        _inputUrl.value = ""
        _analyzedVideo.value = null
        _statusMessage.value = null
        _isError.value = false
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    private fun loadSavedTheme(): AppThemeMode {
        val name = prefs.getString("theme_mode", AppThemeMode.OLED.name) ?: AppThemeMode.OLED.name
        return try {
            AppThemeMode.valueOf(name)
        } catch (_: Exception) {
            AppThemeMode.OLED
        }
    }

    fun setThemeMode(mode: AppThemeMode) {
        _themeMode.value = mode
        prefs.edit().putString("theme_mode", mode.name).apply()
    }

    fun setAutoPaste(enabled: Boolean) {
        _autoPasteEnabled.value = enabled
        prefs.edit().putBoolean("auto_paste", enabled).apply()
    }

    private fun checkClipboardOnStartup() {
        try {
            val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clipData = clipboard?.primaryClip
            if (clipData != null && clipData.itemCount > 0) {
                val text = clipData.getItemAt(0)?.text?.toString() ?: ""
                val extracted = TikTokExtractor.extractUrlFromText(text)
                if (!extracted.isNullOrBlank() && extracted != _inputUrl.value) {
                    _inputUrl.value = extracted
                    analyzeUrl(extracted)
                }
            }
        } catch (_: Exception) {}
    }

    fun pasteFromClipboard() {
        try {
            val clipboard = getApplication<Application>().getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            val clipData = clipboard?.primaryClip
            if (clipData != null && clipData.itemCount > 0) {
                val text = clipData.getItemAt(0)?.text?.toString() ?: ""
                val extracted = TikTokExtractor.extractUrlFromText(text) ?: text.trim()
                if (extracted.isNotBlank()) {
                    _inputUrl.value = extracted
                    analyzeUrl(extracted)
                } else {
                    _statusMessage.value = "الحافظة فارغة أو لا تحتوي على نص"
                    _isError.value = true
                }
            } else {
                _statusMessage.value = "لا يوجد محتوى في الحافظة"
                _isError.value = true
            }
        } catch (e: Exception) {
            _statusMessage.value = "تعذر القراءة من الحافظة: ${e.localizedMessage}"
            _isError.value = true
        }
    }

    fun analyzeUrl(targetUrl: String = _inputUrl.value) {
        val url = targetUrl.trim()
        if (url.isBlank()) {
            _statusMessage.value = "يرجى إدخال أو لصق رابط فيديو تيك توك أولاً"
            _isError.value = true
            return
        }

        viewModelScope.launch {
            _isAnalyzing.value = true
            _statusMessage.value = "جاري فحص الرابط وفك تشفير الفيديو بدون علامة مائية..."
            _isError.value = false
            _analyzedVideo.value = null

            val result = extractor.fetchVideoDetails(url)
            _isAnalyzing.value = false

            result.onSuccess { video ->
                _analyzedVideo.value = video
                _statusMessage.value = "تم استخراج الفيديو بنجاح! اختر الجودة للتحميل"
                _isError.value = false
            }.onFailure { err ->
                _statusMessage.value = err.message ?: "تعذر استخراج بيانات الفيديو من تيك توك"
                _isError.value = true
            }
        }
    }

    fun downloadCurrentVideo(useHd: Boolean = true, isAudioOnly: Boolean = false) {
        val video = _analyzedVideo.value ?: return

        val downloadUrl = when {
            isAudioOnly -> video.audioUrl.ifBlank { video.videoNoWatermarkUrl }
            useHd -> video.videoHdUrl.ifBlank { video.videoNoWatermarkUrl }
            else -> video.videoNoWatermarkUrl
        }

        if (downloadUrl.isBlank()) {
            _statusMessage.value = "الرابط المطلوب غير متاح لهذا الفيديو"
            _isError.value = true
            return
        }

        val downloadId = "${video.id}_${if (isAudioOnly) "audio" else "video"}_${System.currentTimeMillis()}"

        viewModelScope.launch(Dispatchers.IO) {
            fileDownloader.downloadFile(
                downloadId = downloadId,
                url = downloadUrl,
                title = video.title,
                author = video.authorName,
                thumbnailUrl = video.coverUrl,
                isAudio = isAudioOnly
            ).collect { activeDownload ->
                val currentMap = _activeDownloads.value.toMutableMap()
                currentMap[downloadId] = activeDownload
                _activeDownloads.value = currentMap

                if (activeDownload.status == DownloadStatus.COMPLETED) {
                    // Save to Room database
                    val entity = DownloadEntity(
                        tiktokId = video.id,
                        title = video.title,
                        authorName = video.authorName,
                        authorUsername = video.authorUsername,
                        authorAvatar = video.authorAvatar,
                        thumbnailUrl = video.coverUrl,
                        localFilePath = activeDownload.localFilePath,
                        fileSize = activeDownload.downloadedBytes,
                        duration = video.duration,
                        isAudioOnly = isAudioOnly,
                        sourceUrl = video.originalSourceUrl
                    )
                    repository.saveDownload(entity)
                }
            }
        }
    }

    fun openPreview(url: String, title: String) {
        _previewVideoUrl.value = url
        _previewVideoTitle.value = title
    }

    fun closePreview() {
        _previewVideoUrl.value = null
        _previewVideoTitle.value = ""
    }

    fun dismissActiveDownload(downloadId: String) {
        val currentMap = _activeDownloads.value.toMutableMap()
        currentMap.remove(downloadId)
        _activeDownloads.value = currentMap
    }

    fun deleteSavedDownload(download: DownloadEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            // Delete physical file
            try {
                val file = File(download.localFilePath)
                if (file.exists()) {
                    file.delete()
                }
            } catch (_: Exception) {}

            repository.deleteDownload(download.id)
        }
    }

    fun clearAllDownloads() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = _savedDownloadsList()
            list.forEach { item ->
                try {
                    val file = File(item.localFilePath)
                    if (file.exists()) file.delete()
                } catch (_: Exception) {}
            }
            repository.clearAll()
        }
    }

    private suspend fun _savedDownloadsList(): List<DownloadEntity> {
        return savedDownloads.value
    }
}
