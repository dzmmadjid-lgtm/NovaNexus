package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.screens.PubgBoosterMainScreen
import com.example.ui.theme.PubgBoosterTheme
import com.example.viewmodel.PubgBoosterViewModel

class MainActivity : ComponentActivity() {

    private val boosterViewModel: PubgBoosterViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            PubgBoosterTheme {
                PubgBoosterMainScreen(viewModel = boosterViewModel)
            }
        }
    }
}
