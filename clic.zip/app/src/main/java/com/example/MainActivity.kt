package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.screens.MainApkBuilderScreen
import com.example.ui.theme.PubgBoosterTheme
import com.example.viewmodel.BuilderViewModel

class MainActivity : ComponentActivity() {

    private val builderViewModel: BuilderViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            PubgBoosterTheme {
                MainApkBuilderScreen(viewModel = builderViewModel)
            }
        }
    }
}
