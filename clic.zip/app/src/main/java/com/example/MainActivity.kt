package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.screens.YouTubeMainScreen
import com.example.ui.theme.PlayTubeTheme
import com.example.viewmodel.YouTubeViewModel

class MainActivity : ComponentActivity() {

    private val youTubeViewModel: YouTubeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            PlayTubeTheme(darkTheme = true) {
                YouTubeMainScreen(viewModel = youTubeViewModel)
            }
        }
    }
}
