package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.network.TikTokExtractor
import com.example.ui.screens.TikDownloaderMainScreen
import com.example.ui.theme.TikDownloaderTheme
import com.example.viewmodel.TikDownloaderViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: TikDownloaderViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        handleIncomingIntent(intent)

        setContent {
            val currentTheme by viewModel.themeMode.collectAsState()
            TikDownloaderTheme(themeMode = currentTheme) {
                TikDownloaderMainScreen(viewModel = viewModel)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT) ?: ""
            val extractedUrl = TikTokExtractor.extractUrlFromText(sharedText) ?: sharedText.trim()
            if (extractedUrl.isNotBlank()) {
                viewModel.onUrlChange(extractedUrl)
                viewModel.analyzeUrl(extractedUrl)
            }
        }
    }
}
