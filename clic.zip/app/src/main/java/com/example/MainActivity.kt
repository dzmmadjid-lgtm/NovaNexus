package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.ui.screens.ApkBuilderMainScreen
import com.example.ui.theme.ApkBuilderTheme
import com.example.viewmodel.ApkBuilderViewModel

class MainActivity : ComponentActivity() {

    private val apkBuilderViewModel: ApkBuilderViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by apkBuilderViewModel.uiState.collectAsState()
            ApkBuilderTheme(darkTheme = uiState.isDarkTheme) {
                ApkBuilderMainScreen(viewModel = apkBuilderViewModel)
            }
        }
    }
}
