package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.screens.ApkBuilderMainScreen
import com.example.ui.theme.ApkBuilderTheme
import com.example.viewmodel.ApkBuilderViewModel

class MainActivity : ComponentActivity() {

    private val apkBuilderViewModel: ApkBuilderViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ApkBuilderTheme(darkTheme = true) {
                ApkBuilderMainScreen(viewModel = apkBuilderViewModel)
            }
        }
    }
}

