package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.ui.screens.NotesMainScreen
import com.example.ui.theme.ClickCalculatorTheme
import com.example.viewmodel.NotesViewModel

class MainActivity : ComponentActivity() {

    private val notesViewModel: NotesViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by notesViewModel.uiState.collectAsState()

            ClickCalculatorTheme(darkTheme = uiState.isDarkTheme) {
                NotesMainScreen(viewModel = notesViewModel)
            }
        }
    }
}
