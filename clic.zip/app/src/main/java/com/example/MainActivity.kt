package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.ui.theme.BgDark
import com.example.ui.theme.MyApplicationTheme
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

class MainActivity : ComponentActivity() {

    companion object {
        private const val TAG = "ClickSchool"
        private const val CHANNEL_ID = "click_school_downloads"
        private const val CHANNEL_NAME = "Click School Downloads"
    }

    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var webViewInstance: WebView? = null

    // Permission launcher for storage & notifications (Android 13+)
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.entries.all { it.value }
        Log.d(TAG, "Permissions result: $permissions, allGranted: $granted")
    }

    // File picker launcher
    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val intent = result.data
            val results: Array<Uri>? = when {
                intent?.data != null -> arrayOf(intent.data!!)
                intent?.clipData != null -> {
                    val clipData = intent.clipData!!
                    Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                }
                else -> null
            }
            filePathCallback?.onReceiveValue(results)
        } else {
            filePathCallback?.onReceiveValue(null)
        }
        filePathCallback = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        createNotificationChannel()
        checkAndRequestPermissions()

        setContent {
            MyApplicationTheme {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(BgDark)
                        .windowInsetsPadding(WindowInsets.statusBars)
                        .windowInsetsPadding(WindowInsets.navigationBars)
                ) {
                    ClickSchoolWebView(
                        onWebViewReady = { webViewInstance = it },
                        onOpenFileChooser = { callback, params ->
                            filePathCallback = callback
                            val intent = params.createIntent().apply {
                                addCategory(Intent.CATEGORY_OPENABLE)
                                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                            }
                            try {
                                filePickerLauncher.launch(intent)
                            } catch (e: Exception) {
                                Log.e(TAG, "Error launching file picker", e)
                                filePathCallback = null
                            }
                        },
                        onSaveBase64File = { base64Data, fileName, mimeType ->
                            saveBase64ToDownloads(base64Data, fileName, mimeType)
                        }
                    )
                }
            }
        }
    }

    private fun checkAndRequestPermissions() {
        val permissionsToRequest = mutableListOf<String>()

        // Notification permission for Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                != PackageManager.PERMISSION_GRANTED
            ) {
                permissionsToRequest.add(Manifest.permission.READ_MEDIA_IMAGES)
            }
        } else {
            // Android 12 and below
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED
            ) {
                permissionsToRequest.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED
                ) {
                    permissionsToRequest.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                }
            }
        }

        if (permissionsToRequest.isNotEmpty()) {
            permissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Click School file download notifications"
                enableVibration(true)
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }
    }

    /**
     * Saves raw Base64 data directly into Environment.DIRECTORY_DOWNLOADS using MediaStore (API 29+)
     * or standard Downloads directory (API <= 28) and notifies the system and user.
     */
    fun saveBase64ToDownloads(base64Data: String, rawFileName: String, mimeType: String): Uri? {
        return try {
            val cleanBase64 = if (base64Data.contains(",")) {
                base64Data.substringAfter(",")
            } else {
                base64Data
            }

            val bytes = Base64.decode(cleanBase64, Base64.DEFAULT)
            val fileName = if (rawFileName.isNotBlank()) rawFileName else "ClickSchool_File.pdf"
            val resolvedMime = when {
                mimeType.isNotBlank() && mimeType != "application/octet-stream" -> mimeType
                fileName.endsWith(".pdf", ignoreCase = true) -> "application/pdf"
                fileName.endsWith(".zip", ignoreCase = true) -> "application/zip"
                fileName.endsWith(".png", ignoreCase = true) -> "image/png"
                fileName.endsWith(".jpg", ignoreCase = true) || fileName.endsWith(".jpeg", ignoreCase = true) -> "image/jpeg"
                else -> "application/pdf"
            }

            var savedUri: Uri? = null
            var savedFile: File? = null

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Scoped Storage: Android 10+ (API 29+) and Android 13/14/15/16
                val contentValues = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, resolvedMime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }

                val resolver = applicationContext.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
                if (uri != null) {
                    resolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.write(bytes)
                        outputStream.flush()
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, contentValues, null, null)
                    savedUri = uri
                }
            } else {
                // Legacy Storage: Android 9 and below
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!downloadsDir.exists()) {
                    downloadsDir.mkdirs()
                }
                var targetFile = File(downloadsDir, fileName)
                var counter = 1
                while (targetFile.exists()) {
                    val nameWithoutExt = fileName.substringBeforeLast(".")
                    val ext = fileName.substringAfterLast(".", "")
                    val newName = if (ext.isNotEmpty()) "${nameWithoutExt}_$counter.$ext" else "${nameWithoutExt}_$counter"
                    targetFile = File(downloadsDir, newName)
                    counter++
                }

                FileOutputStream(targetFile).use { fos ->
                    fos.write(bytes)
                    fos.flush()
                }
                savedFile = targetFile
                savedUri = Uri.fromFile(targetFile)

                MediaScannerConnection.scanFile(
                    applicationContext,
                    arrayOf(targetFile.absolutePath),
                    arrayOf(resolvedMime),
                    null
                )
            }

            Handler(Looper.getMainLooper()).post {
                Toast.makeText(
                    applicationContext,
                    "تم حفظ الملف في مجلد التنزيلات (Downloads):\n$fileName",
                    Toast.LENGTH_LONG
                ).show()

                showDownloadNotification(fileName, resolvedMime, savedUri, savedFile)
            }

            savedUri
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save file to downloads", e)
            Handler(Looper.getMainLooper()).post {
                Toast.makeText(
                    applicationContext,
                    "فشل حفظ الملف: ${e.localizedMessage}",
                    Toast.LENGTH_SHORT
                ).show()
            }
            null
        }
    }

    private fun showDownloadNotification(
        fileName: String,
        mimeType: String,
        fileUri: Uri?,
        fileObj: File?
    ) {
        try {
            val openIntent = Intent(Intent.ACTION_VIEW).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION

                if (fileUri != null && fileUri.scheme == "content") {
                    setDataAndType(fileUri, mimeType)
                } else if (fileObj != null) {
                    val contentUri = FileProvider.getUriForFile(
                        applicationContext,
                        "${applicationContext.packageName}.fileprovider",
                        fileObj
                    )
                    setDataAndType(contentUri, mimeType)
                }
            }

            val pendingIntent = PendingIntent.getActivity(
                applicationContext,
                System.currentTimeMillis().toInt(),
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("تم تنزيل الملف بنجاح")
                .setContentText(fileName)
                .setStyle(
                    NotificationCompat.BigTextStyle()
                        .bigText("تم حفظ $fileName في مجلد التنزيلات بنجاح. انقر هنا لفتح الملف.")
                )
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.notify(System.currentTimeMillis().toInt(), notification)
        } catch (e: Exception) {
            Log.e(TAG, "Notification error", e)
        }
    }
}

/**
 * JavaScript Interface exposing native download and file saving capabilities
 */
class WebAppInterface(
    private val activity: MainActivity,
    private val onSaveBase64File: (String, String, String) -> Unit
) {
    @JavascriptInterface
    fun saveBase64File(base64Data: String, fileName: String, mimeType: String) {
        Log.d("ClickSchoolNative", "saveBase64File received: $fileName, mime: $mimeType")
        onSaveBase64File(base64Data, fileName, mimeType)
    }

    @JavascriptInterface
    fun showToast(message: String) {
        Handler(Looper.getMainLooper()).post {
            Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun ClickSchoolWebView(
    onWebViewReady: (WebView) -> Unit,
    onOpenFileChooser: (ValueCallback<Array<Uri>>, WebChromeClient.FileChooserParams) -> Unit,
    onSaveBase64File: (String, String, String) -> Unit
) {
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { context ->
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )

                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    allowFileAccess = true
                    allowContentAccess = true
                    allowFileAccessFromFileURLs = true
                    allowUniversalAccessFromFileURLs = true
                    setSupportZoom(true)
                    builtInZoomControls = true
                    displayZoomControls = false
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    cacheMode = WebSettings.LOAD_DEFAULT
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                }

                // Add Javascript Interface
                if (context is MainActivity) {
                    addJavascriptInterface(
                        WebAppInterface(context, onSaveBase64File),
                        "AndroidDownloader"
                    )
                }

                // Setup DownloadListener for direct links & media
                setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
                    Log.d("ClickSchoolDownload", "setDownloadListener: $url, mime: $mimeType")
                    if (url.startsWith("data:")) {
                        val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                        val mime = if (mimeType.isNullOrBlank()) "application/pdf" else mimeType
                        onSaveBase64File(url, fileName, mime)
                    } else if (url.startsWith("blob:")) {
                        // Request JS to convert blob to base64 and send to AndroidDownloader
                        val js = """
                            (async function() {
                                try {
                                    const response = await fetch('$url');
                                    const blob = await response.blob();
                                    const reader = new FileReader();
                                    reader.onloadend = function() {
                                        if (window.AndroidDownloader) {
                                            window.AndroidDownloader.saveBase64File(
                                                reader.result,
                                                '${URLUtil.guessFileName(url, contentDisposition, mimeType)}',
                                                blob.type || '$mimeType'
                                            );
                                        }
                                    };
                                    reader.readAsDataURL(blob);
                                } catch (e) {
                                    console.error('Blob download error:', e);
                                }
                            })();
                        """.trimIndent()
                        evaluateJavascript(js, null)
                    } else if (url.startsWith("http://") || url.startsWith("https://")) {
                        try {
                            val request = DownloadManager.Request(Uri.parse(url)).apply {
                                setMimeType(mimeType)
                                val cookies = CookieManager.getInstance().getCookie(url)
                                addRequestHeader("cookie", cookies)
                                addRequestHeader("User-Agent", userAgent)
                                setDescription("Downloading file via Click School")
                                val filename = URLUtil.guessFileName(url, contentDisposition, mimeType)
                                setTitle(filename)
                                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename)
                            }
                            val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                            dm.enqueue(request)
                            Toast.makeText(context, "بدأ تنزيل الملف...", Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            Log.e("ClickSchoolDownload", "DownloadManager error", e)
                        }
                    }
                })

                webChromeClient = object : WebChromeClient() {
                    override fun onShowFileChooser(
                        webView: WebView?,
                        filePathCallback: ValueCallback<Array<Uri>>?,
                        fileChooserParams: FileChooserParams?
                    ): Boolean {
                        if (filePathCallback != null && fileChooserParams != null) {
                            onOpenFileChooser(filePathCallback, fileChooserParams)
                            return true
                        }
                        return false
                    }
                }

                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        // Inject script to override saveAs and anchor download triggers
                        val injectionJs = """
                            (function() {
                                if (window._clickSchoolBridgeInjected) return;
                                window._clickSchoolBridgeInjected = true;
                                
                                function bridgeSaveBlob(blob, filename) {
                                    if (window.AndroidDownloader && blob) {
                                        var reader = new FileReader();
                                        reader.onloadend = function() {
                                            window.AndroidDownloader.saveBase64File(
                                                reader.result,
                                                filename || 'ClickSchool_Document.pdf',
                                                blob.type || 'application/pdf'
                                            );
                                        };
                                        reader.readAsDataURL(blob);
                                        return true;
                                    }
                                    return false;
                                }

                                if (typeof window.saveAs === 'function') {
                                    var origSaveAs = window.saveAs;
                                    window.saveAs = function(blob, filename, options) {
                                        if (!bridgeSaveBlob(blob, filename)) {
                                            origSaveAs(blob, filename, options);
                                        }
                                    };
                                }

                                window.addEventListener('click', function(e) {
                                    var target = e.target.closest('a[download]');
                                    if (target && target.href) {
                                        if (target.href.startsWith('blob:') || target.href.startsWith('data:')) {
                                            e.preventDefault();
                                            var filename = target.getAttribute('download') || 'download.pdf';
                                            fetch(target.href)
                                                .then(res => res.blob())
                                                .then(blob => bridgeSaveBlob(blob, filename))
                                                .catch(err => console.error(err));
                                        }
                                    }
                                }, true);
                            })();
                        """.trimIndent()
                        view?.evaluateJavascript(injectionJs, null)
                    }

                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): Boolean {
                        val url = request?.url?.toString() ?: ""
                        if (url.startsWith("file://") || url.startsWith("http://") || url.startsWith("https://") || url.startsWith("data:") || url.startsWith("blob:")) {
                            return false
                        }
                        return try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                            context.startActivity(intent)
                            true
                        } catch (e: Exception) {
                            false
                        }
                    }
                }

                loadUrl("file:///android_asset/index.html")
                onWebViewReady(this)
            }
        }
    )
}
