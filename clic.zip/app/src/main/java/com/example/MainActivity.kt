package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.ui.screens.ApkExtractorScreen
import com.example.ui.theme.ClickCalculatorTheme
import com.example.viewmodel.ApkExtractorViewModel

class MainActivity : ComponentActivity() {

    private val apkExtractorViewModel: ApkExtractorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by apkExtractorViewModel.uiState.collectAsState()

            ClickCalculatorTheme(darkTheme = uiState.isDarkTheme) {
                ApkExtractorScreen(viewModel = apkExtractorViewModel)
            }
        }
    }
}

