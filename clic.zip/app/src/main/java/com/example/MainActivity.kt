package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.ui.screens.TranslatorMainScreen
import com.example.ui.theme.ClickCalculatorTheme
import com.example.viewmodel.TranslatorViewModel

class MainActivity : ComponentActivity() {

    private val translatorViewModel: TranslatorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val uiState by translatorViewModel.uiState.collectAsState()

            ClickCalculatorTheme(darkTheme = uiState.isDarkTheme) {
                TranslatorMainScreen(viewModel = translatorViewModel)
            }
        }
    }
}
