package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ide.ui.DroidIdeScreen
import com.example.ide.viewmodel.IdeViewModel
import com.example.ui.theme.DroidIdeTheme

/**
 * النشاط الرئيسي لتطبيق بيئة التطوير DroidIDE
 */
class MainActivity : ComponentActivity() {

    private val viewModel: IdeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val isDark by viewModel.isDarkMode.collectAsStateWithLifecycle()
            DroidIdeTheme(isDark = isDark) {
                DroidIdeScreen(viewModel = viewModel)
            }
        }
    }
}



