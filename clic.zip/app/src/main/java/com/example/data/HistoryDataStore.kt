package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.HistoryEntry
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "click_calculator_prefs")

class HistoryDataStore(private val context: Context) {

    private val historyKey = stringPreferencesKey("calculation_history_json")
    private val themeKey = booleanPreferencesKey("app_theme_is_dark")

    val isDarkTheme: Flow<Boolean> = context.dataStore.data.map { preferences ->
        preferences[themeKey] ?: true // default to OLED dark mode
    }

    suspend fun saveTheme(isDark: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[themeKey] = isDark
        }
    }

    val historyFlow: Flow<List<HistoryEntry>> = context.dataStore.data.map { preferences ->
        val jsonStr = preferences[historyKey] ?: "[]"
        parseHistoryJson(jsonStr)
    }

    suspend fun addHistoryEntry(entry: HistoryEntry) {
        context.dataStore.edit { preferences ->
            val currentJson = preferences[historyKey] ?: "[]"
            val currentList = parseHistoryJson(currentJson).toMutableList()
            // Add new entry at top
            currentList.add(0, entry)
            // Limit to last 100 entries
            val trimmedList = if (currentList.size > 100) currentList.subList(0, 100) else currentList
            preferences[historyKey] = encodeHistoryJson(trimmedList)
        }
    }

    suspend fun deleteHistoryEntry(id: Long) {
        context.dataStore.edit { preferences ->
            val currentJson = preferences[historyKey] ?: "[]"
            val currentList = parseHistoryJson(currentJson).toMutableList()
            currentList.removeAll { it.id == id }
            preferences[historyKey] = encodeHistoryJson(currentList)
        }
    }

    suspend fun clearHistory() {
        context.dataStore.edit { preferences ->
            preferences[historyKey] = "[]"
        }
    }

    private fun parseHistoryJson(json: String): List<HistoryEntry> {
        val list = mutableListOf<HistoryEntry>()
        try {
            val jsonArray = JSONArray(json)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                list.add(
                    HistoryEntry(
                        id = obj.optLong("id", System.currentTimeMillis()),
                        type = obj.optString("type", "STANDARD"),
                        expression = obj.optString("expression", ""),
                        result = obj.optString("result", ""),
                        tafqeet = obj.optString("tafqeet", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    private fun encodeHistoryJson(list: List<HistoryEntry>): String {
        val jsonArray = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("type", item.type)
                put("expression", item.expression)
                put("result", item.result)
                put("tafqeet", item.tafqeet)
                put("timestamp", item.timestamp)
            }
            jsonArray.put(obj)
        }
        return jsonArray.toString()
    }
}
