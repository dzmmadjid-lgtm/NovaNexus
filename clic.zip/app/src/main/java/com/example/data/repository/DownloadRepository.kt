package com.example.data.repository

import com.example.data.local.DownloadDao
import com.example.data.local.DownloadEntity
import kotlinx.coroutines.flow.Flow

class DownloadRepository(private val downloadDao: DownloadDao) {

    val allDownloads: Flow<List<DownloadEntity>> = downloadDao.getAllDownloads()

    fun searchDownloads(query: String): Flow<List<DownloadEntity>> {
        return if (query.isBlank()) {
            downloadDao.getAllDownloads()
        } else {
            downloadDao.searchDownloads(query.trim())
        }
    }

    suspend fun saveDownload(download: DownloadEntity): Long {
        return downloadDao.insertDownload(download)
    }

    suspend fun deleteDownload(id: Long) {
        downloadDao.deleteById(id)
    }

    suspend fun clearAll() {
        downloadDao.deleteAll()
    }
}
