package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {

    @Query("SELECT * FROM downloaded_videos ORDER BY downloadedAt DESC")
    fun getAllDownloads(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloaded_videos WHERE id = :id LIMIT 1")
    suspend fun getDownloadById(id: Long): DownloadEntity?

    @Query("SELECT * FROM downloaded_videos WHERE tiktokId = :tiktokId LIMIT 1")
    suspend fun getDownloadByTikTokId(tiktokId: String): DownloadEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: DownloadEntity): Long

    @Query("DELETE FROM downloaded_videos WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM downloaded_videos")
    suspend fun deleteAll()

    @Query("SELECT * FROM downloaded_videos WHERE title LIKE '%' || :query || '%' OR authorName LIKE '%' || :query || '%' OR authorUsername LIKE '%' || :query || '%' ORDER BY downloadedAt DESC")
    fun searchDownloads(query: String): Flow<List<DownloadEntity>>
}
