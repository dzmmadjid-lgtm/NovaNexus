package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "downloaded_videos")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val tiktokId: String,
    val title: String,
    val authorName: String,
    val authorUsername: String,
    val authorAvatar: String,
    val thumbnailUrl: String,
    val localFilePath: String,
    val fileSize: Long = 0L,
    val duration: Int = 0,
    val isAudioOnly: Boolean = false,
    val sourceUrl: String,
    val downloadedAt: Long = System.currentTimeMillis()
)
