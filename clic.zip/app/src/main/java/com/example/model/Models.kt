package com.example.model

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class AiEngineMode(val label: String, val arabicLabel: String, val speed: String, val iconName: String) {
    FLASH("Flash Neural", "الوضع الفائق السرعة", "120 t/s", "Bolt"),
    DEEP_LOGIC("Quantum Logic", "المنطق والتحليل المعقد", "45 t/s", "Psychology"),
    CREATIVE("Creative Synth", "التوليد الإبداعي المتقدم", "85 t/s", "AutoAwesome")
}

data class ChatMessage(
    val id: String,
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val modelName: String = "Nova-3.7-Pro",
    val tokens: Int = 0,
    val latencyMs: Long = 0,
    val isStreaming: Boolean = false,
    val isCode: Boolean = false,
    val codeLanguage: String = ""
)

data class QuickPrompt(
    val id: String,
    val title: String,
    val arabicTitle: String,
    val prompt: String,
    val category: String,
    val colorHex: Long = 0xFF00F5D4
)

enum class SmartToolType(val title: String, val arabicTitle: String, val description: String) {
    PROMPT_ENHANCER("Prompt Matrix", "مُحسّن الأوامر الذكي", "يحول أي فكرة بسيطة لأمر متقدم عالي الدقة"),
    CODE_OPTIMIZER("Code Refactor", "مُحسّن ومراجع الأكواد", "تحليل الكود وتحسين الأداء واكتشاف الثغرات"),
    SENTIMENT_ANALYZER("Tone & Logic", "محلل النبرة والمشاعر", "استخراج المشاعر والمنطق والنقاط المحورية"),
    SMART_TRANSLATOR("Neural Translate", "المترجم العصبي الفوري", "ترجمة ذكية تحافظ على السياق والمصطلحات التقنية")
}

data class SystemMetric(
    val title: String,
    val arabicTitle: String,
    val value: String,
    val progress: Float,
    val unit: String,
    val statusText: String,
    val colorHex: Long
)
