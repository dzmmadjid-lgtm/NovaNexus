package com.example.model

enum class DownloadStatus {
    IDLE,
    PREPARING,
    DOWNLOADING,
    SAVING,
    COMPLETED,
    FAILED
}

data class ActiveDownload(
    val downloadId: String,
    val title: String,
    val thumbnailUrl: String,
    val status: DownloadStatus = DownloadStatus.IDLE,
    val progress: Float = 0f, // 0.0f to 1.0f
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,
    val localFilePath: String = "",
    val errorMessage: String? = null,
    val isAudioOnly: Boolean = false,
    val downloadManagerId: Long = -1L
)
