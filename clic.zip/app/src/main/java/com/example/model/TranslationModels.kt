package com.example.model

enum class AppLanguage(val code: String, val titleAr: String, val titleNative: String, val flag: String, val ttsLocale: String) {
    AUTO("auto", "اكتشاف تلقائي", "Auto Detect", "🌐", "ar"),
    ARABIC("ar", "العربية", "العربية", "🇸🇦", "ar"),
    ENGLISH("en", "الإنجليزية", "English", "🇬🇧", "en"),
    FRENCH("fr", "الفرنسية", "Français", "🇫🇷", "fr")
}

enum class TranslationTone(val key: String, val titleAr: String, val icon: String, val descriptionAr: String) {
    CONTEXTUAL("contextual", "سياقية ذكية", "🧠", "فهم المعنى الحقيقي والأمثال والتعبيرات"),
    FORMAL("formal", "رسمية ومهنية", "💼", "مناسبة للعمل، الإيميلات، والخطابات الرسمية"),
    CASUAL("casual", "محادثة وعامية", "💬", "لغة يومية طبيعية تناسب الحوار والدردشة"),
    LITERARY("literary", "أدبية وبلاغية", "📖", "صياغة راقية وبليغة تحافظ على جمالية النص"),
    SIMPLIFIED("simplified", "مبسطة ومباشرة", "⚡", "جمل واضحة وقصيرة ومباشرة الفهم")
}

data class VocabularyItem(
    val word: String,
    val translation: String,
    val note: String = ""
)

data class TranslationResult(
    val translatedText: String = "",
    val detectedSourceLanguage: String = "",
    val contextExplanation: String? = null,
    val alternativePhrasings: List<String> = emptyList(),
    val vocabularyBreakdown: List<VocabularyItem> = emptyList()
)

data class TranslationHistoryItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sourceText: String,
    val translatedText: String,
    val sourceLangCode: String,
    val targetLangCode: String,
    val toneKey: String,
    val contextExplanation: String? = null,
    val isFavorite: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
