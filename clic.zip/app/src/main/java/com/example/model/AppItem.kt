package com.example.model

import android.graphics.drawable.Drawable

enum class AppTabFilter(val title: String, val countLabel: String) {
    USER("المثبتة", "تطبيقات المستخدم"),
    SYSTEM("النظام", "تطبيقات النظام"),
    EXTRACTED("المستخرجة", "ملفات APK الجاهزة")
}

enum class SortOption(val title: String) {
    NAME_ASC("الاسم (أ-ي)"),
    SIZE_DESC("الحجم (الأكبر أولاً)"),
    DATE_DESC("تاريخ التثبيت")
}

data class AppItem(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val isSystemApp: Boolean,
    val apkSourcePath: String,
    val apkSizeBytes: Long,
    val formattedSize: String,
    val targetSdk: Int,
    val minSdk: Int,
    val lastUpdatedTime: Long,
    val icon: Drawable? = null,
    val isSelected: Boolean = false,
    val isExtracted: Boolean = false,
    val extractedPath: String? = null
)

data class ExtractionResult(
    val appName: String,
    val packageName: String,
    val fileName: String,
    val filePath: String,
    val fileSizeFormatted: String,
    val timestamp: Long = System.currentTimeMillis()
)
