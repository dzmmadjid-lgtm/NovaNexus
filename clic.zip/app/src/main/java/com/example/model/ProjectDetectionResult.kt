package com.example.model

data class ProjectDetectionResult(
    val projectName: String,
    val projectType: ProjectKind,
    val packageId: String,
    val buildTools: String,
    val detectedFiles: List<String>,
    val canBuildOnGitHub: Boolean = true
)

enum class ProjectKind(val title: String, val badgeColorHex: Long) {
    NATIVE_ANDROID("Native Android (Kotlin/Java)", 0xFF10B981),
    FLUTTER("Flutter Mobile Framework", 0xFF0284C7),
    REACT_NATIVE("React Native App", 0xFF6366F1),
    CORDOVA_CAPACITOR("Web / Capacitor App", 0xFFF59E0B),
    GENERIC_GRADLE("Gradle Android Project", 0xFF8B5CF6)
}

data class BuildLogEntry(
    val timestamp: String,
    val message: String,
    val isError: Boolean = false,
    val isSuccess: Boolean = false,
    val isStepHeader: Boolean = false
)
