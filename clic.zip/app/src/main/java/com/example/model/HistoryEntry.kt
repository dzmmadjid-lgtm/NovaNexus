package com.example.model

data class HistoryEntry(
    val id: Long = System.currentTimeMillis(),
    val type: String, // "STANDARD" or "CHANGE"
    val expression: String,
    val result: String,
    val tafqeet: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
