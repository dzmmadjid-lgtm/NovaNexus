package com.example.model

data class TikTokVideo(
    val id: String,
    val title: String,
    val coverUrl: String,
    val originCoverUrl: String = "",
    val duration: Int = 0,
    val videoNoWatermarkUrl: String,
    val videoHdUrl: String = "",
    val videoWatermarkUrl: String = "",
    val audioUrl: String = "",
    val audioTitle: String = "",
    val audioAuthor: String = "",
    val authorName: String,
    val authorUsername: String,
    val authorAvatar: String,
    val viewsCount: Long = 0,
    val likesCount: Long = 0,
    val commentsCount: Long = 0,
    val sharesCount: Long = 0,
    val originalSourceUrl: String
)
