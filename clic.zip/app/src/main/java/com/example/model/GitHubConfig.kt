package com.example.model

enum class MainAppSection(val title: String, val subtitle: String) {
    BUILDER("بناء APK سحابي", "GitHub Actions CI/CD"),
    EXTRACTOR("مستخرج APK", "استخراج حزم الهاتف")
}

data class GitHubConfig(
    val token: String = "",
    val owner: String = "",
    val repo: String = "",
    val workflowFileName: String = "build-apk.yml",
    val branch: String = "main",
    val isConfigured: Boolean = false
)

data class GitHubWorkflowRun(
    val id: Long,
    val status: String,
    val conclusion: String?,
    val htmlUrl: String,
    val runNumber: Int,
    val event: String,
    val createdAt: String,
    val updatedAt: String
)

data class GitHubArtifact(
    val id: Long,
    val name: String,
    val sizeInBytes: Long,
    val archiveDownloadUrl: String,
    val expired: Boolean
)
