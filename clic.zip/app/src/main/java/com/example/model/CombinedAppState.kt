package com.example.model

import com.example.model.ExtractedApkItem
import com.example.model.InstalledAppInfo
import java.io.File

data class CombinedAppState(
    val currentSection: MainAppSection = MainAppSection.BUILDER,
    val isDarkTheme: Boolean = true,
    
    // GitHub Cloud Builder State
    val gitHubConfig: GitHubConfig = GitHubConfig(),
    val isVerifyingRepo: Boolean = false,
    val repoVerificationMessage: String? = null,
    val isRepoVerified: Boolean = false,
    
    val selectedZipFile: File? = null,
    val zipFileName: String = "",
    val zipFileSizeFormatted: String = "",
    val detectedProject: ProjectDetectionResult? = null,
    
    val isBuilding: Boolean = false,
    val buildProgressPercent: Int = 0,
    val buildStatusText: String = "جاهز للبناء السحابي",
    val buildLogs: List<BuildLogEntry> = emptyList(),
    val builtApkFile: File? = null,
    
    val recentWorkflowRuns: List<GitHubWorkflowRun> = emptyList(),
    val isPollingWorkflow: Boolean = false,
    val activeRunId: Long? = null,
    
    // APK Extractor State
    val isLoadingApps: Boolean = false,
    val userApps: List<InstalledAppInfo> = emptyList(),
    val systemApps: List<InstalledAppInfo> = emptyList(),
    val extractedApks: List<ExtractedApkItem> = emptyList(),
    val searchQuery: String = "",
    val selectedCategory: AppCategory = AppCategory.USER_APPS,
    val isMultiSelectMode: Boolean = false,
    val selectedPackages: Set<String> = emptySet(),
    val isExtracting: Boolean = false,
    val extractionProgress: Float = 0f,
    val extractionStatusMessage: String = "",
    val snackbarMessage: String? = null
)
