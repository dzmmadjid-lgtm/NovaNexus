package com.example.model

import java.io.File

data class CombinedAppState(
    val currentSection: MainAppSection = MainAppSection.BUILDER,
    val isDarkTheme: Boolean = true,
    
    // GitHub Cloud Builder State
    val gitHubConfig: GitHubConfig = GitHubConfig(),
    val isVerifyingRepo: Boolean = false,
    val repoVerificationMessage: String? = null,
    val isRepoVerified: Boolean = false,
    
    val selectedZipFile: File? = null,
    val zipFileName: String = "",
    val zipFileSizeFormatted: String = "",
    val detectedProject: DetectedProjectInfo? = null,
    
    val isBuilding: Boolean = false,
    val buildProgressPercent: Int = 0,
    val buildStatusText: String = "جاهز للبناء السحابي",
    val buildLogs: List<BuildLogEntry> = emptyList(),
    
    val recentWorkflowRuns: List<GitHubWorkflowRun> = emptyList(),
    val isPollingWorkflow: Boolean = false,
    val activeRunId: Long? = null,
    val activeRunUrl: String? = null,
    val activeRunStatus: String? = null,
    val activeRunConclusion: String? = null,
    val activeArtifacts: List<GitHubArtifact> = emptyList(),
    val downloadWebPageUrl: String? = null,
    
    // Dialogs
    val showConfigDialog: Boolean = false,
    val showWorkflowTemplateDialog: Boolean = false,
    
    // APK Extractor State
    val isLoadingApps: Boolean = false,
    val installedApps: List<AppItem> = emptyList(),
    val extractedApks: List<ExtractionResult> = emptyList(),
    val searchQuery: String = "",
    val selectedAppTab: AppTabFilter = AppTabFilter.USER,
    val isExtracting: Boolean = false,
    val extractionProgress: Float = 0f,
    val extractionStatusMessage: String = "",
    val snackbarMessage: String? = null
)

