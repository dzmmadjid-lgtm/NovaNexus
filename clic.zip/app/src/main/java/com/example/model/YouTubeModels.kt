package com.example.model

data class YouTubeVideo(
    val id: String,
    val title: String,
    val channelTitle: String,
    val channelId: String = "",
    val channelAvatarUrl: String = "",
    val thumbnailUrl: String = "https://img.youtube.com/vi/$id/hqdefault.jpg",
    val maxResThumbnailUrl: String = "https://img.youtube.com/vi/$id/maxresdefault.jpg",
    val durationText: String = "10:24",
    val viewCountText: String = "1.2M",
    val publishedTimeText: String = "منذ يومين",
    val description: String = "",
    val category: VideoCategory = VideoCategory.ALL,
    val isLive: Boolean = false,
    val likesCount: String = "45K"
) {
    val embedUrl: String
        get() = "https://www.youtube-nocookie.com/embed/$id?autoplay=1&enablejsapi=1&playsinline=1&rel=0&iv_load_policy=3&modestbranding=1"

    val watchUrl: String
        get() = "https://www.youtube.com/watch?v=$id"
}

enum class VideoCategory(val titleAr: String, val titleEn: String, val icon: String) {
    ALL("الكل", "All", "🔥"),
    MUSIC("موسيقى وأناشيد", "Music", "🎵"),
    QURAN("قرآن وتلاوات", "Quran", "📖"),
    PODCAST("بودكاست", "Podcasts", "🎙️"),
    GAMING("ألعاب", "Gaming", "🎮"),
    TECH("تقنية وبرمجة", "Tech", "💻"),
    NEWS("أخبار وبث مباشر", "News & Live", "🔴"),
    NATURE("طبيعة واسترخاء", "Relax & Lo-Fi", "🌿")
}

data class PlaybackState(
    val currentVideo: YouTubeVideo? = null,
    val isPlaying: Boolean = false,
    val isBackgroundPlaybackActive: Boolean = false,
    val currentPositionSeconds: Float = 0f,
    val durationSeconds: Float = 0f,
    val playbackSpeed: Float = 1.0f,
    val isLooping: Boolean = false,
    val isPlayerExpanded: Boolean = false,
    val queue: List<YouTubeVideo> = emptyList(),
    val queueIndex: Int = 0
)

data class ChannelInfo(
    val id: String,
    val name: String,
    val avatarUrl: String,
    val subscriberCount: String,
    val isVerified: Boolean = true
)
