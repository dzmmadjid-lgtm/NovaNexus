package com.example.model

enum class AppThemeMode(val titleAr: String, val subtitleAr: String) {
    OLED("شاشات OLED (أسود نقي)", "توفير فائق لطاقة البطارية مع سواد 100%"),
    DARK("الوضع الليلي (رمادي داكن)", "مريح للعينين في الإضاءة الخافتة"),
    LIGHT("الوضع النهاري (فاتح ناصع)", "وضوح عالي وألوان ناصعة تحت ضوء الشمس")
}
