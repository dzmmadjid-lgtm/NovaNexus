package com.example.model

data class ExtractedApkItem(
    val fileName: String,
    val filePath: String,
    val fileSizeFormatted: String,
    val lastModifiedFormatted: String,
    val fileSizeBytes: Long
)

data class InstalledAppInfo(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val isSystemApp: Boolean,
    val sourceApkPath: String,
    val apkSizeFormatted: String,
    val apkSizeBytes: Long,
    val lastUpdateTime: Long
)

enum class AppCategory {
    USER_APPS,
    SYSTEM_APPS,
    EXTRACTED_APKS
}
