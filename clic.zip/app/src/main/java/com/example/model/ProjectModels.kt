package com.example.model

enum class ProjectType(val displayName: String, val icon: String, val description: String) {
    FLUTTER("Flutter Project", "🎯", "مشروع Flutter مع محرك Dart وبناء Android APK"),
    REACT_NATIVE("React Native / Expo", "⚛️", "مشروع React Native مع Metro Bundler و Gradle"),
    ANDROID_KOTLIN_JAVA("Native Android (Kotlin/Java)", "🤖", "مشروع أندرويد نيتيف باستخدام Gradle و Android SDK"),
    IONIC_CAPACITOR("Ionic / Capacitor", "⚡", "مشروع ويب هجين مبني على Capacitor"),
    UNKNOWN("Unknown / Generic", "📁", "مشروع عام، سيتم تحليله تلقائياً")
}

enum class BuildStatus {
    IDLE,
    ANALYZING,
    CONFIGURING,
    BUILDING,
    DOWNLOADING_APK,
    COMPLETED,
    FAILED
}

data class BuildLog(
    val timestamp: String,
    val message: String,
    val isError: Boolean = false,
    val isSuccess: Boolean = false
)

data class DetectedProjectInfo(
    val name: String,
    val type: ProjectType,
    val packageOrBundleId: String,
    val buildTool: String,
    val sdkVersion: String,
    val keyFilesFound: List<String>,
    val estimatedBuildTimeMinutes: Int,
    val detectedSize: String = "12.4 MB"
)
