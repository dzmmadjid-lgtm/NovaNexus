package com.example.model

data class NoteItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String = "",
    val content: String = "",
    val category: String = "عام",
    val colorHex: Long = 0xFF1E293B,
    val isPinned: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

enum class NoteCategory(val title: String, val colorHex: Long) {
    ALL("الكل", 0xFF3B82F6),
    GENERAL("عام", 0xFF64748B),
    WORK("عمل", 0xFF0284C7),
    IDEAS("أفكار", 0xFFF59E0B),
    PERSONAL("شخصي", 0xFF10B981),
    URGENT("مهم", 0xFFEF4444)
}

val NoteColors = listOf(
    0xFF1E293B, // Slate Dark
    0xFF1E3A8A, // Deep Blue
    0xFF064E3B, // Deep Emerald
    0xFF78350F, // Deep Amber
    0xFF701A75, // Deep Fuchsia
    0xFF831843  // Deep Rose
)
