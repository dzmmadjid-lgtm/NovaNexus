package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ide.compiler.GradleSimulator
import com.example.ide.model.DefaultProject
import com.example.ide.model.FileType
import com.example.ide.model.ProjectFile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun testAppNameString() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("DroidIDE", appName)
    }

    @Test
    fun testProjectFileTree() {
        val project = DefaultProject.createSampleProject()
        assertTrue(project.isDirectory)
        assertEquals("MyFirstApp", project.name)
        assertTrue(project.children.isNotEmpty())
    }

    @Test
    fun testSyntaxValidation() {
        val cleanFile = ProjectFile(
            name = "Clean.kt",
            path = "Clean.kt",
            fileType = FileType.KOTLIN,
            content = "fun hello() { println(\"world\") }"
        )
        val cleanErrors = GradleSimulator.validateProject(cleanFile)
        assertTrue(cleanErrors.isEmpty())

        val brokenFile = ProjectFile(
            name = "Broken.kt",
            path = "Broken.kt",
            fileType = FileType.KOTLIN,
            content = "fun hello() { println(\"missing closing brace\")"
        )
        val brokenErrors = GradleSimulator.validateProject(brokenFile)
        assertTrue(brokenErrors.isNotEmpty())
    }

    @Test
    fun testThemeToggle() {
        val viewModel = com.example.ide.viewmodel.IdeViewModel()
        assertTrue(viewModel.isDarkMode.value)
        viewModel.toggleTheme()
        org.junit.Assert.assertFalse(viewModel.isDarkMode.value)
        viewModel.toggleTheme()
        assertTrue(viewModel.isDarkMode.value)
    }
}

