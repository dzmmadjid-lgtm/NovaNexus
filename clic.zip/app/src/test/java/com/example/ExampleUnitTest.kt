package com.example

import com.example.network.TikTokExtractor
import com.example.util.MediaHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testTikTokUrlExtractor() {
        val raw1 = "Check this video https://www.tiktok.com/@user/video/733481749182749?is_from_webapp=1"
        val extracted1 = TikTokExtractor.extractUrlFromText(raw1)
        assertNotNull(extracted1)
        assertTrue(extracted1!!.contains("tiktok.com/@user/video/733481749182749"))

        val rawShort = "https://vm.tiktok.com/ZM6xxxxxx/"
        val extractedShort = TikTokExtractor.extractUrlFromText(rawShort)
        assertNotNull(extractedShort)
        assertTrue(extractedShort!!.contains("vm.tiktok.com"))
    }

    @Test
    fun testMediaHelperFormatting() {
        assertEquals("0 B", MediaHelper.formatFileSize(0))
        val formattedKb = MediaHelper.formatFileSize(2048)
        assertTrue(formattedKb.contains("2"))

        val formattedDuration = MediaHelper.formatDuration(75)
        assertEquals("01:15", formattedDuration)
    }
}
