package com.example

import com.example.ide.compiler.GradleSimulator
import com.example.ide.model.DefaultProject
import com.example.ide.model.FileType
import com.example.ide.model.ProjectFile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testFileTypeDetection() {
        val ktFile = ProjectFile(name = "Test.kt", path = "Test.kt", fileType = FileType.KOTLIN)
        assertEquals(FileType.KOTLIN, ktFile.fileType)

        val javaFile = ProjectFile(name = "Test.java", path = "Test.java", fileType = FileType.JAVA)
        assertEquals(FileType.JAVA, javaFile.fileType)

        val xmlFile = ProjectFile(name = "Test.xml", path = "Test.xml", fileType = FileType.XML)
        assertEquals(FileType.XML, xmlFile.fileType)
    }

    @Test
    fun testDefaultProjectStructure() {
        val project = DefaultProject.createSampleProject()
        assertNotNull(project)
        assertTrue(project.isDirectory)
        assertTrue(project.children.any { it.name == "app" })
    }

    @Test
    fun testSimulatorValidation() {
        val validKotlin = ProjectFile(
            name = "App.kt",
            path = "App.kt",
            fileType = FileType.KOTLIN,
            content = "class App { fun run() {} }"
        )
        val errors = GradleSimulator.validateProject(validKotlin)
        assertTrue(errors.isEmpty())
    }
}
