package com.example

import com.example.util.ArabicNumberToWords
import com.example.util.CalculatorEvaluator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testTafqeetConversion() {
    val thirty = ArabicNumberToWords.convertToDinarWords(30.0)
    assertTrue(thirty.contains("ثلاثون"))
    assertTrue(thirty.contains("دينار"))

    val twoFifty = ArabicNumberToWords.convertToDinarWords(250.0)
    assertTrue(twoFifty.contains("مائتان وخمسون"))

    val thousand = ArabicNumberToWords.convertToDinarWords(1000.0)
    assertTrue(thousand.contains("ألف"))
  }

  @Test
  fun testCalculatorEvaluator() {
    val res1 = CalculatorEvaluator.evaluate("150 + 50 * 2")
    assertTrue(res1 is CalculatorEvaluator.EvaluationResult.Success)
    assertEquals("250", (res1 as CalculatorEvaluator.EvaluationResult.Success).formattedText)

    val res2 = CalculatorEvaluator.evaluate("100 / 0")
    assertTrue(res2 is CalculatorEvaluator.EvaluationResult.Error)
  }
}
