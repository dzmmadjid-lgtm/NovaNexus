package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AiEngineMode
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberDarkElevated
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun FuturisticHeader(
    title: String,
    subtitle: String,
    neuralLoad: Float = 0.42f,
    isKeyConfigured: Boolean = false,
    onSettingsClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (isKeyConfigured) NeonGreen.copy(alpha = pulseAlpha) else NeonCyan.copy(alpha = pulseAlpha))
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary,
                    letterSpacing = 0.5.sp
                )
            }
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = TextSecondary,
                modifier = Modifier.padding(start = 18.dp, top = 2.dp)
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            // Neural Core Status Indicator Badge / Key Trigger
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(CyberSurfaceVariant)
                    .border(
                        1.dp,
                        if (isKeyConfigured) NeonGreen.copy(alpha = 0.5f) else NeonCyan.copy(alpha = 0.3f),
                        RoundedCornerShape(20.dp)
                    )
                    .clickable { onSettingsClick?.invoke() }
                    .testTag("core_status_badge")
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isKeyConfigured) Icons.Default.AutoAwesome else Icons.Default.Key,
                        contentDescription = "Core Active",
                        tint = if (isKeyConfigured) NeonGreen else NeonCyan,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = if (isKeyConfigured) "LIVE GEMINI" else "API KEY",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isKeyConfigured) NeonGreen else NeonCyan
                    )
                }
            }
        }
    }
}

@Composable
fun AiModeSelector(
    activeMode: AiEngineMode,
    onModeSelected: (AiEngineMode) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        AiEngineMode.values().forEach { mode ->
            val isSelected = mode == activeMode
            val bgCol by animateColorAsState(
                targetValue = if (isSelected) CyberSurfaceVariant else CyberDarkElevated,
                label = "bg"
            )
            val borderCol by animateColorAsState(
                targetValue = if (isSelected) when (mode) {
                    AiEngineMode.FLASH -> NeonCyan
                    AiEngineMode.DEEP_LOGIC -> NeonViolet
                    AiEngineMode.CREATIVE -> NeonMagenta
                } else Color(0x22FFFFFF),
                label = "border"
            )

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(bgCol)
                    .border(1.dp, borderCol, RoundedCornerShape(12.dp))
                    .clickable { onModeSelected(mode) }
                    .testTag("mode_${mode.name.lowercase()}")
                    .padding(vertical = 8.dp, horizontal = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        val icon = when (mode) {
                            AiEngineMode.FLASH -> Icons.Default.Bolt
                            AiEngineMode.DEEP_LOGIC -> Icons.Default.Psychology
                            AiEngineMode.CREATIVE -> Icons.Default.AutoAwesome
                        }
                        val tint = when (mode) {
                            AiEngineMode.FLASH -> NeonCyan
                            AiEngineMode.DEEP_LOGIC -> NeonViolet
                            AiEngineMode.CREATIVE -> NeonMagenta
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = mode.label,
                            tint = if (isSelected) tint else TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = mode.label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) TextPrimary else TextSecondary,
                            maxLines = 1
                        )
                    }
                    Text(
                        text = mode.speed,
                        fontSize = 10.sp,
                        color = if (isSelected) NeonCyan else TextMuted
                    )
                }
            }
        }
    }
}
