package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChatMessage
import com.example.model.QuickPrompt
import com.example.ui.components.AiModeSelector
import com.example.ui.components.ChatBubble
import com.example.ui.components.FuturisticHeader
import com.example.ui.components.NeuralWaveVisualizer
import com.example.ui.theme.CyberDark
import com.example.ui.theme.CyberDarkElevated
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceVariant
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AppUiState
import com.example.viewmodel.MainViewModel

@Composable
fun StudioScreen(
    viewModel: MainViewModel,
    uiState: AppUiState,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()

    LaunchedEffect(uiState.messages.size, uiState.activeStreamTokens) {
        if (uiState.messages.isNotEmpty()) {
            listState.animateScrollToItem(uiState.messages.size)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberDark)
    ) {
        // Futuristic App Header
        FuturisticHeader(
            title = "NOVA NEXUS",
            subtitle = "Neural Studio & AI Core v3.7",
            neuralLoad = uiState.neuralLoad,
            isKeyConfigured = uiState.isApiKeyConfigured,
            onSettingsClick = { viewModel.openApiKeyDialog() }
        )

        // AI Engine Mode Tabs (Flash, Deep Logic, Creative)
        AiModeSelector(
            activeMode = uiState.activeMode,
            onModeSelected = { viewModel.setAiMode(it) }
        )

        // Quick Prompt Chips Carousel
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(viewModel.quickPrompts) { item ->
                QuickPromptChip(
                    quickPrompt = item,
                    onClick = { viewModel.useQuickPrompt(item) }
                )
            }
        }

        // Chat & Generation Stream Area
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 16.dp, top = 8.dp)
            ) {
                items(uiState.messages, key = { it.id }) { msg ->
                    ChatBubble(message = msg)
                }

                // Streaming in-progress bubble
                if (uiState.isGenerating && uiState.activeStreamTokens.isNotEmpty()) {
                    item {
                        ChatBubble(
                            message = ChatMessage(
                                id = "streaming_token",
                                text = uiState.activeStreamTokens + " ▋",
                                isUser = false,
                                modelName = uiState.activeMode.label,
                                isStreaming = true
                            )
                        )
                    }
                } else if (uiState.isGenerating) {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = NeonCyan,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "جاري التفكير والتوليد العصبي...",
                                fontSize = 12.sp,
                                color = NeonCyan
                            )
                        }
                    }
                }
            }
        }

        // Animated Audio Wave when active
        AnimatedVisibility(
            visible = uiState.activeAudioWave,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            NeuralWaveVisualizer(isActive = uiState.activeAudioWave)
        }

        // Glowing Prompt Input Dock
        PromptInputDock(
            inputText = uiState.inputText,
            onTextChanged = { viewModel.onInputTextChanged(it) },
            onSend = { viewModel.sendMessage() },
            isGenerating = uiState.isGenerating,
            isAudioActive = uiState.activeAudioWave,
            onToggleAudio = { viewModel.toggleAudioWave() },
            onClearHistory = { viewModel.clearHistory() }
        )
    }

    // API Key Dialog
    if (uiState.showApiKeyDialog) {
        ApiKeyConfigDialog(
            currentKey = uiState.apiKeyInputValue,
            onKeyChanged = { viewModel.onApiKeyInputChanged(it) },
            onSave = { viewModel.saveCustomApiKey(it) },
            onDismiss = { viewModel.closeApiKeyDialog() }
        )
    }
}

@Composable
fun ApiKeyConfigDialog(
    currentKey: String,
    onKeyChanged: (String) -> Unit,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CyberDarkElevated,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Key,
                    contentDescription = null,
                    tint = NeonCyan,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "مفتاح Gemini API",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column {
                Text(
                    text = "للحصول على أقصى ذكاء وتنوع غير محدود، يمكنك وضع مفتاح Gemini API الخاص بك مجاناً من Google AI Studio:",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
                Spacer(modifier = Modifier.height(14.dp))
                OutlinedTextField(
                    value = currentKey,
                    onValueChange = onKeyChanged,
                    placeholder = { Text("AIzaSy...", color = TextMuted, fontSize = 13.sp) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("api_key_input_field"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = CyberSurfaceVariant,
                        focusedContainerColor = CyberSurface,
                        unfocusedContainerColor = CyberSurface,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "💡 إذا تركته فارغاً، سيعمل التطبيق بالمحرك الذكي الديناميكي الداخلي.",
                    color = NeonAmber,
                    fontSize = 11.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(currentKey) },
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("save_api_key_btn")
            ) {
                Text("حفظ وتفعيل", color = CyberDark, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = TextMuted)
            }
        }
    )
}

@Composable
fun QuickPromptChip(
    quickPrompt: QuickPrompt,
    onClick: () -> Unit
) {
    val chipColor = Color(quickPrompt.colorHex)
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CyberSurface)
            .border(1.dp, chipColor.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag("chip_${quickPrompt.id}")
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(chipColor)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = quickPrompt.arabicTitle,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = TextPrimary
            )
        }
    }
}

@Composable
fun PromptInputDock(
    inputText: String,
    onTextChanged: (String) -> Unit,
    onSend: () -> Unit,
    isGenerating: Boolean,
    isAudioActive: Boolean,
    onToggleAudio: () -> Unit,
    onClearHistory: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberDarkElevated)
            .border(1.dp, CyberSurfaceVariant, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Clear History Button
            IconButton(
                onClick = onClearHistory,
                modifier = Modifier
                    .size(38.dp)
                    .testTag("clear_history_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "Clear History",
                    tint = TextMuted,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Audio Wave / Voice Trigger Button
            IconButton(
                onClick = onToggleAudio,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(if (isAudioActive) NeonMagenta.copy(alpha = 0.2f) else Color.Transparent)
                    .testTag("mic_toggle_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Voice Input",
                    tint = if (isAudioActive) NeonMagenta else NeonCyan,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Main Input Text Field
            OutlinedTextField(
                value = inputText,
                onValueChange = onTextChanged,
                placeholder = {
                    Text(
                        text = if (isAudioActive) "جاري الاستماع للنبض الصوتي..." else "اكتب فكرتك أو استفسارك هنا...",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("prompt_input_field"),
                shape = RoundedCornerShape(20.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = Color(0x33FFFFFF),
                    focusedContainerColor = CyberSurface,
                    unfocusedContainerColor = CyberSurface,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                maxLines = 3
            )

            Spacer(modifier = Modifier.width(6.dp))

            // Glowing Send Button
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(if (inputText.trim().isNotEmpty() && !isGenerating) NeonCyan else CyberSurfaceVariant)
                    .clickable(enabled = inputText.trim().isNotEmpty() && !isGenerating) {
                        onSend()
                    }
                    .testTag("send_prompt_btn"),
                contentAlignment = Alignment.Center
            ) {
                if (isGenerating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(20.dp),
                        color = NeonCyan,
                        strokeWidth = 2.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send",
                        tint = if (inputText.trim().isNotEmpty()) CyberDark else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
