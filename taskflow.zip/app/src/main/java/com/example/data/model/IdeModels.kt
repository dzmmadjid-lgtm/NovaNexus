package com.example.data.model

import java.io.File

data class Project(
    val name: String,
    val rootDir: File,
    val packageName: String,
    val minSdk: Int = 24,
    val targetSdk: Int = 36,
    val template: String = "Compose Empty Activity"
)

data class FileNode(
    val file: File,
    val name: String,
    val isDirectory: Boolean,
    val children: List<FileNode> = emptyList(),
    val extension: String = "",
    val isExpanded: Boolean = false
)

data class EditorTab(
    val file: File,
    val title: String,
    val content: String,
    val isDirty: Boolean = false,
    val cursorLine: Int = 1,
    val cursorCol: Int = 1,
    val undoStack: List<String> = emptyList(),
    val redoStack: List<String> = emptyList()
)

enum class BuildStatus {
    IDLE,
    RUNNING,
    SUCCESS,
    FAILED,
    CANCELLED
}

data class BuildLogEntry(
    val message: String,
    val isError: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class ProblemItem(
    val file: File?,
    val relativePath: String,
    val line: Int,
    val column: Int,
    val message: String,
    val isError: Boolean = true
)

data class BuildResult(
    val status: BuildStatus,
    val durationMs: Long,
    val exitCode: Int,
    val apkFile: File? = null,
    val apkSize: Long = 0,
    val logs: List<BuildLogEntry> = emptyList(),
    val problems: List<ProblemItem> = emptyList()
)

enum class ThemeMode {
    DARK,
    LIGHT,
    OLED
}

enum class BottomToolWindow {
    BUILD_OUTPUT,
    PROBLEMS,
    TERMINAL,
    GIT,
    AI_ASSISTANT
}

data class SearchResult(
    val file: File,
    val relativePath: String,
    val lineNumber: Int,
    val lineContent: String
)
