package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.editor.CodeSyntaxHighlighter
import com.example.data.model.*
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IdeMainScreen(viewModel: IdeViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val themeMode by viewModel.themeMode.collectAsState()
    val projects by viewModel.projects.collectAsState()
    val currentProject by viewModel.currentProject.collectAsState()
    val fileTree by viewModel.fileTree.collectAsState()
    val openTabs by viewModel.openTabs.collectAsState()
    val activeTabIndex by viewModel.activeTabIndex.collectAsState()
    val activeToolWindow by viewModel.activeToolWindow.collectAsState()
    val isToolWindowExpanded by viewModel.isToolWindowExpanded.collectAsState()
    val showProjectsDialog by viewModel.showProjectsDialog.collectAsState()
    val buildStatus by viewModel.buildStatus.collectAsState()
    val buildLogs by viewModel.buildLogs.collectAsState()
    val problems by viewModel.problems.collectAsState()
    val buildResult by viewModel.buildResult.collectAsState()
    val jdkInfo by viewModel.jdkInfo.collectAsState()

    // File Tree Context Actions
    var showNewFileDialog by remember { mutableStateOf<File?>(null) }
    var showNewFolderDialog by remember { mutableStateOf<File?>(null) }
    var showRenameDialog by remember { mutableStateOf<File?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf<File?>(null) }

    var newFileName by remember { mutableStateOf("") }
    var newFolderName by remember { mutableStateOf("") }
    var renameTargetName by remember { mutableStateOf("") }

    val activeTab = if (activeTabIndex in openTabs.indices) openTabs[activeTabIndex] else null

    // Launcher for ZIP import
    val zipPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                if (inputStream != null) {
                    val fallbackName = uri.lastPathSegment?.substringAfterLast('/')?.removeSuffix(".zip") ?: "ImportedProject"
                    viewModel.importProjectFromZip(inputStream, fallbackName)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier
                    .widthIn(max = 320.dp)
                    .fillMaxHeight(),
                drawerContainerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Drawer Header
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Code,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = currentProject?.name ?: "DroidIDE",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 17.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = currentProject?.packageName ?: "No project selected",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Quick Project Switcher / New Project Button
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilledTonalButton(
                                    onClick = {
                                        coroutineScope.launch { drawerState.close() }
                                        viewModel.setShowProjectsDialog(true)
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Projects", fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        coroutineScope.launch { drawerState.close() }
                                        zipPickerLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
                                    },
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("ZIP", fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // Explorer Title & Actions
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PROJECT FILES",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Row {
                            IconButton(
                                modifier = Modifier.size(28.dp),
                                onClick = {
                                    showNewFileDialog = currentProject?.rootDir
                                    newFileName = ""
                                }
                            ) {
                                Icon(Icons.Default.NoteAdd, contentDescription = "New File", modifier = Modifier.size(16.dp))
                            }
                            IconButton(
                                modifier = Modifier.size(28.dp),
                                onClick = {
                                    showNewFolderDialog = currentProject?.rootDir
                                    newFolderName = ""
                                }
                            ) {
                                Icon(Icons.Default.CreateNewFolder, contentDescription = "New Folder", modifier = Modifier.size(16.dp))
                            }
                            IconButton(
                                modifier = Modifier.size(28.dp),
                                onClick = { viewModel.refreshFileTree() }
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "Refresh", modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    HorizontalDivider()

                    // Project Files Tree
                    val tree = fileTree
                    if (tree != null) {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(vertical = 4.dp)
                        ) {
                            items(tree.children) { childNode ->
                                FileTreeNodeItem(
                                    node = childNode,
                                    depth = 0,
                                    activeFilePath = activeTab?.file?.absolutePath,
                                    onFileClick = { file ->
                                        viewModel.openFile(file)
                                        coroutineScope.launch { drawerState.close() }
                                    },
                                    onNewFile = { dir ->
                                        showNewFileDialog = dir
                                        newFileName = ""
                                    },
                                    onNewFolder = { dir ->
                                        showNewFolderDialog = dir
                                        newFolderName = ""
                                    },
                                    onRename = { file ->
                                        showRenameDialog = file
                                        renameTargetName = file.name
                                    },
                                    onDelete = { file ->
                                        showDeleteConfirmDialog = file
                                    }
                                )
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Loading tree...", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { viewModel.setShowProjectsDialog(true) }
                        ) {
                            Icon(
                                Icons.Default.Folder,
                                contentDescription = null,
                                tint = Color(0xFFFFCA28),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = currentProject?.name ?: "DroidIDE",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Projects")

                            Spacer(modifier = Modifier.width(6.dp))

                            // Build Status Indicator
                            when (buildStatus) {
                                BuildStatus.RUNNING -> {
                                    AssistChip(
                                        onClick = { viewModel.setActiveToolWindow(BottomToolWindow.BUILD_OUTPUT) },
                                        label = { Text("Building...", fontSize = 10.sp) },
                                        leadingIcon = {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(10.dp),
                                                strokeWidth = 2.dp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    )
                                }
                                BuildStatus.SUCCESS -> {
                                    AssistChip(
                                        onClick = { viewModel.setActiveToolWindow(BottomToolWindow.BUILD_OUTPUT) },
                                        label = { Text("Success", fontSize = 10.sp) },
                                        leadingIcon = {
                                            Icon(
                                                Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = Color(0xFF4CAF50),
                                                modifier = Modifier.size(12.dp)
                                            )
                                        }
                                    )
                                }
                                BuildStatus.FAILED -> {
                                    AssistChip(
                                        onClick = { viewModel.setActiveToolWindow(BottomToolWindow.BUILD_OUTPUT) },
                                        label = { Text("Failed", fontSize = 10.sp) },
                                        leadingIcon = {
                                            Icon(
                                                Icons.Default.Error,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(12.dp)
                                            )
                                        }
                                    )
                                }
                                else -> {}
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            coroutineScope.launch {
                                if (drawerState.isOpen) drawerState.close() else drawerState.open()
                            }
                        }) {
                            Icon(Icons.Default.Menu, contentDescription = "Open Drawer")
                        }
                    },
                    actions = {
                        // Assemble Debug / Play Button
                        if (buildStatus == BuildStatus.RUNNING) {
                            IconButton(onClick = { viewModel.cancelBuild() }) {
                                Icon(
                                    Icons.Default.Stop,
                                    contentDescription = "Cancel Build",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        } else {
                            IconButton(onClick = { viewModel.startBuild(listOf("assembleDebug")) }) {
                                Icon(
                                    Icons.Default.PlayArrow,
                                    contentDescription = "Run assembleDebug",
                                    tint = Color(0xFF4CAF50)
                                )
                            }
                        }

                        // Clean & Build
                        IconButton(onClick = { viewModel.cleanBuild() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Clean & Build")
                        }

                        // Projects Manager
                        IconButton(onClick = { viewModel.setShowProjectsDialog(true) }) {
                            Icon(Icons.Default.FolderOpen, contentDescription = "Projects")
                        }

                        // Save File
                        IconButton(
                            onClick = { viewModel.saveCurrentFile() },
                            enabled = activeTab?.isDirty == true
                        ) {
                            Icon(
                                Icons.Default.Save,
                                contentDescription = "Save File",
                                tint = if (activeTab?.isDirty == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                            )
                        }

                        // Theme Toggle (Dark / OLED / Light)
                        IconButton(onClick = { viewModel.toggleTheme() }) {
                            val icon = when (themeMode) {
                                ThemeMode.DARK -> Icons.Default.DarkMode
                                ThemeMode.OLED -> Icons.Default.Brightness4
                                ThemeMode.LIGHT -> Icons.Default.Brightness7
                            }
                            Icon(icon, contentDescription = "Toggle Theme")
                        }

                        // Terminal / Output Toggle
                        IconButton(onClick = { viewModel.toggleToolWindow() }) {
                            Icon(Icons.Default.Terminal, contentDescription = "Toggle Tools")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                // Main Editor Area (Full Width on mobile)
                Column(
                    modifier = Modifier
                        .weight(if (isToolWindowExpanded) 0.6f else 1f)
                        .fillMaxWidth()
                ) {
                    // Open Tabs Row
                    if (openTabs.isNotEmpty()) {
                        ScrollableTabRow(
                            selectedTabIndex = activeTabIndex.coerceAtLeast(0),
                            edgePadding = 8.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp),
                            divider = { HorizontalDivider() }
                        ) {
                            openTabs.forEachIndexed { index, tab ->
                                Tab(
                                    selected = activeTabIndex == index,
                                    onClick = { viewModel.selectTab(index) },
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = tab.title + if (tab.isDirty) " •" else "",
                                                fontSize = 12.sp,
                                                fontWeight = if (activeTabIndex == index) FontWeight.SemiBold else FontWeight.Normal,
                                                maxLines = 1
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                Icons.Default.Close,
                                                contentDescription = "Close Tab",
                                                modifier = Modifier
                                                    .size(14.dp)
                                                    .clickable { viewModel.closeTab(index) }
                                            )
                                        }
                                    }
                                )
                            }
                        }
                    }

                    // Active Editor or Empty State
                    if (activeTab != null) {
                        EditorContent(
                            tab = activeTab,
                            themeMode = themeMode,
                            onContentChange = { newContent ->
                                viewModel.updateActiveTabContent(newContent)
                            }
                        )
                    } else {
                        // Empty State Welcome
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(MaterialTheme.colorScheme.background)
                                .padding(20.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Icon(
                                    Icons.Default.Code,
                                    contentDescription = null,
                                    modifier = Modifier.size(56.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "DroidIDE Android Studio",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Open files from the side menu or start a build.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Button(
                                    onClick = { coroutineScope.launch { drawerState.open() } },
                                    modifier = Modifier.fillMaxWidth(0.8f)
                                ) {
                                    Icon(Icons.Default.Folder, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Open Project Files")
                                }

                                FilledTonalButton(
                                    onClick = { viewModel.startBuild(listOf("assembleDebug")) },
                                    modifier = Modifier.fillMaxWidth(0.8f)
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF4CAF50))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Build APK (assembleDebug)")
                                }

                                OutlinedButton(
                                    onClick = { viewModel.setShowProjectsDialog(true) },
                                    modifier = Modifier.fillMaxWidth(0.8f)
                                ) {
                                    Icon(Icons.Default.Layers, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Manage Projects")
                                }
                            }
                        }
                    }
                }

                // Bottom Tool Window (Terminal / Build Output / Problems)
                AnimatedVisibility(visible = isToolWindowExpanded) {
                    Surface(
                        modifier = Modifier
                            .weight(0.4f)
                            .fillMaxWidth(),
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 4.dp
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            // Header Tabs
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .padding(horizontal = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.horizontalScroll(rememberScrollState())
                                ) {
                                    ToolWindowHeaderChip(
                                        title = "Build Output",
                                        icon = Icons.Default.Terminal,
                                        isSelected = activeToolWindow == BottomToolWindow.BUILD_OUTPUT,
                                        onClick = { viewModel.setActiveToolWindow(BottomToolWindow.BUILD_OUTPUT) }
                                    )
                                    ToolWindowHeaderChip(
                                        title = "Problems (${problems.size})",
                                        icon = Icons.Default.Warning,
                                        isSelected = activeToolWindow == BottomToolWindow.PROBLEMS,
                                        onClick = { viewModel.setActiveToolWindow(BottomToolWindow.PROBLEMS) },
                                        badgeColor = if (problems.isNotEmpty()) MaterialTheme.colorScheme.error else null
                                    )
                                    ToolWindowHeaderChip(
                                        title = "Terminal",
                                        icon = Icons.Default.Code,
                                        isSelected = activeToolWindow == BottomToolWindow.TERMINAL,
                                        onClick = { viewModel.setActiveToolWindow(BottomToolWindow.TERMINAL) }
                                    )
                                    ToolWindowHeaderChip(
                                        title = "AI Assistant",
                                        icon = Icons.Default.AutoAwesome,
                                        isSelected = activeToolWindow == BottomToolWindow.AI_ASSISTANT,
                                        onClick = { viewModel.setActiveToolWindow(BottomToolWindow.AI_ASSISTANT) }
                                    )
                                }
                                IconButton(onClick = { viewModel.toggleToolWindow() }) {
                                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Collapse Tools")
                                }
                            }
                            HorizontalDivider()

                            Box(modifier = Modifier.fillMaxSize()) {
                                when (activeToolWindow) {
                                    BottomToolWindow.BUILD_OUTPUT -> {
                                        BuildOutputView(logs = buildLogs, result = buildResult)
                                    }
                                    BottomToolWindow.PROBLEMS -> {
                                        ProblemsListView(
                                            problems = problems,
                                            onProblemClick = { problem -> viewModel.jumpToProblem(problem) }
                                        )
                                    }
                                    BottomToolWindow.TERMINAL -> {
                                        TerminalView(jdkInfo = jdkInfo)
                                    }
                                    BottomToolWindow.AI_ASSISTANT -> {
                                        AiAssistantView(problems = problems)
                                    }
                                    else -> {
                                        BuildOutputView(logs = buildLogs, result = buildResult)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Projects Manager Dialog
    if (showProjectsDialog) {
        ProjectsManagerDialog(
            currentProject = currentProject,
            projects = projects,
            onSelectProject = { proj -> viewModel.openProject(proj); viewModel.setShowProjectsDialog(false) },
            onCreateProject = { name, pkg -> viewModel.createNewProject(name, pkg) },
            onImportZipClick = {
                zipPickerLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
            },
            onDeleteProject = { proj -> viewModel.deleteProject(proj) },
            onDismiss = { viewModel.setShowProjectsDialog(false) }
        )
    }

    // New File Dialog
    if (showNewFileDialog != null) {
        val parent = showNewFileDialog!!
        AlertDialog(
            onDismissRequest = { showNewFileDialog = null },
            title = { Text("New File") },
            text = {
                Column {
                    Text("Enter file name (e.g. MyComponent.kt):", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newFileName,
                        onValueChange = { newFileName = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newFileName.isNotBlank()) {
                            viewModel.createFile(parent, newFileName.trim())
                            showNewFileDialog = null
                        }
                    }
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewFileDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // New Folder Dialog
    if (showNewFolderDialog != null) {
        val parent = showNewFolderDialog!!
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = null },
            title = { Text("New Directory") },
            text = {
                Column {
                    Text("Enter directory name:", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newFolderName,
                        onValueChange = { newFolderName = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newFolderName.isNotBlank()) {
                            viewModel.createFolder(parent, newFolderName.trim())
                            showNewFolderDialog = null
                        }
                    }
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolderDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Rename Dialog
    if (showRenameDialog != null) {
        val target = showRenameDialog!!
        AlertDialog(
            onDismissRequest = { showRenameDialog = null },
            title = { Text("Rename") },
            text = {
                OutlinedTextField(
                    value = renameTargetName,
                    onValueChange = { renameTargetName = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (renameTargetName.isNotBlank()) {
                            viewModel.renameItem(target, renameTargetName.trim())
                            showRenameDialog = null
                        }
                    }
                ) {
                    Text("Rename")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete Confirm Dialog
    if (showDeleteConfirmDialog != null) {
        val target = showDeleteConfirmDialog!!
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = null },
            title = { Text("Delete Confirmation") },
            text = { Text("Are you sure you want to delete '${target.name}'? This cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteItem(target)
                        showDeleteConfirmDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ProjectsManagerDialog(
    currentProject: Project?,
    projects: List<Project>,
    onSelectProject: (Project) -> Unit,
    onCreateProject: (String, String) -> Unit,
    onImportZipClick: () -> Unit,
    onDeleteProject: (Project) -> Unit,
    onDismiss: () -> Unit
) {
    var isCreatingNew by remember { mutableStateOf(false) }
    var newProjName by remember { mutableStateOf("MyAwesomeApp") }
    var newPkgName by remember { mutableStateOf("com.example.myawesomeapp") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Layers, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Projects (المشاريع)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
            ) {
                if (isCreatingNew) {
                    Text("Create New Android Project", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = newProjName,
                        onValueChange = {
                            newProjName = it
                            newPkgName = "com.example.${it.lowercase().replace(Regex("[^a-zA-Z0-9]"), "")}"
                        },
                        label = { Text("Project Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newPkgName,
                        onValueChange = { newPkgName = it },
                        label = { Text("Package Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { isCreatingNew = false }) {
                            Text("Back")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                if (newProjName.isNotBlank() && newPkgName.isNotBlank()) {
                                    onCreateProject(newProjName.trim(), newPkgName.trim())
                                }
                            }
                        ) {
                            Text("Create Project")
                        }
                    }
                } else {
                    // Action Buttons Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilledTonalButton(
                            onClick = { isCreatingNew = true },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New Project", fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = onImportZipClick,
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Import ZIP", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Available Projects (${projects.size}):", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(6.dp))

                    if (projects.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No projects yet. Click 'New Project' or 'Import ZIP'.", fontSize = 12.sp)
                        }
                    } else {
                        LazyColumn(modifier = Modifier.fillMaxWidth()) {
                            items(projects) { proj ->
                                val isCurrent = proj.rootDir.absolutePath == currentProject?.rootDir?.absolutePath
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clickable { onSelectProject(proj) },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isCurrent) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                                        else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = proj.name,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp
                                                )
                                                if (isCurrent) {
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = "(Active)",
                                                        fontSize = 11.sp,
                                                        color = MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }
                                            Text(
                                                text = proj.packageName,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }

                                        IconButton(
                                            onClick = { onDeleteProject(proj) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Delete,
                                                contentDescription = "Delete",
                                                tint = MaterialTheme.colorScheme.error.copy(alpha = 0.7f),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun FileTreeNodeItem(
    node: FileNode,
    depth: Int,
    activeFilePath: String?,
    onFileClick: (File) -> Unit,
    onNewFile: (File) -> Unit,
    onNewFolder: (File) -> Unit,
    onRename: (File) -> Unit,
    onDelete: (File) -> Unit
) {
    var isExpanded by remember { mutableStateOf(depth < 2) }
    val isSelected = activeFilePath == node.file.absolutePath

    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                    else Color.Transparent
                )
                .clickable {
                    if (node.isDirectory) {
                        isExpanded = !isExpanded
                    } else {
                        onFileClick(node.file)
                    }
                }
                .padding(start = (depth * 14 + 8).dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (node.isDirectory) {
                Icon(
                    imageVector = if (isExpanded) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowRight,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.Folder,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = Color(0xFFFFCA28)
                )
            } else {
                Spacer(modifier = Modifier.width(16.dp))
                val extColor = when (node.extension) {
                    "kt", "kts" -> Color(0xFF7F52FF)
                    "java" -> Color(0xFFF44336)
                    "xml" -> Color(0xFF4CAF50)
                    "gradle" -> Color(0xFF02569B)
                    "json" -> Color(0xFFFF9800)
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
                Icon(
                    imageVector = Icons.Default.InsertDriveFile,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = extColor
                )
            }

            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = node.name,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
        }

        if (node.isDirectory && isExpanded) {
            for (child in node.children) {
                FileTreeNodeItem(
                    node = child,
                    depth = depth + 1,
                    activeFilePath = activeFilePath,
                    onFileClick = onFileClick,
                    onNewFile = onNewFile,
                    onNewFolder = onNewFolder,
                    onRename = onRename,
                    onDelete = onDelete
                )
            }
        }
    }
}

@Composable
fun EditorContent(
    tab: EditorTab,
    themeMode: ThemeMode,
    onContentChange: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    val lines = remember(tab.content) { tab.content.lines() }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Line Numbers Gutter
        Column(
            modifier = Modifier
                .width(38.dp)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f))
                .verticalScroll(scrollState)
                .padding(vertical = 8.dp, horizontal = 2.dp),
            horizontalAlignment = Alignment.End
        ) {
            for (i in 1..lines.size) {
                Text(
                    text = "$i",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    lineHeight = 18.sp
                )
            }
        }

        HorizontalDivider(modifier = Modifier.fillMaxHeight().width(1.dp))

        // Code Editor Text Area
        Box(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .horizontalScroll(rememberScrollState())
                .padding(8.dp)
        ) {
            BasicTextField(
                value = tab.content,
                onValueChange = onContentChange,
                textStyle = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    color = MaterialTheme.colorScheme.onBackground
                ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun ToolWindowHeaderChip(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    badgeColor: Color? = null
) {
    Surface(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        shape = MaterialTheme.shapes.small,
        color = if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier.size(14.dp),
                tint = if (badgeColor != null) badgeColor
                else if (isSelected) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                color = if (badgeColor != null) badgeColor
                else if (isSelected) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun BuildOutputView(logs: List<BuildLogEntry>, result: BuildResult?) {
    val listState = rememberLazyListState()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        if (result != null) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = if (result.status == BuildStatus.SUCCESS) Color(0xFF1B5E20).copy(alpha = 0.2f)
                else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (result.status == BuildStatus.SUCCESS) "BUILD SUCCESSFUL (${result.durationMs / 1000}s)"
                        else "BUILD FAILED (exit code: ${result.exitCode})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = if (result.status == BuildStatus.SUCCESS) Color(0xFF4CAF50) else MaterialTheme.colorScheme.error
                    )
                    if (result.apkFile != null) {
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "APK: ${result.apkFile.name} (${result.apkSize / 1024} KB)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF121212))
                .padding(8.dp)
        ) {
            items(logs) { entry ->
                Text(
                    text = entry.message,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = if (entry.isError) Color(0xFFEF5350) else Color(0xFFB0BEC5),
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
fun ProblemsListView(problems: List<ProblemItem>, onProblemClick: (ProblemItem) -> Unit) {
    if (problems.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No compile problems found.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        LazyColumn(modifier = Modifier.fillMaxSize().padding(8.dp)) {
            items(problems) { problem ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onProblemClick(problem) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (problem.isError) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (problem.isError) Icons.Default.Error else Icons.Default.Warning,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (problem.isError) MaterialTheme.colorScheme.error else Color(0xFFFFB74D)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${problem.relativePath}:${problem.line}:${problem.column}",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = problem.message,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TerminalView(jdkInfo: JdkInfo?) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E1E1E))
            .padding(12.dp)
    ) {
        Text("DroidIDE Embedded Terminal Engine", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF81C784))
        Spacer(modifier = Modifier.height(4.dp))
        Text("JDK Status: ${if (jdkInfo?.isAvailable == true) "Available" else "Ready"}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.White)
        Text("Version: ${jdkInfo?.javaVersion ?: "OpenJDK 17.0.20.1"}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.LightGray)
        Text("Architecture: ${jdkInfo?.architecture ?: "arm64-v8a"}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.LightGray)
        Text("Target Platform: ${jdkInfo?.targetPlatform ?: "Android 16"}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.LightGray)
        Spacer(modifier = Modifier.height(8.dp))
        Text("$ ./gradlew assembleDebug --info", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFF64B5F6))
        Text("Ready for build tasks.", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.Gray)
    }
}

@Composable
fun AiAssistantView(problems: List<ProblemItem>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("DroidIDE AI Code Assistant", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Spacer(modifier = Modifier.height(8.dp))
        if (problems.isNotEmpty()) {
            Text(
                text = "Detected ${problems.size} issue(s) during last build. Suggestions:",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            problems.take(3).forEach { p ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(text = "Issue in ${p.relativePath} (line ${p.line}):", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                        Text(text = p.message, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        } else {
            Text(
                text = "No compile issues detected. You can use DroidIDE to build, edit, and export your Android apps directly on your device.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
