package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.editor.CodeSyntaxHighlighter
import com.example.data.model.*
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IdeMainScreen(viewModel: IdeViewModel) {
    val themeMode by viewModel.themeMode.collectAsState()
    val currentProject by viewModel.currentProject.collectAsState()
    val fileTree by viewModel.fileTree.collectAsState()
    val openTabs by viewModel.openTabs.collectAsState()
    val activeTabIndex by viewModel.activeTabIndex.collectAsState()
    val activeToolWindow by viewModel.activeToolWindow.collectAsState()
    val isToolWindowExpanded by viewModel.isToolWindowExpanded.collectAsState()
    val isFileExplorerVisible by viewModel.isFileExplorerVisible.collectAsState()
    val buildStatus by viewModel.buildStatus.collectAsState()
    val buildLogs by viewModel.buildLogs.collectAsState()
    val problems by viewModel.problems.collectAsState()
    val buildResult by viewModel.buildResult.collectAsState()
    val jdkInfo by viewModel.jdkInfo.collectAsState()

    // Dialog States
    var showNewFileDialog by remember { mutableStateOf<File?>(null) }
    var showNewFolderDialog by remember { mutableStateOf<File?>(null) }
    var showRenameDialog by remember { mutableStateOf<File?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf<File?>(null) }

    var newFileName by remember { mutableStateOf("") }
    var newFolderName by remember { mutableStateOf("") }
    var renameTargetName by remember { mutableStateOf("") }

    val activeTab = if (activeTabIndex in openTabs.indices) openTabs[activeTabIndex] else null

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = currentProject?.name ?: "DroidIDE",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        // Build Status Chip
                        when (buildStatus) {
                            BuildStatus.RUNNING -> {
                                AssistChip(
                                    onClick = { },
                                    label = { Text("Building...", fontSize = 11.sp) },
                                    leadingIcon = {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(12.dp),
                                            strokeWidth = 2.dp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    },
                                    colors = AssistChipDefaults.assistChipColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                                    )
                                )
                            }
                            BuildStatus.SUCCESS -> {
                                AssistChip(
                                    onClick = { },
                                    label = { Text("Build Success", fontSize = 11.sp) },
                                    leadingIcon = {
                                        Icon(
                                            Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = Color(0xFF4CAF50),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                )
                            }
                            BuildStatus.FAILED -> {
                                AssistChip(
                                    onClick = { },
                                    label = { Text("Build Failed", fontSize = 11.sp) },
                                    leadingIcon = {
                                        Icon(
                                            Icons.Default.Error,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                )
                            }
                            else -> {}
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.toggleFileExplorer() }) {
                        Icon(Icons.Default.Menu, contentDescription = "Toggle Explorer")
                    }
                },
                actions = {
                    // Run / Assemble Debug
                    if (buildStatus == BuildStatus.RUNNING) {
                        IconButton(onClick = { viewModel.cancelBuild() }) {
                            Icon(
                                Icons.Default.Stop,
                                contentDescription = "Cancel Build",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    } else {
                        IconButton(onClick = { viewModel.startBuild(listOf("assembleDebug")) }) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = "Run assembleDebug",
                                tint = Color(0xFF4CAF50)
                            )
                        }
                    }

                    // Clean & Build
                    IconButton(onClick = { viewModel.cleanBuild() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Clean & Build")
                    }

                    // Save
                    IconButton(
                        onClick = { viewModel.saveCurrentFile() },
                        enabled = activeTab?.isDirty == true
                    ) {
                        Icon(
                            Icons.Default.Save,
                            contentDescription = "Save File",
                            tint = if (activeTab?.isDirty == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                        )
                    }

                    // Theme Toggle (Dark / OLED / Light)
                    IconButton(onClick = { viewModel.toggleTheme() }) {
                        val icon = when (themeMode) {
                            ThemeMode.DARK -> Icons.Default.DarkMode
                            ThemeMode.OLED -> Icons.Default.Brightness4
                            ThemeMode.LIGHT -> Icons.Default.Brightness7
                        }
                        Icon(icon, contentDescription = "Toggle Theme")
                    }

                    // Toggle Tool Window
                    IconButton(onClick = { viewModel.toggleToolWindow() }) {
                        Icon(Icons.Default.Terminal, contentDescription = "Toggle Tools")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Main workspace (File Explorer + Editor)
            Row(
                modifier = Modifier
                    .weight(if (isToolWindowExpanded) 0.65f else 0.95f)
                    .fillMaxWidth()
            ) {
                // Left Panel: File Explorer
                AnimatedVisibility(visible = isFileExplorerVisible) {
                    Surface(
                        modifier = Modifier
                            .width(260.dp)
                            .fillMaxHeight(),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        tonalElevation = 2.dp
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            // Explorer Header
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "PROJECT FILES",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Row {
                                    IconButton(
                                        modifier = Modifier.size(28.dp),
                                        onClick = {
                                            showNewFileDialog = currentProject?.rootDir
                                            newFileName = ""
                                        }
                                    ) {
                                        Icon(Icons.Default.NoteAdd, contentDescription = "New File", modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(
                                        modifier = Modifier.size(28.dp),
                                        onClick = {
                                            showNewFolderDialog = currentProject?.rootDir
                                            newFolderName = ""
                                        }
                                    ) {
                                        Icon(Icons.Default.CreateNewFolder, contentDescription = "New Folder", modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(
                                        modifier = Modifier.size(28.dp),
                                        onClick = { viewModel.refreshFileTree() }
                                    ) {
                                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                            Divider()

                            // File Tree
                            val tree = fileTree
                            if (tree != null) {
                                LazyColumn(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(vertical = 4.dp)
                                ) {
                                    items(tree.children) { childNode ->
                                        FileTreeNodeItem(
                                            node = childNode,
                                            depth = 0,
                                            activeFilePath = activeTab?.file?.absolutePath,
                                            onFileClick = { file -> viewModel.openFile(file) },
                                            onNewFile = { dir ->
                                                showNewFileDialog = dir
                                                newFileName = ""
                                            },
                                            onNewFolder = { dir ->
                                                showNewFolderDialog = dir
                                                newFolderName = ""
                                            },
                                            onRename = { file ->
                                                showRenameDialog = file
                                                renameTargetName = file.name
                                            },
                                            onDelete = { file ->
                                                showDeleteConfirmDialog = file
                                            }
                                        )
                                    }
                                }
                            } else {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("Loading tree...", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }

                // Right Panel: Editor Area
                Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    // Editor Tabs
                    if (openTabs.isNotEmpty()) {
                        ScrollableTabRow(
                            selectedTabIndex = activeTabIndex.coerceAtLeast(0),
                            edgePadding = 0.dp,
                            modifier = Modifier.fillMaxWidth().height(42.dp),
                            divider = { Divider() }
                        ) {
                            openTabs.forEachIndexed { index, tab ->
                                Tab(
                                    selected = activeTabIndex == index,
                                    onClick = { viewModel.selectTab(index) },
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = tab.title + if (tab.isDirty) " •" else "",
                                                fontSize = 13.sp,
                                                fontWeight = if (activeTabIndex == index) FontWeight.SemiBold else FontWeight.Normal,
                                                maxLines = 1
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                Icons.Default.Close,
                                                contentDescription = "Close Tab",
                                                modifier = Modifier
                                                    .size(14.dp)
                                                    .clickable { viewModel.closeTab(index) }
                                            )
                                        }
                                    }
                                )
                            }
                        }
                    }

                    // Active Editor or Empty State
                    if (activeTab != null) {
                        EditorContent(
                            tab = activeTab,
                            themeMode = themeMode,
                            onContentChange = { newContent ->
                                viewModel.updateActiveTabContent(newContent)
                            }
                        )
                    } else {
                        // Empty State Welcome
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(MaterialTheme.colorScheme.background),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    Icons.Default.Code,
                                    contentDescription = null,
                                    modifier = Modifier.size(64.dp),
                                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                                )
                                Text(
                                    text = "DroidIDE Android Development Studio",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Select a source file on the left to edit code, or click Run to build APK.",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Button(onClick = { viewModel.startBuild(listOf("assembleDebug")) }) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Build APK (assembleDebug)")
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Tool Window
            AnimatedVisibility(visible = isToolWindowExpanded) {
                Surface(
                    modifier = Modifier
                        .weight(0.35f)
                        .fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Tool Window Tabs Header
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                .padding(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                ToolWindowHeaderChip(
                                    title = "Build Output",
                                    icon = Icons.Default.Terminal,
                                    isSelected = activeToolWindow == BottomToolWindow.BUILD_OUTPUT,
                                    onClick = { viewModel.setActiveToolWindow(BottomToolWindow.BUILD_OUTPUT) }
                                )
                                ToolWindowHeaderChip(
                                    title = "Problems (${problems.size})",
                                    icon = Icons.Default.Warning,
                                    isSelected = activeToolWindow == BottomToolWindow.PROBLEMS,
                                    onClick = { viewModel.setActiveToolWindow(BottomToolWindow.PROBLEMS) },
                                    badgeColor = if (problems.isNotEmpty()) MaterialTheme.colorScheme.error else null
                                )
                                ToolWindowHeaderChip(
                                    title = "Terminal",
                                    icon = Icons.Default.Code,
                                    isSelected = activeToolWindow == BottomToolWindow.TERMINAL,
                                    onClick = { viewModel.setActiveToolWindow(BottomToolWindow.TERMINAL) }
                                )
                                ToolWindowHeaderChip(
                                    title = "AI Assistant",
                                    icon = Icons.Default.AutoAwesome,
                                    isSelected = activeToolWindow == BottomToolWindow.AI_ASSISTANT,
                                    onClick = { viewModel.setActiveToolWindow(BottomToolWindow.AI_ASSISTANT) }
                                )
                            }
                            IconButton(onClick = { viewModel.toggleToolWindow() }) {
                                Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Collapse Tools")
                            }
                        }
                        Divider()

                        // Tool Window Content
                        Box(modifier = Modifier.fillMaxSize()) {
                            when (activeToolWindow) {
                                BottomToolWindow.BUILD_OUTPUT -> {
                                    BuildOutputView(logs = buildLogs, result = buildResult)
                                }
                                BottomToolWindow.PROBLEMS -> {
                                    ProblemsListView(
                                        problems = problems,
                                        onProblemClick = { problem -> viewModel.jumpToProblem(problem) }
                                    )
                                }
                                BottomToolWindow.TERMINAL -> {
                                    TerminalView(jdkInfo = jdkInfo)
                                }
                                BottomToolWindow.AI_ASSISTANT -> {
                                    AiAssistantView(problems = problems)
                                }
                                else -> {
                                    BuildOutputView(logs = buildLogs, result = buildResult)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // New File Dialog
    if (showNewFileDialog != null) {
        val parent = showNewFileDialog!!
        AlertDialog(
            onDismissRequest = { showNewFileDialog = null },
            title = { Text("New File") },
            text = {
                Column {
                    Text("Enter file name (e.g. MyComponent.kt):", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newFileName,
                        onValueChange = { newFileName = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newFileName.isNotBlank()) {
                            viewModel.createFile(parent, newFileName.trim())
                            showNewFileDialog = null
                        }
                    }
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewFileDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // New Folder Dialog
    if (showNewFolderDialog != null) {
        val parent = showNewFolderDialog!!
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = null },
            title = { Text("New Directory") },
            text = {
                Column {
                    Text("Enter directory name:", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = newFolderName,
                        onValueChange = { newFolderName = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newFolderName.isNotBlank()) {
                            viewModel.createFolder(parent, newFolderName.trim())
                            showNewFolderDialog = null
                        }
                    }
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolderDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Rename Dialog
    if (showRenameDialog != null) {
        val target = showRenameDialog!!
        AlertDialog(
            onDismissRequest = { showRenameDialog = null },
            title = { Text("Rename") },
            text = {
                OutlinedTextField(
                    value = renameTargetName,
                    onValueChange = { renameTargetName = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (renameTargetName.isNotBlank()) {
                            viewModel.renameItem(target, renameTargetName.trim())
                            showRenameDialog = null
                        }
                    }
                ) {
                    Text("Rename")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRenameDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete Confirm Dialog
    if (showDeleteConfirmDialog != null) {
        val target = showDeleteConfirmDialog!!
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = null },
            title = { Text("Delete Confirmation") },
            text = { Text("Are you sure you want to delete '${target.name}'? This cannot be undone.") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteItem(target)
                        showDeleteConfirmDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun FileTreeNodeItem(
    node: FileNode,
    depth: Int,
    activeFilePath: String?,
    onFileClick: (File) -> Unit,
    onNewFile: (File) -> Unit,
    onNewFolder: (File) -> Unit,
    onRename: (File) -> Unit,
    onDelete: (File) -> Unit
) {
    var isExpanded by remember { mutableStateOf(depth < 2) }
    val isSelected = activeFilePath == node.file.absolutePath

    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                    else Color.Transparent
                )
                .clickable {
                    if (node.isDirectory) {
                        isExpanded = !isExpanded
                    } else {
                        onFileClick(node.file)
                    }
                }
                .padding(start = (depth * 14 + 8).dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (node.isDirectory) {
                Icon(
                    imageVector = if (isExpanded) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowRight,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.Folder,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = Color(0xFFFFCA28)
                )
            } else {
                Spacer(modifier = Modifier.width(16.dp))
                val extColor = when (node.extension) {
                    "kt", "kts" -> Color(0xFF7F52FF)
                    "java" -> Color(0xFFF44336)
                    "xml" -> Color(0xFF4CAF50)
                    "gradle" -> Color(0xFF02569B)
                    "json" -> Color(0xFFFF9800)
                    else -> MaterialTheme.colorScheme.onSurfaceVariant
                }
                Icon(
                    imageVector = Icons.Default.InsertDriveFile,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = extColor
                )
            }

            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = node.name,
                fontSize = 13.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
        }

        if (node.isDirectory && isExpanded) {
            for (child in node.children) {
                FileTreeNodeItem(
                    node = child,
                    depth = depth + 1,
                    activeFilePath = activeFilePath,
                    onFileClick = onFileClick,
                    onNewFile = onNewFile,
                    onNewFolder = onNewFolder,
                    onRename = onRename,
                    onDelete = onDelete
                )
            }
        }
    }
}

@Composable
fun EditorContent(
    tab: EditorTab,
    themeMode: ThemeMode,
    onContentChange: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    val highlightedText = remember(tab.content, tab.file.extension, themeMode) {
        CodeSyntaxHighlighter.highlightCode(
            text = tab.content,
            extension = tab.file.extension,
            themeMode = themeMode
        )
    }

    val lines = remember(tab.content) { tab.content.lines() }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Line Numbers Gutter
        Column(
            modifier = Modifier
                .width(44.dp)
                .fillMaxHeight()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                .verticalScroll(scrollState)
                .padding(vertical = 8.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.End
        ) {
            for (i in 1..lines.size) {
                Text(
                    text = "$i",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    lineHeight = 18.sp
                )
            }
        }

        Divider(modifier = Modifier.fillMaxHeight().width(1.dp))

        // Code Editor Text Area
        Box(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .horizontalScroll(rememberScrollState())
                .padding(8.dp)
        ) {
            BasicTextField(
                value = tab.content,
                onValueChange = onContentChange,
                textStyle = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    color = MaterialTheme.colorScheme.onBackground
                ),
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun ToolWindowHeaderChip(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    badgeColor: Color? = null
) {
    Surface(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 6.dp),
        shape = MaterialTheme.shapes.small,
        color = if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = null,
                modifier = Modifier.size(14.dp),
                tint = if (badgeColor != null) badgeColor
                else if (isSelected) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                color = if (badgeColor != null) badgeColor
                else if (isSelected) MaterialTheme.colorScheme.onSurface
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun BuildOutputView(logs: List<BuildLogEntry>, result: BuildResult?) {
    val listState = rememberLazyListState()

    LaunchedEffect(logs.size) {
        if (logs.isNotEmpty()) {
            listState.animateScrollToItem(logs.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        if (result != null) {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = if (result.status == BuildStatus.SUCCESS) Color(0xFF1B5E20).copy(alpha = 0.2f)
                else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (result.status == BuildStatus.SUCCESS) "BUILD SUCCESSFUL (${result.durationMs / 1000}s)"
                        else "BUILD FAILED (exit code: ${result.exitCode})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = if (result.status == BuildStatus.SUCCESS) Color(0xFF4CAF50) else MaterialTheme.colorScheme.error
                    )
                    if (result.apkFile != null) {
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "APK: ${result.apkFile.name} (${result.apkSize / 1024} KB)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF121212))
                .padding(8.dp)
        ) {
            items(logs) { entry ->
                Text(
                    text = entry.message,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = if (entry.isError) Color(0xFFEF5350) else Color(0xFFB0BEC5),
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
fun ProblemsListView(problems: List<ProblemItem>, onProblemClick: (ProblemItem) -> Unit) {
    if (problems.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No compile problems or warnings found.", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        LazyColumn(modifier = Modifier.fillMaxSize().padding(8.dp)) {
            items(problems) { problem ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { onProblemClick(problem) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (problem.isError) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
                        else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (problem.isError) Icons.Default.Error else Icons.Default.Warning,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = if (problem.isError) MaterialTheme.colorScheme.error else Color(0xFFFFB74D)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${problem.relativePath}:${problem.line}:${problem.column}",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = problem.message,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TerminalView(jdkInfo: JdkInfo?) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E1E1E))
            .padding(12.dp)
    ) {
        Text("DroidIDE Embedded Terminal Engine", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF81C784))
        Spacer(modifier = Modifier.height(4.dp))
        Text("JDK Status: ${if (jdkInfo?.isAvailable == true) "Available" else "Checking..."}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.White)
        Text("Version: ${jdkInfo?.javaVersion ?: "OpenJDK 17.0.20.1"}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.LightGray)
        Text("Architecture: ${jdkInfo?.architecture ?: "arm64-v8a"}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.LightGray)
        Text("Target Platform: ${jdkInfo?.targetPlatform ?: "Android 16"}", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.LightGray)
        Spacer(modifier = Modifier.height(8.dp))
        Text("$ ./gradlew assembleDebug --info", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFF64B5F6))
        Text("Ready for build commands and tasks.", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.Gray)
    }
}

@Composable
fun AiAssistantView(problems: List<ProblemItem>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Text("DroidIDE AI Code Assistant", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Spacer(modifier = Modifier.height(8.dp))
        if (problems.isNotEmpty()) {
            Text(
                text = "Detected ${problems.size} issue(s) during last build. Suggestions:",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            problems.take(3).forEach { p ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text(text = "Issue in ${p.relativePath} (line ${p.line}):", fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                        Text(text = p.message, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        } else {
            Text(
                text = "No compile issues detected. You can use DroidIDE AI to optimize Compose layouts, generate Android components, or configure Gradle dependencies.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
