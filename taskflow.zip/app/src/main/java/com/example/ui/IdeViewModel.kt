package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.fs.ProjectManager
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

data class JdkInfo(
    val isAvailable: Boolean = true,
    val javaVersion: String = "OpenJDK 17.0.20.1",
    val architecture: String = "arm64-v8a",
    val targetPlatform: String = "Android 16 / arm64-v8a"
)

class IdeViewModel(application: Application) : AndroidViewModel(application) {

    private val projectManager = ProjectManager(application)
    @Volatile
    private var activeBuildProcess: Process? = null
    @Volatile
    private var isBuildCancelled = false

    // Theme Mode
    private val _themeMode = MutableStateFlow(ThemeMode.DARK)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    // Projects & File Tree
    private val _projects = MutableStateFlow<List<Project>>(emptyList())
    val projects: StateFlow<List<Project>> = _projects.asStateFlow()

    private val _currentProject = MutableStateFlow<Project?>(null)
    val currentProject: StateFlow<Project?> = _currentProject.asStateFlow()

    private val _fileTree = MutableStateFlow<FileNode?>(null)
    val fileTree: StateFlow<FileNode?> = _fileTree.asStateFlow()

    // Editor Tabs
    private val _openTabs = MutableStateFlow<List<EditorTab>>(emptyList())
    val openTabs: StateFlow<List<EditorTab>> = _openTabs.asStateFlow()

    private val _activeTabIndex = MutableStateFlow(-1)
    val activeTabIndex: StateFlow<Int> = _activeTabIndex.asStateFlow()

    // Target line to jump to in editor
    private val _targetEditorLine = MutableStateFlow<Int?>(null)
    val targetEditorLine: StateFlow<Int?> = _targetEditorLine.asStateFlow()

    // Bottom Tool Window
    private val _activeToolWindow = MutableStateFlow(BottomToolWindow.BUILD_OUTPUT)
    val activeToolWindow: StateFlow<BottomToolWindow> = _activeToolWindow.asStateFlow()

    private val _isToolWindowExpanded = MutableStateFlow(true)
    val isToolWindowExpanded: StateFlow<Boolean> = _isToolWindowExpanded.asStateFlow()

    private val _isFileExplorerVisible = MutableStateFlow(true)
    val isFileExplorerVisible: StateFlow<Boolean> = _isFileExplorerVisible.asStateFlow()

    // Build & Terminal State
    private val _buildStatus = MutableStateFlow(BuildStatus.IDLE)
    val buildStatus: StateFlow<BuildStatus> = _buildStatus.asStateFlow()

    private val _buildLogs = MutableStateFlow<List<BuildLogEntry>>(emptyList())
    val buildLogs: StateFlow<List<BuildLogEntry>> = _buildLogs.asStateFlow()

    private val _problems = MutableStateFlow<List<ProblemItem>>(emptyList())
    val problems: StateFlow<List<ProblemItem>> = _problems.asStateFlow()

    private val _buildResult = MutableStateFlow<BuildResult?>(null)
    val buildResult: StateFlow<BuildResult?> = _buildResult.asStateFlow()

    // JDK Info
    private val _jdkInfo = MutableStateFlow<JdkInfo?>(JdkInfo())
    val jdkInfo: StateFlow<JdkInfo?> = _jdkInfo.asStateFlow()

    init {
        loadProjects()
    }

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
    }

    fun toggleTheme() {
        _themeMode.value = when (_themeMode.value) {
            ThemeMode.DARK -> ThemeMode.LIGHT
            ThemeMode.LIGHT -> ThemeMode.OLED
            ThemeMode.OLED -> ThemeMode.DARK
        }
    }

    fun loadProjects() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = projectManager.listProjects()
            _projects.value = list

            // If no project is selected, open the first or root project
            if (_currentProject.value == null) {
                if (list.isNotEmpty()) {
                    openProject(list.first())
                } else {
                    val candidate = File("/app/applet")
                    if (candidate.exists()) {
                        val workspaceProj = Project(
                            name = "DroidIDE",
                            rootDir = candidate,
                            packageName = "com.example.droidide"
                        )
                        openProject(workspaceProj)
                    }
                }
            }
        }
    }

    fun openProject(project: Project) {
        _currentProject.value = project
        refreshFileTree()
    }

    fun refreshFileTree() {
        val proj = _currentProject.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val tree = projectManager.buildFileTree(proj.rootDir)
            _fileTree.value = tree

            // If tabs empty, open MainActivity or first kotlin file
            if (_openTabs.value.isEmpty()) {
                val mainAct = File(proj.rootDir, "app/src/main/java/com/example/MainActivity.kt")
                if (mainAct.exists()) {
                    openFile(mainAct)
                }
            }
        }
    }

    fun openFile(file: File, jumpToLine: Int? = null) {
        if (!file.exists() || file.isDirectory) return

        viewModelScope.launch(Dispatchers.IO) {
            val currentTabs = _openTabs.value.toMutableList()
            val existingIndex = currentTabs.indexOfFirst { it.file.absolutePath == file.absolutePath }

            if (existingIndex >= 0) {
                _activeTabIndex.value = existingIndex
                _targetEditorLine.value = jumpToLine
            } else {
                val content = projectManager.readFileContent(file)
                val newTab = EditorTab(
                    file = file,
                    title = file.name,
                    content = content,
                    isDirty = false
                )
                currentTabs.add(newTab)
                _openTabs.value = currentTabs
                _activeTabIndex.value = currentTabs.size - 1
                _targetEditorLine.value = jumpToLine
            }
        }
    }

    fun closeTab(index: Int) {
        val currentTabs = _openTabs.value.toMutableList()
        if (index in currentTabs.indices) {
            currentTabs.removeAt(index)
            _openTabs.value = currentTabs
            val newActive = when {
                currentTabs.isEmpty() -> -1
                _activeTabIndex.value >= currentTabs.size -> currentTabs.size - 1
                _activeTabIndex.value == index -> index.coerceAtMost(currentTabs.size - 1)
                _activeTabIndex.value > index -> _activeTabIndex.value - 1
                else -> _activeTabIndex.value
            }
            _activeTabIndex.value = newActive
        }
    }

    fun selectTab(index: Int) {
        if (index in _openTabs.value.indices) {
            _activeTabIndex.value = index
        }
    }

    fun updateActiveTabContent(newContent: String) {
        val index = _activeTabIndex.value
        val tabs = _openTabs.value.toMutableList()
        if (index in tabs.indices) {
            val tab = tabs[index]
            tabs[index] = tab.copy(
                content = newContent,
                isDirty = true
            )
            _openTabs.value = tabs
        }
    }

    fun saveCurrentFile() {
        val index = _activeTabIndex.value
        val tabs = _openTabs.value.toMutableList()
        if (index in tabs.indices) {
            val tab = tabs[index]
            viewModelScope.launch(Dispatchers.IO) {
                projectManager.saveFileContent(tab.file, tab.content)
                tabs[index] = tab.copy(isDirty = false)
                _openTabs.value = tabs
            }
        }
    }

    fun saveAllFiles() {
        viewModelScope.launch(Dispatchers.IO) {
            val tabs = _openTabs.value.toMutableList()
            for (i in tabs.indices) {
                val tab = tabs[i]
                if (tab.isDirty) {
                    projectManager.saveFileContent(tab.file, tab.content)
                    tabs[i] = tab.copy(isDirty = false)
                }
            }
            _openTabs.value = tabs
        }
    }

    fun createFile(parentDir: File, fileName: String, initialContent: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            val created = projectManager.createFile(parentDir, fileName, initialContent)
            refreshFileTree()
            openFile(created)
        }
    }

    fun createFolder(parentDir: File, folderName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            projectManager.createDirectory(parentDir, folderName)
            refreshFileTree()
        }
    }

    fun deleteItem(file: File) {
        viewModelScope.launch(Dispatchers.IO) {
            val currentTabs = _openTabs.value.filterNot { it.file.absolutePath == file.absolutePath }
            _openTabs.value = currentTabs
            _activeTabIndex.value = if (currentTabs.isNotEmpty()) 0 else -1

            projectManager.deleteFileOrDirectory(file)
            refreshFileTree()
        }
    }

    fun renameItem(file: File, newName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val renamed = projectManager.renameFileOrDirectory(file, newName)
            if (renamed != null) {
                val currentTabs = _openTabs.value.map { tab ->
                    if (tab.file.absolutePath == file.absolutePath) {
                        tab.copy(file = renamed, title = renamed.name)
                    } else tab
                }
                _openTabs.value = currentTabs
            }
            refreshFileTree()
        }
    }

    fun startBuild(tasks: List<String> = listOf("assembleDebug")) {
        val proj = _currentProject.value ?: return
        if (_buildStatus.value == BuildStatus.RUNNING) return

        saveAllFiles()

        _buildStatus.value = BuildStatus.RUNNING
        _buildLogs.value = emptyList()
        _problems.value = emptyList()
        _activeToolWindow.value = BottomToolWindow.BUILD_OUTPUT
        _isToolWindowExpanded.value = true
        isBuildCancelled = false

        viewModelScope.launch(Dispatchers.IO) {
            val startTime = System.currentTimeMillis()
            val logs = mutableListOf<BuildLogEntry>()
            val rawLines = mutableListOf<String>()

            fun emit(msg: String, isErr: Boolean = false) {
                val entry = BuildLogEntry(msg, isErr, System.currentTimeMillis())
                logs.add(entry)
                rawLines.add(msg)
                _buildLogs.value = _buildLogs.value + entry
            }

            emit("> Starting build with tasks: ${tasks.joinToString(" ")}")

            val wrapperJar = File(proj.rootDir, "gradle/wrapper/gradle-wrapper.jar")
            val gradlewScript = File(proj.rootDir, "gradlew")
            val command = mutableListOf<String>()

            if (wrapperJar.exists()) {
                val javaBin = System.getenv("JAVA_HOME")?.let { "$it/bin/java" } ?: "java"
                command.addAll(listOf(javaBin, "-Dorg.gradle.appname=gradlew", "-Dorg.gradle.daemon=false", "-classpath", wrapperJar.absolutePath, "org.gradle.wrapper.GradleWrapperMain", "-p", proj.rootDir.absolutePath))
                command.addAll(tasks)
            } else if (gradlewScript.exists()) {
                try { gradlewScript.setExecutable(true) } catch (_: Exception) {}
                command.addAll(listOf("sh", gradlewScript.absolutePath, "-p", proj.rootDir.absolutePath))
                command.addAll(tasks)
            } else {
                command.addAll(listOf("gradle", "-p", proj.rootDir.absolutePath))
                command.addAll(tasks)
            }

            var exitCode = -1
            try {
                val pb = ProcessBuilder(command).directory(proj.rootDir)
                val process = pb.start()
                activeBuildProcess = process

                val reader = BufferedReader(InputStreamReader(process.inputStream))
                val errReader = BufferedReader(InputStreamReader(process.errorStream))

                val t1 = Thread {
                    var l: String?
                    while (reader.readLine().also { l = it } != null) {
                        l?.let { emit(it, false) }
                    }
                }
                val t2 = Thread {
                    var l: String?
                    while (errReader.readLine().also { l = it } != null) {
                        l?.let { emit(it, true) }
                    }
                }
                t1.start()
                t2.start()

                exitCode = process.waitFor()
                t1.join(1000)
                t2.join(1000)
            } catch (e: Exception) {
                if (isBuildCancelled) {
                    emit("> Build cancelled.", true)
                } else {
                    emit("> Build error: ${e.message}", true)
                }
            } finally {
                activeBuildProcess = null
            }

            val duration = System.currentTimeMillis() - startTime
            val status = if (isBuildCancelled) BuildStatus.CANCELLED else if (exitCode == 0) BuildStatus.SUCCESS else BuildStatus.FAILED
            val apkCandidate = File(proj.rootDir, "app/build/outputs/apk/debug")
                .listFiles { _, name -> name.endsWith(".apk") }?.firstOrNull()

            val result = BuildResult(
                status = status,
                durationMs = duration,
                exitCode = exitCode,
                apkFile = apkCandidate,
                apkSize = apkCandidate?.length() ?: 0,
                logs = logs,
                problems = emptyList()
            )
            _buildResult.value = result
            _buildStatus.value = status
        }
    }

    fun cleanBuild() {
        startBuild(listOf("clean", "assembleDebug"))
    }

    fun cancelBuild() {
        isBuildCancelled = true
        activeBuildProcess?.destroy()
        _buildStatus.value = BuildStatus.CANCELLED
    }

    fun setActiveToolWindow(window: BottomToolWindow) {
        _activeToolWindow.value = window
        _isToolWindowExpanded.value = true
    }

    fun toggleToolWindow() {
        _isToolWindowExpanded.value = !_isToolWindowExpanded.value
    }

    fun toggleFileExplorer() {
        _isFileExplorerVisible.value = !_isFileExplorerVisible.value
    }

    fun jumpToProblem(problem: ProblemItem) {
        val file = problem.file ?: return
        openFile(file, problem.line)
    }

    fun clearTargetEditorLine() {
        _targetEditorLine.value = null
    }
}
