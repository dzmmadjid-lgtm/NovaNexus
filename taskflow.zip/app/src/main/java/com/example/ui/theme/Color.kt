package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// IDE Themes
val DarkSurface = Color(0xFF1E1E1E)
val DarkBackground = Color(0xFF121212)
val DarkSurfaceVariant = Color(0xFF2D2D2D)
val DarkPrimary = Color(0xFF4CAF50)

val OledBackground = Color(0xFF000000)
val OledSurface = Color(0xFF0A0A0A)
val OledSurfaceVariant = Color(0xFF1A1A1A)

val LightBackground = Color(0xFFF8F9FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE9ECEF)
val LightPrimary = Color(0xFF2E7D32)
