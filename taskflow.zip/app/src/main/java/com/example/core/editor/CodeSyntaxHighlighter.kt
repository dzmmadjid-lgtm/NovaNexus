package com.example.core.editor

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import com.example.data.model.ThemeMode
import java.util.regex.Pattern

object CodeSyntaxHighlighter {
    private val KOTLIN_KEYWORDS = setOf(
        "as", "break", "class", "continue", "do", "else", "for", "fun", "if", "in",
        "interface", "is", "null", "object", "package", "return", "super", "this",
        "throw", "try", "typealias", "val", "var", "when", "while", "by", "catch",
        "constructor", "delegate", "dynamic", "field", "file", "finally", "get",
        "import", "init", "param", "property", "receiver", "set", "setparam",
        "where", "actual", "abstract", "annotation", "companion", "const",
        "crossinline", "data", "enum", "expect", "external", "final", "infix",
        "inline", "inner", "internal", "lateinit", "noinline", "open", "operator",
        "out", "override", "private", "protected", "public", "reified", "sealed",
        "suspend", "tailrec", "vararg"
    )

    private val GRADLE_KEYWORDS = setOf(
        "plugins", "id", "alias", "apply", "version", "android", "compileSdk",
        "defaultConfig", "applicationId", "minSdk", "targetSdk", "versionCode",
        "versionName", "buildTypes", "release", "debug", "dependencies",
        "implementation", "testImplementation", "androidTestImplementation",
        "buildFeatures", "compose", "kotlinOptions", "jvmTarget", "include",
        "rootProject", "pluginManagement", "repositories", "google", "mavenCentral"
    )

    private val KOTLIN_TYPES = setOf(
        "String", "Int", "Long", "Float", "Double", "Boolean", "Char", "Byte",
        "Short", "Unit", "Any", "Nothing", "List", "MutableList", "Set",
        "MutableSet", "Map", "MutableMap", "Array", "File", "Context",
        "Bundle", "ComponentActivity", "Modifier", "Composable"
    )

    fun highlightCode(
        text: String,
        extension: String,
        themeMode: ThemeMode
    ): AnnotatedString {
        if (text.isEmpty()) return buildAnnotatedString { }
        val isDark = themeMode != ThemeMode.LIGHT
        val keywordColor = if (isDark) Color(0xFFCC7832) else Color(0xFF0033B3)
        val typeColor = if (isDark) Color(0xFF4EC9B0) else Color(0xFF267F99)
        val stringColor = if (isDark) Color(0xFF6A8759) else Color(0xFF067D17)
        val commentColor = if (isDark) Color(0xFF808080) else Color(0xFF8C8C8C)
        val numberColor = if (isDark) Color(0xFF6897BB) else Color(0xFF1750EB)
        val annotationColor = if (isDark) Color(0xFFBBB529) else Color(0xFF9E880D)
        val tagColor = if (isDark) Color(0xFFE8BF6A) else Color(0xFF0033B3)
        val attrColor = if (isDark) Color(0xFF9876AA) else Color(0xFF174BE6)
        val ext = extension.lowercase()

        return buildAnnotatedString {
            append(text)
            when (ext) {
                "kt", "kts", "java", "gradle" -> {
                    val stringPattern = Pattern.compile("\"(\\\\.|[^\"])*\"")
                    val stringMatcher = stringPattern.matcher(text)
                    while (stringMatcher.find()) {
                        addStyle(SpanStyle(color = stringColor), stringMatcher.start(), stringMatcher.end())
                    }

                    val wordPattern = Pattern.compile("\\b[a-zA-Z_][a-zA-Z0-9_]*\\b")
                    val wordMatcher = wordPattern.matcher(text)
                    while (wordMatcher.find()) {
                        val word = wordMatcher.group()
                        val start = wordMatcher.start()
                        val end = wordMatcher.end()
                        if (KOTLIN_KEYWORDS.contains(word) || GRADLE_KEYWORDS.contains(word)) {
                            addStyle(SpanStyle(color = keywordColor, fontWeight = FontWeight.Bold), start, end)
                        } else if (KOTLIN_TYPES.contains(word)) {
                            addStyle(SpanStyle(color = typeColor, fontWeight = FontWeight.SemiBold), start, end)
                        }
                    }

                    val annotationPattern = Pattern.compile("@[a-zA-Z0-9_]+")
                    val annotationMatcher = annotationPattern.matcher(text)
                    while (annotationMatcher.find()) {
                        addStyle(SpanStyle(color = annotationColor, fontWeight = FontWeight.Medium), annotationMatcher.start(), annotationMatcher.end())
                    }

                    val numberPattern = Pattern.compile("\\b\\d+(\\.\\d+)?[fFL]?\\b")
                    val numberMatcher = numberPattern.matcher(text)
                    while (numberMatcher.find()) {
                        addStyle(SpanStyle(color = numberColor), numberMatcher.start(), numberMatcher.end())
                    }

                    val singleCommentPattern = Pattern.compile("//.*")
                    val singleCommentMatcher = singleCommentPattern.matcher(text)
                    while (singleCommentMatcher.find()) {
                        addStyle(SpanStyle(color = commentColor), singleCommentMatcher.start(), singleCommentMatcher.end())
                    }
                }
                "xml" -> {
                    val tagPattern = Pattern.compile("<(/?)([a-zA-Z0-9_.:-]+)")
                    val tagMatcher = tagPattern.matcher(text)
                    while (tagMatcher.find()) {
                        addStyle(SpanStyle(color = tagColor, fontWeight = FontWeight.Bold), tagMatcher.start(), tagMatcher.end())
                    }
                    val attrPattern = Pattern.compile("([a-zA-Z0-9_.:-]+)(?=\\=)")
                    val attrMatcher = attrPattern.matcher(text)
                    while (attrMatcher.find()) {
                        addStyle(SpanStyle(color = attrColor), attrMatcher.start(), attrMatcher.end())
                    }
                }
            }
        }
    }
}
