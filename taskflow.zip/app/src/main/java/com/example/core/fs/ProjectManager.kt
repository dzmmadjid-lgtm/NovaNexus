package com.example.core.fs

import android.content.Context
import com.example.data.model.FileNode
import com.example.data.model.Project
import java.io.*
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

class ProjectManager(private val context: Context) {
    val rootProjectsDir: File
        get() {
            val dir = context.getExternalFilesDir("projects") ?: File(context.filesDir, "projects")
            if (!dir.exists()) {
                dir.mkdirs()
            }
            return dir
        }

    fun listProjects(): List<Project> {
        val projects = mutableListOf<Project>()
        val files = rootProjectsDir.listFiles() ?: return emptyList()
        for (file in files) {
            if (file.isDirectory) {
                var projectName = file.name
                val settingsFile = listOf("settings.gradle.kts", "settings.gradle")
                    .map { File(file, it) }
                    .firstOrNull { it.exists() }
                if (settingsFile != null) {
                    val settingsContent = settingsFile.readText()
                    val match = Regex("rootProject\\.name\\s*=\\s*[\"']([^\"']+)[\"']").find(settingsContent)
                    if (match != null && match.groupValues[1].isNotBlank()) {
                        projectName = match.groupValues[1].trim()
                    }
                }
                val manifest = File(file, "app/src/main/AndroidManifest.xml")
                var pkgName = "com.example.${file.name.lowercase().replace(Regex("[^a-zA-Z0-9]"), "")}"
                if (manifest.exists()) {
                    val content = manifest.readText()
                    val match = Regex("package=\"([^\"]+)\"").find(content)
                    if (match != null) {
                        pkgName = match.groupValues[1]
                    }
                }
                projects.add(
                    Project(
                        name = projectName,
                        rootDir = file,
                        packageName = pkgName
                    )
                )
            }
        }
        return projects.sortedByDescending { it.rootDir.lastModified() }
    }

    fun ensureDefaultProject(): Project {
        val existing = listProjects()
        if (existing.isNotEmpty()) {
            return existing.first()
        }
        return createProject("MyFirstApp", "com.example.myfirstapp")
    }

    fun createProject(projectName: String, packageName: String): Project {
        val safeDirName = projectName.replace(Regex("[^a-zA-Z0-9_\\-]"), "")
        val projDir = File(rootProjectsDir, if (safeDirName.isNotBlank()) safeDirName else "AndroidProject_${System.currentTimeMillis()}")
        projDir.mkdirs()

        // 1. settings.gradle.kts
        File(projDir, "settings.gradle.kts").writeText(
            """
            pluginManagement {
                repositories {
                    google()
                    mavenCentral()
                    gradlePluginPortal()
                }
            }
            dependencyResolutionManagement {
                repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
                repositories {
                    google()
                    mavenCentral()
                }
            }
            rootProject.name = "$projectName"
            include(":app")
            """.trimIndent()
        )

        // 2. build.gradle.kts (root)
        File(projDir, "build.gradle.kts").writeText(
            """
            plugins {
                id("com.android.application") version "8.5.2" apply false
                id("org.jetbrains.kotlin.android") version "2.0.0" apply false
                id("org.jetbrains.kotlin.plugin.compose") version "2.0.0" apply false
            }
            """.trimIndent()
        )

        // 3. gradle.properties
        File(projDir, "gradle.properties").writeText(
            """
            org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
            android.useAndroidX=true
            android.nonTransitiveRClass=true
            kotlin.code.style=official
            android.suppressUnsupportedCompileSdk=36
            """.trimIndent()
        )

        // 4. gradle wrapper properties
        val wrapperDir = File(projDir, "gradle/wrapper")
        wrapperDir.mkdirs()
        File(wrapperDir, "gradle-wrapper.properties").writeText(
            """
            distributionBase=GRADLE_USER_HOME
            distributionPath=wrapper/dists
            distributionUrl=https\://services.gradle.org/distributions/gradle-8.7-bin.zip
            networkTimeout=10000
            validateDistributionUrl=true
            zipStoreBase=GRADLE_USER_HOME
            zipStorePath=wrapper/dists
            """.trimIndent()
        )

        // Try to copy wrapper jar from workspace if present
        val sysWrapper = File("/app/applet/gradle/wrapper/gradle-wrapper.jar")
        if (sysWrapper.exists()) {
            try {
                sysWrapper.copyTo(File(wrapperDir, "gradle-wrapper.jar"), overwrite = true)
            } catch (_: Exception) {}
        }
        val sysGradlew = File("/app/applet/gradlew")
        if (sysGradlew.exists()) {
            try {
                val destGradlew = File(projDir, "gradlew")
                sysGradlew.copyTo(destGradlew, overwrite = true)
                destGradlew.setExecutable(true)
            } catch (_: Exception) {}
        }

        // 5. app/build.gradle.kts
        val appDir = File(projDir, "app")
        appDir.mkdirs()
        File(appDir, "build.gradle.kts").writeText(
            """
            plugins {
                id("com.android.application")
                id("org.jetbrains.kotlin.android")
                id("org.jetbrains.kotlin.plugin.compose")
            }

            android {
                namespace = "$packageName"
                compileSdk = 34

                defaultConfig {
                    applicationId = "$packageName"
                    minSdk = 24
                    targetSdk = 34
                    versionCode = 1
                    versionName = "1.0"
                }

                buildTypes {
                    release {
                        isMinifyEnabled = false
                    }
                }

                compileOptions {
                    sourceCompatibility = JavaVersion.VERSION_17
                    targetCompatibility = JavaVersion.VERSION_17
                }

                kotlinOptions {
                    jvmTarget = "17"
                }

                buildFeatures {
                    compose = true
                }
            }

            dependencies {
                implementation("androidx.core:core-ktx:1.13.1")
                implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
                implementation("androidx.activity:activity-compose:1.9.1")
                implementation(platform("androidx.compose:compose-bom:2024.06.00"))
                implementation("androidx.compose.ui:ui")
                implementation("androidx.compose.material3:material3")
            }
            """.trimIndent()
        )

        // 6. app/src/main/AndroidManifest.xml
        val mainDir = File(appDir, "src/main")
        mainDir.mkdirs()
        File(mainDir, "AndroidManifest.xml").writeText(
            """
            <?xml version="1.0" encoding="utf-8"?>
            <manifest xmlns:android="http://schemas.android.com/apk/res/android">
                <application
                    android:allowBackup="true"
                    android:label="$projectName"
                    android:supportsRtl="true"
                    android:theme="@android:style/Theme.Material.Light.NoActionBar">
                    <activity
                        android:name=".MainActivity"
                        android:exported="true">
                        <intent-filter>
                            <action android:name="android.intent.action.MAIN" />
                            <category android:name="android.intent.category.LAUNCHER" />
                        </intent-filter>
                    </activity>
                </application>
            </manifest>
            """.trimIndent()
        )

        // 7. app/src/main/java/pkg/MainActivity.kt
        val pkgPath = packageName.replace('.', '/')
        val javaDir = File(mainDir, "java/$pkgPath")
        javaDir.mkdirs()
        File(javaDir, "MainActivity.kt").writeText(
            """
            package $packageName

            import android.os.Bundle
            import androidx.activity.ComponentActivity
            import androidx.activity.compose.setContent
            import androidx.compose.foundation.layout.*
            import androidx.compose.material3.*
            import androidx.compose.runtime.*
            import androidx.compose.ui.Alignment
            import androidx.compose.ui.Modifier
            import androidx.compose.ui.unit.dp

            class MainActivity : ComponentActivity() {
                override fun onCreate(savedInstanceState: Bundle?) {
                    super.onCreate(savedInstanceState)
                    setContent {
                        MaterialTheme {
                            Surface(
                                modifier = Modifier.fillMaxSize(),
                                color = MaterialTheme.colorScheme.background
                            ) {
                                MainAppContent()
                            }
                        }
                    }
                }
            }

            @Composable
            fun MainAppContent() {
                var count by remember { mutableStateOf(0) }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Hello from DroidIDE!",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Your Android Compose project is ready to compile into APK.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(onClick = { count++ }) {
                        Text("Clicks: ${'$'}count")
                    }
                }
            }
            """.trimIndent()
        )

        // 8. res/values/strings.xml
        val resValuesDir = File(mainDir, "res/values")
        resValuesDir.mkdirs()
        File(resValuesDir, "strings.xml").writeText(
            """
            <resources>
                <string name="app_name">$projectName</string>
            </resources>
            """.trimIndent()
        )

        return Project(
            name = projectName,
            rootDir = projDir,
            packageName = packageName
        )
    }

    fun importProjectFromZip(inputStream: InputStream, targetProjectName: String): Project? {
        val safeName = targetProjectName.replace(Regex("[^a-zA-Z0-9_\\-]"), "").ifBlank { "ImportedProject_${System.currentTimeMillis()}" }
        val targetDir = File(rootProjectsDir, safeName)
        targetDir.mkdirs()

        try {
            val zis = ZipInputStream(BufferedInputStream(inputStream))
            var entry: ZipEntry? = zis.nextEntry
            val buffer = ByteArray(8192)

            while (entry != null) {
                val entryName = entry.name.replace("\\", "/")
                // Skip Mac __MACOSX or root directory prefix if any
                if (!entryName.startsWith("__MACOSX")) {
                    val destFile = File(targetDir, entryName)
                    if (entry.isDirectory) {
                        destFile.mkdirs()
                    } else {
                        destFile.parentFile?.mkdirs()
                        val fos = FileOutputStream(destFile)
                        var len: Int
                        while (zis.read(buffer).also { len = it } > 0) {
                            fos.write(buffer, 0, len)
                        }
                        fos.close()
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
            zis.close()

            val detectedProjects = listProjects()
            return detectedProjects.firstOrNull { it.rootDir.absolutePath == targetDir.absolutePath }
                ?: Project(name = targetProjectName, rootDir = targetDir, packageName = "com.example.$safeName")
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    fun deleteProject(project: Project): Boolean {
        return project.rootDir.deleteRecursively()
    }

    fun buildFileTree(directory: File): FileNode {
        val childrenNodes = mutableListOf<FileNode>()
        val files: List<File> = directory.listFiles()?.sortedWith(
            compareBy<File> { !it.isDirectory }.thenBy { it.name.lowercase() }
        ) ?: emptyList()

        for (file in files) {
            if (file.name == ".gradle" && file.isDirectory) continue
            if (file.name == ".idea" && file.isDirectory) continue
            if (file.name == "build" && file.isDirectory && file.parentFile?.name == directory.name) continue
            if (file.isDirectory) {
                childrenNodes.add(buildFileTree(file))
            } else {
                childrenNodes.add(
                    FileNode(
                        file = file,
                        name = file.name,
                        isDirectory = false,
                        extension = file.extension.lowercase()
                    )
                )
            }
        }
        return FileNode(
            file = directory,
            name = directory.name,
            isDirectory = true,
            children = childrenNodes,
            isExpanded = true
        )
    }

    fun createFile(parentDir: File, fileName: String, initialContent: String = ""): File {
        val file = File(parentDir, fileName)
        if (!file.exists()) {
            file.parentFile?.mkdirs()
            file.writeText(initialContent)
        }
        return file
    }

    fun createDirectory(parentDir: File, dirName: String): File {
        val dir = File(parentDir, dirName)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun deleteFileOrDirectory(file: File): Boolean {
        return if (file.isDirectory) file.deleteRecursively() else file.delete()
    }

    fun renameFileOrDirectory(source: File, newName: String): File? {
        val target = File(source.parentFile, newName)
        return if (source.renameTo(target)) target else null
    }

    fun readFileContent(file: File): String {
        return if (file.exists() && file.isFile) file.readText() else ""
    }

    fun saveFileContent(file: File, content: String) {
        file.parentFile?.mkdirs()
        file.writeText(content)
    }
}
