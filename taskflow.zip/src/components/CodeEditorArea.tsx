import React, { useState, useEffect, useRef } from "react";
import {
  X,
  Save,
  Undo2,
  Redo2,
  Search,
  AlignLeft,
  FileCode
} from "lucide-react";
import { EditorTabDto } from "../types";

interface CodeEditorAreaProps {
  tabs: EditorTabDto[];
  activeTabIndex: number;
  targetLine: number | null;
  onSelectTab: (index: number) => void;
  onCloseTab: (index: number) => void;
  onContentChange: (newContent: string) => void;
  onSaveFile: () => void;
  onClearTargetLine: () => void;
}

export const CodeEditorArea: React.FC<CodeEditorAreaProps> = ({
  tabs,
  activeTabIndex,
  targetLine,
  onSelectTab,
  onCloseTab,
  onContentChange,
  onSaveFile,
  onClearTargetLine
}) => {
  const activeTab = activeTabIndex >= 0 && activeTabIndex < tabs.length ? tabs[activeTabIndex] : null;
  const [history, setHistory] = useState<{ [path: string]: { undo: string[]; redo: string[] } }>({});
  const [showFind, setShowFind] = useState(false);
  const [findText, setFindText] = useState("");
  const [replaceText, setReplaceText] = useState("");
  const [cursorPos, setCursorPos] = useState({ line: 1, col: 1 });
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const lineNumbersRef = useRef<HTMLDivElement>(null);

  // Jump to problem target line
  useEffect(() => {
    if (targetLine && activeTab && textareaRef.current) {
      const lines = activeTab.content.split("\n");
      let charOffset = 0;
      for (let i = 0; i < Math.min(targetLine - 1, lines.length); i++) {
        charOffset += lines[i].length + 1;
      }
      textareaRef.current.focus();
      textareaRef.current.setSelectionRange(charOffset, charOffset);
      const lineHeight = 20;
      textareaRef.current.scrollTop = Math.max(0, (targetLine - 5) * lineHeight);
      onClearTargetLine();
    }
  }, [targetLine, activeTab, onClearTargetLine]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if ((e.ctrlKey || e.metaKey) && e.key === "s") {
      e.preventDefault();
      onSaveFile();
    }
    if ((e.ctrlKey || e.metaKey) && e.key === "f") {
      e.preventDefault();
      setShowFind((prev) => !prev);
    }
    if (e.key === "Tab") {
      e.preventDefault();
      if (!textareaRef.current || !activeTab) return;
      const start = textareaRef.current.selectionStart;
      const end = textareaRef.current.selectionEnd;
      const newContent = activeTab.content.substring(0, start) + "    " + activeTab.content.substring(end);
      onContentChange(newContent);
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = textareaRef.current.selectionEnd = start + 4;
        }
      }, 0);
    }
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    if (activeTab) {
      const currentHistory = history[activeTab.path] || { undo: [], redo: [] };
      const updatedUndo = [...currentHistory.undo, activeTab.content].slice(-40);
      setHistory({
        ...history,
        [activeTab.path]: { undo: updatedUndo, redo: [] }
      });
    }
    onContentChange(val);
    updateCursorInfo();
  };

  const updateCursorInfo = () => {
    if (!textareaRef.current || !activeTab) return;
    const sel = textareaRef.current.selectionStart;
    const textBefore = activeTab.content.substring(0, sel);
    const line = (textBefore.match(/\n/g) || []).length + 1;
    const lastNewline = textBefore.lastIndexOf("\n");
    const col = lastNewline === -1 ? sel + 1 : sel - lastNewline;
    setCursorPos({ line, col });
  };

  const handleUndo = () => {
    if (!activeTab) return;
    const hist = history[activeTab.path];
    if (hist && hist.undo.length > 0) {
      const prev = hist.undo[hist.undo.length - 1];
      const newUndo = hist.undo.slice(0, -1);
      const newRedo = [activeTab.content, ...hist.redo];
      setHistory({
        ...history,
        [activeTab.path]: { undo: newUndo, redo: newRedo }
      });
      onContentChange(prev);
    }
  };

  const handleRedo = () => {
    if (!activeTab) return;
    const hist = history[activeTab.path];
    if (hist && hist.redo.length > 0) {
      const next = hist.redo[0];
      const newRedo = hist.redo.slice(1);
      const newUndo = [...hist.undo, activeTab.content];
      setHistory({
        ...history,
        [activeTab.path]: { undo: newUndo, redo: newRedo }
      });
      onContentChange(next);
    }
  };

  const formatIndentation = () => {
    if (!activeTab) return;
    const lines = activeTab.content.split("\n");
    let indent = 0;
    const formatted = lines.map((l) => {
      const trimmed = l.trim();
      if (!trimmed) return "";
      if (trimmed.startsWith("}") || trimmed.startsWith(")") || trimmed.startsWith("</")) {
        indent = Math.max(0, indent - 1);
      }
      const lineIndent = "    ".repeat(indent);
      const opens = (trimmed.match(/[{<(]/g) || []).length;
      const closes = (trimmed.match(/[}>)]/g) || []).length;
      indent = Math.max(0, indent + opens - closes);
      return lineIndent + trimmed;
    }).join("\n");
    onContentChange(formatted);
  };

  const handleReplaceAll = () => {
    if (!activeTab || !findText) return;
    const escaped = findText.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const regex = new RegExp(escaped, "g");
    const newContent = activeTab.content.replace(regex, replaceText);
    onContentChange(newContent);
  };

  const lines = activeTab ? activeTab.content.split("\n") : [];
  const lineCount = Math.max(lines.length, 1);

  if (!activeTab) {
    return (
      <div className="flex-1 h-full bg-neutral-950 flex flex-col items-center justify-center text-neutral-500 select-none">
        <FileCode className="w-16 h-16 opacity-30 mb-3" />
        <h3 className="text-sm font-medium text-neutral-400">No File Open</h3>
        <p className="text-xs text-neutral-600 mt-1 max-w-sm text-center">
          Select a file from the project explorer to view, edit, and build with real Gradle support.
        </p>
      </div>
    );
  }

  return (
    <div className="flex-1 h-full flex flex-col bg-neutral-950 overflow-hidden">
      {/* Tabs Header */}
      <div className="h-9 border-b border-neutral-800 bg-neutral-900/60 flex items-center overflow-x-auto shrink-0 select-none">
        {tabs.map((tab, idx) => {
          const isActive = idx === activeTabIndex;
          return (
            <div
              key={`${tab.path}-${idx}`}
              onClick={() => onSelectTab(idx)}
              className={`group h-full flex items-center gap-2 px-3 border-r border-neutral-800/80 cursor-pointer text-xs font-mono transition-colors ${
                isActive
                  ? "bg-neutral-950 text-neutral-100 border-t-2 border-t-emerald-500 font-medium"
                  : "text-neutral-400 hover:bg-neutral-800/50 hover:text-neutral-200"
              }`}
            >
              {tab.isDirty && (
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0" />
              )}
              <span className="truncate max-w-[150px]">{tab.name}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onCloseTab(idx);
                }}
                className="opacity-0 group-hover:opacity-100 p-0.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition-opacity"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          );
        })}
      </div>

      {/* Editor Action Toolbar */}
      <div className="h-8 border-b border-neutral-800/60 bg-neutral-900/30 px-3 flex items-center justify-between text-xs text-neutral-400 shrink-0 select-none">
        <div className="flex items-center gap-2">
          <button
            onClick={onSaveFile}
            title="Save File (Ctrl+S)"
            className="p-1 rounded hover:bg-neutral-800 hover:text-neutral-200 transition-colors flex items-center gap-1"
          >
            <Save className="w-3.5 h-3.5" />
            <span className="text-[11px]">Save</span>
          </button>
          <button
            onClick={handleUndo}
            title="Undo"
            className="p-1 rounded hover:bg-neutral-800 hover:text-neutral-200 transition-colors"
          >
            <Undo2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleRedo}
            title="Redo"
            className="p-1 rounded hover:bg-neutral-800 hover:text-neutral-200 transition-colors"
          >
            <Redo2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setShowFind((prev) => !prev)}
            title="Find & Replace (Ctrl+F)"
            className={`p-1 rounded hover:bg-neutral-800 hover:text-neutral-200 transition-colors ${showFind ? "text-emerald-400" : ""}`}
          >
            <Search className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={formatIndentation}
            title="Format Indentation"
            className="p-1 rounded hover:bg-neutral-800 hover:text-neutral-200 transition-colors"
          >
            <AlignLeft className="w-3.5 h-3.5" />
          </button>
        </div>
        <div className="flex items-center gap-3 text-[11px] font-mono text-neutral-400">
          <span>Ln {cursorPos.line}, Col {cursorPos.col}</span>
          <span className="px-1.5 py-0.5 rounded bg-neutral-800 uppercase text-[10px] font-semibold text-neutral-300">
            {activeTab.extension}
          </span>
        </div>
      </div>

      {/* Find & Replace bar */}
      {showFind && (
        <div className="bg-neutral-900 border-b border-neutral-800 p-2 flex flex-wrap items-center gap-2 text-xs shrink-0">
          <input
            type="text"
            placeholder="Find..."
            value={findText}
            onChange={(e) => setFindText(e.target.value)}
            className="px-2 py-1 bg-neutral-950 border border-neutral-700 rounded text-neutral-200 focus:outline-none focus:border-emerald-500 font-mono text-xs w-48"
          />
          <input
            type="text"
            placeholder="Replace with..."
            value={replaceText}
            onChange={(e) => setReplaceText(e.target.value)}
            className="px-2 py-1 bg-neutral-950 border border-neutral-700 rounded text-neutral-200 focus:outline-none focus:border-emerald-500 font-mono text-xs w-48"
          />
          <button
            onClick={handleReplaceAll}
            className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium"
          >
            Replace All
          </button>
          <button
            onClick={() => setShowFind(false)}
            className="p-1 rounded hover:bg-neutral-800 text-neutral-400"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Editor Body with line numbers */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Line Numbers */}
        <div
          ref={lineNumbersRef}
          className="w-12 bg-neutral-950 border-r border-neutral-800/80 select-none py-2 px-1 text-right text-xs font-mono text-neutral-600 shrink-0 overflow-hidden leading-5"
        >
          {Array.from({ length: lineCount }).map((_, i) => (
            <div
              key={i}
              className={i + 1 === cursorPos.line ? "text-emerald-400 font-bold" : ""}
            >
              {i + 1}
            </div>
          ))}
        </div>
        {/* Text Area */}
        <textarea
          ref={textareaRef}
          value={activeTab.content}
          onChange={handleTextChange}
          onKeyDown={handleKeyDown}
          onClick={updateCursorInfo}
          onKeyUp={updateCursorInfo}
          onScroll={(e) => {
            if (lineNumbersRef.current) {
              lineNumbersRef.current.scrollTop = e.currentTarget.scrollTop;
            }
          }}
          spellCheck={false}
          className="flex-1 h-full bg-neutral-950 text-neutral-100 p-2 font-mono text-xs leading-5 resize-none focus:outline-none whitespace-pre overflow-auto border-none selection:bg-neutral-700"
        />
      </div>
    </div>
  );
};
