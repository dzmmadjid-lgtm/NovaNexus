import React, { useState, useRef } from "react";
import {
  Terminal as TermIcon,
  AlertTriangle,
  GitBranch,
  Copy,
  Maximize2,
  Minimize2,
  Trash2,
  ChevronDown,
  ChevronUp,
  Share2,
  Smartphone,
  Send,
  CheckCircle2,
  XCircle,
  Clock,
  ShieldCheck
} from "lucide-react";
import {
  BottomTabType,
  BuildStatusType,
  BuildLogEntryDto,
  ProblemDto,
  ApkFileDto,
  BuildResultDto,
  JdkStatusDto
} from "../types";

interface BottomToolWindowsViewProps {
  activeTab: BottomTabType;
  isExpanded: boolean;
  buildStatus: BuildStatusType;
  buildLogs: BuildLogEntryDto[];
  buildResult: BuildResultDto | null;
  problems: ProblemDto[];
  apkFile: ApkFileDto | null;
  jdkStatus: JdkStatusDto | null;
  onSelectTab: (tab: BottomTabType) => void;
  onToggleExpanded: () => void;
  onClearLogs: () => void;
  onJumpToProblem: (filePath: string, line: number) => void;
  onRunTerminalCommand: (command: string) => void;
  terminalLogs: string[];
}

export const BottomToolWindowsView: React.FC<BottomToolWindowsViewProps> = ({
  activeTab,
  isExpanded,
  buildStatus,
  buildLogs,
  buildResult,
  problems,
  apkFile,
  jdkStatus,
  onSelectTab,
  onToggleExpanded,
  onClearLogs,
  onJumpToProblem,
  onRunTerminalCommand,
  terminalLogs
}) => {
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [terminalInput, setTerminalInput] = useState("");
  const [copiedNotification, setCopiedNotification] = useState("");
  const logContainerRef = useRef<HTMLDivElement>(null);

  const handleCopyAllLogs = () => {
    const fullText = buildLogs.map((l) => l.message).join("\n");
    if (!fullText) return;
    navigator.clipboard.writeText(fullText);
    setCopiedNotification("All logs copied to clipboard!");
    setTimeout(() => setCopiedNotification(""), 3000);
  };

  const handleSelectAllLogs = () => {
    if (logContainerRef.current) {
      const range = document.createRange();
      range.selectNodeContents(logContainerRef.current);
      const sel = window.getSelection();
      if (sel) {
        sel.removeAllRanges();
        sel.addRange(range);
      }
    }
  };

  const handleTerminalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!terminalInput.trim()) return;
    onRunTerminalCommand(terminalInput);
    setTerminalInput("");
  };

  const statusColor = {
    IDLE: "text-neutral-400",
    RUNNING: "text-emerald-400 animate-pulse",
    SUCCESS: "text-emerald-400",
    FAILED: "text-rose-400",
    CANCELLED: "text-amber-400"
  }[buildStatus];

  return (
    <div
      className={`border-t border-neutral-800 bg-neutral-900 flex flex-col shrink-0 transition-all ${
        isFullScreen
          ? "fixed inset-0 z-50 bg-neutral-950"
          : isExpanded
          ? "h-64"
          : "h-9"
      }`}
    >
      {/* Tab Navigation Header */}
      <div className="h-9 px-2 border-b border-neutral-800 bg-neutral-900/90 flex items-center justify-between select-none shrink-0">
        <div className="flex items-center gap-1">
          {/* Build Output Tab */}
          <button
            onClick={() => {
              onSelectTab("build");
              if (!isExpanded) onToggleExpanded();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === "build" && isExpanded
                ? "bg-neutral-800 text-emerald-400"
                : "text-neutral-400 hover:bg-neutral-800/60 hover:text-neutral-200"
            }`}
          >
            <TermIcon className="w-3.5 h-3.5" />
            <span>Build Output</span>
            {buildStatus === "RUNNING" && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            )}
            {buildStatus === "SUCCESS" && (
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
            )}
            {buildStatus === "FAILED" && (
              <span className="w-2 h-2 rounded-full bg-rose-500" />
            )}
          </button>

          {/* Problems Tab */}
          <button
            onClick={() => {
              onSelectTab("problems");
              if (!isExpanded) onToggleExpanded();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === "problems" && isExpanded
                ? "bg-neutral-800 text-emerald-400"
                : "text-neutral-400 hover:bg-neutral-800/60 hover:text-neutral-200"
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Problems</span>
            {problems.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-rose-900 text-rose-200 text-[10px] font-bold">
                {problems.length}
              </span>
            )}
          </button>

          {/* Terminal Tab */}
          <button
            onClick={() => {
              onSelectTab("terminal");
              if (!isExpanded) onToggleExpanded();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === "terminal" && isExpanded
                ? "bg-neutral-800 text-emerald-400"
                : "text-neutral-400 hover:bg-neutral-800/60 hover:text-neutral-200"
            }`}
          >
            <TermIcon className="w-3.5 h-3.5" />
            <span>Terminal</span>
          </button>

          {/* Git Tab */}
          <button
            onClick={() => {
              onSelectTab("git");
              if (!isExpanded) onToggleExpanded();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === "git" && isExpanded
                ? "bg-neutral-800 text-emerald-400"
                : "text-neutral-400 hover:bg-neutral-800/60 hover:text-neutral-200"
            }`}
          >
            <GitBranch className="w-3.5 h-3.5" />
            <span>Git</span>
          </button>

          {/* JDK Info Tab */}
          <button
            onClick={() => {
              onSelectTab("jdk");
              if (!isExpanded) onToggleExpanded();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors ${
              activeTab === "jdk" && isExpanded
                ? "bg-neutral-800 text-emerald-400"
                : "text-neutral-400 hover:bg-neutral-800/60 hover:text-neutral-200"
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>JDK 17 Status</span>
          </button>
        </div>

        {/* Header Controls */}
        <div className="flex items-center gap-1">
          {copiedNotification && (
            <span className="text-[11px] text-emerald-400 mr-2 font-medium">
              {copiedNotification}
            </span>
          )}
          {activeTab === "build" && isExpanded && (
            <>
              <button
                onClick={handleSelectAllLogs}
                title="Select All Logs"
                className="px-2 py-1 rounded hover:bg-neutral-800 text-neutral-300 text-xs font-medium transition-colors"
              >
                Select All
              </button>
              <button
                onClick={handleCopyAllLogs}
                title="Copy All Logs to Clipboard"
                className="flex items-center gap-1 px-2 py-1 rounded hover:bg-neutral-800 text-neutral-300 text-xs font-medium transition-colors"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy All Logs</span>
              </button>
              <button
                onClick={onClearLogs}
                title="Clear Logs"
                className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </>
          )}
          <button
            onClick={() => setIsFullScreen((prev) => !prev)}
            title={isFullScreen ? "Exit Full Screen" : "Full Screen"}
            className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
          >
            {isFullScreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
          </button>
          {!isFullScreen && (
            <button
              onClick={onToggleExpanded}
              title={isExpanded ? "Collapse" : "Expand"}
              className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
            >
              {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
            </button>
          )}
        </div>
      </div>

      {/* Expanded Content Area */}
      {isExpanded && (
        <div className="flex-1 overflow-hidden flex flex-col bg-neutral-950">
          {/* Tab 1: Build Output */}
          {activeTab === "build" && (
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="px-3 py-1.5 bg-neutral-900 border-b border-neutral-800/80 flex flex-wrap items-center justify-between text-xs shrink-0">
                <div className="flex items-center gap-3">
                  <span className={`font-mono font-semibold ${statusColor}`}>
                    Status: {buildStatus}
                  </span>
                  {buildResult && (
                    <span className="text-neutral-400 flex items-center gap-1 font-mono text-[11px]">
                      <Clock className="w-3 h-3" />
                      {(buildResult.durationMs / 1000).toFixed(1)}s
                    </span>
                  )}
                  <span className="text-neutral-500 text-[11px]">
                    ({buildLogs.length} lines)
                  </span>
                </div>
                {/* APK Ready Indicator */}
                {apkFile && (
                  <div className="flex items-center gap-2 bg-emerald-950/80 border border-emerald-800/70 px-2 py-1 rounded">
                    <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-300 font-mono text-[11px] font-medium">
                      APK: {apkFile.name} ({(apkFile.size / 1024).toFixed(0)} KB)
                    </span>
                    <button
                      onClick={() => alert(`Ready to install ${apkFile.name}`)}
                      className="px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-[11px] transition-colors"
                    >
                      Install
                    </button>
                    <button
                      onClick={() => {
                        if (navigator.share) {
                          navigator.share({ title: apkFile.name, text: `Generated APK ${apkFile.name}` });
                        } else {
                          alert(`APK location: ${apkFile.path}`);
                        }
                      }}
                      className="p-1 rounded hover:bg-emerald-800/60 text-emerald-300"
                      title="Share APK"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>
              {/* Logs */}
              <div
                ref={logContainerRef}
                className="flex-1 overflow-x-auto overflow-y-auto p-3 font-mono text-xs leading-5 select-text bg-neutral-950"
              >
                {buildLogs.length === 0 ? (
                  <div className="text-neutral-600 italic">
                    No build logs yet. Click "Build APK" to trigger Gradle assembleDebug.
                  </div>
                ) : (
                  buildLogs.map((entry, idx) => {
                    const isSuccessLine = entry.message.includes("BUILD SUCCESSFUL");
                    const isHeaderLine = entry.message.startsWith(">");
                    return (
                      <div
                        key={idx}
                        className={`whitespace-pre ${
                          entry.isError
                            ? "text-rose-400 bg-rose-950/20 px-1 rounded-xs"
                            : isSuccessLine
                            ? "text-emerald-400 font-bold bg-emerald-950/20 px-1 rounded-xs"
                            : isHeaderLine
                            ? "text-cyan-400 font-medium"
                            : "text-neutral-300"
                        }`}
                      >
                        {entry.message}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* Tab 2: Problems */}
          {activeTab === "problems" && (
            <div className="flex-1 overflow-y-auto p-3 font-mono text-xs">
              {problems.length === 0 ? (
                <div className="flex items-center gap-2 text-emerald-400 p-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>No build problems or compilation errors detected.</span>
                </div>
              ) : (
                <div className="flex flex-col gap-1.5">
                  <div className="text-neutral-400 text-[11px] mb-1 font-sans">
                    Click any problem below to jump directly to that line in the code editor:
                  </div>
                  {problems.map((prob, i) => (
                    <div
                      key={i}
                      onClick={() => onJumpToProblem(prob.file, prob.line)}
                      className="p-2 rounded bg-neutral-900 hover:bg-neutral-800/80 border border-neutral-800 cursor-pointer flex items-start gap-2 transition-colors"
                    >
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <div className="flex-1 overflow-hidden">
                        <div className="flex items-center gap-2">
                          <span className="text-emerald-400 font-bold underline">
                            {prob.file}:{prob.line}:{prob.column}
                          </span>
                        </div>
                        <div className="text-neutral-200 mt-1 whitespace-pre-wrap">
                          {prob.message}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Tab 3: Terminal */}
          {activeTab === "terminal" && (
            <div className="flex-1 flex flex-col overflow-hidden font-mono text-xs">
              <div className="flex-1 overflow-y-auto p-3 bg-neutral-950 text-neutral-300 space-y-1">
                <div className="text-neutral-500 mb-2">
                  DroidIDE Embedded Terminal [Android 16 / OpenJDK 17 ARM64]
                </div>
                {terminalLogs.map((log, idx) => (
                  <div key={idx} className="whitespace-pre-wrap">
                    {log}
                  </div>
                ))}
              </div>
              <form
                onSubmit={handleTerminalSubmit}
                className="h-10 border-t border-neutral-800 bg-neutral-900 px-3 flex items-center gap-2 shrink-0"
              >
                <span className="text-emerald-400 font-bold">$</span>
                <input
                  type="text"
                  value={terminalInput}
                  onChange={(e) => setTerminalInput(e.target.value)}
                  placeholder="Enter command (e.g. java -version, gradle -v, ls -la)..."
                  className="flex-1 bg-transparent text-neutral-100 placeholder-neutral-500 focus:outline-none text-xs font-mono"
                />
                <button
                  type="submit"
                  className="p-1.5 rounded hover:bg-neutral-800 text-neutral-300"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </div>
          )}

          {/* Tab 4: Git */}
          {activeTab === "git" && (
            <div className="flex-1 p-3 overflow-y-auto text-xs text-neutral-300">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <GitBranch className="w-4 h-4 text-emerald-400" />
                  <span className="font-semibold text-neutral-200">Branch: main</span>
                </div>
                <button
                  onClick={() => alert("GitHub remote sync initialized.")}
                  className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-medium text-xs"
                >
                  Pull / Push
                </button>
              </div>
              <div className="p-3 rounded bg-neutral-900 border border-neutral-800">
                <div className="text-[11px] text-neutral-400 font-medium mb-1">Commit changes:</div>
                <input
                  type="text"
                  placeholder="Commit message..."
                  className="w-full px-2 py-1.5 bg-neutral-950 border border-neutral-700 rounded text-neutral-200 focus:outline-none focus:border-emerald-500 text-xs mb-2"
                />
                <button
                  onClick={() => alert("Changes committed locally.")}
                  className="px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs"
                >
                  Commit to Local Repo
                </button>
              </div>
            </div>
          )}

          {/* Tab 5: JDK Status */}
          {activeTab === "jdk" && (
            <div className="flex-1 p-4 overflow-y-auto text-xs text-neutral-300 space-y-3">
              <div className="flex items-center gap-2 text-emerald-400 font-semibold text-sm">
                <ShieldCheck className="w-5 h-5" />
                <span>Local OpenJDK 17 Provisioning & Execution Status</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="p-3 rounded bg-neutral-900 border border-neutral-800 space-y-1">
                  <div className="text-neutral-500 text-[11px]">Target Architecture:</div>
                  <div className="font-mono text-neutral-200 font-semibold">Android 16 / ARM64-v8a</div>
                </div>
                <div className="p-3 rounded bg-neutral-900 border border-neutral-800 space-y-1">
                  <div className="text-neutral-500 text-[11px]">JAVA_HOME:</div>
                  <div className="font-mono text-emerald-400 truncate">{jdkStatus?.javaHome || "/usr/lib/jvm/java-17-openjdk-amd64"}</div>
                </div>
              </div>
              <div className="p-3 rounded bg-neutral-900 border border-neutral-800 space-y-1">
                <div className="text-neutral-500 text-[11px]">Output of `java -version`:</div>
                <pre className="font-mono text-[11px] text-neutral-300 bg-neutral-950 p-2 rounded overflow-x-auto whitespace-pre">
                  {jdkStatus?.output || "openjdk version \"17.0.18\"\nOpenJDK Runtime Environment (build 17.0.18+8-Debian-1deb12u1)"}
                </pre>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
