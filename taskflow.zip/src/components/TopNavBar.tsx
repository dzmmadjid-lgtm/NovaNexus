import React from "react";
import { Play, Square, Search, Sun, Moon, Settings, FolderTree, ShieldCheck } from "lucide-react";
import { BuildStatusType, JdkStatusDto } from "../types";

interface TopNavBarProps {
  appName: string;
  buildStatus: BuildStatusType;
  isSidebarOpen: boolean;
  theme: "dark" | "light";
  jdkStatus: JdkStatusDto | null;
  onToggleSidebar: () => void;
  onRunBuild: () => void;
  onStopBuild: () => void;
  onToggleTheme: () => void;
  onOpenSettings: () => void;
  onOpenSearch: () => void;
}

export const TopNavBar: React.FC<TopNavBarProps> = ({
  appName,
  buildStatus,
  isSidebarOpen,
  theme,
  jdkStatus,
  onToggleSidebar,
  onRunBuild,
  onStopBuild,
  onToggleTheme,
  onOpenSettings,
  onOpenSearch
}) => {
  return (
    <header className="h-12 border-b border-neutral-800 bg-neutral-900/95 px-3 flex items-center justify-between select-none shrink-0 z-20">
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          title={isSidebarOpen ? "Collapse Explorer" : "Expand Explorer"}
          className="p-1.5 rounded hover:bg-neutral-800 text-neutral-300 transition-colors"
        >
          <FolderTree className="w-4 h-4" />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded bg-emerald-600 flex items-center justify-center font-bold text-xs text-white">
            D
          </div>
          <span className="font-semibold text-sm tracking-tight text-neutral-100">
            {appName}
          </span>
          <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800/60 font-medium">
            Android 16 • ARM64
          </span>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {/* JDK indicator pill */}
        <div
          onClick={onOpenSettings}
          className="cursor-pointer hidden sm:flex items-center gap-1.5 px-2 py-1 rounded bg-neutral-800/80 hover:bg-neutral-800 border border-neutral-700/50 text-xs text-neutral-300"
          title={jdkStatus?.output || "Local OpenJDK 17 ARM64"}
        >
          <ShieldCheck className={`w-3.5 h-3.5 ${jdkStatus?.available ? "text-emerald-400" : "text-amber-400"}`} />
          <span className="text-[11px] font-mono">
            {jdkStatus?.isJava17 ? "OpenJDK 17 Ready" : "JDK 17 Active"}
          </span>
        </div>
        {/* Global Search */}
        <button
          onClick={onOpenSearch}
          className="p-1.5 rounded hover:bg-neutral-800 text-neutral-300 text-xs flex items-center gap-1 transition-colors"
          title="Search Project"
        >
          <Search className="w-4 h-4" />
        </button>
        {/* Build Run / Stop button */}
        {buildStatus === "RUNNING" ? (
          <button
            onClick={onStopBuild}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white font-medium text-xs transition-all shadow-sm shadow-rose-950"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            <span>Stop Build</span>
          </button>
        ) : (
          <button
            onClick={onRunBuild}
            className="flex items-center gap-1.5 px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs transition-all shadow-sm shadow-emerald-950"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Build APK</span>
          </button>
        )}
        {/* Theme toggle */}
        <button
          onClick={onToggleTheme}
          className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition-colors"
          title="Toggle Theme"
        >
          {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>
        {/* Settings */}
        <button
          onClick={onOpenSettings}
          className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200 transition-colors"
          title="IDE & JDK Settings"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
