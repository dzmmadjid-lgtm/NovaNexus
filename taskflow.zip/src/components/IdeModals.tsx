import React, { useState } from "react";
import { X, Search, AlertTriangle } from "lucide-react";
import { JdkStatusDto } from "../types";

interface TextInputModalProps {
  isOpen: boolean;
  title: string;
  placeholder?: string;
  initialValue?: string;
  confirmText?: string;
  onConfirm: (val: string) => void;
  onClose: () => void;
}

export const TextInputModal: React.FC<TextInputModalProps> = ({
  isOpen,
  title,
  placeholder,
  initialValue = "",
  confirmText = "Confirm",
  onConfirm,
  onClose
}) => {
  const [val, setVal] = useState(initialValue);
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50">
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 w-full max-w-sm text-neutral-200 shadow-xl">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-sm text-neutral-100">{title}</h3>
          <button onClick={onClose} className="p-1 hover:bg-neutral-800 rounded text-neutral-400">
            <X className="w-4 h-4" />
          </button>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (val.trim()) {
              onConfirm(val.trim());
              onClose();
            }
          }}
        >
          <input
            type="text"
            value={val}
            onChange={(e) => setVal(e.target.value)}
            placeholder={placeholder}
            autoFocus
            className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded text-sm text-neutral-100 focus:outline-none focus:border-emerald-500 font-mono mb-4"
          />
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-xs font-medium text-white transition-colors"
            >
              {confirmText}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

interface ConfirmModalProps {
  isOpen: boolean;
  title: string;
  message: string;
  confirmText?: string;
  isDanger?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({
  isOpen,
  title,
  message,
  confirmText = "Confirm",
  isDanger = false,
  onConfirm,
  onClose
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50">
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-5 w-full max-w-md text-neutral-200 shadow-xl">
        <div className="flex items-center gap-2 mb-3">
          {isDanger && <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0" />}
          <h3 className="font-semibold text-base text-neutral-100">{title}</h3>
        </div>
        <p className="text-xs text-neutral-400 mb-5 leading-relaxed">{message}</p>
        <div className="flex justify-end gap-2">
          <button
            onClick={onClose}
            className="px-3 py-1.5 rounded bg-neutral-800 hover:bg-neutral-700 text-xs font-medium text-neutral-300 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className={`px-3 py-1.5 rounded text-xs font-medium text-white transition-colors ${
              isDanger ? "bg-rose-600 hover:bg-rose-500" : "bg-emerald-600 hover:bg-emerald-500"
            }`}
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
};

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onJumpTo: (file: string, line: number) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose, onJumpTo }) => {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Array<{ file: string; line: number; text: string }>>([]);

  if (!isOpen) return null;

  const handleSearch = async (q: string) => {
    setQuery(q);
    if (!q.trim()) {
      setResults([]);
      return;
    }
    // Search sample in main files
    setResults([
      { file: "app/src/main/java/com/example/MainActivity.kt", line: 12, text: "class MainActivity : ComponentActivity()" },
      { file: "app/build.gradle.kts", line: 7, text: "compileSdk = 36" }
    ]);
  };

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50">
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 w-full max-w-lg text-neutral-200 flex flex-col max-h-[80vh] shadow-xl">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-semibold text-sm text-neutral-100 flex items-center gap-2">
            <Search className="w-4 h-4 text-emerald-400" />
            <span>Search Across Project</span>
          </h3>
          <button onClick={onClose} className="p-1 hover:bg-neutral-800 rounded text-neutral-400">
            <X className="w-4 h-4" />
          </button>
        </div>
        <input
          type="text"
          value={query}
          onChange={(e) => handleSearch(e.target.value)}
          placeholder="Search text in project files..."
          autoFocus
          className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded text-xs text-neutral-100 focus:outline-none focus:border-emerald-500 font-mono mb-3"
        />
        <div className="flex-1 overflow-y-auto space-y-1.5 font-mono text-xs">
          {results.map((res, i) => (
            <div
              key={i}
              onClick={() => {
                onJumpTo(res.file, res.line);
                onClose();
              }}
              className="p-2 rounded bg-neutral-950 hover:bg-neutral-800 border border-neutral-800/60 cursor-pointer"
            >
              <div className="text-emerald-400 text-[11px] font-bold">
                {res.file}:{res.line}
              </div>
              <div className="text-neutral-300 text-[11px] truncate mt-0.5">{res.text}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

interface SettingsModalProps {
  isOpen: boolean;
  jdkStatus: JdkStatusDto | null;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, jdkStatus, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50">
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-5 w-full max-w-lg text-neutral-200 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-sm text-neutral-100">IDE & JDK 17 Configuration</h3>
          <button onClick={onClose} className="p-1 hover:bg-neutral-800 rounded text-neutral-400">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="space-y-3 text-xs">
          <div className="p-3 rounded bg-neutral-950 border border-neutral-800">
            <div className="text-neutral-500 text-[11px]">Runtime Architecture:</div>
            <div className="font-mono text-neutral-200 font-bold mt-0.5">
              Android 16 / ARM64-v8a Compatible
            </div>
          </div>
          <div className="p-3 rounded bg-neutral-950 border border-neutral-800">
            <div className="text-neutral-500 text-[11px]">JAVA_HOME:</div>
            <div className="font-mono text-emerald-400 mt-0.5 truncate">
              {jdkStatus?.javaHome || "/usr/lib/jvm/java-17-openjdk-amd64"}
            </div>
          </div>
          <div className="p-3 rounded bg-neutral-950 border border-neutral-800">
            <div className="text-neutral-500 text-[11px]">java -version command output:</div>
            <pre className="font-mono text-[11px] text-neutral-300 mt-1 overflow-x-auto whitespace-pre">
              {jdkStatus?.output || "openjdk version \"17.0.18\"\nOpenJDK 64-Bit Server VM"}
            </pre>
          </div>
        </div>
        <div className="mt-5 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-xs font-medium text-white transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
