export interface FileNodeDto {
  name: string;
  path: string;
  isDirectory: boolean;
  extension: string;
  children?: FileNodeDto[];
}

export interface EditorTabDto {
  path: string;
  name: string;
  content: string;
  isDirty: boolean;
  extension: string;
  cursorLine: number;
  cursorCol: number;
}

export type BuildStatusType = "IDLE" | "RUNNING" | "SUCCESS" | "FAILED" | "CANCELLED";

export interface BuildLogEntryDto {
  message: string;
  isError: boolean;
  timestamp: number;
}

export interface ProblemDto {
  file: string;
  line: number;
  column: number;
  message: string;
  isError: boolean;
}

export interface ApkFileDto {
  name: string;
  path: string;
  size: number;
}

export interface BuildResultDto {
  status: BuildStatusType;
  exitCode: number;
  durationMs: number;
  apkFile: ApkFileDto | null;
  logs: BuildLogEntryDto[];
}

export interface JdkStatusDto {
  available: boolean;
  output: string;
  isJava17: boolean;
  javaHome: string;
  arch: string;
  targetPlatform: string;
}

export type BottomTabType = "build" | "problems" | "terminal" | "git" | "ai" | "jdk";
