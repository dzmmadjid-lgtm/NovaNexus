package com.example.data.api

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// --- Gemini Request / Response DTOs using Moshi ---

data class GeminiPart(
    val text: String? = null
)

data class GeminiContent(
    val role: String? = null,
    val parts: List<GeminiPart>
)

data class GeminiGenerationConfig(
    val temperature: Float? = null,
    val topP: Float? = null,
    val topK: Int? = null,
    val maxOutputTokens: Int? = null
)

data class GeminiRequest(
    val contents: List<GeminiContent>,
    val generationConfig: GeminiGenerationConfig? = null
)

data class GeminiCandidate(
    val content: GeminiContent?
)

data class GeminiResponse(
    val candidates: List<GeminiCandidate>?
)

interface GeminiRestService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val logging = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BODY
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .addInterceptor(logging)
        .build()

    val api: GeminiRestService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(GeminiRestService::class.java)
    }

    suspend fun askGemini(
        prompt: String,
        temperature: Float = 0.7f,
        history: List<GeminiContent> = emptyList()
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val rawKey: Any? = try {
                BuildConfig::class.java.getField("GEMINI_API_KEY").get(null)
            } catch (e: Exception) {
                null
            }
            val apiKey = (rawKey as? String) ?: ""
            if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
                return@withContext Result.failure(
                    IllegalStateException("KEY_NOT_CONFIGURED")
                )
            }

            val currentContents = if (history.isNotEmpty()) {
                history + GeminiContent(role = "user", parts = listOf(GeminiPart(text = prompt)))
            } else {
                listOf(GeminiContent(role = "user", parts = listOf(GeminiPart(text = prompt))))
            }

            val request = GeminiRequest(
                contents = currentContents,
                generationConfig = GeminiGenerationConfig(
                    temperature = temperature,
                    maxOutputTokens = 2048
                )
            )

            val response = api.generateContent(apiKey = apiKey, request = request)
            val replyText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            if (replyText != null) {
                Result.success(replyText)
            } else {
                Result.failure(Exception("لم يتم استلام نص استجابة من النموذج"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
