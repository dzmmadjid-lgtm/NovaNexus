package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Futuristic Cyber / Neural Theme Colors
val CyberDark = Color(0xFF090D16)
val CyberDarkElevated = Color(0xFF0E1524)
val CyberSurface = Color(0xFF141D30)
val CyberSurfaceVariant = Color(0xFF1E2942)
val CyberSurfaceBorder = Color(0x3300F5D4)

val NeonCyan = Color(0xFF00F5D4)
val NeonCyanDim = Color(0xFF00BFA5)
val NeonViolet = Color(0xFF9D4EDD)
val NeonPurple = Color(0xFF7B2CBF)
val NeonMagenta = Color(0xFFFF007F)
val NeonAmber = Color(0xFFFFB703)
val NeonGreen = Color(0xFF06D6A0)
val NeonBlue = Color(0xFF3A86FF)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Gradients
val CyberGradient = Brush.linearGradient(
    colors = listOf(NeonCyan, NeonViolet)
)

val GlowGradient = Brush.radialGradient(
    colors = listOf(NeonCyan.copy(alpha = 0.25f), Color.Transparent)
)

val CardGradient = Brush.verticalGradient(
    colors = listOf(CyberSurface.copy(alpha = 0.95f), CyberDarkElevated.copy(alpha = 0.95f))
)

val AccentGradient = Brush.horizontalGradient(
    colors = listOf(NeonCyan, NeonBlue, NeonViolet)
)
