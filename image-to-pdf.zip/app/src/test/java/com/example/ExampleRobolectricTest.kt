package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.build.ProblemsParser
import com.example.core.editor.CodeSyntaxHighlighter
import com.example.core.fs.ProjectManager
import com.example.data.model.ThemeMode
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("DroidIDE", appName)
    }

    @Test
    fun `test project creation and file structure`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val pm = ProjectManager(context)

        val project = pm.createProject(
            projectName = "TestApp",
            packageName = "com.example.testapp",
            minSdk = 24,
            targetSdk = 36,
            template = "Compose Empty Activity"
        )

        assertNotNull(project)
        assertTrue(project.rootDir.exists())
        assertEquals("TestApp", project.name)

        val fileTree = pm.buildFileTree(project.rootDir)
        assertTrue(fileTree.children.isNotEmpty())

        val buildGradle = File(project.rootDir, "build.gradle.kts")
        assertTrue(buildGradle.exists())
        val gradleContent = pm.readFileContent(buildGradle)
        assertTrue(gradleContent.contains("android"))
    }

    @Test
    fun `test problems parser with compiler error lines`() {
        val rootDir = File("/tmp/test_project")
        val errorLine = "e: /tmp/test_project/app/src/main/java/MainActivity.kt:14:5: error: Unresolved reference 'Button'"
        val problem = ProblemsParser.parseLine(errorLine, rootDir)

        assertNotNull(problem)
        assertTrue(problem!!.isError)
        assertEquals(14, problem.line)
        assertEquals(5, problem.column)
        assertTrue(problem.message.contains("Unresolved reference"))
    }

    @Test
    fun `test syntax highlighter generates styled text`() {
        val kotlinCode = """
            package com.example
            import androidx.compose.material3.Text
            class MainActivity {
                fun test() {
                    val message = "Hello Android"
                }
            }
        """.trimIndent()

        val annotated = CodeSyntaxHighlighter.highlightCode(
            text = kotlinCode,
            extension = "kt",
            themeMode = ThemeMode.DARK
        )

        assertNotNull(annotated)
        assertEquals(kotlinCode, annotated.text)
        assertTrue(annotated.spanStyles.isNotEmpty())
    }

    @Test
    fun `test build environment detector wrapper inspection`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val pm = ProjectManager(context)

        val project = pm.createProject(
            projectName = "BuildCheckApp",
            packageName = "com.example.buildcheck",
            minSdk = 24,
            targetSdk = 36,
            template = "Compose Empty Activity"
        )

        val report = com.example.core.build.BuildEnvironmentDetector.detect(context, project.rootDir)
        assertNotNull(report)
        assertTrue("Project should have gradlew", report.wrapperStatus.hasGradlew)
        assertTrue("Project should have wrapper properties", report.wrapperStatus.hasWrapperProperties)
        assertTrue("Project should have wrapper jar", report.wrapperStatus.hasWrapperJar)
        assertNotNull(report.wrapperStatus.distributionUrl)
        assertTrue(report.wrapperStatus.distributionUrl!!.contains("gradle-8.9"))
    }
}

