package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.build.ProblemsParser
import com.example.core.editor.CodeSyntaxHighlighter
import com.example.core.fs.ProjectManager
import com.example.data.model.ThemeMode
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("DroidIDE", appName)
    }

    @Test
    fun `test project creation and file structure`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val pm = ProjectManager(context)

        val project = pm.createProject(
            projectName = "TestApp",
            packageName = "com.example.testapp",
            minSdk = 24,
            targetSdk = 36,
            template = "Compose Empty Activity"
        )

        assertNotNull(project)
        assertTrue(project.rootDir.exists())
        assertEquals("TestApp", project.name)

        val fileTree = pm.buildFileTree(project.rootDir)
        assertTrue(fileTree.children.isNotEmpty())

        val buildGradle = File(project.rootDir, "build.gradle.kts")
        assertTrue(buildGradle.exists())
        val gradleContent = pm.readFileContent(buildGradle)
        assertTrue(gradleContent.contains("android"))
    }

    @Test
    fun `test problems parser with compiler error lines`() {
        val rootDir = File("/tmp/test_project")
        val errorLine = "e: /tmp/test_project/app/src/main/java/MainActivity.kt:14:5: error: Unresolved reference 'Button'"
        val problem = ProblemsParser.parseLine(errorLine, rootDir)

        assertNotNull(problem)
        assertTrue(problem!!.isError)
        assertEquals(14, problem.line)
        assertEquals(5, problem.column)
        assertTrue(problem.message.contains("Unresolved reference"))
    }

    @Test
    fun `test syntax highlighter generates styled text`() {
        val kotlinCode = """
            package com.example
            import androidx.compose.material3.Text
            class MainActivity {
                fun test() {
                    val message = "Hello Android"
                }
            }
        """.trimIndent()

        val annotated = CodeSyntaxHighlighter.highlightCode(
            text = kotlinCode,
            extension = "kt",
            themeMode = ThemeMode.DARK
        )

        assertNotNull(annotated)
        assertEquals(kotlinCode, annotated.text)
        assertTrue(annotated.spanStyles.isNotEmpty())
    }

    @Test
    fun `test build environment detector wrapper inspection`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val pm = ProjectManager(context)

        val project = pm.createProject(
            projectName = "BuildCheckApp",
            packageName = "com.example.buildcheck",
            minSdk = 24,
            targetSdk = 36,
            template = "Compose Empty Activity"
        )

        val report = com.example.core.build.BuildEnvironmentDetector.detect(context, project.rootDir)
        assertNotNull(report)
        assertTrue("Project should have gradlew", report.wrapperStatus.hasGradlew)
        assertTrue("Project should have wrapper properties", report.wrapperStatus.hasWrapperProperties)
        assertTrue("Project should have wrapper jar", report.wrapperStatus.hasWrapperJar)
        assertNotNull(report.wrapperStatus.distributionUrl)
        assertTrue(report.wrapperStatus.distributionUrl!!.contains("gradle-8.9"))
    }

    @Test
    fun `test zip import flattens nested repo folder and makes gradlew executable`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val pm = ProjectManager(context)

        // 1. Create a real Android project
        val origProj = pm.createProject(
            projectName = "SampleZipApp",
            packageName = "com.example.samplezip",
            minSdk = 24,
            targetSdk = 36,
            template = "Compose Empty Activity"
        )

        // 2. Export to zip
        val zipFile = File(context.cacheDir, "sample_export.zip")
        com.example.core.fs.ZipUtils.exportProjectToZip(origProj.rootDir, zipFile)
        assertTrue(zipFile.exists() && zipFile.length() > 0)

        // 3. Import from zip into imported_6901
        val targetDir = File(pm.rootProjectsDir, "imported_6901")
        if (targetDir.exists()) targetDir.deleteRecursively()

        zipFile.inputStream().use { stream ->
            com.example.core.fs.ZipUtils.importProjectFromZip(stream, targetDir)
        }

        // 4. Verify filesystem directly
        val gradlewFile = File(targetDir, "gradlew")
        assertTrue("gradlew must exist directly in imported_6901", gradlewFile.exists())
        assertTrue("gradlew must be executable", gradlewFile.canExecute())

        val wrapperProps = File(targetDir, "gradle/wrapper/gradle-wrapper.properties")
        assertTrue("wrapper properties must exist", wrapperProps.exists())

        val wrapperJar = File(targetDir, "gradle/wrapper/gradle-wrapper.jar")
        assertTrue("wrapper jar must exist", wrapperJar.exists())
    }

    @Test
    fun `test build engine logs correct working directory and wrapper status`() = kotlinx.coroutines.runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val pm = ProjectManager(context)

        val project = pm.createProject(
            projectName = "BuildEngineTestApp",
            packageName = "com.example.enginetest",
            minSdk = 24,
            targetSdk = 36,
            template = "Compose Empty Activity"
        )

        val engine = com.example.core.build.LocalProcessBuildEngine(context)
        val logs = mutableListOf<String>()

        val result = engine.build(project, "assembleDebug") { entry ->
            logs.add(entry.message)
            println(entry.message)
        }

        assertNotNull(result)
        // Verify required logging format
        assertTrue("Must log Working directory", logs.any { it.startsWith("Working directory:") && it.contains(project.rootDir.absolutePath) })
        assertTrue("Must log Gradle wrapper: found", logs.any { it.contains("Gradle wrapper: found") })
        assertTrue("Must log Gradle wrapper: ./gradlew", logs.any { it.contains("Gradle wrapper: ./gradlew") })
        assertTrue("Must log JAVA_HOME", logs.any { it.startsWith("JAVA_HOME:") })
        assertTrue("Must log java path", logs.any { it.startsWith("java path:") })
        assertTrue("Must log Java version", logs.any { it.startsWith("Java version:") })
        assertTrue("Must log Testing Java runtime", logs.any { it.contains("Testing Java runtime before executing Gradle:") })
        assertTrue("Must log Executing: ./gradlew assembleDebug", logs.any { it.contains("Executing: ./gradlew assembleDebug") })
    }
}

