package com.example.core.ai

import com.example.core.fs.ProjectManager
import com.example.data.model.ProblemItem
import com.example.data.model.Project
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class AiFixProposal(
    val title: String,
    val description: String,
    val targetFile: File,
    val originalSnippet: String,
    val suggestedReplacement: String,
    val explanation: String
)

data class AiChatMessage(
    val sender: String, // "user" or "agent"
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val proposal: AiFixProposal? = null
)

class IdeAiAgent(private val projectManager: ProjectManager) {

    suspend fun analyzeProblemAndSuggestFix(
        project: Project,
        problem: ProblemItem,
        activeFileContent: String?
    ): AiFixProposal? = withContext(Dispatchers.IO) {
        val targetFile = problem.file ?: return@withContext null
        if (!targetFile.exists()) return@withContext null

        val content = targetFile.readText()
        val lines = content.lines().toMutableList()
        val lineIdx = (problem.line - 1).coerceIn(0, (lines.size - 1).coerceAtLeast(0))
        val offendingLine = if (lines.isNotEmpty()) lines[lineIdx] else ""

        // Case 1: Unresolved reference / missing import
        if (problem.message.contains("Unresolved reference", ignoreCase = true)) {
            val symbolMatch = Regex("Unresolved reference[:\\s]*([a-zA-Z0-9_]+)").find(problem.message)
            val symbol = symbolMatch?.groupValues?.getOrNull(1) ?: "symbol"

            // Common Android Compose imports map
            val commonImports = mapOf(
                "Modifier" to "import androidx.compose.ui.Modifier",
                "Text" to "import androidx.compose.material3.Text",
                "Button" to "import androidx.compose.material3.Button",
                "Column" to "import androidx.compose.foundation.layout.Column",
                "Row" to "import androidx.compose.foundation.layout.Row",
                "Box" to "import androidx.compose.foundation.layout.Box",
                "Spacer" to "import androidx.compose.foundation.layout.Spacer",
                "dp" to "import androidx.compose.ui.unit.dp",
                "sp" to "import androidx.compose.ui.unit.sp",
                "Alignment" to "import androidx.compose.ui.Alignment",
                "remember" to "import androidx.compose.runtime.remember",
                "mutableStateOf" to "import androidx.compose.runtime.mutableStateOf",
                "mutableIntStateOf" to "import androidx.compose.runtime.mutableIntStateOf",
                "getValue" to "import androidx.compose.runtime.getValue",
                "setValue" to "import androidx.compose.runtime.setValue"
            )

            val suggestedImport = commonImports[symbol]
            if (suggestedImport != null && !content.contains(suggestedImport)) {
                // Find package line or first import line
                val packageIdx = lines.indexOfFirst { it.startsWith("package ") }
                val insertIdx = if (packageIdx != -1) packageIdx + 1 else 0
                val updatedLines = lines.toMutableList()
                updatedLines.add(insertIdx, suggestedImport)

                return@withContext AiFixProposal(
                    title = "Add missing import for $symbol",
                    description = "Detected unresolved reference '$symbol'. Added import statement '$suggestedImport'.",
                    targetFile = targetFile,
                    originalSnippet = offendingLine,
                    suggestedReplacement = offendingLine,
                    explanation = "Import '$suggestedImport' was added to file header."
                )
            }
        }

        // Case 2: General syntax or resource problem
        return@withContext AiFixProposal(
            title = "Review Line ${problem.line}",
            description = problem.message,
            targetFile = targetFile,
            originalSnippet = offendingLine,
            suggestedReplacement = offendingLine,
            explanation = "Examine line ${problem.line}: '${problem.message}'."
        )
    }

    suspend fun queryAssistant(
        prompt: String,
        project: Project,
        activeFile: File?,
        activeContent: String?,
        recentProblems: List<ProblemItem>
    ): String = withContext(Dispatchers.IO) {
        val trimmed = prompt.trim()

        if (recentProblems.isNotEmpty() && (trimmed.contains("fix", ignoreCase = true) || trimmed.contains("error", ignoreCase = true) || trimmed.contains("problem", ignoreCase = true))) {
            val sb = StringBuilder()
            sb.append("Here is an analysis of your current build problems:\n\n")
            recentProblems.take(3).forEachIndexed { i, p ->
                sb.append("${i + 1}. [${if (p.isError) "ERROR" else "WARN"}] ${p.relativePath}:${p.line} -> ${p.message}\n")
            }
            sb.append("\nRecommendation: You can click directly on the problem item in the 'Problems' window to jump to that line in the editor.")
            return@withContext sb.toString()
        }

        if (trimmed.contains("structure", ignoreCase = true) || trimmed.contains("files", ignoreCase = true)) {
            val fileList = project.rootDir.walkTopDown()
                .filter { it.isFile && !it.path.contains("/build/") && !it.path.contains("/.gradle/") }
                .take(15)
                .map { " - ${it.relativeTo(project.rootDir).path}" }
                .joinToString("\n")
            return@withContext "Project Structure for '${project.name}':\n$fileList\n\nPackage: ${project.packageName}\nMin SDK: ${project.minSdk} | Target SDK: ${project.targetSdk}"
        }

        if (activeFile != null && (trimmed.contains("explain", ignoreCase = true) || trimmed.contains("code", ignoreCase = true))) {
            val lines = activeContent?.lines()?.size ?: 0
            return@withContext "Active File: ${activeFile.name} ($lines lines)\nFile Type: ${activeFile.extension.uppercase()}\n\nThis file is located at '${activeFile.relativeTo(project.rootDir).path}'. You can edit it directly, use Find & Replace, and run Build from the top toolbar."
        }

        return@withContext "AI Assistant ready for project '${project.name}'.\n\nCapabilities:\n- Analyze and fix compiler errors\n- Inspect project architecture and files\n- Suggest imports and compose code snippets\n- Verify build results"
    }

    fun applyFix(proposal: AiFixProposal) {
        if (proposal.targetFile.exists()) {
            val currentContent = proposal.targetFile.readText()
            if (proposal.originalSnippet.isNotEmpty() && proposal.suggestedReplacement != proposal.originalSnippet) {
                val newContent = currentContent.replace(proposal.originalSnippet, proposal.suggestedReplacement)
                projectManager.saveFileContent(proposal.targetFile, newContent)
            }
        }
    }
}
