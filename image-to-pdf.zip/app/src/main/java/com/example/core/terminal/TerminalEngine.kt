package com.example.core.terminal

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

data class TerminalLine(
    val text: String,
    val isCommand: Boolean = false,
    val isError: Boolean = false
)

class TerminalEngine(private val scope: CoroutineScope) {

    private val _output = MutableStateFlow<List<TerminalLine>>(emptyList())
    val output: StateFlow<List<TerminalLine>> = _output.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private var activeProcess: Process? = null
    private var executionJob: Job? = null

    fun appendLine(text: String, isCommand: Boolean = false, isError: Boolean = false) {
        _output.value = _output.value + TerminalLine(text, isCommand, isError)
    }

    fun clear() {
        _output.value = emptyList()
    }

    fun executeCommand(command: String, workingDir: File) {
        val trimmed = command.trim()
        if (trimmed.isEmpty()) return

        appendLine("$ $trimmed", isCommand = true)

        if (trimmed == "clear" || trimmed == "cls") {
            clear()
            return
        }

        executionJob?.cancel()
        executionJob = scope.launch(Dispatchers.IO) {
            _isRunning.value = true
            try {
                val pb = ProcessBuilder("/system/bin/sh", "-c", trimmed)
                pb.directory(workingDir)
                pb.redirectErrorStream(false)

                val env = pb.environment()
                val androidHome = System.getenv("ANDROID_HOME") ?: System.getenv("ANDROID_SDK_ROOT")
                if (androidHome != null) {
                    env["ANDROID_HOME"] = androidHome
                    env["ANDROID_SDK_ROOT"] = androidHome
                }

                val process = pb.start()
                activeProcess = process

                // Coroutine to read stdout
                val outJob = launch {
                    val reader = BufferedReader(InputStreamReader(process.inputStream))
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        appendLine(line ?: "")
                    }
                }

                // Coroutine to read stderr
                val errJob = launch {
                    val errReader = BufferedReader(InputStreamReader(process.errorStream))
                    var errLine: String?
                    while (errReader.readLine().also { errLine = it } != null) {
                        appendLine(errLine ?: "", isError = true)
                    }
                }

                outJob.join()
                errJob.join()

                val exitCode = process.waitFor()
                appendLine("[Process completed with exit code $exitCode]")
            } catch (e: Exception) {
                appendLine("Terminal execution error: ${e.localizedMessage}", isError = true)
            } finally {
                activeProcess = null
                _isRunning.value = false
            }
        }
    }

    fun stop() {
        activeProcess?.destroy()
        executionJob?.cancel()
        activeProcess = null
        _isRunning.value = false
        appendLine("[Process stopped by user]", isError = true)
    }
}
