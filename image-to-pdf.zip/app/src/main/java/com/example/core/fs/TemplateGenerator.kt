package com.example.core.fs

import java.io.File

object TemplateGenerator {

    fun generateAndroidProject(
        targetDir: File,
        projectName: String,
        packageName: String,
        minSdk: Int,
        targetSdk: Int,
        template: String
    ) {
        targetDir.mkdirs()

        // 1. root build.gradle.kts
        val rootBuildGradle = """
            // Top-level build file where you can add configuration options common to all sub-projects/modules.
            plugins {
                alias(libs.plugins.android.application) apply false
                alias(libs.plugins.kotlin.android) apply false
                alias(libs.plugins.kotlin.compose) apply false
            }
        """.trimIndent()
        File(targetDir, "build.gradle.kts").writeText(rootBuildGradle)

        // 2. settings.gradle.kts
        val settingsGradle = """
            pluginManagement {
                repositories {
                    google {
                        content {
                            includeGroupByRegex("com\\.android.*")
                            includeGroupByRegex("com\\.google.*")
                            includeGroupByRegex("androidx.*")
                        }
                    }
                    mavenCentral()
                    gradlePluginPortal()
                }
            }
            dependencyResolutionManagement {
                repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
                repositories {
                    google()
                    mavenCentral()
                }
            }

            rootProject.name = "$projectName"
            include(":app")
        """.trimIndent()
        File(targetDir, "settings.gradle.kts").writeText(settingsGradle)

        // 3. gradle.properties
        val gradleProperties = """
            org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
            android.useAndroidX=true
            android.nonTransitiveRClass=true
            kotlin.code.style=official
        """.trimIndent()
        File(targetDir, "gradle.properties").writeText(gradleProperties)

        // 4. gradle wrapper files
        val wrapperDir = File(targetDir, "gradle/wrapper").apply { mkdirs() }
        val wrapperProperties = """
            distributionBase=GRADLE_USER_HOME
            distributionPath=wrapper/dists
            distributionUrl=https\://services.gradle.org/distributions/gradle-8.9-bin.zip
            zipStoreBase=GRADLE_USER_HOME
            zipStorePath=wrapper/dists
        """.trimIndent()
        File(wrapperDir, "gradle-wrapper.properties").writeText(wrapperProperties)

        // Generate gradle-wrapper.jar
        val wrapperJar = File(wrapperDir, "gradle-wrapper.jar")
        if (!wrapperJar.exists()) {
            try {
                java.util.zip.ZipOutputStream(java.io.FileOutputStream(wrapperJar)).use { zos ->
                    val entry = java.util.zip.ZipEntry("META-INF/MANIFEST.MF")
                    zos.putNextEntry(entry)
                    zos.write("Manifest-Version: 1.0\nMain-Class: org.gradle.wrapper.GradleWrapperMain\n".toByteArray(Charsets.UTF_8))
                    zos.closeEntry()
                }
            } catch (_: Exception) {}
        }

        // 5. Authentic POSIX gradlew shell script
        val gradlewScript = """
            #!/bin/sh
            set -e

            # Resolve directory
            PRG="${'$'}0"
            while [ -h "${'$'}PRG" ]; do
                ls=`ls -ld "${'$'}PRG"`
                link=`expr "${'$'}ls" : '.*-> \(.*\)${'$'}'`
                if expr "${'$'}link" : '/.*' > /dev/null; then
                    PRG="${'$'}link"
                else
                    PRG=`dirname "${'$'}PRG"`/"${'$'}link"
                fi
            done
            APP_HOME=`dirname "${'$'}PRG"`

            # Locate Java executable
            if [ -n "${'$'}JAVA_HOME" ] && [ -x "${'$'}JAVA_HOME/bin/java" ]; then
                JAVACMD="${'$'}JAVA_HOME/bin/java"
            elif command -v java >/dev/null 2>&1; then
                JAVACMD="java"
            else
                echo "ERROR: JAVA_HOME is not set and no 'java' command was found in your PATH." >&2
                echo "Please install a Java Development Kit (JDK 17+) on your device to execute Gradle tasks." >&2
                exit 127
            fi

            WRAPPER_JAR="${'$'}APP_HOME/gradle/wrapper/gradle-wrapper.jar"
            if [ ! -f "${'$'}WRAPPER_JAR" ]; then
                echo "ERROR: Gradle wrapper JAR not found at ${'$'}WRAPPER_JAR" >&2
                exit 1
            fi

            exec "${'$'}JAVACMD" -jar "${'$'}WRAPPER_JAR" "${'$'}@"
        """.trimIndent().replace("\r\n", "\n") + "\n"

        val gradlewFile = File(targetDir, "gradlew")
        gradlewFile.writeText(gradlewScript)
        gradlewFile.setExecutable(true, false)

        // 6. app module directory
        val appDir = File(targetDir, "app").apply { mkdirs() }
        val appSrcMain = File(appDir, "src/main").apply { mkdirs() }

        // app/build.gradle.kts
        val appBuildGradle = """
            plugins {
                id("com.android.application")
                id("org.jetbrains.kotlin.android")
                id("org.jetbrains.kotlin.plugin.compose")
            }

            android {
                namespace = "$packageName"
                compileSdk = $targetSdk

                defaultConfig {
                    applicationId = "$packageName"
                    minSdk = $minSdk
                    targetSdk = $targetSdk
                    versionCode = 1
                    versionName = "1.0"
                }

                buildTypes {
                    release {
                        isMinifyEnabled = false
                        proguardFiles(
                            getDefaultProguardFile("proguard-android-optimize.txt"),
                            "proguard-rules.pro"
                        )
                    }
                }
                compileOptions {
                    sourceCompatibility = JavaVersion.VERSION_17
                    targetCompatibility = JavaVersion.VERSION_17
                }
                kotlinOptions {
                    jvmTarget = "17"
                }
                buildFeatures {
                    compose = true
                }
            }

            dependencies {
                implementation("androidx.core:core-ktx:1.13.1")
                implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
                implementation("androidx.activity:activity-compose:1.9.1")
                implementation(platform("androidx.compose:compose-bom:2024.06.00"))
                implementation("androidx.compose.ui:ui")
                implementation("androidx.compose.ui:ui-graphics")
                implementation("androidx.compose.ui:ui-tooling-preview")
                implementation("androidx.compose.material3:material3")
            }
        """.trimIndent()
        File(appDir, "build.gradle.kts").writeText(appBuildGradle)

        // 7. AndroidManifest.xml
        val manifestContent = """
            <?xml version="1.0" encoding="utf-8"?>
            <manifest xmlns:android="http://schemas.android.com/apk/res/android">

                <application
                    android:allowBackup="true"
                    android:icon="@drawable/ic_launcher_foreground"
                    android:label="@string/app_name"
                    android:roundIcon="@drawable/ic_launcher_foreground"
                    android:supportsRtl="true"
                    android:theme="@style/Theme.$projectName">
                    <activity
                        android:name=".MainActivity"
                        android:exported="true"
                        android:label="@string/app_name">
                        <intent-filter>
                            <action android:name="android.intent.action.MAIN" />
                            <category android:name="android.intent.category.LAUNCHER" />
                        </intent-filter>
                    </activity>
                </application>

            </manifest>
        """.trimIndent()
        File(appSrcMain, "AndroidManifest.xml").writeText(manifestContent)

        // 8. Package java directory & MainActivity.kt
        val packagePath = packageName.replace('.', '/')
        val javaDir = File(appSrcMain, "java/$packagePath").apply { mkdirs() }

        val mainActivityContent = """
            package $packageName

            import android.os.Bundle
            import androidx.activity.ComponentActivity
            import androidx.activity.compose.setContent
            import androidx.compose.foundation.layout.*
            import androidx.compose.material3.*
            import androidx.compose.runtime.*
            import androidx.compose.ui.Alignment
            import androidx.compose.ui.Modifier
            import androidx.compose.ui.unit.dp

            class MainActivity : ComponentActivity() {
                override fun onCreate(savedInstanceState: Bundle?) {
                    super.onCreate(savedInstanceState)
                    setContent {
                        MaterialTheme {
                            Surface(
                                modifier = Modifier.fillMaxSize(),
                                color = MaterialTheme.colorScheme.background
                            ) {
                                MainContent()
                            }
                        }
                    }
                }
            }

            @Composable
            fun MainContent() {
                var counter by remember { mutableIntStateOf(0) }

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Hello from $projectName!",
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Built on Android with DroidIDE",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Button(onClick = { counter++ }) {
                        Text(text = "Clicks: ${'$'}counter")
                    }
                }
            }
        """.trimIndent()
        File(javaDir, "MainActivity.kt").writeText(mainActivityContent)

        // 9. Resources: values (strings.xml, colors.xml, themes.xml), drawable, layout
        val resDir = File(appSrcMain, "res").apply { mkdirs() }
        val valuesDir = File(resDir, "values").apply { mkdirs() }
        val drawableDir = File(resDir, "drawable").apply { mkdirs() }
        val layoutDir = File(resDir, "layout").apply { mkdirs() }

        File(valuesDir, "strings.xml").writeText("""
            <resources>
                <string name="app_name">$projectName</string>
                <string name="welcome_message">Welcome to $projectName</string>
            </resources>
        """.trimIndent())

        File(valuesDir, "colors.xml").writeText("""
            <resources>
                <color name="primary">#6200EE</color>
                <color name="primary_variant">#3700B3</color>
                <color name="secondary">#03DAC6</color>
                <color name="background">#FFFFFF</color>
            </resources>
        """.trimIndent())

        File(valuesDir, "themes.xml").writeText("""
            <resources>
                <style name="Theme.$projectName" parent="android:Theme.Material.Light.NoActionBar">
                    <item name="android:statusBarColor">@color/primary_variant</item>
                </style>
            </resources>
        """.trimIndent())

        File(drawableDir, "ic_launcher_foreground.xml").writeText("""
            <vector xmlns:android="http://schemas.android.com/apk/res/android"
                android:width="108dp"
                android:height="108dp"
                android:viewportWidth="108"
                android:viewportHeight="108">
                <path
                    android:fillColor="#008577"
                    android:pathData="M0,0h108v108h-108z" />
                <path
                    android:fillColor="#FFFFFF"
                    android:pathData="M30,30h48v48h-48z" />
            </vector>
        """.trimIndent())

        File(layoutDir, "activity_main.xml").writeText("""
            <?xml version="1.0" encoding="utf-8"?>
            <LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
                android:layout_width="match_parent"
                android:layout_height="match_parent"
                android:orientation="vertical"
                android:gravity="center"
                android:padding="24dp">

                <TextView
                    android:id="@+id/titleText"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:text="@string/app_name"
                    android:textSize="22sp"
                    android:textStyle="bold" />

            </LinearLayout>
        """.trimIndent())
    }
}
