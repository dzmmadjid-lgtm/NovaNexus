package com.example.core.fs

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ZipUtils {

    fun exportProjectToZip(projectDir: File, destinationZip: File) {
        if (!projectDir.exists()) return
        destinationZip.parentFile?.mkdirs()

        ZipOutputStream(BufferedOutputStream(FileOutputStream(destinationZip))).use { zos ->
            zipFileTree(projectDir, projectDir.name, zos)
        }
    }

    private fun zipFileTree(fileToZip: File, baseName: String, zos: ZipOutputStream) {
        // Skip .gradle cache and build folders to keep zip compact and clean
        if (fileToZip.name == ".gradle" || fileToZip.name == "build" && fileToZip.isDirectory) {
            return
        }

        if (fileToZip.isDirectory) {
            val children = fileToZip.listFiles() ?: return
            for (child in children) {
                zipFileTree(child, "$baseName/${child.name}", zos)
            }
        } else {
            val entry = ZipEntry(baseName)
            zos.putNextEntry(entry)
            FileInputStream(fileToZip).use { fis ->
                fis.copyTo(zos)
            }
            zos.closeEntry()
        }
    }

    fun importProjectFromZip(zipStream: InputStream, targetDir: File): File? {
        if (!targetDir.exists()) {
            targetDir.mkdirs()
        }

        var detectedProjectFolder: File? = null
        val buffer = ByteArray(8192)

        ZipInputStream(BufferedInputStream(zipStream)).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val entryName = entry.name
                // Guard against zip slip vulnerability
                val newFile = File(targetDir, entryName)
                val canonicalTarget = targetDir.canonicalPath
                val canonicalFile = newFile.canonicalPath
                if (!canonicalFile.startsWith(canonicalTarget + File.separator) && canonicalFile != canonicalTarget) {
                    entry = zis.nextEntry
                    continue
                }

                if (entry.isDirectory) {
                    newFile.mkdirs()
                    if (detectedProjectFolder == null && !entryName.contains("/")) {
                        detectedProjectFolder = newFile
                    }
                } else {
                    newFile.parentFile?.mkdirs()
                    FileOutputStream(newFile).use { fos ->
                        var len: Int
                        while (zis.read(buffer).also { len = it } > 0) {
                            fos.write(buffer, 0, len)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        // Return the project folder (or targetDir if root files exist)
        return detectedProjectFolder ?: targetDir
    }
}
