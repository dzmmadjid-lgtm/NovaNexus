package com.example.core.fs

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

object ZipUtils {

    fun exportProjectToZip(projectDir: File, destinationZip: File) {
        if (!projectDir.exists()) return
        destinationZip.parentFile?.mkdirs()

        ZipOutputStream(BufferedOutputStream(FileOutputStream(destinationZip))).use { zos ->
            zipFileTree(projectDir, projectDir.name, zos)
        }
    }

    private fun zipFileTree(fileToZip: File, baseName: String, zos: ZipOutputStream) {
        // Skip .gradle cache and build folders to keep zip clean
        if (fileToZip.name == ".gradle" || (fileToZip.name == "build" && fileToZip.isDirectory)) {
            return
        }

        if (fileToZip.isDirectory) {
            val children = fileToZip.listFiles() ?: return
            for (child in children) {
                zipFileTree(child, "$baseName/${child.name}", zos)
            }
        } else {
            val entry = ZipEntry(baseName)
            zos.putNextEntry(entry)
            FileInputStream(fileToZip).use { fis ->
                fis.copyTo(zos)
            }
            zos.closeEntry()
        }
    }

    /**
     * Extracts an imported ZIP stream completely onto the filesystem.
     * Preserves:
     * - directory structures and file names
     * - hidden files (.gitignore, .gradle, dotfiles)
     * - executable permissions for gradlew
     * - gradle wrapper properties and jar
     * - flattens single root folder if the ZIP wrapped the project inside a subfolder
     */
    fun importProjectFromZip(zipStream: InputStream, targetDir: File): File {
        if (!targetDir.exists()) {
            targetDir.mkdirs()
        }

        // 1. Buffer stream to temporary ZIP file for safe 2-pass inspection
        val tempZipFile = File.createTempFile("import_project_", ".zip", targetDir.parentFile)
        try {
            FileOutputStream(tempZipFile).use { fos ->
                zipStream.copyTo(fos)
            }

            ZipFile(tempZipFile).use { zip ->
                val entries = zip.entries().asSequence().toList()

                // Check if all non-empty entries share a common top-level directory prefix (e.g., "MyProject-master/")
                val topLevelNames = entries
                    .map { it.name.trimStart('/') }
                    .filter { it.isNotBlank() }
                    .map { it.split('/').first() }
                    .distinct()

                val commonPrefix = if (topLevelNames.size == 1 && entries.any { it.name.contains('/') }) {
                    "${topLevelNames.first()}/"
                } else {
                    ""
                }

                val canonicalTarget = targetDir.canonicalPath
                val buffer = ByteArray(8192)

                for (entry in entries) {
                    var entryName = entry.name.trimStart('/')
                    if (commonPrefix.isNotEmpty() && entryName.startsWith(commonPrefix)) {
                        entryName = entryName.removePrefix(commonPrefix)
                    }

                    if (entryName.isBlank()) continue

                    val outFile = File(targetDir, entryName)
                    val canonicalOut = outFile.canonicalPath

                    // Zip Slip security check
                    if (!canonicalOut.startsWith(canonicalTarget + File.separator) && canonicalOut != canonicalTarget) {
                        continue
                    }

                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        zip.getInputStream(entry).use { input ->
                            FileOutputStream(outFile).use { output ->
                                var len: Int
                                while (input.read(buffer).also { len = it } > 0) {
                                    output.write(buffer, 0, len)
                                }
                                output.flush()
                            }
                        }

                        // Restore execution permissions and line endings for gradlew
                        if (outFile.name == "gradlew") {
                            normalizeAndMakeExecutable(outFile)
                        }
                    }
                }
            }
        } finally {
            if (tempZipFile.exists()) {
                tempZipFile.delete()
            }
        }

        // 2. Post-extraction validation & nested directory promotion
        // If targetDir does not have gradlew, but an immediate subdirectory does, promote files up to targetDir
        val rootGradlew = File(targetDir, "gradlew")
        if (!rootGradlew.exists()) {
            val subFolders = targetDir.listFiles { f -> f.isDirectory } ?: emptyArray()
            val childWithProject = subFolders.firstOrNull { child ->
                File(child, "gradlew").exists() ||
                        File(child, "build.gradle").exists() ||
                        File(child, "build.gradle.kts").exists() ||
                        File(child, "settings.gradle").exists() ||
                        File(child, "settings.gradle.kts").exists()
            }

            if (childWithProject != null) {
                // Flatten child into targetDir
                promoteDirectoryContents(childWithProject, targetDir)
            }
        }

        // Final verification on gradlew if present
        val finalGradlew = File(targetDir, "gradlew")
        if (finalGradlew.exists()) {
            normalizeAndMakeExecutable(finalGradlew)
        }

        return targetDir
    }

    private fun normalizeAndMakeExecutable(file: File) {
        try {
            if (file.exists() && file.isFile) {
                val text = file.readText()
                if (text.contains("\r\n")) {
                    file.writeText(text.replace("\r\n", "\n"))
                }
                file.setExecutable(true, false)
                file.setReadable(true, false)
                try {
                    Runtime.getRuntime().exec(arrayOf("chmod", "755", file.absolutePath)).waitFor()
                } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    private fun promoteDirectoryContents(sourceDir: File, destDir: File) {
        val children = sourceDir.listFiles() ?: return
        for (child in children) {
            val destChild = File(destDir, child.name)
            if (destChild.exists()) {
                if (destChild.isDirectory) destChild.deleteRecursively() else destChild.delete()
            }
            child.renameTo(destChild)
        }
        sourceDir.delete()
    }
}
