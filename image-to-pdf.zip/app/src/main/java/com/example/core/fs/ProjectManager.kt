package com.example.core.fs

import android.content.Context
import com.example.data.model.FileNode
import com.example.data.model.Project
import java.io.File

class ProjectManager(private val context: Context) {

    val rootProjectsDir: File
        get() {
            val dir = context.getExternalFilesDir("projects") ?: File(context.filesDir, "projects")
            if (!dir.exists()) {
                dir.mkdirs()
            }
            return dir
        }

    fun listProjects(): List<Project> {
        val projects = mutableListOf<Project>()
        val files = rootProjectsDir.listFiles() ?: return emptyList()

        for (file in files) {
            if (file.isDirectory) {
                // Ensure directory is flattened if nested
                resolveAndFlattenNestedProject(file)

                var projectName = file.name
                val settingsFile = listOf("settings.gradle.kts", "settings.gradle")
                    .map { File(file, it) }
                    .firstOrNull { it.exists() }
                if (settingsFile != null) {
                    val settingsContent = settingsFile.readText()
                    val match = Regex("rootProject\\.name\\s*=\\s*[\"']([^\"']+)[\"']").find(settingsContent)
                    if (match != null && match.groupValues[1].isNotBlank()) {
                        projectName = match.groupValues[1].trim()
                    }
                }

                val manifest = File(file, "app/src/main/AndroidManifest.xml")
                var pkgName = "com.example.${file.name.lowercase().replace(Regex("[^a-zA-Z0-9]"), "")}"
                if (manifest.exists()) {
                    val content = manifest.readText()
                    val match = Regex("package=\"([^\"]+)\"").find(content)
                    if (match != null) {
                        pkgName = match.groupValues[1]
                    }
                } else {
                    // Try parsing namespace from app/build.gradle.kts
                    val buildGradle = listOf("app/build.gradle.kts", "app/build.gradle")
                        .map { File(file, it) }
                        .firstOrNull { it.exists() }
                    if (buildGradle != null) {
                        val buildContent = buildGradle.readText()
                        val match = Regex("namespace\\s*=\\s*[\"']([^\"']+)[\"']").find(buildContent)
                            ?: Regex("applicationId\\s*=\\s*[\"']([^\"']+)[\"']").find(buildContent)
                        if (match != null) {
                            pkgName = match.groupValues[1]
                        }
                    }
                }

                projects.add(
                    Project(
                        name = projectName,
                        rootDir = file,
                        packageName = pkgName
                    )
                )
            }
        }
        return projects.sortedByDescending { it.rootDir.lastModified() }
    }

    private fun resolveAndFlattenNestedProject(dir: File) {
        val hasRootGradle = File(dir, "gradlew").exists() ||
                File(dir, "build.gradle").exists() ||
                File(dir, "build.gradle.kts").exists() ||
                File(dir, "settings.gradle").exists() ||
                File(dir, "settings.gradle.kts").exists()

        if (!hasRootGradle) {
            val subFolders = dir.listFiles { f -> f.isDirectory } ?: emptyArray()
            val childWithGradle = subFolders.firstOrNull { child ->
                File(child, "gradlew").exists() ||
                        File(child, "build.gradle").exists() ||
                        File(child, "build.gradle.kts").exists() ||
                        File(child, "settings.gradle").exists() ||
                        File(child, "settings.gradle.kts").exists()
            }
            if (childWithGradle != null) {
                // Promote children to dir
                val children = childWithGradle.listFiles() ?: emptyArray()
                for (c in children) {
                    val dest = File(dir, c.name)
                    if (dest.exists()) {
                        if (dest.isDirectory) dest.deleteRecursively() else dest.delete()
                    }
                    c.renameTo(dest)
                }
                childWithGradle.delete()
            }
        }
    }

    fun createProject(
        projectName: String,
        packageName: String,
        minSdk: Int,
        targetSdk: Int,
        template: String
    ): Project {
        val safeName = projectName.trim().replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
        val projectDir = File(rootProjectsDir, safeName)
        if (projectDir.exists()) {
            projectDir.deleteRecursively()
        }

        TemplateGenerator.generateAndroidProject(
            targetDir = projectDir,
            projectName = projectName,
            packageName = packageName,
            minSdk = minSdk,
            targetSdk = targetSdk,
            template = template
        )

        return Project(
            name = projectName,
            rootDir = projectDir,
            packageName = packageName,
            minSdk = minSdk,
            targetSdk = targetSdk,
            template = template
        )
    }

    fun deleteProject(project: Project): Boolean {
        return project.rootDir.deleteRecursively()
    }

    fun buildFileTree(directory: File): FileNode {
        val childrenNodes = mutableListOf<FileNode>()
        val files: List<File> = directory.listFiles()?.sortedWith(
            compareBy<File> { !it.isDirectory }.thenBy { it.name.lowercase() }
        ) ?: emptyList()

        for (file in files) {
            if (file.name == ".gradle" && file.isDirectory) continue

            if (file.isDirectory) {
                childrenNodes.add(buildFileTree(file))
            } else {
                childrenNodes.add(
                    FileNode(
                        file = file,
                        name = file.name,
                        isDirectory = false,
                        extension = file.extension.lowercase()
                    )
                )
            }
        }

        return FileNode(
            file = directory,
            name = directory.name,
            isDirectory = true,
            children = childrenNodes,
            isExpanded = true
        )
    }

    fun createFile(parentDir: File, fileName: String, initialContent: String = ""): File {
        val file = File(parentDir, fileName)
        if (!file.exists()) {
            file.parentFile?.mkdirs()
            file.writeText(initialContent)
        }
        return file
    }

    fun createDirectory(parentDir: File, dirName: String): File {
        val dir = File(parentDir, dirName)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun deleteFileOrDirectory(file: File): Boolean {
        return if (file.isDirectory) file.deleteRecursively() else file.delete()
    }

    fun renameFileOrDirectory(source: File, newName: String): File? {
        val target = File(source.parentFile, newName)
        return if (source.renameTo(target)) target else null
    }

    fun readFileContent(file: File): String {
        return if (file.exists() && file.isFile) file.readText() else ""
    }

    fun saveFileContent(file: File, content: String) {
        file.parentFile?.mkdirs()
        file.writeText(content)
    }
}
