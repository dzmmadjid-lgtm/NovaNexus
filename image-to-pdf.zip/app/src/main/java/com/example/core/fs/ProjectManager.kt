package com.example.core.fs

import android.content.Context
import com.example.data.model.FileNode
import com.example.data.model.Project
import java.io.File

class ProjectManager(private val context: Context) {

    val rootProjectsDir: File
        get() {
            val dir = context.getExternalFilesDir("projects") ?: File(context.filesDir, "projects")
            if (!dir.exists()) {
                dir.mkdirs()
            }
            return dir
        }

    fun listProjects(): List<Project> {
        val projects = mutableListOf<Project>()
        val files = rootProjectsDir.listFiles() ?: return emptyList()

        for (file in files) {
            if (file.isDirectory) {
                val manifest = File(file, "app/src/main/AndroidManifest.xml")
                var pkgName = "com.example.${file.name.lowercase().replace(" ", "")}"
                if (manifest.exists()) {
                    val content = manifest.readText()
                    val match = Regex("package=\"([^\"]+)\"").find(content)
                    if (match != null) {
                        pkgName = match.groupValues[1]
                    }
                }
                projects.add(
                    Project(
                        name = file.name,
                        rootDir = file,
                        packageName = pkgName
                    )
                )
            }
        }
        return projects.sortedByDescending { it.rootDir.lastModified() }
    }

    fun createProject(
        projectName: String,
        packageName: String,
        minSdk: Int,
        targetSdk: Int,
        template: String
    ): Project {
        val safeName = projectName.trim().replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
        val projectDir = File(rootProjectsDir, safeName)
        if (projectDir.exists()) {
            projectDir.deleteRecursively()
        }

        TemplateGenerator.generateAndroidProject(
            targetDir = projectDir,
            projectName = projectName,
            packageName = packageName,
            minSdk = minSdk,
            targetSdk = targetSdk,
            template = template
        )

        return Project(
            name = projectName,
            rootDir = projectDir,
            packageName = packageName,
            minSdk = minSdk,
            targetSdk = targetSdk,
            template = template
        )
    }

    fun deleteProject(project: Project): Boolean {
        return project.rootDir.deleteRecursively()
    }

    fun buildFileTree(directory: File): FileNode {
        val childrenNodes = mutableListOf<FileNode>()
        val files: List<File> = directory.listFiles()?.sortedWith(
            compareBy<File> { !it.isDirectory }.thenBy { it.name.lowercase() }
        ) ?: emptyList()

        for (file in files) {
            // Filter out internal hidden cache directories like .gradle and build
            if (file.name == ".gradle") continue

            if (file.isDirectory) {
                childrenNodes.add(buildFileTree(file))
            } else {
                childrenNodes.add(
                    FileNode(
                        file = file,
                        name = file.name,
                        isDirectory = false,
                        extension = file.extension.lowercase()
                    )
                )
            }
        }

        return FileNode(
            file = directory,
            name = directory.name,
            isDirectory = true,
            children = childrenNodes,
            isExpanded = true
        )
    }

    fun createFile(parentDir: File, fileName: String, initialContent: String = ""): File {
        val file = File(parentDir, fileName)
        if (!file.exists()) {
            file.parentFile?.mkdirs()
            file.writeText(initialContent)
        }
        return file
    }

    fun createDirectory(parentDir: File, dirName: String): File {
        val dir = File(parentDir, dirName)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun deleteFileOrDirectory(file: File): Boolean {
        return if (file.isDirectory) file.deleteRecursively() else file.delete()
    }

    fun renameFileOrDirectory(source: File, newName: String): File? {
        val target = File(source.parentFile, newName)
        return if (source.renameTo(target)) target else null
    }

    fun readFileContent(file: File): String {
        return if (file.exists() && file.isFile) file.readText() else ""
    }

    fun saveFileContent(file: File, content: String) {
        file.parentFile?.mkdirs()
        file.writeText(content)
    }
}
