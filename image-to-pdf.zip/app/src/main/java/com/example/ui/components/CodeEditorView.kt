package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.editor.CodeSyntaxHighlighter
import com.example.data.model.EditorTab
import com.example.data.model.ThemeMode

@Composable
fun CodeEditorView(
    tab: EditorTab,
    themeMode: ThemeMode,
    onContentChange: (String) -> Unit,
    onCursorChange: (Int, Int) -> Unit,
    onSave: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    targetLine: Int? = null
) {
    var textFieldValue by remember(tab.file.absolutePath) {
        mutableStateOf(TextFieldValue(tab.content))
    }

    // Keep value updated if tab content was updated externally (e.g. reload or AI fix)
    LaunchedEffect(tab.content) {
        if (textFieldValue.text != tab.content) {
            textFieldValue = textFieldValue.copy(text = tab.content)
        }
    }

    // Scroll to target line if jump requested from Problems view
    val verticalScrollState = rememberScrollState()
    val horizontalScrollState = rememberScrollState()

    LaunchedEffect(targetLine) {
        if (targetLine != null && targetLine > 0) {
            val lines = textFieldValue.text.lines()
            var charOffset = 0
            for (i in 0 until (targetLine - 1).coerceAtMost(lines.size - 1)) {
                charOffset += lines[i].length + 1
            }
            textFieldValue = textFieldValue.copy(selection = TextRange(charOffset))
            // Scroll roughly to position
            val approxScrollY = (targetLine - 1) * 22
            verticalScrollState.animateScrollTo(approxScrollY)
        }
    }

    // Find and Replace state
    var showFindReplace by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var replaceQuery by remember { mutableStateOf("") }

    val lines = remember(textFieldValue.text) { textFieldValue.text.lines() }
    val lineCount = lines.size.coerceAtLeast(1)

    // Cursor position calculation
    val (curLine, curCol) = remember(textFieldValue.selection.start, textFieldValue.text) {
        val sel = textFieldValue.selection.start.coerceIn(0, textFieldValue.text.length)
        val textBefore = textFieldValue.text.substring(0, sel)
        val lineIdx = textBefore.count { it == '\n' } + 1
        val lastNewline = textBefore.lastIndexOf('\n')
        val colIdx = if (lastNewline == -1) sel + 1 else sel - lastNewline
        Pair(lineIdx, colIdx)
    }

    LaunchedEffect(curLine, curCol) {
        onCursorChange(curLine, curCol)
    }

    val visualTransformation = remember(tab.file.extension, themeMode) {
        VisualTransformation { text ->
            val annotated = CodeSyntaxHighlighter.highlightCode(
                text = text.text,
                extension = tab.file.extension,
                themeMode = themeMode
            )
            TransformedText(annotated, OffsetMapping.Identity)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top mini-toolbar of Editor
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onUndo,
                    enabled = tab.undoStack.isNotEmpty(),
                    modifier = Modifier.size(30.dp).testTag("editor_undo_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Undo,
                        contentDescription = "Undo",
                        modifier = Modifier.size(16.dp),
                        tint = if (tab.undoStack.isNotEmpty()) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                    )
                }
                IconButton(
                    onClick = onRedo,
                    enabled = tab.redoStack.isNotEmpty(),
                    modifier = Modifier.size(30.dp).testTag("editor_redo_btn")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Redo,
                        contentDescription = "Redo",
                        modifier = Modifier.size(16.dp),
                        tint = if (tab.redoStack.isNotEmpty()) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = { showFindReplace = !showFindReplace },
                    modifier = Modifier.size(30.dp).testTag("editor_find_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.FindInPage,
                        contentDescription = "Find and Replace",
                        modifier = Modifier.size(16.dp),
                        tint = if (showFindReplace) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                IconButton(
                    onClick = {
                        // Quick indentation format
                        val formatted = formatIndentation(textFieldValue.text)
                        if (formatted != textFieldValue.text) {
                            textFieldValue = textFieldValue.copy(text = formatted)
                            onContentChange(formatted)
                        }
                    },
                    modifier = Modifier.size(30.dp).testTag("editor_format_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.FormatAlignLeft,
                        contentDescription = "Format Indentation",
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // Status bar info: Line / Col and file type
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Ln $curLine, Col $curCol  |  $lineCount lines",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    shape = MaterialTheme.shapes.extraSmall,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = tab.file.extension.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Inline Find and Replace Bar
        if (showFindReplace) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Find...", fontSize = 12.sp) },
                            singleLine = true,
                            textStyle = TextStyle(fontSize = 12.sp),
                            modifier = Modifier.weight(1f).height(44.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))

                        val matchCount = if (searchQuery.isNotEmpty()) {
                            Regex.escape(searchQuery).toRegex(RegexOption.IGNORE_CASE)
                                .findAll(textFieldValue.text).count()
                        } else 0

                        Text(
                            text = if (searchQuery.isNotEmpty()) "$matchCount matches" else "",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 4.dp)
                        )

                        IconButton(
                            onClick = {
                                if (searchQuery.isNotEmpty()) {
                                    val idx = textFieldValue.text.indexOf(searchQuery, textFieldValue.selection.end, ignoreCase = true)
                                    val targetIdx = if (idx != -1) idx else textFieldValue.text.indexOf(searchQuery, 0, ignoreCase = true)
                                    if (targetIdx != -1) {
                                        textFieldValue = textFieldValue.copy(
                                            selection = TextRange(targetIdx, targetIdx + searchQuery.length)
                                        )
                                    }
                                }
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Next match")
                        }

                        IconButton(
                            onClick = { showFindReplace = false },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close search")
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = replaceQuery,
                            onValueChange = { replaceQuery = it },
                            placeholder = { Text("Replace with...", fontSize = 12.sp) },
                            singleLine = true,
                            textStyle = TextStyle(fontSize = 12.sp),
                            modifier = Modifier.weight(1f).height(44.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))

                        Button(
                            onClick = {
                                if (searchQuery.isNotEmpty()) {
                                    val sel = textFieldValue.selection
                                    val selText = textFieldValue.text.substring(sel.start, sel.end)
                                    if (selText.equals(searchQuery, ignoreCase = true)) {
                                        val newText = textFieldValue.text.replaceRange(sel.start, sel.end, replaceQuery)
                                        textFieldValue = textFieldValue.copy(
                                            text = newText,
                                            selection = TextRange(sel.start + replaceQuery.length)
                                        )
                                        onContentChange(newText)
                                    }
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("Replace", fontSize = 11.sp)
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        FilledTonalButton(
                            onClick = {
                                if (searchQuery.isNotEmpty()) {
                                    val newText = textFieldValue.text.replace(searchQuery, replaceQuery, ignoreCase = true)
                                    textFieldValue = textFieldValue.copy(text = newText)
                                    onContentChange(newText)
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("All", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

        // Main Editor Surface with Line Numbers gutter
        Row(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(verticalScrollState)
        ) {
            // Line numbers column
            Column(
                modifier = Modifier
                    .width(48.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                    .padding(vertical = 12.dp, horizontal = 4.dp),
                horizontalAlignment = Alignment.End
            ) {
                for (i in 1..lineCount) {
                    val isCurrent = i == curLine
                    Text(
                        text = "$i",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 20.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                        color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    )
                }
            }

            // Gutter divider
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .width(1.dp)
                    .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
            )

            // Code Text Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(horizontalScrollState)
                    .padding(vertical = 12.dp, horizontal = 8.dp)
            ) {
                BasicTextField(
                    value = textFieldValue,
                    onValueChange = { newVal ->
                        textFieldValue = newVal
                        onContentChange(newVal.text)
                    },
                    textStyle = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 20.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    ),
                    visualTransformation = visualTransformation,
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("code_editor_text_field")
                )
            }
        }
    }
}

private fun formatIndentation(code: String): String {
    val lines = code.lines()
    val sb = StringBuilder()
    var indentLevel = 0

    for (line in lines) {
        val trimmed = line.trim()
        if (trimmed.isEmpty()) {
            sb.append("\n")
            continue
        }

        if (trimmed.startsWith("}") || trimmed.startsWith(")") || trimmed.startsWith("</")) {
            indentLevel = (indentLevel - 1).coerceAtLeast(0)
        }

        val indent = "    ".repeat(indentLevel)
        sb.append(indent).append(trimmed).append("\n")

        val opens = trimmed.count { it == '{' || it == '(' || (it == '<' && !trimmed.startsWith("</") && !trimmed.endsWith("/>")) }
        val closes = trimmed.count { it == '}' || it == ')' || trimmed.endsWith("/>") }
        indentLevel = (indentLevel + (opens - closes)).coerceAtLeast(0)
    }

    return sb.toString().trimEnd()
}
