package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BuildStatus
import com.example.data.model.Project

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IdeTopBar(
    project: Project?,
    buildStatus: BuildStatus,
    isDirty: Boolean,
    onToggleDrawer: () -> Unit,
    onRunBuild: (String) -> Unit,
    onCancelBuild: () -> Unit,
    onSaveActiveFile: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenNewProject: () -> Unit,
    onExportZip: () -> Unit,
    onImportZip: () -> Unit
) {
    var showBuildMenu by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }

    TopAppBar(
        title = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = project?.name ?: "DroidIDE",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    if (isDirty) {
                        Box(
                            modifier = Modifier
                                .padding(start = 6.dp)
                                .size(8.dp)
                                .background(MaterialTheme.colorScheme.primary, shape = androidx.compose.foundation.shape.CircleShape)
                        )
                    }
                }
                if (project != null) {
                    Text(
                        text = project.packageName,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        },
        navigationIcon = {
            IconButton(
                onClick = onToggleDrawer,
                modifier = Modifier.testTag("toggle_project_explorer_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Project Explorer"
                )
            }
        },
        actions = {
            // Save file button
            IconButton(
                onClick = onSaveActiveFile,
                modifier = Modifier.testTag("save_file_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Save,
                    contentDescription = "Save File",
                    tint = if (isDirty) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                )
            }

            // Search in project
            IconButton(
                onClick = onOpenSearch,
                modifier = Modifier.testTag("search_project_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search in Project"
                )
            }

            // Build action / Stop button
            if (buildStatus == BuildStatus.RUNNING) {
                IconButton(
                    onClick = onCancelBuild,
                    modifier = Modifier.testTag("cancel_build_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop Build",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            } else {
                Box {
                    IconButton(
                        onClick = { showBuildMenu = true },
                        modifier = Modifier.testTag("build_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Build and Run",
                            tint = MaterialTheme.colorScheme.secondary
                        )
                    }

                    DropdownMenu(
                        expanded = showBuildMenu,
                        onDismissRequest = { showBuildMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("assembleDebug (Build APK)") },
                            leadingIcon = { Icon(Icons.Default.Build, contentDescription = null) },
                            onClick = {
                                showBuildMenu = false
                                onRunBuild("assembleDebug")
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("assembleRelease") },
                            leadingIcon = { Icon(Icons.Default.RocketLaunch, contentDescription = null) },
                            onClick = {
                                showBuildMenu = false
                                onRunBuild("assembleRelease")
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("clean") },
                            leadingIcon = { Icon(Icons.Default.CleaningServices, contentDescription = null) },
                            onClick = {
                                showBuildMenu = false
                                onRunBuild("clean")
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("check / lint") },
                            leadingIcon = { Icon(Icons.Default.CheckCircle, contentDescription = null) },
                            onClick = {
                                showBuildMenu = false
                                onRunBuild("check")
                            }
                        )
                    }
                }
            }

            // Overflow menu
            Box {
                IconButton(
                    onClick = { showOverflowMenu = true },
                    modifier = Modifier.testTag("overflow_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "More Options"
                    )
                }

                DropdownMenu(
                    expanded = showOverflowMenu,
                    onDismissRequest = { showOverflowMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("New Project...") },
                        leadingIcon = { Icon(Icons.Default.CreateNewFolder, contentDescription = null) },
                        onClick = {
                            showOverflowMenu = false
                            onOpenNewProject()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Import Project (ZIP)...") },
                        leadingIcon = { Icon(Icons.Default.FileDownload, contentDescription = null) },
                        onClick = {
                            showOverflowMenu = false
                            onImportZip()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Export Project (ZIP)") },
                        leadingIcon = { Icon(Icons.Default.FileUpload, contentDescription = null) },
                        onClick = {
                            showOverflowMenu = false
                            onExportZip()
                        }
                    )
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = { Text("IDE Settings & Theme") },
                        leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        onClick = {
                            showOverflowMenu = false
                            onOpenSettings()
                        }
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface
        )
    )
}
