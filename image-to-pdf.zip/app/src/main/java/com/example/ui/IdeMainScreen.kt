package com.example.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.NoteAdd
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.BottomToolWindow
import com.example.ui.components.*
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IdeMainScreen(viewModel: IdeViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    // State collections
    val project by viewModel.currentProject.collectAsStateWithLifecycle()
    val fileTree by viewModel.fileTree.collectAsStateWithLifecycle()
    val openTabs by viewModel.openTabs.collectAsStateWithLifecycle()
    val activeTabIndex by viewModel.activeTabIndex.collectAsStateWithLifecycle()
    val buildStatus by viewModel.buildStatus.collectAsStateWithLifecycle()
    val buildLogs by viewModel.buildLogs.collectAsStateWithLifecycle()
    val buildResult by viewModel.buildResult.collectAsStateWithLifecycle()
    val problems by viewModel.problems.collectAsStateWithLifecycle()
    val terminalLines by viewModel.terminalEngine.output.collectAsStateWithLifecycle()
    val isTerminalRunning by viewModel.terminalEngine.isRunning.collectAsStateWithLifecycle()
    val gitStatus by viewModel.gitStatus.collectAsStateWithLifecycle()
    val aiMessages by viewModel.aiMessages.collectAsStateWithLifecycle()
    val isAiBusy by viewModel.isAiBusy.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val isSearching by viewModel.isSearching.collectAsStateWithLifecycle()
    val activeToolWindow by viewModel.activeToolWindow.collectAsStateWithLifecycle()
    val isToolWindowExpanded by viewModel.isToolWindowExpanded.collectAsStateWithLifecycle()
    val targetLine by viewModel.targetEditorLine.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val isCloudBuild by viewModel.isCloudBuild.collectAsStateWithLifecycle()
    val cloudBuildUrl by viewModel.cloudBuildUrl.collectAsStateWithLifecycle()

    val currentTab = openTabs.getOrNull(activeTabIndex)

    // File picker for ZIP Import
    val zipPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importProjectZip(uri)
            Toast.makeText(context, "Importing project archive...", Toast.LENGTH_SHORT).show()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.width(280.dp)
            ) {
                ProjectExplorer(
                    rootNode = fileTree,
                    selectedFile = currentTab?.file,
                    onFileSelected = { file ->
                        viewModel.openFile(file)
                        coroutineScope.launch { drawerState.close() }
                    },
                    onNewFileClicked = { targetDir ->
                        viewModel.targetNewFileDirectory = targetDir
                        viewModel.showNewFileDialog = true
                    },
                    onNewFolderClicked = { targetDir ->
                        viewModel.targetNewFileDirectory = targetDir
                        viewModel.showNewFileDialog = true
                    },
                    onDeleteFileClicked = { file ->
                        viewModel.deleteFile(file)
                    },
                    onRenameFileClicked = { file ->
                        viewModel.fileToRename = file
                        viewModel.showRenameDialog = true
                    },
                    onRefresh = {
                        viewModel.refreshFileTree()
                    }
                )
            }
        }
    ) {
        Scaffold(
            topBar = {
                IdeTopBar(
                    project = project,
                    buildStatus = buildStatus,
                    isDirty = currentTab?.isDirty ?: false,
                    onToggleDrawer = {
                        coroutineScope.launch {
                            if (drawerState.isClosed) drawerState.open() else drawerState.close()
                        }
                    },
                    onRunBuild = { task -> viewModel.runBuild(task) },
                    onCancelBuild = { viewModel.cancelBuild() },
                    onSaveActiveFile = { viewModel.saveActiveFile() },
                    onOpenSearch = { viewModel.showSearchDialog = true },
                    onOpenSettings = { viewModel.showSettingsDialog = true },
                    onOpenNewProject = { viewModel.showNewProjectDialog = true },
                    onExportZip = {
                        if (project != null) {
                            val exportFile = File(context.cacheDir, "${project!!.name}.zip")
                            val ok = viewModel.exportProjectZip(exportFile)
                            if (ok) {
                                try {
                                    val uri = FileProvider.getUriForFile(
                                        context,
                                        "${context.packageName}.provider",
                                        exportFile
                                    )
                                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "application/zip"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
                                    }
                                    context.startActivity(Intent.createChooser(sendIntent, "Export Project ZIP"))
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Export error: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    },
                    onImportZip = {
                        zipPickerLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*"))
                    }
                )
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Editor Tabs Row
                if (openTabs.isNotEmpty()) {
                    EditorTabsRow(
                        tabs = openTabs,
                        activeTabIndex = activeTabIndex,
                        onTabSelected = { viewModel.selectTab(it) },
                        onTabClosed = { viewModel.closeTab(it) }
                    )
                }

                // Main Content: Code Editor or Welcome Screen
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (currentTab != null) {
                        CodeEditorView(
                            tab = currentTab,
                            themeMode = themeMode,
                            onContentChange = { viewModel.updateActiveTabContent(it) },
                            onCursorChange = { line, col -> viewModel.updateCursorPosition(line, col) },
                            onSave = { viewModel.saveActiveFile() },
                            onUndo = { viewModel.undo() },
                            onRedo = { viewModel.redo() },
                            targetLine = targetLine
                        )

                        // Clear targetLine once navigated
                        if (targetLine != null) {
                            LaunchedEffect(targetLine) {
                                viewModel.clearTargetLine()
                            }
                        }
                    } else {
                        // Empty Workspace placeholder
                        EmptyWorkspaceView(
                            projectName = project?.name ?: "No Project",
                            onOpenExplorer = {
                                coroutineScope.launch { drawerState.open() }
                            },
                            onNewFile = {
                                viewModel.targetNewFileDirectory = project?.rootDir
                                viewModel.showNewFileDialog = true
                            },
                            onRunBuild = {
                                viewModel.runBuild("assembleDebug")
                            }
                        )
                    }
                }

                // Bottom Tool Windows (Build Output, Problems, Terminal, Git, AI Agent)
                BottomToolWindows(
                    activeWindow = activeToolWindow,
                    isExpanded = isToolWindowExpanded,
                    onTabSelected = { viewModel.setToolWindow(it) },
                    onToggleExpanded = { viewModel.toggleToolWindowExpanded() },
                    buildResult = buildResult,
                    buildLogs = buildLogs,
                    buildStatus = buildStatus,
                    onClearLogs = { viewModel.clearBuildLogs() },
                    problems = problems,
                    onJumpToProblem = { file, line -> viewModel.jumpToProblem(file, line) },
                    terminalLines = terminalLines,
                    isTerminalRunning = isTerminalRunning,
                    onExecuteCommand = { viewModel.executeTerminalCommand(it) },
                    onStopTerminal = { viewModel.terminalEngine.stop() },
                    onClearTerminal = { viewModel.terminalEngine.clear() },
                    gitStatus = gitStatus,
                    onCommit = { viewModel.commitGit(it) },
                    onCloneRepo = { viewModel.cloneGitHubRepo(it) },
                    aiMessages = aiMessages,
                    isAiBusy = isAiBusy,
                    onSendAiPrompt = { viewModel.sendAiPrompt(it) },
                    onApplyAiFix = { viewModel.applyAiFix(it) }
                )
            }
        }
    }

    // Dialogs
    if (viewModel.showNewProjectDialog) {
        NewProjectDialog(
            onDismiss = { viewModel.showNewProjectDialog = false },
            onCreate = { name, pkg, minSdk, targetSdk, tmpl ->
                viewModel.createProject(name, pkg, minSdk, targetSdk, tmpl)
                viewModel.showNewProjectDialog = false
            }
        )
    }

    if (viewModel.showNewFileDialog) {
        val targetDir = viewModel.targetNewFileDirectory ?: project?.rootDir ?: context.filesDir
        NewFileDialog(
            targetDir = targetDir,
            onDismiss = { viewModel.showNewFileDialog = false },
            onCreateFile = { name, content ->
                viewModel.createFile(name, content)
                viewModel.showNewFileDialog = false
            },
            onCreateFolder = { name ->
                viewModel.createDirectory(name)
                viewModel.showNewFileDialog = false
            }
        )
    }

    val fileToRename = viewModel.fileToRename
    if (viewModel.showRenameDialog && fileToRename != null) {
        RenameDialog(
            currentName = fileToRename.name,
            onDismiss = {
                viewModel.showRenameDialog = false
                viewModel.fileToRename = null
            },
            onConfirm = { newName ->
                viewModel.renameFile(fileToRename, newName)
                viewModel.showRenameDialog = false
                viewModel.fileToRename = null
            }
        )
    }

    if (viewModel.showSearchDialog) {
        SearchInProjectDialog(
            searchResults = searchResults,
            isSearching = isSearching,
            onSearch = { viewModel.searchInProject(it) },
            onSelectResult = { res ->
                viewModel.openFile(res.file)
                viewModel.jumpToProblem(res.file, res.lineNumber)
                viewModel.showSearchDialog = false
            },
            onDismiss = { viewModel.showSearchDialog = false }
        )
    }

    if (viewModel.showSettingsDialog) {
        SettingsDialog(
            currentTheme = themeMode,
            isCloudBuild = isCloudBuild,
            cloudBuildUrl = cloudBuildUrl,
            onThemeChange = { viewModel.setTheme(it) },
            onCloudBuildToggle = { viewModel.setCloudBuild(it) },
            onCloudBuildUrlChange = { viewModel.setCloudBuildUrl(it) },
            onDismiss = { viewModel.showSettingsDialog = false }
        )
    }
}

@Composable
private fun EmptyWorkspaceView(
    projectName: String,
    onOpenExplorer: () -> Unit,
    onNewFile: () -> Unit,
    onRunBuild: () -> Unit
) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(24.dp)
        ) {
            Icon(
                imageVector = Icons.Default.DeveloperMode,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(54.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = projectName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Select a file from Project Explorer to start editing",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onOpenExplorer,
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Open Explorer", fontSize = 12.sp)
                }

                FilledTonalButton(
                    onClick = onNewFile,
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.NoteAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("New File", fontSize = 12.sp)
                }
            }
        }
    }
}
