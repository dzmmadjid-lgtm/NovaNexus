package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Accent colors
val IdeBlue = Color(0xFF3574F0)
val IdeBlueDark = Color(0xFF2656B8)
val IdeGreen = Color(0xFF59A869)
val IdeYellow = Color(0xFFE5A800)
val IdeRed = Color(0xFFE05252)

// Dark Theme (Modern Studio Dark)
val DarkBackground = Color(0xFF1E1F22)
val DarkSurface = Color(0xFF2B2D30)
val DarkSurfaceVariant = Color(0xFF393B40)
val DarkBorder = Color(0xFF43454A)
val DarkTextPrimary = Color(0xFFDFE1E5)
val DarkTextSecondary = Color(0xFF9DA0A8)

// OLED Pure Black Theme (True #000000)
val OledBackground = Color(0xFF000000)
val OledSurface = Color(0xFF0D0D0D)
val OledSurfaceVariant = Color(0xFF171717)
val OledBorder = Color(0xFF262626)
val OledTextPrimary = Color(0xFFEDEDED)
val OledTextSecondary = Color(0xFFA0A0A0)

// Light Theme (Clean Studio Light)
val LightBackground = Color(0xFFF7F8FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEBECF0)
val LightBorder = Color(0xFFD1D5DB)
val LightTextPrimary = Color(0xFF1F2328)
val LightTextSecondary = Color(0xFF656D76)

