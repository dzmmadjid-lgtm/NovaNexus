package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.ai.AiChatMessage
import com.example.core.ai.AiFixProposal
import com.example.core.ai.IdeAiAgent
import com.example.core.build.BuildEngine
import com.example.core.build.CloudBuildEngine
import com.example.core.build.LocalProcessBuildEngine
import com.example.core.build.ProblemsParser
import com.example.core.fs.ProjectManager
import com.example.core.fs.ZipUtils
import com.example.core.git.GitManager
import com.example.core.git.GitStatus
import com.example.core.terminal.TerminalEngine
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

class IdeViewModel(application: Application) : AndroidViewModel(application) {

    val projectManager = ProjectManager(application.applicationContext)
    val terminalEngine = TerminalEngine(viewModelScope)
    val gitManager = GitManager()
    val aiAgent = IdeAiAgent(projectManager)

    private val localBuildEngine = LocalProcessBuildEngine()
    private val cloudBuildEngine = CloudBuildEngine()

    // Current State
    private val _projects = MutableStateFlow<List<Project>>(emptyList())
    val projects: StateFlow<List<Project>> = _projects.asStateFlow()

    private val _currentProject = MutableStateFlow<Project?>(null)
    val currentProject: StateFlow<Project?> = _currentProject.asStateFlow()

    private val _fileTree = MutableStateFlow<FileNode?>(null)
    val fileTree: StateFlow<FileNode?> = _fileTree.asStateFlow()

    private val _openTabs = MutableStateFlow<List<EditorTab>>(emptyList())
    val openTabs: StateFlow<List<EditorTab>> = _openTabs.asStateFlow()

    private val _activeTabIndex = MutableStateFlow(0)
    val activeTabIndex: StateFlow<Int> = _activeTabIndex.asStateFlow()

    // Build State
    private val _buildStatus = MutableStateFlow(BuildStatus.IDLE)
    val buildStatus: StateFlow<BuildStatus> = _buildStatus.asStateFlow()

    private val _buildLogs = MutableStateFlow<List<BuildLogEntry>>(emptyList())
    val buildLogs: StateFlow<List<BuildLogEntry>> = _buildLogs.asStateFlow()

    private val _buildResult = MutableStateFlow<BuildResult?>(null)
    val buildResult: StateFlow<BuildResult?> = _buildResult.asStateFlow()

    private val _problems = MutableStateFlow<List<ProblemItem>>(emptyList())
    val problems: StateFlow<List<ProblemItem>> = _problems.asStateFlow()

    // Git State
    private val _gitStatus = MutableStateFlow<GitStatus?>(null)
    val gitStatus: StateFlow<GitStatus?> = _gitStatus.asStateFlow()

    // AI Assistant State
    private val _aiMessages = MutableStateFlow<List<AiChatMessage>>(emptyList())
    val aiMessages: StateFlow<List<AiChatMessage>> = _aiMessages.asStateFlow()

    private val _isAiBusy = MutableStateFlow(false)
    val isAiBusy: StateFlow<Boolean> = _isAiBusy.asStateFlow()

    // Search Results State
    private val _searchResults = MutableStateFlow<List<SearchResult>>(emptyList())
    val searchResults: StateFlow<List<SearchResult>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    // Navigation & Tool Window
    private val _activeToolWindow = MutableStateFlow(BottomToolWindow.BUILD_OUTPUT)
    val activeToolWindow: StateFlow<BottomToolWindow> = _activeToolWindow.asStateFlow()

    private val _isToolWindowExpanded = MutableStateFlow(false)
    val isToolWindowExpanded: StateFlow<Boolean> = _isToolWindowExpanded.asStateFlow()

    private val _targetEditorLine = MutableStateFlow<Int?>(null)
    val targetEditorLine: StateFlow<Int?> = _targetEditorLine.asStateFlow()

    // Theme & Settings State
    private val _themeMode = MutableStateFlow(ThemeMode.DARK)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _isCloudBuild = MutableStateFlow(false)
    val isCloudBuild: StateFlow<Boolean> = _isCloudBuild.asStateFlow()

    private val _cloudBuildUrl = MutableStateFlow("https://android-builder.example.com/api/build")
    val cloudBuildUrl: StateFlow<String> = _cloudBuildUrl.asStateFlow()

    // Dialog flags
    var showNewProjectDialog by mutableStateOf(false)
    var showNewFileDialog by mutableStateOf(false)
    var targetNewFileDirectory by mutableStateOf<File?>(null)
    var showSearchDialog by mutableStateOf(false)
    var showSettingsDialog by mutableStateOf(false)
    var showRenameDialog by mutableStateOf(false)
    var fileToRename by mutableStateOf<File?>(null)

    init {
        loadProjectsAndOpenDefault()
    }

    private fun loadProjectsAndOpenDefault() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = projectManager.listProjects()
            _projects.value = list
            if (list.isNotEmpty()) {
                openProject(list.first())
            } else {
                // Generate a real default sample Android project if none exist!
                val defaultProj = projectManager.createProject(
                    projectName = "DroidApp",
                    packageName = "com.example.droidapp",
                    minSdk = 24,
                    targetSdk = 36,
                    template = "Compose Empty Activity"
                )
                _projects.value = listOf(defaultProj)
                openProject(defaultProj)
            }
        }
    }

    fun openProject(project: Project) {
        viewModelScope.launch(Dispatchers.IO) {
            _currentProject.value = project
            refreshFileTree()

            // Initialize Git if needed
            gitManager.initRepo(project.rootDir, "main")
            refreshGitStatus()

            // Open MainActivity.kt by default if present
            val mainAct = project.rootDir.walkTopDown().firstOrNull { it.name == "MainActivity.kt" }
            if (mainAct != null) {
                openFile(mainAct)
            }

            // Append greeting in AI chat
            _aiMessages.value = listOf(
                AiChatMessage(
                    sender = "agent",
                    text = "Welcome to DroidIDE! Project '${project.name}' is open and ready. You can write code, run assembleDebug, inspect problems, and execute shell commands in Terminal."
                )
            )
        }
    }

    fun refreshFileTree() {
        viewModelScope.launch(Dispatchers.IO) {
            val proj = _currentProject.value ?: return@launch
            _fileTree.value = projectManager.buildFileTree(proj.rootDir)
        }
    }

    fun refreshGitStatus() {
        val proj = _currentProject.value ?: return
        _gitStatus.value = gitManager.getStatus(proj.rootDir)
    }

    fun openFile(file: File) {
        if (!file.exists() || file.isDirectory) return

        val existingIdx = _openTabs.value.indexOfFirst { it.file.absolutePath == file.absolutePath }
        if (existingIdx != -1) {
            _activeTabIndex.value = existingIdx
            return
        }

        val content = projectManager.readFileContent(file)
        val newTab = EditorTab(
            file = file,
            title = file.name,
            content = content,
            isDirty = false
        )
        val updatedTabs = _openTabs.value + newTab
        _openTabs.value = updatedTabs
        _activeTabIndex.value = updatedTabs.size - 1
    }

    fun closeTab(index: Int) {
        val tabs = _openTabs.value.toMutableList()
        if (index in tabs.indices) {
            tabs.removeAt(index)
            _openTabs.value = tabs
            if (_activeTabIndex.value >= tabs.size) {
                _activeTabIndex.value = (tabs.size - 1).coerceAtLeast(0)
            }
        }
    }

    fun selectTab(index: Int) {
        if (index in _openTabs.value.indices) {
            _activeTabIndex.value = index
        }
    }

    fun updateActiveTabContent(newContent: String) {
        val idx = _activeTabIndex.value
        val tabs = _openTabs.value.toMutableList()
        if (idx in tabs.indices) {
            val current = tabs[idx]
            if (current.content != newContent) {
                val newUndo = current.undoStack + current.content
                tabs[idx] = current.copy(
                    content = newContent,
                    isDirty = true,
                    undoStack = newUndo.takeLast(50),
                    redoStack = emptyList()
                )
                _openTabs.value = tabs
            }
        }
    }

    fun updateCursorPosition(line: Int, col: Int) {
        val idx = _activeTabIndex.value
        val tabs = _openTabs.value.toMutableList()
        if (idx in tabs.indices) {
            tabs[idx] = tabs[idx].copy(cursorLine = line, cursorCol = col)
            _openTabs.value = tabs
        }
    }

    fun undo() {
        val idx = _activeTabIndex.value
        val tabs = _openTabs.value.toMutableList()
        if (idx in tabs.indices) {
            val cur = tabs[idx]
            if (cur.undoStack.isNotEmpty()) {
                val prev = cur.undoStack.last()
                val updatedUndo = cur.undoStack.dropLast(1)
                val updatedRedo = cur.redoStack + cur.content
                tabs[idx] = cur.copy(
                    content = prev,
                    isDirty = true,
                    undoStack = updatedUndo,
                    redoStack = updatedRedo
                )
                _openTabs.value = tabs
            }
        }
    }

    fun redo() {
        val idx = _activeTabIndex.value
        val tabs = _openTabs.value.toMutableList()
        if (idx in tabs.indices) {
            val cur = tabs[idx]
            if (cur.redoStack.isNotEmpty()) {
                val next = cur.redoStack.last()
                val updatedRedo = cur.redoStack.dropLast(1)
                val updatedUndo = cur.undoStack + cur.content
                tabs[idx] = cur.copy(
                    content = next,
                    isDirty = true,
                    undoStack = updatedUndo,
                    redoStack = updatedRedo
                )
                _openTabs.value = tabs
            }
        }
    }

    fun saveActiveFile() {
        val idx = _activeTabIndex.value
        val tabs = _openTabs.value.toMutableList()
        if (idx in tabs.indices) {
            val tab = tabs[idx]
            projectManager.saveFileContent(tab.file, tab.content)
            tabs[idx] = tab.copy(isDirty = false)
            _openTabs.value = tabs
            refreshGitStatus()
        }
    }

    fun createProject(
        name: String,
        packageName: String,
        minSdk: Int,
        targetSdk: Int,
        template: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val newProj = projectManager.createProject(name, packageName, minSdk, targetSdk, template)
            val list = projectManager.listProjects()
            _projects.value = list
            openProject(newProj)
        }
    }

    fun createFile(fileName: String, initialContent: String) {
        val parent = targetNewFileDirectory ?: _currentProject.value?.rootDir ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val file = projectManager.createFile(parent, fileName, initialContent)
            refreshFileTree()
            openFile(file)
        }
    }

    fun createDirectory(dirName: String) {
        val parent = targetNewFileDirectory ?: _currentProject.value?.rootDir ?: return
        viewModelScope.launch(Dispatchers.IO) {
            projectManager.createDirectory(parent, dirName)
            refreshFileTree()
        }
    }

    fun deleteFile(file: File) {
        viewModelScope.launch(Dispatchers.IO) {
            // Close tab if open
            val tabs = _openTabs.value.toMutableList()
            val openIdx = tabs.indexOfFirst { it.file.absolutePath == file.absolutePath }
            if (openIdx != -1) {
                tabs.removeAt(openIdx)
                _openTabs.value = tabs
            }
            projectManager.deleteFileOrDirectory(file)
            refreshFileTree()
            refreshGitStatus()
        }
    }

    fun renameFile(file: File, newName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val renamed = projectManager.renameFileOrDirectory(file, newName)
            if (renamed != null) {
                // Update open tab
                val tabs = _openTabs.value.toMutableList()
                val idx = tabs.indexOfFirst { it.file.absolutePath == file.absolutePath }
                if (idx != -1) {
                    tabs[idx] = tabs[idx].copy(file = renamed, title = renamed.name)
                    _openTabs.value = tabs
                }
                refreshFileTree()
            }
        }
    }

    // Build Actions
    fun runBuild(task: String) {
        val proj = _currentProject.value ?: return

        // Auto save any dirty tabs
        saveActiveFile()

        _buildStatus.value = BuildStatus.RUNNING
        _buildLogs.value = emptyList()
        _problems.value = emptyList()
        _activeToolWindow.value = BottomToolWindow.BUILD_OUTPUT
        _isToolWindowExpanded.value = true

        val engine: BuildEngine = if (_isCloudBuild.value) cloudBuildEngine else localBuildEngine

        viewModelScope.launch {
            val result = engine.build(proj, task) { logEntry ->
                _buildLogs.value = _buildLogs.value + logEntry
            }
            _buildResult.value = result
            _buildStatus.value = result.status
            _problems.value = result.problems

            if (result.problems.isNotEmpty()) {
                _activeToolWindow.value = BottomToolWindow.PROBLEMS
            }
        }
    }

    fun cancelBuild() {
        if (_isCloudBuild.value) {
            cloudBuildEngine.cancel()
        } else {
            localBuildEngine.cancel()
        }
        _buildStatus.value = BuildStatus.CANCELLED
    }

    fun clearBuildLogs() {
        _buildLogs.value = emptyList()
    }

    // Problems jump
    fun jumpToProblem(file: File?, line: Int) {
        if (file != null && file.exists()) {
            openFile(file)
        }
        _targetEditorLine.value = line
    }

    fun clearTargetLine() {
        _targetEditorLine.value = null
    }

    // Terminal commands
    fun executeTerminalCommand(cmd: String) {
        val proj = _currentProject.value ?: return
        terminalEngine.executeCommand(cmd, proj.rootDir)
    }

    // Git Actions
    fun commitGit(message: String) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            gitManager.commit(proj.rootDir, message)
            refreshGitStatus()
        }
    }

    fun cloneGitHubRepo(url: String) {
        val projDir = File(projectManager.rootProjectsDir, "cloned_" + System.currentTimeMillis() % 10000)
        viewModelScope.launch(Dispatchers.IO) {
            _activeToolWindow.value = BottomToolWindow.BUILD_OUTPUT
            _isToolWindowExpanded.value = true
            _buildLogs.value = listOf(BuildLogEntry("Cloning GitHub repository: $url"))

            val success = gitManager.cloneGitHubRepo(url, projDir) { logMsg ->
                _buildLogs.value = _buildLogs.value + BuildLogEntry(logMsg)
            }
            if (success) {
                val newProj = Project(
                    name = projDir.name,
                    rootDir = projDir,
                    packageName = "com.example.cloned"
                )
                val list = projectManager.listProjects()
                _projects.value = list
                openProject(newProj)
            }
        }
    }

    // AI Assistant Actions
    fun sendAiPrompt(prompt: String) {
        val proj = _currentProject.value ?: return
        val currentTab = _openTabs.value.getOrNull(_activeTabIndex.value)

        val userMsg = AiChatMessage(sender = "user", text = prompt)
        _aiMessages.value = _aiMessages.value + userMsg
        _isAiBusy.value = true

        viewModelScope.launch {
            if (_problems.value.isNotEmpty() && (prompt.contains("fix", ignoreCase = true) || prompt.contains("error", ignoreCase = true))) {
                val firstProblem = _problems.value.first()
                val proposal = aiAgent.analyzeProblemAndSuggestFix(proj, firstProblem, currentTab?.content)
                val agentResponse = if (proposal != null) {
                    AiChatMessage(
                        sender = "agent",
                        text = "I analyzed ${firstProblem.relativePath}:${firstProblem.line}.\n${proposal.description}",
                        proposal = proposal
                    )
                } else {
                    AiChatMessage(
                        sender = "agent",
                        text = "Analyzed problem: ${firstProblem.message}. Please inspect line ${firstProblem.line} in ${firstProblem.relativePath}."
                    )
                }
                _aiMessages.value = _aiMessages.value + agentResponse
            } else {
                val reply = aiAgent.queryAssistant(
                    prompt = prompt,
                    project = proj,
                    activeFile = currentTab?.file,
                    activeContent = currentTab?.content,
                    recentProblems = _problems.value
                )
                _aiMessages.value = _aiMessages.value + AiChatMessage(sender = "agent", text = reply)
            }
            _isAiBusy.value = false
        }
    }

    fun applyAiFix(proposal: AiFixProposal) {
        viewModelScope.launch(Dispatchers.IO) {
            aiAgent.applyFix(proposal)
            // Reload file in tab
            val tabs = _openTabs.value.toMutableList()
            val idx = tabs.indexOfFirst { it.file.absolutePath == proposal.targetFile.absolutePath }
            if (idx != -1) {
                val newContent = proposal.targetFile.readText()
                tabs[idx] = tabs[idx].copy(content = newContent, isDirty = false)
                _openTabs.value = tabs
            }
            _aiMessages.value = _aiMessages.value + AiChatMessage(
                sender = "agent",
                text = "Fix successfully applied to ${proposal.targetFile.name}."
            )
        }
    }

    // Search in project
    fun searchInProject(query: String) {
        val proj = _currentProject.value ?: return
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            _isSearching.value = true
            val results = mutableListOf<SearchResult>()
            proj.rootDir.walkTopDown()
                .filter { it.isFile && !it.path.contains("/build/") && !it.path.contains("/.gradle/") }
                .take(300)
                .forEach { file ->
                    try {
                        file.useLines { lines ->
                            lines.forEachIndexed { index, line ->
                                if (line.contains(query, ignoreCase = true)) {
                                    results.add(
                                        SearchResult(
                                            file = file,
                                            relativePath = file.relativeTo(proj.rootDir).path,
                                            lineNumber = index + 1,
                                            lineContent = line
                                        )
                                    )
                                }
                            }
                        }
                    } catch (e: Exception) {
                        // ignore binary file read errors
                    }
                }
            _searchResults.value = results.take(100)
            _isSearching.value = false
        }
    }

    // ZIP Export and Import
    fun exportProjectZip(targetFile: File): Boolean {
        val proj = _currentProject.value ?: return false
        return try {
            ZipUtils.exportProjectToZip(proj.rootDir, targetFile)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun importProjectZip(uri: Uri) {
        val context = getApplication<Application>().applicationContext
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri) ?: return@launch
                val targetDir = File(projectManager.rootProjectsDir, "imported_" + System.currentTimeMillis() % 10000)
                ZipUtils.importProjectFromZip(inputStream, targetDir)
                inputStream.close()

                val list = projectManager.listProjects()
                _projects.value = list
                val importedProj = list.firstOrNull { it.rootDir.name == targetDir.name }
                    ?: Project(targetDir.name, targetDir, "com.example.${targetDir.name.lowercase()}")
                openProject(importedProj)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    // Theme & Settings
    fun setTheme(mode: ThemeMode) {
        _themeMode.value = mode
    }

    fun setCloudBuild(isCloud: Boolean) {
        _isCloudBuild.value = isCloud
    }

    fun setCloudBuildUrl(url: String) {
        _cloudBuildUrl.value = url
        cloudBuildEngine.updateServerUrl(url)
    }

    fun setToolWindow(window: BottomToolWindow) {
        _activeToolWindow.value = window
        _isToolWindowExpanded.value = true
    }

    fun toggleToolWindowExpanded() {
        _isToolWindowExpanded.value = !_isToolWindowExpanded.value
    }
}
