package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FileNode
import java.io.File

@Composable
fun ProjectExplorer(
    rootNode: FileNode?,
    selectedFile: File?,
    onFileSelected: (File) -> Unit,
    onNewFileClicked: (File) -> Unit,
    onNewFolderClicked: (File) -> Unit,
    onDeleteFileClicked: (File) -> Unit,
    onRenameFileClicked: (File) -> Unit,
    onRefresh: () -> Unit
) {
    var expandedPaths by remember { mutableStateOf(setOf<String>()) }

    // Auto-expand root
    LaunchedEffect(rootNode) {
        if (rootNode != null) {
            val toExpand = mutableSetOf(rootNode.file.absolutePath)
            // also expand app and src/main if present
            rootNode.children.forEach { child ->
                if (child.isDirectory && (child.name == "app" || child.name == "src" || child.name == "main")) {
                    toExpand.add(child.file.absolutePath)
                }
            }
            expandedPaths = expandedPaths + toExpand
        }
    }

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(280.dp)
            .background(MaterialTheme.colorScheme.surface)
    ) {
        // Explorer Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "PROJECT EXPLORER",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                letterSpacing = 1.sp
            )
            Row {
                IconButton(
                    onClick = { rootNode?.let { onNewFileClicked(it.file) } },
                    modifier = Modifier.size(32.dp).testTag("explorer_new_file_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.NoteAdd,
                        contentDescription = "New File",
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = { rootNode?.let { onNewFolderClicked(it.file) } },
                    modifier = Modifier.size(32.dp).testTag("explorer_new_dir_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.CreateNewFolder,
                        contentDescription = "New Folder",
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier.size(32.dp).testTag("explorer_refresh_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh",
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

        if (rootNode == null || rootNode.children.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No files found in project.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            val flattenedList = remember(rootNode, expandedPaths) {
                val list = mutableListOf<Pair<FileNode, Int>>()
                fun traverse(node: FileNode, depth: Int) {
                    list.add(Pair(node, depth))
                    if (node.isDirectory && expandedPaths.contains(node.file.absolutePath)) {
                        node.children.forEach { traverse(it, depth + 1) }
                    }
                }
                rootNode.children.forEach { traverse(it, 0) }
                list
            }

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(flattenedList, key = { it.first.file.absolutePath }) { (node, depth) ->
                    val isExpanded = expandedPaths.contains(node.file.absolutePath)
                    val isSelected = selectedFile?.absolutePath == node.file.absolutePath

                    FileNodeItem(
                        node = node,
                        depth = depth,
                        isExpanded = isExpanded,
                        isSelected = isSelected,
                        onNodeClick = {
                            if (node.isDirectory) {
                                expandedPaths = if (isExpanded) {
                                    expandedPaths - node.file.absolutePath
                                } else {
                                    expandedPaths + node.file.absolutePath
                                }
                            } else {
                                onFileSelected(node.file)
                            }
                        },
                        onNewFile = { onNewFileClicked(node.file) },
                        onNewFolder = { onNewFolderClicked(node.file) },
                        onDelete = { onDeleteFileClicked(node.file) },
                        onRename = { onRenameFileClicked(node.file) }
                    )
                }
            }
        }
    }
}

@Composable
fun FileNodeItem(
    node: FileNode,
    depth: Int,
    isExpanded: Boolean,
    isSelected: Boolean,
    onNodeClick: () -> Unit,
    onNewFile: () -> Unit,
    onNewFolder: () -> Unit,
    onDelete: () -> Unit,
    onRename: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    val bgColor = when {
        isSelected -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
        else -> Color.Transparent
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(bgColor)
            .clickable(onClick = onNodeClick)
            .padding(start = (depth * 14 + 8).dp, top = 4.dp, bottom = 4.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Expand/collapse chevron for directories
        if (node.isDirectory) {
            Icon(
                imageVector = if (isExpanded) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowRight,
                contentDescription = null,
                modifier = Modifier.size(16.dp),
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            Spacer(modifier = Modifier.size(16.dp))
        }

        Spacer(modifier = Modifier.width(4.dp))

        // File/Directory Icon
        val (icon, iconTint) = getFileIconAndTint(node)
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
            tint = iconTint
        )

        Spacer(modifier = Modifier.width(6.dp))

        Text(
            text = node.name,
            style = MaterialTheme.typography.bodySmall,
            color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f)
        )

        // Options dropdown button
        Box {
            IconButton(
                onClick = { showMenu = true },
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MoreHoriz,
                    contentDescription = "File actions",
                    modifier = Modifier.size(14.dp),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            DropdownMenu(
                expanded = showMenu,
                onDismissRequest = { showMenu = false }
            ) {
                if (node.isDirectory) {
                    DropdownMenuItem(
                        text = { Text("New File Here") },
                        leadingIcon = { Icon(Icons.Default.Add, contentDescription = null) },
                        onClick = {
                            showMenu = false
                            onNewFile()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("New Directory Here") },
                        leadingIcon = { Icon(Icons.Default.CreateNewFolder, contentDescription = null) },
                        onClick = {
                            showMenu = false
                            onNewFolder()
                        }
                    )
                    HorizontalDivider()
                }
                DropdownMenuItem(
                    text = { Text("Rename") },
                    leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                    onClick = {
                        showMenu = false
                        onRename()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
                    leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                    onClick = {
                        showMenu = false
                        onDelete()
                    }
                )
            }
        }
    }
}

@Composable
fun getFileIconAndTint(node: FileNode): Pair<androidx.compose.ui.graphics.vector.ImageVector, Color> {
    if (node.isDirectory) {
        return Pair(Icons.Default.Folder, Color(0xFFE5A800))
    }
    return when (node.extension) {
        "kt", "kts" -> Pair(Icons.Default.Code, Color(0xFF7F52FF))
        "java" -> Pair(Icons.Default.Code, Color(0xFFF89820))
        "xml" -> Pair(Icons.Default.DataObject, Color(0xFFE25B2D))
        "gradle" -> Pair(Icons.Default.SettingsSuggest, Color(0xFF02303A))
        "json" -> Pair(Icons.Default.DataArray, Color(0xFF855845))
        "md" -> Pair(Icons.Default.Description, Color(0xFF0366D6))
        "png", "jpg", "jpeg", "webp" -> Pair(Icons.Default.Image, Color(0xFF388E3C))
        else -> Pair(Icons.AutoMirrored.Filled.InsertDriveFile, MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
