package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SearchResult
import com.example.data.model.ThemeMode
import java.io.File

@Composable
fun NewProjectDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, pkg: String, minSdk: Int, targetSdk: Int, template: String) -> Unit
) {
    var projectName by remember { mutableStateOf("MyApplication") }
    var packageName by remember { mutableStateOf("com.example.myapplication") }
    var minSdk by remember { mutableIntStateOf(24) }
    var targetSdk by remember { mutableIntStateOf(36) }
    var template by remember { mutableStateOf("Compose Empty Activity") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Android Project", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = projectName,
                    onValueChange = {
                        projectName = it
                        packageName = "com.example.${it.lowercase().replace(Regex("[^a-z0-9]"), "")}"
                    },
                    label = { Text("Project Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("new_project_name_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = packageName,
                    onValueChange = { packageName = it },
                    label = { Text("Package Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("new_project_pkg_input")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = "$minSdk",
                        onValueChange = { minSdk = it.toIntOrNull() ?: 24 },
                        label = { Text("Min SDK") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedTextField(
                        value = "$targetSdk",
                        onValueChange = { targetSdk = it.toIntOrNull() ?: 36 },
                        label = { Text("Target SDK") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text("Template:", style = MaterialTheme.typography.labelSmall)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = template == "Compose Empty Activity",
                        onClick = { template = "Compose Empty Activity" }
                    )
                    Text("Jetpack Compose Activity", fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = template == "Standard Android Views",
                        onClick = { template = "Standard Android Views" }
                    )
                    Text("XML Layout + Activity", fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (projectName.isNotBlank() && packageName.isNotBlank()) {
                        onCreate(projectName.trim(), packageName.trim(), minSdk, targetSdk, template)
                    }
                },
                modifier = Modifier.testTag("confirm_create_project_btn")
            ) {
                Text("Create Project")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun NewFileDialog(
    targetDir: File,
    onDismiss: () -> Unit,
    onCreateFile: (String, String) -> Unit,
    onCreateFolder: (String) -> Unit
) {
    var isFolder by remember { mutableStateOf(false) }
    var fileName by remember { mutableStateOf("") }
    var presetType by remember { mutableStateOf("kt") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (isFolder) "New Directory" else "New File in ${targetDir.name}")
        },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(
                        selected = !isFolder,
                        onClick = { isFolder = false }
                    )
                    Text("File", fontSize = 13.sp)
                    Spacer(modifier = Modifier.width(16.dp))
                    RadioButton(
                        selected = isFolder,
                        onClick = { isFolder = true }
                    )
                    Text("Directory", fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = fileName,
                    onValueChange = { fileName = it },
                    label = { Text(if (isFolder) "Directory Name" else "File Name (e.g. MyScreen.kt)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("new_file_name_input")
                )

                if (!isFolder) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Quick Presets:", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SuggestionChip(
                            onClick = {
                                if (!fileName.endsWith(".kt")) fileName = "${fileName.removeSuffix(".kt")}.kt"
                                presetType = "kt"
                            },
                            label = { Text("Kotlin (.kt)", fontSize = 10.sp) }
                        )
                        SuggestionChip(
                            onClick = {
                                if (!fileName.endsWith(".xml")) fileName = "${fileName.removeSuffix(".xml")}.xml"
                                presetType = "xml"
                            },
                            label = { Text("XML (.xml)", fontSize = 10.sp) }
                        )
                        SuggestionChip(
                            onClick = {
                                if (!fileName.endsWith(".gradle.kts")) fileName = "${fileName.removeSuffix(".gradle.kts")}.gradle.kts"
                                presetType = "kts"
                            },
                            label = { Text("Gradle KTS", fontSize = 10.sp) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (fileName.isNotBlank()) {
                        if (isFolder) {
                            onCreateFolder(fileName.trim())
                        } else {
                            val initialContent = when {
                                fileName.endsWith(".kt") -> "// Kotlin source\n"
                                fileName.endsWith(".xml") -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n</resources>\n"
                                fileName.endsWith(".json") -> "{\n}\n"
                                else -> ""
                            }
                            onCreateFile(fileName.trim(), initialContent)
                        }
                    }
                },
                modifier = Modifier.testTag("confirm_create_file_btn")
            ) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun RenameDialog(
    currentName: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var newName by remember { mutableStateOf(currentName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rename") },
        text = {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                label = { Text("New Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newName.isNotBlank() && newName != currentName) {
                        onConfirm(newName.trim())
                    }
                }
            ) {
                Text("Rename")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun SearchInProjectDialog(
    searchResults: List<SearchResult>,
    isSearching: Boolean,
    onSearch: (String) -> Unit,
    onSelectResult: (SearchResult) -> Unit,
    onDismiss: () -> Unit
) {
    var query by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Search in Project Files", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth().height(350.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = {
                        query = it
                        onSearch(it)
                    },
                    placeholder = { Text("Search text, symbols, classes...") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (isSearching) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                Text(
                    text = "${searchResults.size} results found",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                LazyColumn(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    items(searchResults) { result ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectResult(result) }
                                .padding(vertical = 6.dp)
                        ) {
                            Text(
                                text = "${result.relativePath} : line ${result.lineNumber}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = result.lineContent.trim(),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            HorizontalDivider(modifier = Modifier.padding(top = 4.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun SettingsDialog(
    currentTheme: ThemeMode,
    isCloudBuild: Boolean,
    cloudBuildUrl: String,
    projectRootDir: File? = null,
    onThemeChange: (ThemeMode) -> Unit,
    onCloudBuildToggle: (Boolean) -> Unit,
    onCloudBuildUrlChange: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var urlInput by remember { mutableStateOf(cloudBuildUrl) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val envReport = remember(projectRootDir) {
        com.example.core.build.BuildEnvironmentDetector.detect(context, projectRootDir)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("IDE Settings & Build Environment", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                item {
                    Text("Appearance Theme:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = currentTheme == ThemeMode.DARK,
                            onClick = { onThemeChange(ThemeMode.DARK) }
                        )
                        Text("Dark Theme (Studio Default)")
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = currentTheme == ThemeMode.OLED,
                            onClick = { onThemeChange(ThemeMode.OLED) }
                        )
                        Text("OLED Pure Black (#000000)")
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = currentTheme == ThemeMode.LIGHT,
                            onClick = { onThemeChange(ThemeMode.LIGHT) }
                        )
                        Text("Light Theme")
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    Text("Device Environment Diagnostics:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                "OS: Android ${envReport.osRelease} (API ${envReport.sdkInt})",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                "ABI: ${envReport.supportedAbis.firstOrNull() ?: "generic"}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(4.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (envReport.javaStatus.isAvailable) "● JDK: Installed" else "● JDK: Not Found in OS",
                                    color = if (envReport.javaStatus.isAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (!envReport.javaStatus.isAvailable) {
                                Text(
                                    "Standard Android OS (ART) does not provide OpenJDK. Local gradle execution requires Cloud Build or custom JDK.",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (envReport.wrapperStatus.hasGradlew) "● Wrapper: 'gradlew' Found" else "● Wrapper: 'gradlew' Missing",
                                color = if (envReport.wrapperStatus.hasGradlew) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                    Text("Build Engine Selection:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = !isCloudBuild,
                            onClick = { onCloudBuildToggle(false) }
                        )
                        Column {
                            Text("Local Process Runner")
                            Text(
                                "Executes ./gradlew via /system/bin/sh in project directory",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = isCloudBuild,
                            onClick = { onCloudBuildToggle(true) }
                        )
                        Column {
                            Text("Remote Cloud Build Runner (Recommended)")
                            Text(
                                "Builds on remote server with full JDK/SDK and returns real APK",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (isCloudBuild) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = urlInput,
                            onValueChange = {
                                urlInput = it
                                onCloudBuildUrlChange(it)
                            },
                            label = { Text("Cloud Build API Endpoint URL") },
                            placeholder = { Text("https://builder.yourserver.com/api/build") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Done")
            }
        }
    )
}
