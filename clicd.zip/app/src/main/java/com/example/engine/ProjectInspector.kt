package com.example.engine

import android.content.Context
import android.net.Uri
import com.example.model.ProjectInspectionResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.util.zip.ZipInputStream

object ProjectInspector {

    suspend fun inspectZipFile(context: Context, uri: Uri, fileName: String): ProjectInspectionResult =
        withContext(Dispatchers.IO) {
            var hasSettings = false
            var hasBuildGradle = false
            var extractedProjectName = fileName.replace(".zip", "")
            var detectedGradleVersion = "9.3.1"
            val detectedModules = mutableListOf<String>()
            var totalSize = 0L

            try {
                context.contentResolver.openInputStream(uri)?.use { inputStream: InputStream ->
                    val bytes = inputStream.readBytes()
                    totalSize = bytes.size.toLong()

                    ZipInputStream(bytes.inputStream()).use { zis ->
                        var entry = zis.nextEntry
                        while (entry != null) {
                            val name = entry.name
                            if (name.endsWith("settings.gradle") || name.endsWith("settings.gradle.kts")) {
                                hasSettings = true
                                val content = zis.bufferedReader().readText()
                                val rootMatch = Regex("rootProject\\.name\\s*=\\s*[\"']([^\"']+)[\"']").find(content)
                                if (rootMatch != null) {
                                    extractedProjectName = rootMatch.groupValues[1]
                                }
                                val includeMatches = Regex("include\\s*\\([\"':]+([a-zA-Z0-9_-]+)[\"']?\\)").findAll(content)
                                includeMatches.forEach { match ->
                                    detectedModules.add(match.groupValues[1])
                                }
                            }
                            if (name.endsWith("build.gradle") || name.endsWith("build.gradle.kts")) {
                                hasBuildGradle = true
                            }
                            if (name.endsWith("gradle-wrapper.properties")) {
                                val content = zis.bufferedReader().readText()
                                val versionMatch = Regex("gradle-([0-9]+\\.[0-9]+(\\.[0-9]+)?)").find(content)
                                if (versionMatch != null) {
                                    detectedGradleVersion = versionMatch.groupValues[1]
                                }
                            }
                            entry = zis.nextEntry
                        }
                    }
                }

                val sizeFormatted = String.format("%.2f MB", totalSize / (1024.0 * 1024.0))

                if (!hasSettings && !hasBuildGradle) {
                    return@withContext ProjectInspectionResult(
                        isValid = false,
                        fileName = fileName,
                        fileSizeFormatted = sizeFormatted,
                        projectName = extractedProjectName,
                        hasSettingsGradle = false,
                        hasBuildGradle = false,
                        detectedGradleVersion = detectedGradleVersion,
                        detectedModules = detectedModules,
                        errorMessage = "الملف المضغوط لا يحتوي على ملفات مشروع أندرويد صالحة (settings.gradle أو build.gradle)."
                    )
                }

                ProjectInspectionResult(
                    isValid = true,
                    fileName = fileName,
                    fileSizeFormatted = sizeFormatted,
                    projectName = extractedProjectName,
                    hasSettingsGradle = hasSettings,
                    hasBuildGradle = hasBuildGradle,
                    detectedGradleVersion = detectedGradleVersion,
                    detectedModules = if (detectedModules.isEmpty()) listOf("app") else detectedModules
                )

            } catch (e: Exception) {
                ProjectInspectionResult(
                    isValid = false,
                    fileName = fileName,
                    fileSizeFormatted = "0 MB",
                    projectName = fileName,
                    hasSettingsGradle = false,
                    hasBuildGradle = false,
                    detectedGradleVersion = "Unknown",
                    detectedModules = emptyList(),
                    errorMessage = "فشل في قراءة وفحص ملف الـ ZIP: ${e.localizedMessage}"
                )
            }
        }
}
