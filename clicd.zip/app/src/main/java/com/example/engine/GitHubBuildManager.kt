package com.example.engine

import android.content.Context
import android.net.Uri
import android.util.Base64
import com.example.model.BuildLogEntry
import com.example.model.BuildStatus
import com.example.model.LogType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

class GitHubBuildManager(
    private val token: String,
    private val owner: String,
    private val repo: String
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(120, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    private fun currentTime(): String =
        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

    suspend fun startBuildPipeline(
        context: Context,
        zipUri: Uri,
        fileName: String,
        onLog: (BuildLogEntry) -> Unit,
        onStatusChange: (BuildStatus, Int) -> Unit,
        onApkReady: (File, String) -> Unit,
        onFailure: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        try {
            onStatusChange(BuildStatus.INSPECTING_LOCAL_ZIP, 10)
            onLog(BuildLogEntry(currentTime(), "بدء قراءة ملف الـ ZIP المختار: $fileName", LogType.INFO))

            val zipBytes = context.contentResolver.openInputStream(zipUri)?.use { it.readBytes() }
                ?: throw IOException("تعذر قراءة بيانات الملف من الهاتف.")

            val fileSizeFormatted = String.format(Locale.US, "%.2f MB", zipBytes.size / (1024.0 * 1024.0))
            onLog(BuildLogEntry(currentTime(), "تم تحميل الملف بنجاح إلى الذاكرة ($fileSizeFormatted)", LogType.SUCCESS))

            // 1. الرفع الفعلي إلى GitHub
            onStatusChange(BuildStatus.UPLOADING_TO_GITHUB, 25)
            onLog(BuildLogEntry(currentTime(), "جاري رفع ملف $fileName عبر GitHub Contents API...", LogType.PROGRESS))
            uploadProjectZip(fileName, zipBytes)
            onLog(BuildLogEntry(currentTime(), "تم رفع ملف الـ ZIP بنجاح وتحديثه في المستودع.", LogType.SUCCESS))

            // 2. تشغيل الـ Workflow مع تمرير target_zip
            onStatusChange(BuildStatus.TRIGGERING_WORKFLOW, 40)
            onLog(BuildLogEntry(currentTime(), "إرسال أمر التشغيل (workflow_dispatch) مع target_zip='$fileName'...", LogType.INFO))
            val triggerTime = System.currentTimeMillis()
            triggerWorkflow(fileName)
            onLog(BuildLogEntry(currentTime(), "تم قبول أمر التشغيل من سيرفر GitHub Actions.", LogType.SUCCESS))

            // 3. التقاط ومعرفة رقم جلسة البناء الحقيقية
            onStatusChange(BuildStatus.RUNNER_QUEUED, 50)
            onLog(BuildLogEntry(currentTime(), "جاري البحث عن الـ Hosted Runner وبدء الجلسة...", LogType.INFO))
            delay(5000)

            val runId = locateActiveWorkflowRun(triggerTime)
            onLog(BuildLogEntry(currentTime(), "تم ربط الجلسة بنجاح (Run ID: #$runId)", LogType.SUCCESS))

            // 4. مراقبة التقدم الحي للبناء
            var isCompleted = false
            var pollCount = 0
            val maxPolls = 70 // حتى 12 دقيقة

            while (!isCompleted && pollCount < maxPolls) {
                delay(8000)
                pollCount++
                val (status, conclusion) = fetchRunStatus(runId)

                when {
                    status == "completed" && conclusion == "success" -> {
                        isCompleted = true
                        onStatusChange(BuildStatus.DOWNLOADING_APK, 92)
                        onLog(BuildLogEntry(currentTime(), "اكتمل بناء الـ APK بنجاح على سيرفر GitHub!", LogType.SUCCESS))
                        onLog(BuildLogEntry(currentTime(), "جاري تنزيل حزمة الـ Artifact واستخراج ملف الـ APK...", LogType.PROGRESS))
                        val apkFile = downloadArtifactApk(context, runId, fileName, onLog)
                        onStatusChange(BuildStatus.SUCCESS, 100)
                        onLog(BuildLogEntry(currentTime(), "تم تنزيل وتجهيز ملف الـ APK: ${apkFile.name}", LogType.SUCCESS))
                        onApkReady(apkFile, fileName)
                        return@withContext
                    }
                    status == "completed" && conclusion != "success" -> {
                        onStatusChange(BuildStatus.FAILED, 0)
                        val errMsg = "فشل البناء على السيرفر (النتيجة: $conclusion)"
                        onLog(BuildLogEntry(currentTime(), errMsg, LogType.ERROR))
                        onFailure(errMsg)
                        return@withContext
                    }
                    status == "in_progress" -> {
                        val currentProgress = (50 + (pollCount * 40 / maxPolls)).coerceAtMost(88)
                        onStatusChange(BuildStatus.BUILDING_GRADLE, currentProgress)
                        onLog(BuildLogEntry(currentTime(), "الخادم يترجم الأكواد عبر Gradle [in_progress] (المحاولة $pollCount)...", LogType.INFO))
                    }
                    else -> {
                        onStatusChange(BuildStatus.RUNNER_QUEUED, 52)
                        onLog(BuildLogEntry(currentTime(), "خادم GitHub في قائمة الانتظار [$status]...", LogType.INFO))
                    }
                }
            }

            throw IOException("انتهت مهلة المراقبة أثناء بناء المشروع على GitHub.")

        } catch (e: Exception) {
            val error = e.localizedMessage ?: "حدث خطأ غير معروف."
            onStatusChange(BuildStatus.FAILED, 0)
            onLog(BuildLogEntry(currentTime(), "خطأ: $error", LogType.ERROR))
            onFailure(error)
        }
    }

    suspend fun downloadApkDirectly(
        context: Context,
        runId: Long,
        fileName: String,
        onLog: (BuildLogEntry) -> Unit,
        onStatusChange: (BuildStatus, Int) -> Unit,
        onApkReady: (File, String) -> Unit,
        onFailure: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        try {
            onStatusChange(BuildStatus.DOWNLOADING_APK, 92)
            onLog(BuildLogEntry(currentTime(), "بدء تنزيل حزمة الـ Artifact مباشرة للجلسة #$runId...", LogType.PROGRESS))
            val apkFile = downloadArtifactApk(context, runId, fileName, onLog)
            onStatusChange(BuildStatus.SUCCESS, 100)
            onLog(BuildLogEntry(currentTime(), "تم تنزيل وتجهيز ملف الـ APK: ${apkFile.name}", LogType.SUCCESS))
            onApkReady(apkFile, fileName)
        } catch (e: Exception) {
            val error = e.localizedMessage ?: "فشل تنزيل ملف الـ APK."
            onStatusChange(BuildStatus.FAILED, 0)
            onLog(BuildLogEntry(currentTime(), "خطأ: $error", LogType.ERROR))
            onFailure(error)
        }
    }

    private fun uploadProjectZip(fileName: String, bytes: ByteArray) {
        val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
        val fileUrl = "https://api.github.com/repos/$owner/$repo/contents/$fileName"
        val existingSha = fetchExistingSha(fileUrl)

        val json = JSONObject().apply {
            put("message", "Upload project $fileName via Cloud APK Builder")
            put("content", base64)
            if (existingSha != null) {
                put("sha", existingSha)
            }
        }

        val request = Request.Builder()
            .url(fileUrl)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .put(json.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            val err = response.body?.string()
            throw IOException("فشل رفع ملف الـ ZIP إلى GitHub: $err")
        }
    }

    private fun triggerWorkflow(fileName: String) {
        val url = "https://api.github.com/repos/$owner/$repo/actions/workflows/build.yml/dispatches"
        val json = JSONObject().apply {
            put("ref", "main")
            put("inputs", JSONObject().apply {
                put("target_zip", fileName)
            })
        }

        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        if (!response.isSuccessful) {
            val err = response.body?.string()
            throw IOException("فشل إرسال أمر workflow_dispatch إلى GitHub: $err")
        }
    }

    suspend fun findLatestSuccessfulRunId(): Long {
        val url = "https://api.github.com/repos/$owner/$repo/actions/runs?status=completed&conclusion=success&per_page=5"
        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .get()
            .build()

        val response = client.newCall(request).execute()
        val json = JSONObject(response.body?.string() ?: "")
        val runs = json.optJSONArray("workflow_runs")
        if (runs != null && runs.length() > 0) {
            return runs.getJSONObject(0).getLong("id")
        }
        throw IOException("لم يتم العثور على أي جلسة بناء ناجحة سابقة على GitHub.")
    }

    private suspend fun locateActiveWorkflowRun(triggerTime: Long): Long {
        val url = "https://api.github.com/repos/$owner/$repo/actions/runs?event=workflow_dispatch&per_page=5"
        
        for (attempt in 1..10) {
            val request = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $token")
                .header("Accept", "application/vnd.github+json")
                .get()
                .build()

            val response = client.newCall(request).execute()
            val json = JSONObject(response.body?.string() ?: "")
            val runs = json.optJSONArray("workflow_runs")
            if (runs != null && runs.length() > 0) {
                // Return the latest run
                return runs.getJSONObject(0).getLong("id")
            }
            delay(2500)
        }
        throw IOException("لم يتم العثور على جلسة البناء على سيرفر GitHub. تأكد من صحة الـ Token واسم المستودع.")
    }

    private fun fetchRunStatus(runId: Long): Pair<String, String?> {
        val url = "https://api.github.com/repos/$owner/$repo/actions/runs/$runId"
        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .get()
            .build()

        val response = client.newCall(request).execute()
        val json = JSONObject(response.body?.string() ?: "")
        val status = json.optString("status", "queued")
        val conclusion = if (json.has("conclusion") && !json.isNull("conclusion")) json.getString("conclusion") else null
        return Pair(status, conclusion)
    }

    private suspend fun downloadArtifactApk(
        context: Context,
        runId: Long,
        baseName: String,
        onLog: (BuildLogEntry) -> Unit
    ): File {
        val url = "https://api.github.com/repos/$owner/$repo/actions/runs/$runId/artifacts"
        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .get()
            .build()

        val response = client.newCall(request).execute()
        val json = JSONObject(response.body?.string() ?: "")
        val artifacts = json.getJSONArray("artifacts")
        if (artifacts.length() == 0) throw IOException("لا يوجد أي ملفات APK متوفرة في الـ Artifacts.")

        val downloadUrl = artifacts.getJSONObject(0).getString("archive_download_url")
        
        var lastException: Exception? = null
        val tempZip = File(context.cacheDir, "artifact_${System.currentTimeMillis()}.zip")

        // 3 محاولات تنزيل للتعامل مع أي تذبذب مؤقت في DNS أو الاتصال
        for (attempt in 1..4) {
            try {
                if (attempt > 1) {
                    onLog(BuildLogEntry(currentTime(), "إعادة محاولة تنزيل الـ APK (محاولة $attempt)...", LogType.WARNING))
                    delay(3000)
                }

                val downloadReq = Request.Builder()
                    .url(downloadUrl)
                    .header("Authorization", "Bearer $token")
                    .header("Accept", "application/vnd.github+json")
                    .get()
                    .build()

                val downloadResp = client.newCall(downloadReq).execute()
                if (!downloadResp.isSuccessful) {
                    throw IOException("فشل الاتصال بسيرفر تحميل الـ Artifact (رمز: ${downloadResp.code})")
                }

                val body = downloadResp.body ?: throw IOException("استجابة التحميل فارغة من السيرفر.")
                
                body.byteStream().use { input ->
                    FileOutputStream(tempZip).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var bytesRead: Int
                        while (input.read(buffer).also { bytesRead = it } != -1) {
                            output.write(buffer, 0, bytesRead)
                        }
                        output.flush()
                    }
                }
                
                lastException = null
                break
            } catch (e: Exception) {
                lastException = e
            }
        }

        if (lastException != null || !tempZip.exists() || tempZip.length() == 0L) {
            throw IOException(lastException?.message ?: "فشل تنزيل ملف الـ APK بعد عدة محاولات بسبب تعذر الاتصال بالسيرفر السحابي.")
        }

        val cleanName = baseName.replace(".zip", "") + "-release.apk"
        val outputDir = File(context.getExternalFilesDir(null), "BuiltAPKs").apply { mkdirs() }
        val finalApk = File(outputDir, cleanName)

        var foundApk = false
        ZipInputStream(tempZip.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (entry.name.endsWith(".apk", ignoreCase = true)) {
                    FileOutputStream(finalApk).use { fos ->
                        val buffer = ByteArray(64 * 1024)
                        var count: Int
                        while (zis.read(buffer).also { count = it } != -1) {
                            fos.write(buffer, 0, count)
                        }
                        fos.flush()
                    }
                    foundApk = true
                    break
                }
                entry = zis.nextEntry
            }
        }
        tempZip.delete()

        if (!foundApk) {
            throw IOException("لم يتم العثور على ملف .apk داخل حزمة الـ Artifact المنزلة.")
        }
        return finalApk
    }

    private fun fetchExistingSha(url: String): String? {
        return try {
            val req = Request.Builder()
                .url(url)
                .header("Authorization", "Bearer $token")
                .get()
                .build()
            val resp = client.newCall(req).execute()
            if (resp.isSuccessful) {
                JSONObject(resp.body?.string() ?: "").optString("sha")
            } else null
        } catch (e: Exception) {
            null
        }
    }
}
