package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.example.ui.screens.MainApkBuilderScreen
import com.example.ui.theme.ApkBuilderAppTheme
import com.example.viewmodel.BuilderViewModel

class MainActivity : ComponentActivity() {

    private val builderViewModel: BuilderViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val state by builderViewModel.uiState.collectAsState()
            ApkBuilderAppTheme(themeMode = state.themeMode) {
                MainApkBuilderScreen(viewModel = builderViewModel)
            }
        }
    }
}
