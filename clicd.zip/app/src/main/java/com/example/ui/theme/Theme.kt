package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.example.model.AppThemeMode

// ألوان الثيمات
// 1. OLED Pure Black
val OledBlackBg = Color(0xFF000000)
val OledBlackSurface = Color(0xFF070707)
val OledBlackCard = Color(0xFF101010)
val OledBlackCardElevated = Color(0xFF161616)
val OledBlackBorder = Color(0xFF242424)

// 2. Light Theme Colors
val LightBg = Color(0xFFF4F6F9)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFFFFFFF)
val LightCardElevated = Color(0xFFEDF1F7)
val LightBorder = Color(0xFFD6DFEB)
val LightTextPrimary = Color(0xFF111827)
val LightTextSecondary = Color(0xFF4B5563)
val LightTextMuted = Color(0xFF9CA3AF)

private val OledColorScheme = darkColorScheme(
    primary = CyberNeonGreen,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF00381C),
    onPrimaryContainer = CyberNeonGreen,
    secondary = CyberCyan,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF003644),
    onSecondaryContainer = CyberCyan,
    background = OledBlackBg,
    onBackground = Color(0xFFFFFFFF),
    surface = OledBlackSurface,
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = OledBlackCard,
    onSurfaceVariant = Color(0xFFB0B0B0),
    surfaceContainer = OledBlackCardElevated,
    outline = OledBlackBorder,
    error = CyberRed,
    onError = Color.White
)

private val DarkTacticalColorScheme = darkColorScheme(
    primary = CyberNeonGreen,
    onPrimary = Color(0xFF0A0E17),
    primaryContainer = Color(0xFF00381C),
    onPrimaryContainer = CyberNeonGreen,
    secondary = CyberCyan,
    onSecondary = Color(0xFF0A0E17),
    secondaryContainer = Color(0xFF003644),
    onSecondaryContainer = CyberCyan,
    background = CyberDarkBg,
    onBackground = TextPrimary,
    surface = CyberDarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberDarkCard,
    onSurfaceVariant = TextSecondary,
    surfaceContainer = CyberDarkCardElevated,
    outline = CyberDarkBorder,
    error = CyberRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF00875A),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD4F7E6),
    onPrimaryContainer = Color(0xFF003923),
    secondary = Color(0xFF007799),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD0F2FC),
    onSecondaryContainer = Color(0xFF003747),
    background = LightBg,
    onBackground = LightTextPrimary,
    surface = LightSurface,
    onSurface = LightTextPrimary,
    surfaceVariant = LightCard,
    onSurfaceVariant = LightTextSecondary,
    surfaceContainer = LightCardElevated,
    outline = LightBorder,
    error = CyberRed,
    onError = Color.White
)

@Composable
fun ApkBuilderAppTheme(
    themeMode: AppThemeMode = AppThemeMode.OLED_BLACK,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        AppThemeMode.OLED_BLACK -> OledColorScheme
        AppThemeMode.DARK_TACTICAL -> DarkTacticalColorScheme
        AppThemeMode.LIGHT_CLEAN -> LightColorScheme
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val insetsController = WindowCompat.getInsetsController(window, view)
                val isLight = themeMode == AppThemeMode.LIGHT_CLEAN
                val statusBarHex = when (themeMode) {
                    AppThemeMode.OLED_BLACK -> "#000000"
                    AppThemeMode.DARK_TACTICAL -> "#0A0E17"
                    AppThemeMode.LIGHT_CLEAN -> "#F4F6F9"
                }
                window.statusBarColor = android.graphics.Color.parseColor(statusBarHex)
                window.navigationBarColor = android.graphics.Color.parseColor(statusBarHex)
                insetsController.isAppearanceLightStatusBars = isLight
                insetsController.isAppearanceLightNavigationBars = isLight
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
