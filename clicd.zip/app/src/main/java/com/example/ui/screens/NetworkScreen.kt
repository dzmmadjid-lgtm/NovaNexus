package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CellTower
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NetworkDiagnosis
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.PubgYellow

@Composable
fun NetworkScreen(
    networkInfo: NetworkDiagnosis,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Connection Overview Banner
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF111929),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1F2B44))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(CyberNeonGreen.copy(alpha = 0.15f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (networkInfo.connectionType.contains("Wi-Fi")) Icons.Default.Wifi else Icons.Default.CellTower,
                                contentDescription = null,
                                tint = CyberNeonGreen,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Column {
                            Text(
                                text = networkInfo.connectionType,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                ),
                                color = Color.White
                            )
                            Text(
                                text = "حالة الاتصال: متصل ومستقر",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 11.sp,
                                    color = Color(0xFF8B949E)
                                )
                            )
                        }
                    }

                    IconButton(
                        onClick = onRefresh,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("refresh_network_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "تحديث",
                            tint = CyberCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Signal Quality Progress Bar
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "قوة إشارة الراوتر / البرج",
                            fontSize = 11.5.sp,
                            color = Color(0xFF8B949E)
                        )
                        Text(
                            text = "${networkInfo.signalPercent}% (${networkInfo.signalStrengthDbm} dBm)",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = CyberNeonGreen
                        )
                    }
                    LinearProgressIndicator(
                        progress = { networkInfo.signalPercent / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = CyberNeonGreen,
                        trackColor = Color(0xFF1E2B44)
                    )
                }
            }
        }

        // Live Network Metrics Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            NetworkCard(
                title = "سرعة الربط (Link Speed)",
                value = "${networkInfo.linkSpeedMbps} Mbps",
                subtitle = "سرعة نقل البيانات مع الراوتر",
                icon = Icons.Default.Speed,
                accent = CyberCyan,
                modifier = Modifier.weight(1f)
            )
            NetworkCard(
                title = "اختبار Bufferbloat",
                value = networkInfo.bufferbloatGrade,
                subtitle = "استقرار تحت الضغط (ممتاز)",
                icon = Icons.Default.NetworkCheck,
                accent = CyberNeonGreen,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            NetworkCard(
                title = "حجم الحزمة (MTU)",
                value = "${networkInfo.mtu} Bytes",
                subtitle = "الحجم القياسي لحزم ببجي",
                icon = Icons.Default.Router,
                accent = PubgYellow,
                modifier = Modifier.weight(1f)
            )
            NetworkCard(
                title = "فقدان الحزم (Loss)",
                value = "${networkInfo.packetLoss}%",
                subtitle = "ثبات الحزم أثناء الاشتباك",
                icon = Icons.Default.CheckCircle,
                accent = CyberNeonGreen,
                modifier = Modifier.weight(1f)
            )
        }

        // Frequency & Network Routing
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF101726),
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1F2B44))
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "تفاصيل توجيه الشبكة والتردد:",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("تردد الاتصال:", fontSize = 11.5.sp, color = Color(0xFF8B949E))
                    Text(networkInfo.frequencyBand, fontSize = 11.5.sp, color = CyberNeonGreen, fontWeight = FontWeight.SemiBold)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("عنوان Gateway:", fontSize = 11.5.sp, color = Color(0xFF8B949E))
                    Text(networkInfo.gatewayIp, fontSize = 11.5.sp, color = Color.White, fontFamily = FontFamily.Monospace)
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("موجّه الـ DNS الحالي:", fontSize = 11.5.sp, color = Color(0xFF8B949E))
                    Text(networkInfo.dnsServer, fontSize = 11.5.sp, color = CyberCyan, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        // Pro Gaming Ping Optimization Tips
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFF131E30),
            shape = RoundedCornerShape(14.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF263756))
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.TipsAndUpdates,
                        contentDescription = null,
                        tint = PubgYellow,
                        modifier = Modifier.size(18.dp)
                    )
                    Text(
                        text = "نصائح ذهبية لتقليل البينج في ببجي موبايل",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                TipItem(number = "1", title = "استخدم شبكة 5GHz بدلاً من 2.4GHz", desc = "تردد 5GHz يقلل التداخل مع أجهزة المنزل والراوترات المجاورة مما يقضي على الـ Spikes المفاجئة.")
                TipItem(number = "2", title = "تفعيل خادم Cloudflare DNS (1.1.1.1)", desc = "يوجه حزم الاتصال عبر أسرع كابلات الألياف الضوئية بدلاً من مسار مزود الإنترنت المزدحم.")
                TipItem(number = "3", title = "إيقاف التحديثات التلقائية والمزامنة", desc = "أوقف التنزيل في متجر Google Play وGoogle Photos أثناء خوض المباريات المصنفة.")
            }
        }
    }
}

@Composable
private fun NetworkCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = Color(0xFF111929),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1F2B44))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accent,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = title,
                    fontSize = 10.5.sp,
                    color = Color(0xFF8B949E),
                    maxLines = 1
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontSize = 17.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                color = accent
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                fontSize = 10.sp,
                color = Color(0xFF718096),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun TipItem(
    number: String,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .background(Color(0xFF1F2D47), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(number, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = PubgYellow)
        }
        Column {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(desc, fontSize = 11.sp, color = Color(0xFF8B949E), lineHeight = 15.sp)
        }
    }
}
