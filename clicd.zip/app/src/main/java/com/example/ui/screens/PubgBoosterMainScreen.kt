package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.CyberDarkSurface
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberRed
import com.example.ui.theme.PubgYellow
import com.example.viewmodel.PubgBoosterViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PubgBoosterMainScreen(
    viewModel: PubgBoosterViewModel
) {
    val context = LocalContext.current
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()
    val boostState by viewModel.boostState.collectAsStateWithLifecycle()
    val selectedServer by viewModel.selectedServer.collectAsStateWithLifecycle()
    val selectedDns by viewModel.selectedDns.collectAsStateWithLifecycle()
    val serversList by viewModel.serversState.collectAsStateWithLifecycle()
    val dnsList by viewModel.dnsListState.collectAsStateWithLifecycle()
    val networkInfo by viewModel.networkDiagnosis.collectAsStateWithLifecycle()
    val gameEditions by viewModel.gameEditions.collectAsStateWithLifecycle()
    val historySessions by viewModel.historySessions.collectAsStateWithLifecycle()

    // Notification Permission Request for Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { /* handled */ }
    )

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasPermission) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val currentPing = if (boostState.isBoostActive) boostState.currentPing else selectedServer.currentPingMs
    val pingColor = when {
        currentPing <= 40 -> CyberNeonGreen
        currentPing <= 75 -> CyberCyan
        currentPing <= 120 -> PubgYellow
        else -> CyberRed
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = CyberDarkBg,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(PubgYellow, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🎯", fontSize = 15.sp)
                        }
                        Text(
                            text = "PUBG PING BOOSTER",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = Color.White
                        )
                    }
                },
                actions = {
                    Surface(
                        modifier = Modifier.padding(end = 12.dp),
                        color = Color(0xFF142033),
                        shape = RoundedCornerShape(20.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, pingColor.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .background(pingColor, CircleShape)
                            )
                            Text(
                                text = "$currentPing ms",
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = pingColor
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CyberDarkSurface,
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0F1522),
                contentColor = Color.White,
                tonalElevation = 8.dp,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { viewModel.setActiveTab(0) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "المسرّع",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = { Text("المسرّع", fontSize = 10.5.sp, fontWeight = if (activeTab == 0) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF0A0E17),
                        selectedTextColor = CyberNeonGreen,
                        indicatorColor = CyberNeonGreen,
                        unselectedIconColor = Color(0xFF8B949E),
                        unselectedTextColor = Color(0xFF8B949E)
                    ),
                    modifier = Modifier.testTag("nav_booster")
                )

                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { viewModel.setActiveTab(1) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Public,
                            contentDescription = "السيرفرات",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = { Text("السيرفرات", fontSize = 10.5.sp, fontWeight = if (activeTab == 1) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF0A0E17),
                        selectedTextColor = CyberCyan,
                        indicatorColor = CyberCyan,
                        unselectedIconColor = Color(0xFF8B949E),
                        unselectedTextColor = Color(0xFF8B949E)
                    ),
                    modifier = Modifier.testTag("nav_servers")
                )

                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { viewModel.setActiveTab(2) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Dns,
                            contentDescription = "DNS",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = { Text("تسريع DNS", fontSize = 10.5.sp, fontWeight = if (activeTab == 2) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF0A0E17),
                        selectedTextColor = CyberCyan,
                        indicatorColor = CyberCyan,
                        unselectedIconColor = Color(0xFF8B949E),
                        unselectedTextColor = Color(0xFF8B949E)
                    ),
                    modifier = Modifier.testTag("nav_dns")
                )

                NavigationBarItem(
                    selected = activeTab == 3,
                    onClick = { viewModel.setActiveTab(3) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Wifi,
                            contentDescription = "الشبكة",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = { Text("الشبكة", fontSize = 10.5.sp, fontWeight = if (activeTab == 3) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF0A0E17),
                        selectedTextColor = PubgYellow,
                        indicatorColor = PubgYellow,
                        unselectedIconColor = Color(0xFF8B949E),
                        unselectedTextColor = Color(0xFF8B949E)
                    ),
                    modifier = Modifier.testTag("nav_network")
                )

                NavigationBarItem(
                    selected = activeTab == 4,
                    onClick = { viewModel.setActiveTab(4) },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.History,
                            contentDescription = "السجل",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = { Text("السجل", fontSize = 10.5.sp, fontWeight = if (activeTab == 4) FontWeight.Bold else FontWeight.Normal) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Color(0xFF0A0E17),
                        selectedTextColor = CyberNeonGreen,
                        indicatorColor = CyberNeonGreen,
                        unselectedIconColor = Color(0xFF8B949E),
                        unselectedTextColor = Color(0xFF8B949E)
                    ),
                    modifier = Modifier.testTag("nav_history")
                )
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            AnimatedContent(
                targetState = activeTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "screen_transition"
            ) { tab ->
                when (tab) {
                    0 -> BoosterHomeScreen(
                        boostState = boostState,
                        selectedServer = selectedServer,
                        selectedDns = selectedDns,
                        gameEditions = gameEditions,
                        onStartBoost = { viewModel.startUltraBoost() },
                        onStopBoost = { viewModel.stopBoost() },
                        onNavigateToServers = { viewModel.setActiveTab(1) },
                        onNavigateToDns = { viewModel.setActiveTab(2) },
                        onLaunchGame = { edition -> viewModel.launchGame(context, edition.packageName) }
                    )
                    1 -> ServersScreen(
                        servers = serversList,
                        selectedServer = selectedServer,
                        onSelectServer = { viewModel.selectServer(it) },
                        onTestServer = { viewModel.testServer(it) },
                        onTestAllServers = { viewModel.testAllServers() }
                    )
                    2 -> DnsScreen(
                        dnsList = dnsList,
                        selectedDns = selectedDns,
                        onSelectDns = { viewModel.selectDns(it) },
                        onBenchmarkAll = { viewModel.benchmarkAllDns() },
                        onAddCustomDns = { pri, sec, host, name ->
                            viewModel.addCustomDns(pri, sec, host, name)
                        }
                    )
                    3 -> NetworkScreen(
                        networkInfo = networkInfo,
                        onRefresh = { viewModel.refreshNetworkInfo() }
                    )
                    4 -> HistoryScreen(
                        sessions = historySessions,
                        onClearHistory = { viewModel.clearHistory() }
                    )
                }
            }
        }
    }
}
