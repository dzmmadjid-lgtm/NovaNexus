package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Gaming & Cyber Colors
val CyberNeonGreen = Color(0xFF00FF88)
val CyberNeonGreenDark = Color(0xFF00B359)
val CyberCyan = Color(0xFF00D2FF)
val CyberCyanDark = Color(0xFF0088A8)
val CyberAmber = Color(0xFFFFB300)
val CyberRed = Color(0xFFFF334B)
val PubgYellow = Color(0xFFF2A900)

// Tactical Cyber Dark Palette
val CyberDarkBg = Color(0xFF0A0E17)
val CyberDarkSurface = Color(0xFF111726)
val CyberDarkCard = Color(0xFF172033)
val CyberDarkCardElevated = Color(0xFF1F2B44)
val CyberDarkBorder = Color(0xFF2A3A5A)
val CyberDarkBorderGlow = Color(0x6600FF88)

// Text Colors
val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B949E)
val TextMuted = Color(0xFF586069)
val TextHighlight = Color(0xFF00FF88)
