package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BoostState
import com.example.model.DnsProfile
import com.example.model.GameEdition
import com.example.model.PubgServer
import com.example.ui.components.CyberRadarPingView
import com.example.ui.components.PubgGameLauncherBar
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberRed
import com.example.ui.theme.PubgYellow

@Composable
fun BoosterHomeScreen(
    boostState: BoostState,
    selectedServer: PubgServer,
    selectedDns: DnsProfile,
    gameEditions: List<GameEdition>,
    onStartBoost: () -> Unit,
    onStopBoost: () -> Unit,
    onNavigateToServers: () -> Unit,
    onNavigateToDns: () -> Unit,
    onLaunchGame: (GameEdition) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current

    val infiniteTransition = rememberInfiniteTransition(label = "pulse_btn")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "btn_pulse"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(bottom = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Header Banner
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            color = Color(0xFF101726),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E2B44))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(CyberNeonGreen.copy(alpha = 0.15f), CircleShape)
                            .border(1.dp, CyberNeonGreen.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = CyberNeonGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "PUBG PING BOOSTER",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                fontSize = 14.5.sp,
                                letterSpacing = 1.sp
                            ),
                            color = Color.White
                        )
                        Text(
                            text = "مسرّع ومثبت البينج الاحترافي لـ ببجي موبايل",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 11.sp,
                                color = Color(0xFF8B949E)
                            )
                        )
                    }
                }

                Surface(
                    color = if (boostState.isBoostActive) CyberNeonGreen.copy(alpha = 0.15f) else Color(0xFF1E2B44),
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (boostState.isBoostActive) CyberNeonGreen else Color(0xFF2A3A58)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(
                                    if (boostState.isBoostActive) CyberNeonGreen else Color(0xFF8B949E),
                                    CircleShape
                                )
                        )
                        Text(
                            text = if (boostState.isBoostActive) "نشط" else "خامل",
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (boostState.isBoostActive) CyberNeonGreen else Color(0xFF8B949E)
                        )
                    }
                }
            }
        }

        // Radar Visual HUD
        CyberRadarPingView(
            pingMs = if (boostState.isBoostActive) boostState.currentPing else selectedServer.currentPingMs,
            jitterMs = selectedServer.jitterMs,
            packetLossPercent = selectedServer.packetLossPercent,
            isBoosting = boostState.isBoosting,
            isBoostActive = boostState.isBoostActive,
            activeServer = selectedServer
        )

        // Boosting Progress Card (When active or optimizing)
        AnimatedVisibility(visible = boostState.isBoosting) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                color = Color(0xFF0F1829),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = boostState.boostStepText,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = CyberCyan
                        )
                        Text(
                            text = "${(boostState.boostProgress * 100).toInt()}%",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyan
                        )
                    }
                    LinearProgressIndicator(
                        progress = { boostState.boostProgress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = CyberNeonGreen,
                        trackColor = Color(0xFF1E2B44),
                        strokeCap = StrokeCap.Round
                    )
                }
            }
        }

        // Boost Optimization Outcome Card
        AnimatedVisibility(visible = boostState.isBoostActive && !boostState.isBoosting) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                color = Color(0xFF0D1E18),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberNeonGreen.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = CyberNeonGreen,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "تم تحسين وتثبيت الاتصال بنجاح!",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberNeonGreen
                            )
                        }

                        Surface(
                            color = CyberNeonGreen.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "-${boostState.pingReductionPercent}% انخفاض البينج",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyberNeonGreen,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF091410), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("قبل التحسين", fontSize = 10.sp, color = Color(0xFF8B949E))
                            Text("${boostState.initialPing} ms", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = CyberRed)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("الآن", fontSize = 10.sp, color = Color(0xFF8B949E))
                            Text("${boostState.currentPing} ms", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = CyberNeonGreen)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("تنظيف RAM", fontSize = 10.sp, color = Color(0xFF8B949E))
                            Text("${boostState.ramCleanedMb} MB", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = CyberCyan)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("تقليل Jitter", fontSize = 10.sp, color = Color(0xFF8B949E))
                            Text("-${boostState.jitterReductionMs} ms", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PubgYellow)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Big ULTRA BOOST Action Button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            if (!boostState.isBoostActive) {
                Button(
                    onClick = onStartBoost,
                    enabled = !boostState.isBoosting,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .scale(if (!boostState.isBoosting) pulseScale else 1f)
                        .testTag("ultra_boost_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberNeonGreen,
                        contentColor = Color(0xFF0A0E17)
                    ),
                    shape = RoundedCornerShape(16.dp),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp)
                ) {
                    if (boostState.isBoosting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = Color(0xFF0A0E17),
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "جاري تسريع وتثبيت البينج...",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = null,
                                modifier = Modifier.size(26.dp)
                            )
                            Text(
                                text = "🚀 بدء التسريع الفائق (ULTRA BOOST)",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onStopBoost,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("stop_boost_button"),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = CyberRed
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberRed.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PowerSettingsNew,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "إيقاف المسرّع",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Button(
                        onClick = {
                            val targetEdition = gameEditions.firstOrNull { it.isInstalled } ?: gameEditions.firstOrNull()
                            if (targetEdition != null) {
                                onLaunchGame(targetEdition)
                            }
                        },
                        modifier = Modifier
                            .weight(1.5f)
                            .height(52.dp)
                            .testTag("launch_pubg_now_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = PubgYellow,
                            contentColor = Color(0xFF0A0E17)
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = "🎮", fontSize = 18.sp)
                            Text(
                                text = "فتح ببجي الآن",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Selected Server & DNS Quick Switcher Cards
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Quick Server Card
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToServers() }
                    .testTag("quick_server_card"),
                color = Color(0xFF121B2D),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF22314E))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Public,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "سيرفر اللعبة",
                                fontSize = 11.sp,
                                color = Color(0xFF8B949E)
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = Color(0xFF8B949E),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${selectedServer.flag} ${selectedServer.nameAr}",
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1
                    )
                    Text(
                        text = "${selectedServer.currentPingMs} ms • ${selectedServer.region}",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CyberNeonGreen
                    )
                }
            }

            // Quick DNS Card
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigateToDns() }
                    .testTag("quick_dns_card"),
                color = Color(0xFF121B2D),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF22314E))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Dns,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "خادم DNS للألعاب",
                                fontSize = 11.sp,
                                color = Color(0xFF8B949E)
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = Color(0xFF8B949E),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = selectedDns.name,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1
                    )
                    Text(
                        text = "${selectedDns.primaryIp} (${selectedDns.latencyMs}ms)",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = CyberCyan
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // PUBG Game Launcher Quick Section
        PubgGameLauncherBar(
            gameEditions = gameEditions,
            onLaunchGame = onLaunchGame
        )
    }
}
