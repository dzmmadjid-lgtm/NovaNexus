package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PubgServer
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberNeonGreen
import com.example.ui.theme.CyberRed
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CyberRadarPingView(
    pingMs: Int,
    jitterMs: Int,
    packetLossPercent: Float,
    isBoosting: Boolean,
    isBoostActive: Boolean,
    activeServer: PubgServer?,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "radar_anim")

    // Radar Rotation Angle
    val radarAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isBoosting) 1200 else 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radar_rotation"
    )

    // Pulse Scale
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val pingColor = when {
        pingMs <= 40 -> CyberNeonGreen
        pingMs <= 75 -> CyberCyan
        pingMs <= 120 -> CyberAmber
        else -> CyberRed
    }

    val pingQualityText = when {
        pingMs <= 40 -> "⚡ ممتاز (استجابة فورية)"
        pingMs <= 75 -> "🟢 جيد جداً (سلس وبدون لاق)"
        pingMs <= 120 -> "🟡 متوسط (مقبول)"
        else -> "🔴 مرتفع (قد يسبب تقطيع)"
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Main Circular HUD
        Box(
            modifier = Modifier
                .size(240.dp)
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            // Animated Canvas Background Grid & Radar Sweep
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = (size.width / 2f) - 10f

                // Outer boundary circle
                drawCircle(
                    color = Color(0xFF1E2B44),
                    radius = radius,
                    center = center,
                    style = Stroke(width = 2.dp.toPx())
                )

                // Middle concentric circle
                drawCircle(
                    color = Color(0xFF162238),
                    radius = radius * 0.7f,
                    center = center,
                    style = Stroke(
                        width = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                    )
                )

                // Inner concentric circle
                drawCircle(
                    color = Color(0xFF121B2D),
                    radius = radius * 0.4f,
                    center = center,
                    style = Stroke(width = 1.dp.toPx())
                )

                // Crosshair Grid Lines
                drawLine(
                    color = Color(0x3300D2FF),
                    start = Offset(center.x - radius, center.y),
                    end = Offset(center.x + radius, center.y),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = Color(0x3300D2FF),
                    start = Offset(center.x, center.y - radius),
                    end = Offset(center.x, center.y + radius),
                    strokeWidth = 1.dp.toPx()
                )

                // Radar Sweep Line
                val rad = Math.toRadians(radarAngle.toDouble())
                val sweepEnd = Offset(
                    (center.x + (radius * cos(rad))).toFloat(),
                    (center.y + (radius * sin(rad))).toFloat()
                )

                drawLine(
                    brush = Brush.radialGradient(
                        colors = listOf(pingColor, Color.Transparent),
                        center = center,
                        radius = radius
                    ),
                    start = center,
                    end = sweepEnd,
                    strokeWidth = 3.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            // Central Glowing HUD Card
            Surface(
                modifier = Modifier
                    .size(170.dp)
                    .clip(CircleShape)
                    .border(
                        width = 2.dp,
                        brush = Brush.sweepGradient(
                            listOf(
                                pingColor.copy(alpha = 0.8f),
                                Color(0xFF00D2FF).copy(alpha = 0.3f),
                                pingColor.copy(alpha = 0.8f)
                            )
                        ),
                        shape = CircleShape
                    ),
                color = Color(0xFF0C1322),
                tonalElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(pingColor, CircleShape)
                        )
                        Text(
                            text = if (isBoostActive) "STABLE PING" else "CURRENT PING",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF8B949E),
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    // Ping Number in ms
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "$pingMs",
                            fontSize = 46.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = pingColor,
                            letterSpacing = (-1.5).sp
                        )
                        Text(
                            text = "ms",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = pingColor.copy(alpha = 0.8f),
                            modifier = Modifier.padding(bottom = 8.dp, start = 2.dp)
                        )
                    }

                    // Server tag
                    Surface(
                        color = Color(0xFF182238),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.padding(horizontal = 8.dp)
                    ) {
                        Text(
                            text = "${activeServer?.flag ?: "🇸🇦"} ${activeServer?.region ?: "الشرق الأوسط"}",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFFD1E7DD),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                            maxLines = 1
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Status Badge
        Surface(
            color = pingColor.copy(alpha = 0.12f),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, pingColor.copy(alpha = 0.35f))
        ) {
            Text(
                text = pingQualityText,
                color = pingColor,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 3 Key Metrics Row (Jitter, Packet Loss, Boost Status)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricPill(
                title = "Jitter (التذبذب)",
                value = "$jitterMs ms",
                icon = Icons.Default.Speed,
                accentColor = if (jitterMs <= 5) CyberNeonGreen else CyberAmber,
                modifier = Modifier.weight(1f)
            )
            MetricPill(
                title = "فقدان الحزم",
                value = "${String.format("%.1f", packetLossPercent)}%",
                icon = Icons.Default.Wifi,
                accentColor = if (packetLossPercent == 0f) CyberNeonGreen else CyberRed,
                modifier = Modifier.weight(1f)
            )
            MetricPill(
                title = "حالة التسريع",
                value = if (isBoostActive) "⚡ مفعل" else "جاهز",
                icon = Icons.Default.Bolt,
                accentColor = if (isBoostActive) CyberNeonGreen else CyberCyan,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun MetricPill(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = Color(0xFF131C2E),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF22314E))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = accentColor,
                    modifier = Modifier.size(13.dp)
                )
                Text(
                    text = title,
                    fontSize = 10.sp,
                    color = Color(0xFF8B949E),
                    maxLines = 1
                )
            }
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = value,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = accentColor
            )
        }
    }
}
