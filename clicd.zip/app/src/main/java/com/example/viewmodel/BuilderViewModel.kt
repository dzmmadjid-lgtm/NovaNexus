package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.GitHubBuildManager
import com.example.engine.ProjectInspector
import com.example.model.AppThemeMode
import com.example.model.BuildLogEntry
import com.example.model.BuildStatus
import com.example.model.GitHubConfig
import com.example.model.LogType
import com.example.model.ProjectInspectionResult
import com.example.model.SavedApkItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BuilderUiState(
    val config: GitHubConfig = GitHubConfig(),
    val themeMode: AppThemeMode = AppThemeMode.OLED_BLACK,
    val selectedZipUri: Uri? = null,
    val selectedZipName: String? = null,
    val inspectionResult: ProjectInspectionResult? = null,
    val isInspecting: Boolean = false,
    val buildStatus: BuildStatus = BuildStatus.IDLE,
    val progressPercent: Int = 0,
    val statusDescription: String = "جاهز للبناء",
    val logs: List<BuildLogEntry> = emptyList(),
    val generatedApkFile: File? = null,
    val savedApks: List<SavedApkItem> = emptyList(),
    val currentTab: Int = 0, // 0: Builder, 1: Saved APKs Library
    val errorMessage: String? = null,
    val showConfigDialog: Boolean = false,
    val lastCompletedRunId: Long? = null
)

class BuilderViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("apk_builder_prefs", Context.MODE_PRIVATE)

    private val _uiState = MutableStateFlow(
        BuilderUiState(
            config = GitHubConfig(
                token = prefs.getString("gh_token", "") ?: "",
                owner = prefs.getString("gh_owner", "dzmmadjid-lgtm") ?: "dzmmadjid-lgtm",
                repo = prefs.getString("gh_repo", "NovaNexus") ?: "NovaNexus",
                branch = prefs.getString("gh_branch", "main") ?: "main"
            ),
            themeMode = try {
                AppThemeMode.valueOf(prefs.getString("app_theme", AppThemeMode.OLED_BLACK.name) ?: AppThemeMode.OLED_BLACK.name)
            } catch (e: Exception) {
                AppThemeMode.OLED_BLACK
            }
        )
    )
    val uiState: StateFlow<BuilderUiState> = _uiState.asStateFlow()

    init {
        loadSavedApks()
    }

    fun setThemeMode(mode: AppThemeMode) {
        prefs.edit().putString("app_theme", mode.name).apply()
        _uiState.value = _uiState.value.copy(themeMode = mode)
    }

    fun setTab(tabIndex: Int) {
        _uiState.value = _uiState.value.copy(currentTab = tabIndex)
        if (tabIndex == 1) {
            loadSavedApks()
        }
    }

    fun updateConfig(token: String, owner: String, repo: String, branch: String) {
        prefs.edit()
            .putString("gh_token", token)
            .putString("gh_owner", owner)
            .putString("gh_repo", repo)
            .putString("gh_branch", branch)
            .apply()

        _uiState.value = _uiState.value.copy(
            config = GitHubConfig(token, owner, repo, branch),
            showConfigDialog = false
        )
    }

    fun toggleConfigDialog(show: Boolean) {
        _uiState.value = _uiState.value.copy(showConfigDialog = show)
    }

    fun onFileSelected(uri: Uri, fileName: String) {
        _uiState.value = _uiState.value.copy(
            selectedZipUri = uri,
            selectedZipName = fileName,
            isInspecting = true,
            inspectionResult = null,
            errorMessage = null,
            generatedApkFile = null
        )

        addLog("تم اختيار ملف: $fileName. جاري فحصه محلياً...", LogType.INFO)

        viewModelScope.launch {
            val result = ProjectInspector.inspectZipFile(getApplication(), uri, fileName)
            _uiState.value = _uiState.value.copy(
                isInspecting = false,
                inspectionResult = result
            )
            if (result.isValid) {
                addLog("تم التحقق من المشروع: '${result.projectName}' بنجاح (Gradle ${result.detectedGradleVersion})", LogType.SUCCESS)
            } else {
                addLog("تنبيه: ${result.errorMessage}", LogType.WARNING)
            }
        }
    }

    fun startBuild() {
        val state = _uiState.value
        val uri = state.selectedZipUri
        val fileName = state.selectedZipName
        val config = state.config

        if (uri == null || fileName == null) {
            _uiState.value = _uiState.value.copy(errorMessage = "يرجى اختيار ملف مشروع Android بصيغة ZIP أولاً.")
            return
        }

        if (config.token.isBlank() || config.owner.isBlank() || config.repo.isBlank()) {
            _uiState.value = _uiState.value.copy(
                errorMessage = "يرجى إدخال إعدادات GitHub (Token و Owner و Repository) أولاً.",
                showConfigDialog = true
            )
            return
        }

        _uiState.value = _uiState.value.copy(
            buildStatus = BuildStatus.INSPECTING_LOCAL_ZIP,
            progressPercent = 5,
            statusDescription = "بدء دورة البناء...",
            errorMessage = null,
            generatedApkFile = null
        )

        val manager = GitHubBuildManager(config.token, config.owner, config.repo)

        viewModelScope.launch {
            manager.startBuildPipeline(
                context = getApplication(),
                zipUri = uri,
                fileName = fileName,
                onLog = { logEntry ->
                    addLog(logEntry.message, logEntry.type)
                },
                onStatusChange = { status, progress ->
                    _uiState.value = _uiState.value.copy(
                        buildStatus = status,
                        progressPercent = progress,
                        statusDescription = getStatusText(status)
                    )
                },
                onRunIdDetected = { runId ->
                    _uiState.value = _uiState.value.copy(lastCompletedRunId = runId)
                },
                onApkReady = { apkFile, originalName ->
                    _uiState.value = _uiState.value.copy(
                        buildStatus = BuildStatus.SUCCESS,
                        progressPercent = 100,
                        generatedApkFile = apkFile,
                        statusDescription = "تم إنشاء وتنزيل الـ APK بنجاح!"
                    )
                    loadSavedApks()
                },
                onFailure = { error ->
                    _uiState.value = _uiState.value.copy(
                        buildStatus = BuildStatus.FAILED,
                        progressPercent = 0,
                        errorMessage = error,
                        statusDescription = "فشل: $error"
                    )
                }
            )
        }
    }

    fun retryDownloadOnly() {
        val state = _uiState.value
        val config = state.config
        val fileName = state.selectedZipName ?: "project.zip"

        _uiState.value = _uiState.value.copy(
            buildStatus = BuildStatus.DOWNLOADING_APK,
            progressPercent = 92,
            statusDescription = "إعادة محاولة تنزيل الـ APK مباشرة...",
            errorMessage = null
        )

        val manager = GitHubBuildManager(config.token, config.owner, config.repo)

        viewModelScope.launch {
            // Find latest completed run if runId not explicitly stored
            try {
                addLog("جاري البحث عن أحدث Artifact جاهز في المستودع...", LogType.INFO)
                val runId = manager.findLatestSuccessfulRunId()
                addLog("تم العثور على البناء المكتمل (Run #$runId). بدء التنزيل المباشر...", LogType.PROGRESS)
                
                manager.downloadApkDirectly(
                    context = getApplication(),
                    runId = runId,
                    fileName = fileName,
                    onLog = { logEntry -> addLog(logEntry.message, logEntry.type) },
                    onStatusChange = { status, progress ->
                        _uiState.value = _uiState.value.copy(
                            buildStatus = status,
                            progressPercent = progress,
                            statusDescription = getStatusText(status)
                        )
                    },
                    onApkReady = { apkFile, _ ->
                        _uiState.value = _uiState.value.copy(
                            buildStatus = BuildStatus.SUCCESS,
                            progressPercent = 100,
                            generatedApkFile = apkFile,
                            statusDescription = "تم تنزيل الـ APK وتجهيزه بنجاح!"
                        )
                        loadSavedApks()
                    },
                    onFailure = { error ->
                        _uiState.value = _uiState.value.copy(
                            buildStatus = BuildStatus.FAILED,
                            progressPercent = 0,
                            errorMessage = error,
                            statusDescription = "فشل التنزيل: $error"
                        )
                    }
                )
            } catch (e: Exception) {
                val err = e.localizedMessage ?: "تعذر العثور على جلسة البناء السابقة."
                _uiState.value = _uiState.value.copy(
                    buildStatus = BuildStatus.FAILED,
                    errorMessage = err,
                    statusDescription = "خطأ: $err"
                )
                addLog("خطأ: $err", LogType.ERROR)
            }
        }
    }

    fun loadSavedApks() {
        val outputDir = File(getApplication<Application>().getExternalFilesDir(null), "BuiltAPKs")
        if (!outputDir.exists()) outputDir.mkdirs()

        val files = outputDir.listFiles { file -> file.extension.equals("apk", ignoreCase = true) } ?: emptyArray()
        val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())

        val list = files.sortedByDescending { it.lastModified() }.map { file ->
            val sizeMb = String.format(Locale.US, "%.2f MB", file.length() / (1024.0 * 1024.0))
            SavedApkItem(
                id = file.absolutePath,
                name = file.name,
                path = file.absolutePath,
                sizeFormatted = sizeMb,
                buildDate = dateFormat.format(Date(file.lastModified())),
                projectName = file.name.replace("-release.apk", "").replace(".apk", "")
            )
        }
        _uiState.value = _uiState.value.copy(savedApks = list)
    }

    fun deleteApk(item: SavedApkItem) {
        val file = File(item.path)
        if (file.exists()) {
            file.delete()
        }
        loadSavedApks()
    }

    fun clearLogs() {
        _uiState.value = _uiState.value.copy(logs = emptyList())
    }

    private fun addLog(message: String, type: LogType) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val entry = BuildLogEntry(time, message, type)
        _uiState.value = _uiState.value.copy(
            logs = _uiState.value.logs + entry
        )
    }

    private fun getStatusText(status: BuildStatus): String = when (status) {
        BuildStatus.IDLE -> "جاهز للبناء"
        BuildStatus.INSPECTING_LOCAL_ZIP -> "فحص وتجهيز الملف..."
        BuildStatus.UPLOADING_TO_GITHUB -> "رفع ملف الـ ZIP إلى GitHub..."
        BuildStatus.TRIGGERING_WORKFLOW -> "تشغيل سير عمل البناء..."
        BuildStatus.RUNNER_QUEUED -> "حجز وتجهيز خادم الـ Runner..."
        BuildStatus.BUILDING_GRADLE -> "تجميع وترجمة المشروع عبر Gradle..."
        BuildStatus.COMPILING_CODE -> "ترجمة الأكواد وتوليد الـ DEX..."
        BuildStatus.GENERATING_APK -> "إنشاء حزمة الـ APK وتوقيعها..."
        BuildStatus.DOWNLOADING_APK -> "تنزيل الـ APK النهائي إلى الهاتف..."
        BuildStatus.SUCCESS -> "اكتمل البناء وتنزيل الـ APK بنجاح!"
        BuildStatus.FAILED -> "فشل في عملية البناء"
    }
}
