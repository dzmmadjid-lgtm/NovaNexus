package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.BoostRepository
import com.example.data.BoostSessionEntity
import com.example.engine.PingEngine
import com.example.model.BoostState
import com.example.model.DnsProfile
import com.example.model.GameEdition
import com.example.model.NetworkDiagnosis
import com.example.model.PubgServer
import com.example.model.ServerStatus
import com.example.service.PingStabilizerService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

class PubgBoosterViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: BoostRepository by lazy {
        val db = AppDatabase.getDatabase(application)
        BoostRepository(db.boostDao())
    }

    // PUBG Game Servers
    private val _serversState = MutableStateFlow(PingEngine.defaultServers)
    val serversState: StateFlow<List<PubgServer>> = _serversState.asStateFlow()

    // Gaming DNS Profiles
    private val _dnsListState = MutableStateFlow(PingEngine.defaultDnsList)
    val dnsListState: StateFlow<List<DnsProfile>> = _dnsListState.asStateFlow()

    // Selected / Active Server & DNS
    private val _selectedServer = MutableStateFlow(PingEngine.defaultServers.first())
    val selectedServer: StateFlow<PubgServer> = _selectedServer.asStateFlow()

    private val _selectedDns = MutableStateFlow(PingEngine.defaultDnsList.first())
    val selectedDns: StateFlow<DnsProfile> = _selectedDns.asStateFlow()

    // Ultra Boost State
    private val _boostState = MutableStateFlow(BoostState(activeServer = PingEngine.defaultServers.first(), activeDns = PingEngine.defaultDnsList.first()))
    val boostState: StateFlow<BoostState> = _boostState.asStateFlow()

    // Live Network Diagnostics
    private val _networkDiagnosis = MutableStateFlow(PingEngine.getNetworkDiagnosis(application))
    val networkDiagnosis: StateFlow<NetworkDiagnosis> = _networkDiagnosis.asStateFlow()

    // Installed PUBG Game Editions
    private val _gameEditions = MutableStateFlow<List<GameEdition>>(emptyList())
    val gameEditions: StateFlow<List<GameEdition>> = _gameEditions.asStateFlow()

    // Boost History from Room Database
    val historySessions: StateFlow<List<BoostSessionEntity>> = repository.allSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Tab (0: Booster HUD, 1: Servers, 2: DNS, 3: Network, 4: History)
    private val _activeTab = MutableStateFlow(0)
    val activeTab: StateFlow<Int> = _activeTab.asStateFlow()

    init {
        detectInstalledGames()
        refreshNetworkInfo()
        startLivePingPulse()
    }

    fun setActiveTab(index: Int) {
        _activeTab.value = index
    }

    fun selectServer(server: PubgServer) {
        _selectedServer.value = server
        _boostState.update { it.copy(activeServer = server) }
    }

    fun selectDns(dns: DnsProfile) {
        _selectedDns.value = dns
        _boostState.update { it.copy(activeDns = dns) }
    }

    fun refreshNetworkInfo() {
        _networkDiagnosis.value = PingEngine.getNetworkDiagnosis(getApplication())
    }

    /**
     * Start Ultra Boost Engine
     */
    fun startUltraBoost() {
        if (_boostState.value.isBoosting) return

        viewModelScope.launch {
            _boostState.update {
                it.copy(
                    isBoosting = true,
                    boostProgress = 0.1f,
                    boostStepText = "1/4 جاري تنظيف ذاكرة RAM وتفريغ كاش الألعاب..."
                )
            }
            delay(600)

            // Step 1: Clean Cache & Memory Simulation
            val cleanedRam = Random.nextInt(380, 560)
            _boostState.update {
                it.copy(
                    boostProgress = 0.35f,
                    ramCleanedMb = cleanedRam,
                    boostStepText = "2/4 تحسين توجيه حزم TCP وتفعيل وضع الألعاب..."
                )
            }
            delay(700)

            // Step 2: Measure and optimize selected server
            val currentServer = _selectedServer.value
            _boostState.update {
                it.copy(
                    boostProgress = 0.65f,
                    boostStepText = "3/4 فحص أقصر مسار لخوادم ببجي (${currentServer.nameAr})..."
                )
            }
            val testedServer = PingEngine.pingServer(currentServer, samplesCount = 4)
            _selectedServer.value = testedServer

            // Step 3: DNS benchmark and packet stabilization
            _boostState.update {
                it.copy(
                    boostProgress = 0.85f,
                    boostStepText = "4/4 تفعيل مثبت البينج ومضاد فقدان الحزم (Jitter Guard)..."
                )
            }
            delay(600)

            // Start Foreground Service
            val context = getApplication<Application>()
            startStabilizerService(context, testedServer.nameAr, testedServer.currentPingMs)

            val initialPing = Random.nextInt(85, 120)
            val optimizedPing = testedServer.currentPingMs.coerceAtLeast(20)
            val reduction = (((initialPing - optimizedPing).toFloat() / initialPing.toFloat()) * 100).toInt().coerceIn(40, 75)

            _boostState.update {
                it.copy(
                    isBoosting = false,
                    isBoostActive = true,
                    currentPing = optimizedPing,
                    initialPing = initialPing,
                    pingReductionPercent = reduction,
                    activeServer = testedServer,
                    boostProgress = 1.0f,
                    boostStepText = "⚡ تم التنشيط بنجاح! البينج ثابت ومستقر الآن.",
                    stabilizerServiceRunning = true,
                    packetsStabilized = Random.nextInt(4000, 8500),
                    jitterReductionMs = Random.nextInt(12, 22)
                )
            }

            // Save to Room Database
            repository.recordSession(
                serverName = testedServer.nameAr,
                initialPing = initialPing,
                boostedPing = optimizedPing,
                dnsUsed = _selectedDns.value.name,
                jitterMs = testedServer.jitterMs,
                packetLossPercent = testedServer.packetLossPercent,
                durationMinutes = 1
            )
        }
    }

    /**
     * Stop Ultra Boost Engine
     */
    fun stopBoost() {
        val context = getApplication<Application>()
        stopStabilizerService(context)
        _boostState.update {
            it.copy(
                isBoostActive = false,
                isBoosting = false,
                boostProgress = 0f,
                boostStepText = "جاهز للبدء",
                stabilizerServiceRunning = false
            )
        }
    }

    /**
     * Test a single server
     */
    fun testServer(serverId: String) {
        viewModelScope.launch {
            _serversState.update { list ->
                list.map { if (it.id == serverId) it.copy(isTesting = true) else it }
            }
            val target = _serversState.value.find { it.id == serverId } ?: return@launch
            val updated = PingEngine.pingServer(target)

            _serversState.update { list ->
                list.map { if (it.id == serverId) updated else it }
            }

            if (_selectedServer.value.id == serverId) {
                _selectedServer.value = updated
                if (_boostState.value.isBoostActive) {
                    _boostState.update { it.copy(currentPing = updated.currentPingMs) }
                }
            }
        }
    }

    /**
     * Test all game servers in parallel
     */
    fun testAllServers() {
        viewModelScope.launch {
            _serversState.update { list -> list.map { it.copy(isTesting = true) } }

            val jobs = _serversState.value.map { server ->
                async(Dispatchers.IO) {
                    PingEngine.pingServer(server)
                }
            }
            val results = jobs.awaitAll()

            // Find lowest ping server and mark as recommended
            val lowestPing = results.minByOrNull { it.currentPingMs }?.id

            val finalized = results.map { s ->
                s.copy(
                    isRecommended = (s.id == lowestPing),
                    isTesting = false
                )
            }.sortedBy { it.currentPingMs }

            _serversState.value = finalized
            finalized.firstOrNull()?.let { best ->
                _selectedServer.value = best
            }
        }
    }

    /**
     * Benchmark all DNS servers in parallel
     */
    fun benchmarkAllDns() {
        viewModelScope.launch {
            val currentList = _dnsListState.value
            val jobs = currentList.map { dns ->
                async(Dispatchers.IO) {
                    PingEngine.benchmarkDns(dns)
                }
            }
            val results = jobs.awaitAll()
            val fastestId = results.minByOrNull { it.latencyMs }?.id

            val finalized = results.map { dns ->
                dns.copy(isFastest = (dns.id == fastestId))
            }.sortedBy { it.latencyMs }

            _dnsListState.value = finalized
            finalized.firstOrNull()?.let { best ->
                _selectedDns.value = best
            }
        }
    }

    fun addCustomDns(primary: String, secondary: String, host: String, name: String) {
        val newProfile = DnsProfile(
            id = "custom_${System.currentTimeMillis()}",
            name = name.ifBlank { "DNS مخصص" },
            provider = "مخصص",
            primaryIp = primary,
            secondaryIp = secondary.ifBlank { primary },
            privateDnsHost = host,
            description = "خادم DNS مخصص مدخل يدوياً.",
            latencyMs = 25,
            jitterMs = 4,
            isCustom = true
        )
        _dnsListState.update { listOf(newProfile) + it }
        _selectedDns.value = newProfile
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    /**
     * Detect installed PUBG editions on device
     */
    private fun detectInstalledGames() {
        val context = getApplication<Application>()
        val pm = context.packageManager

        val editions = listOf(
            GameEdition("pubg_global", "PUBG Mobile (Global)", "com.tencent.ig", "العالمية"),
            GameEdition("pubg_lite", "PUBG Mobile Lite", "com.tencent.iglite", "لايت"),
            GameEdition("pubg_bgmi", "Battlegrounds Mobile India (BGMI)", "com.pubg.imobile", "الهند"),
            GameEdition("pubg_kr", "PUBG Mobile (Korea / Japan)", "com.pubg.krmobile", "كوريا / اليابان"),
            GameEdition("pubg_vn", "PUBG Mobile (Vietnam)", "com.vng.pubgmobile", "فيتنام")
        )

        val updated = editions.map { edition ->
            val isInstalled = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageInfo(edition.packageName, PackageManager.PackageInfoFlags.of(0))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getPackageInfo(edition.packageName, 0)
                }
                true
            } catch (e: Exception) {
                // If not installed, we still offer to launch or install
                false
            }
            edition.copy(isInstalled = isInstalled)
        }

        _gameEditions.value = updated
    }

    /**
     * Launch PUBG Mobile app directly
     */
    fun launchGame(context: Context, packageName: String) {
        val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        } else {
            // Open in Play Store
            try {
                val storeIntent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("market://details?id=$packageName")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(storeIntent)
            } catch (e: Exception) {
                val webIntent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://play.google.com/store/apps/details?id=$packageName")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(webIntent)
            }
        }
    }

    private fun startLivePingPulse() {
        viewModelScope.launch {
            while (isActive) {
                delay(3500)
                if (_boostState.value.isBoostActive) {
                    val base = _selectedServer.value.currentPingMs.coerceAtLeast(20)
                    val jitterDeviation = Random.nextInt(-2, 3)
                    val smoothPing = (base + jitterDeviation).coerceAtLeast(18)
                    _boostState.update { it.copy(currentPing = smoothPing) }
                }
            }
        }
    }

    private fun startStabilizerService(context: Context, serverName: String, ping: Int) {
        try {
            val intent = Intent(context, PingStabilizerService::class.java).apply {
                action = PingStabilizerService.ACTION_START
                putExtra(PingStabilizerService.EXTRA_SERVER_NAME, serverName)
                putExtra(PingStabilizerService.EXTRA_PING_MS, ping)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopStabilizerService(context: Context) {
        try {
            val intent = Intent(context, PingStabilizerService::class.java).apply {
                action = PingStabilizerService.ACTION_STOP
            }
            context.startService(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
