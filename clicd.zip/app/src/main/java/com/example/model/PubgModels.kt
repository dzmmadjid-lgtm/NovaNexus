package com.example.model

enum class ServerStatus(val labelAr: String, val colorHex: Long) {
    EXCELLENT("مثالي للألعاب", 0xFF00FF88),
    GOOD("جيد جداً", 0xFF00D2FF),
    MODERATE("متوسط", 0xFFFFB300),
    HIGH("بينج مرتفع", 0xFFFF334B),
    TESTING("جاري الفحص...", 0xFF8B949E),
    OFFLINE("غير متاح", 0xFF586069)
}

data class PubgServer(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val region: String,
    val flag: String,
    val host: String,
    val port: Int = 443,
    val currentPingMs: Int = 0,
    val minPingMs: Int = 0,
    val maxPingMs: Int = 0,
    val jitterMs: Int = 0,
    val packetLossPercent: Float = 0f,
    val status: ServerStatus = ServerStatus.GOOD,
    val isRecommended: Boolean = false,
    val isTesting: Boolean = false
)

data class DnsProfile(
    val id: String,
    val name: String,
    val provider: String,
    val primaryIp: String,
    val secondaryIp: String,
    val privateDnsHost: String,
    val description: String,
    val latencyMs: Int = 0,
    val jitterMs: Int = 0,
    val isFastest: Boolean = false,
    val isCustom: Boolean = false
)

data class GameEdition(
    val id: String,
    val name: String,
    val packageName: String,
    val regionLabel: String,
    val isInstalled: Boolean = false
)

data class NetworkDiagnosis(
    val connectionType: String = "Wi-Fi (5GHz)",
    val isConnected: Boolean = true,
    val signalStrengthDbm: Int = -52,
    val signalPercent: Int = 92,
    val linkSpeedMbps: Int = 866,
    val publicIp: String = "192.168.1.105",
    val gatewayIp: String = "192.168.1.1",
    val dnsServer: String = "1.1.1.1 (Cloudflare Gaming)",
    val mtu: Int = 1500,
    val bufferbloatGrade: String = "A+",
    val packetLoss: Float = 0.0f,
    val frequencyBand: String = "5.0 GHz (قناة 44 - منخفضة التداخل)"
)

data class BoostState(
    val isBoosting: Boolean = false,
    val isBoostActive: Boolean = false,
    val currentPing: Int = 38,
    val initialPing: Int = 92,
    val pingReductionPercent: Int = 58,
    val activeServer: PubgServer? = null,
    val activeDns: DnsProfile? = null,
    val boostProgress: Float = 0f,
    val boostStepText: String = "جاهز للبدء",
    val stabilizerServiceRunning: Boolean = false,
    val ramCleanedMb: Int = 420,
    val packetsStabilized: Int = 0,
    val jitterReductionMs: Int = 14
)
