package com.example.model

enum class AppThemeMode {
    OLED_BLACK, // أسود عميق نقي لشاشات OLED
    DARK_TACTICAL, // الوضع الليلي الداكن التكتيكي
    LIGHT_CLEAN // الوضع النهاري الصافي
}

data class SavedApkItem(
    val id: String,
    val name: String,
    val path: String,
    val sizeFormatted: String,
    val buildDate: String,
    val projectName: String
)
