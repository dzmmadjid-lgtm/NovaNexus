package com.example.model

data class ProjectInspectionResult(
    val isValid: Boolean,
    val fileName: String,
    val fileSizeFormatted: String,
    val projectName: String,
    val hasSettingsGradle: Boolean,
    val hasBuildGradle: Boolean,
    val detectedGradleVersion: String,
    val detectedModules: List<String>,
    val errorMessage: String? = null
)

data class BuildLogEntry(
    val timestamp: String,
    val message: String,
    val type: LogType = LogType.INFO
)

enum class LogType {
    INFO,
    SUCCESS,
    WARNING,
    ERROR,
    PROGRESS
}

enum class BuildStatus {
    IDLE,
    INSPECTING_LOCAL_ZIP,
    UPLOADING_TO_GITHUB,
    TRIGGERING_WORKFLOW,
    RUNNER_QUEUED,
    BUILDING_GRADLE,
    COMPILING_CODE,
    GENERATING_APK,
    DOWNLOADING_APK,
    SUCCESS,
    FAILED
}

data class GitHubConfig(
    val token: String = "",
    val owner: String = "",
    val repo: String = "",
    val branch: String = "main"
)
