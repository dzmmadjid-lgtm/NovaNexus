package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "boost_sessions")
data class BoostSessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val serverName: String,
    val initialPing: Int,
    val boostedPing: Int,
    val dnsUsed: String,
    val jitterMs: Int,
    val packetLossPercent: Float,
    val durationMinutes: Int = 1
)

@Dao
interface BoostDao {
    @Query("SELECT * FROM boost_sessions ORDER BY timestamp DESC")
    fun getAllSessions(): Flow<List<BoostSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: BoostSessionEntity): Long

    @Query("DELETE FROM boost_sessions")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM boost_sessions")
    suspend fun getSessionCount(): Int
}

@Database(
    entities = [BoostSessionEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun boostDao(): BoostDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pubg_booster_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class BoostRepository(private val boostDao: BoostDao) {
    val allSessions: Flow<List<BoostSessionEntity>> = boostDao.getAllSessions()

    suspend fun recordSession(
        serverName: String,
        initialPing: Int,
        boostedPing: Int,
        dnsUsed: String,
        jitterMs: Int,
        packetLossPercent: Float,
        durationMinutes: Int = 1
    ) {
        boostDao.insertSession(
            BoostSessionEntity(
                serverName = serverName,
                initialPing = initialPing,
                boostedPing = boostedPing,
                dnsUsed = dnsUsed,
                jitterMs = jitterMs,
                packetLossPercent = packetLossPercent,
                durationMinutes = durationMinutes
            )
        )
    }

    suspend fun clearHistory() {
        boostDao.clearAll()
    }
}
