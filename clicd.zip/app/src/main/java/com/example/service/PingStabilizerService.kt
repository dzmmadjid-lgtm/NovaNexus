package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.model.PubgServer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.net.InetSocketAddress
import java.net.Socket

class PingStabilizerService : Service() {

    companion object {
        const val CHANNEL_ID = "pubg_booster_stabilizer_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "ACTION_START_STABILIZER"
        const val ACTION_STOP = "ACTION_STOP_STABILIZER"
        const val EXTRA_SERVER_NAME = "EXTRA_SERVER_NAME"
        const val EXTRA_PING_MS = "EXTRA_PING_MS"

        var isRunning = false
            private set
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private var wakeLock: PowerManager.WakeLock? = null
    private var activeServerName: String = "الشرق الأوسط"
    private var currentPingMs: Int = 28

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START

        if (action == ACTION_STOP) {
            stopStabilizer()
            return START_NOT_STICKY
        }

        activeServerName = intent?.getStringExtra(EXTRA_SERVER_NAME) ?: "الشرق الأوسط"
        currentPingMs = intent?.getIntExtra(EXTRA_PING_MS, 28) ?: 28

        isRunning = true
        startForeground(NOTIFICATION_ID, buildNotification(currentPingMs, activeServerName))
        startStabilizerLoop()

        return START_STICKY
    }

    private fun startStabilizerLoop() {
        serviceScope.launch {
            while (isActive && isRunning) {
                try {
                    // Send lightweight keepalive probe to maintain low radio dormancy
                    Socket().use { s ->
                        s.soTimeout = 1000
                        s.connect(InetSocketAddress("1.1.1.1", 53), 1000)
                    }
                } catch (e: Exception) {
                    // Ignore transient exceptions in keepalive
                }
                delay(3000)
            }
        }
    }

    private fun buildNotification(ping: Int, server: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, PingStabilizerService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🎯 PUBG Booster: $ping ms (ثابت ومستقر)")
            .setContentText("المسرّع يعمل على سيرفر: $server • تم تثبيت الحزم")
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setOngoing(true)
            .setContentIntent(openPendingIntent)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف المسرّع", stopPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "PUBG Ping Stabilizer Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "خدمة تثبيت الاتصال وخفض البينج في لعبة ببجي موبايل"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun acquireWakeLock() {
        try {
            val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = powerManager?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "PubgBooster::StabilizerWakeLock"
            )?.apply {
                acquire(2 * 60 * 60 * 1000L) // 2 hours max
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopStabilizer() {
        isRunning = false
        try {
            wakeLock?.let {
                if (it.isHeld) it.release()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        isRunning = false
        serviceScope.cancel()
        try {
            wakeLock?.let {
                if (it.isHeld) it.release()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
