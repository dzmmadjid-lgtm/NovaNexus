package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testPingCalculation() {
    val initialPing = 95
    val boostedPing = 28
    val reduction = (((initialPing - boostedPing).toFloat() / initialPing.toFloat()) * 100).toInt()
    assertTrue(reduction > 50)
  }
}
