package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.ui.AppTab
import com.example.ui.MadjidViewModel
import com.example.ui.components.MadjidBottomNavBar
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MadjidViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MadjidMainApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun MadjidMainApp(viewModel: MadjidViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()

    Scaffold(
        bottomBar = {
            MadjidBottomNavBar(
                currentTab = currentTab,
                onTabSelected = { viewModel.setTab(it) }
            )
        },
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "TabContentAnimation"
            ) { targetTab ->
                when (targetTab) {
                    AppTab.HOME -> HomeScreen(viewModel = viewModel)
                    AppTab.PRAYERS -> PrayersScreen(viewModel = viewModel)
                    AppTab.TASBIH -> TasbihScreen(viewModel = viewModel)
                    AppTab.TASKS -> TasksScreen(viewModel = viewModel)
                    AppTab.JOURNAL -> JournalScreen(viewModel = viewModel)
                    AppTab.CONSTANTINE -> ConstantineGuideScreen(viewModel = viewModel)
                }
            }
        }
    }
}
