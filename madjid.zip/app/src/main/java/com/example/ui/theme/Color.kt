package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Algerian Emerald & Gold Theme Palette for Madjid App
val EmeraldPrimary = Color(0xFF064E3B)
val EmeraldSecondary = Color(0xFF059669)
val EmeraldLight = Color(0xFF10B981)
val EmeraldContainer = Color(0xFFD1FAE5)
val OnEmeraldContainer = Color(0xFF062F24)

val GoldAccent = Color(0xFFD97706)
val GoldLight = Color(0xFFFBBF24)
val GoldContainer = Color(0xFFFEF3C7)
val OnGoldContainer = Color(0xFF78350F)

val DeepTeal = Color(0xFF0B1E19)
val DarkSurface = Color(0xFF11221E)
val DarkSurfaceVariant = Color(0xFF19332D)

val WarmWhite = Color(0xFFFDFBF7)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F3)
val BorderLight = Color(0xFFE2E8F0)
val TextPrimaryDark = Color(0xFF0F172A)
val TextSecondaryDark = Color(0xFF475569)
val TextPrimaryLight = Color(0xFFF8FAFC)
val TextSecondaryLight = Color(0xFF94A3B8)

val ConstantineRed = Color(0xFFBE123C)
val ConstantineGold = Color(0xFFF59E0B)
val SkyBlue = Color(0xFF0284C7)

