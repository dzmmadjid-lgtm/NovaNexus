package com.example.ui.screens

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AdhkarCategory
import com.example.data.model.AdhkarRepositoryData
import com.example.ui.MadjidViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasbihScreen(
    viewModel: MadjidViewModel,
    modifier: Modifier = Modifier
) {
    var selectedSection by remember { mutableStateOf(0) } // 0: Digital Tasbih, 1: Adhkar Book
    val context = LocalContext.current

    val currentCount by viewModel.currentTasbihCount.collectAsState()
    val targetCount by viewModel.currentTasbihTarget.collectAsState()
    val selectedDhikr by viewModel.selectedDhikr.collectAsState()
    val completedRounds by viewModel.completedRounds.collectAsState()
    val lifetimeTotal by viewModel.totalLifetimeDhikr.collectAsState()

    val selectedAdhkarCat by viewModel.selectedAdhkarCategory.collectAsState()
    val adhkarProgress by viewModel.adhkarProgress.collectAsState()

    fun triggerHaptic() {
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(30, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(30)
                }
            }
        } catch (_: Exception) {}
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (selectedSection == 0) "المسبحة الإلكترونية" else "الأذكار والتحصينات",
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = GoldContainer,
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Stars, contentDescription = null, tint = OnGoldContainer, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "إجمالي الذكر: ${lifetimeTotal + currentCount}",
                                color = OnGoldContainer,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        modifier = modifier.testTag("tasbih_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tab Switcher (Tasbih vs Adhkar)
            TabRow(
                selectedTabIndex = selectedSection,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = EmeraldPrimary
            ) {
                Tab(
                    selected = selectedSection == 0,
                    onClick = { selectedSection = 0 },
                    text = { Text("المسبحة الذكية", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.Fingerprint, contentDescription = null) }
                )
                Tab(
                    selected = selectedSection == 1,
                    onClick = { selectedSection = 1 },
                    text = { Text("حصن المسلم والأذكار", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.MenuBook, contentDescription = null) }
                )
            }

            if (selectedSection == 0) {
                // Digital Tasbih View
                DigitalTasbihView(
                    currentCount = currentCount,
                    targetCount = targetCount,
                    selectedDhikr = selectedDhikr,
                    completedRounds = completedRounds,
                    onIncrement = {
                        triggerHaptic()
                        viewModel.incrementTasbih()
                    },
                    onReset = { viewModel.resetTasbih() },
                    onSelectDhikr = { viewModel.setSelectedDhikr(it) },
                    onSelectTarget = { viewModel.setTasbihTarget(it) }
                )
            } else {
                // Adhkar Reader View
                AdhkarReaderView(
                    selectedCategory = selectedAdhkarCat,
                    adhkarProgress = adhkarProgress,
                    onSelectCategory = { viewModel.selectAdhkarCategory(it) },
                    onIncrementItem = { id, max ->
                        triggerHaptic()
                        viewModel.incrementAdhkarItem(id, max)
                    },
                    onResetAll = { viewModel.resetAdhkarProgress() }
                )
            }
        }
    }
}

@Composable
fun DigitalTasbihView(
    currentCount: Int,
    targetCount: Int,
    selectedDhikr: String,
    completedRounds: Int,
    onIncrement: () -> Unit,
    onReset: () -> Unit,
    onSelectDhikr: (String) -> Unit,
    onSelectTarget: (Int) -> Unit
) {
    val dhikrOptions = listOf(
        "سُبْحَانَ اللَّهِ",
        "الْحَمْدُ لِلَّهِ",
        "اللَّهُ أَكْبَرُ",
        "لاَ إِلَهَ إِلاَّ اللَّهُ",
        "أَسْتَغْفِرُ اللَّهَ",
        "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ",
        "لاَ حَوْلَ وَلاَ قُوَّةَ إِلاَّ بِاللَّهِ"
    )

    val targetOptions = listOf(33, 99, 100, 0)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Text(
                text = "اختر صيغة الذكر:",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(dhikrOptions) { dhikr ->
                    val isSelected = dhikr == selectedDhikr
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectDhikr(dhikr) },
                        label = { Text(dhikr, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "العدد المستهدف:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    targetOptions.forEach { target ->
                        val isSelected = targetCount == target
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier
                                .clickable { onSelectTarget(target) }
                                .padding(horizontal = 2.dp)
                        ) {
                            Text(
                                text = if (target == 0) "حر" else "$target",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Main Giant Interactive Circular Tasbih Counter Button
        item {
            Card(
                modifier = Modifier
                    .size(260.dp)
                    .clip(CircleShape)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple()
                    ) { onIncrement() }
                    .testTag("tasbih_main_counter_btn"),
                shape = CircleShape,
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                listOf(EmeraldSecondary, EmeraldPrimary, DeepTeal)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Text(
                            text = selectedDhikr,
                            color = GoldLight,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "$currentCount",
                            color = Color.White,
                            style = MaterialTheme.typography.displayLarge.copy(fontSize = 64.sp),
                            fontWeight = FontWeight.ExtraBold
                        )

                        if (targetCount > 0) {
                            Text(
                                text = "من $targetCount • الدورة: $completedRounds",
                                color = EmeraldContainer.copy(alpha = 0.85f),
                                style = MaterialTheme.typography.bodySmall
                            )
                        } else {
                            Text(
                                text = "تسبيح مفتوح • اضغط للزيادة",
                                color = EmeraldContainer.copy(alpha = 0.85f),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onReset,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reset")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تصفير العداد", fontWeight = FontWeight.Bold)
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.DoneAll, contentDescription = null, tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "الدورات المكتملة: $completedRounds",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(80.dp))
        }
    }
}

@Composable
fun AdhkarReaderView(
    selectedCategory: AdhkarCategory,
    adhkarProgress: Map<Int, Int>,
    onSelectCategory: (AdhkarCategory) -> Unit,
    onIncrementItem: (Int, Int) -> Unit,
    onResetAll: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp)
    ) {
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp)
            ) {
                items(AdhkarRepositoryData.categories) { cat ->
                    val isSelected = cat.id == selectedCategory.id
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectCategory(cat) },
                        label = { Text(cat.titleAr, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = EmeraldPrimary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }
        }

        items(selectedCategory.items) { dhikrItem ->
            val progress = adhkarProgress[dhikrItem.id] ?: 0
            val isCompleted = progress >= dhikrItem.targetCount

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .clickable { onIncrementItem(dhikrItem.id, dhikrItem.targetCount) },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCompleted) EmeraldContainer.copy(alpha = 0.6f) else MaterialTheme.colorScheme.surface
                ),
                border = if (isCompleted) androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary) else null,
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = dhikrItem.arabicText,
                        style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp, lineHeight = 28.sp),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "فضل الذكر: ${dhikrItem.virtue}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = GoldContainer
                        ) {
                            Text(
                                text = dhikrItem.source,
                                style = MaterialTheme.typography.labelSmall,
                                color = OnGoldContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = if (isCompleted) EmeraldPrimary else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (isCompleted) Color.White else MaterialTheme.colorScheme.onSurface
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isCompleted) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                                Text(
                                    text = "$progress / ${dhikrItem.targetCount}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 80.dp),
                contentAlignment = Alignment.Center
            ) {
                OutlinedButton(
                    onClick = onResetAll,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إعادة ضبط تقدم الأذكار")
                }
            }
        }
    }
}
