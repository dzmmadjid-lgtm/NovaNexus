package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.entity.JournalEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.TasbihHistoryEntity
import com.example.data.model.*
import com.example.data.repository.MadjidRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

enum class AppTab(val titleAr: String, val iconName: String) {
    HOME("الرئيسية", "home"),
    PRAYERS("المواقيت", "access_time"),
    TASBIH("التسبيح والأذكار", "fingerprint"),
    TASKS("المهام", "check_circle"),
    JOURNAL("اليوميات", "edit_note"),
    CONSTANTINE("قسنطينة", "location_city")
}

class MadjidViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MadjidRepository

    init {
        val db = AppDatabase.getDatabase(application)
        repository = MadjidRepository(db)

        // Seed initial sample data if tasks are empty
        viewModelScope.launch {
            repository.allTasks.firstOrNull()?.let { list ->
                if (list.isEmpty()) {
                    repository.addTask(
                        TaskEntity(
                            title = "صلاة الفجر في وقتها",
                            description = "في مسجد الأمير عبد القادر أو بالبيت",
                            category = "العبادة",
                            priority = "عالية",
                            dueDate = "اليوم",
                            isCompleted = false
                        )
                    )
                    repository.addTask(
                        TaskEntity(
                            title = "أذكار الصباح والمساء",
                            description = "قراءة الورد اليومي والتحصينات",
                            category = "العبادة",
                            priority = "عالية",
                            dueDate = "اليوم",
                            isCompleted = true
                        )
                    )
                    repository.addTask(
                        TaskEntity(
                            title = "مراجعة خطة العمل الأسبوعية",
                            description = "تنظيم أولويات الأسبوع وإنجاز المهام الملحة",
                            category = "العمل",
                            priority = "متوسطة",
                            dueDate = "اليوم",
                            isCompleted = false
                        )
                    )
                    repository.addTask(
                        TaskEntity(
                            title = "مشي مسائي على جسر سيدي مسيد",
                            description = "ممارسة الرياضة والاستمتاع بإطلالة وادي الرمال",
                            category = "الصحة",
                            priority = "عادية",
                            dueDate = "اليوم",
                            isCompleted = false
                        )
                    )
                }
            }

            repository.allJournalEntries.firstOrNull()?.let { list ->
                if (list.isEmpty()) {
                    val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
                    repository.addJournalEntry(
                        JournalEntity(
                            title = "بداية يوم مبارك في قسنطينة",
                            content = "الحمد لله على نعمة العافية والسكينة. نسائم الصباح في مدينة الصخر العتيق تملأ النفس طمأنينة وعزيمة لتحقيق الأهداف اليومية.",
                            mood = "ممتن",
                            tags = "قسنطينة, طمأنينة, شكر",
                            isPinned = true,
                            dateString = sdf.format(Date())
                        )
                    )
                }
            }
        }

        // Timer loop to update prayer countdown smoothly every 10 seconds
        viewModelScope.launch {
            while (true) {
                _currentTimeMillis.value = System.currentTimeMillis()
                delay(10000)
            }
        }
    }

    // Active Navigation
    private val _currentTab = MutableStateFlow(AppTab.HOME)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    fun setTab(tab: AppTab) {
        _currentTab.value = tab
    }

    // Selected Wilaya (Default: Constantine Wilaya 25)
    private val _selectedWilaya = MutableStateFlow(ALGERIAN_WILAYAS[0]) // Constantine
    val selectedWilaya: StateFlow<Wilaya> = _selectedWilaya.asStateFlow()

    fun selectWilaya(wilaya: Wilaya) {
        _selectedWilaya.value = wilaya
    }

    private val _currentTimeMillis = MutableStateFlow(System.currentTimeMillis())

    // Prayer Times derived state
    val prayerTimes: StateFlow<DailyPrayerTimes> = combine(_selectedWilaya, _currentTimeMillis) { wilaya, _ ->
        PrayerCalculator.calculateTimes(wilaya, Calendar.getInstance())
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        PrayerCalculator.calculateTimes(ALGERIAN_WILAYAS[0])
    )

    // Tasks State
    val allTasks: StateFlow<List<TaskEntity>> = repository.allTasks.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    private val _taskFilter = MutableStateFlow("الكل") // "الكل", "اليوم", "قيد الإنجاز", "المكتملة"
    val taskFilter: StateFlow<String> = _taskFilter.asStateFlow()

    fun setTaskFilter(filter: String) {
        _taskFilter.value = filter
    }

    val filteredTasks: StateFlow<List<TaskEntity>> = combine(allTasks, taskFilter) { tasks, filter ->
        when (filter) {
            "اليوم" -> tasks.filter { it.dueDate.contains("اليوم") || !it.isCompleted }
            "قيد الإنجاز" -> tasks.filter { !it.isCompleted }
            "المكتملة" -> tasks.filter { it.isCompleted }
            else -> tasks
        }
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    fun addTask(title: String, description: String, category: String, priority: String, dueDate: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.addTask(
                TaskEntity(
                    title = title.trim(),
                    description = description.trim(),
                    category = category,
                    priority = priority,
                    dueDate = if (dueDate.isBlank()) "اليوم" else dueDate,
                    isCompleted = false
                )
            )
        }
    }

    fun toggleTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.toggleTask(task.id, !task.isCompleted)
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    // Journal State
    val allJournalEntries: StateFlow<List<JournalEntity>> = repository.allJournalEntries.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    private val _journalSearchQuery = MutableStateFlow("")
    val journalSearchQuery: StateFlow<String> = _journalSearchQuery.asStateFlow()

    fun setJournalSearchQuery(query: String) {
        _journalSearchQuery.value = query
    }

    val filteredJournal: StateFlow<List<JournalEntity>> = combine(allJournalEntries, journalSearchQuery) { entries, query ->
        if (query.isBlank()) entries
        else entries.filter {
            it.title.contains(query, ignoreCase = true) ||
            it.content.contains(query, ignoreCase = true) ||
            it.tags.contains(query, ignoreCase = true)
        }
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    fun addJournalEntry(title: String, content: String, mood: String, tags: String) {
        if (title.isBlank() && content.isBlank()) return
        viewModelScope.launch {
            val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
            repository.addJournalEntry(
                JournalEntity(
                    title = title.ifBlank { "تدوينة يومية" },
                    content = content,
                    mood = mood,
                    tags = tags.ifBlank { "قسنطينة" },
                    isPinned = false,
                    dateString = sdf.format(Date())
                )
            )
        }
    }

    fun togglePinJournal(entry: JournalEntity) {
        viewModelScope.launch {
            repository.togglePinEntry(entry.id, !entry.isPinned)
        }
    }

    fun deleteJournalEntry(entry: JournalEntity) {
        viewModelScope.launch {
            repository.deleteJournalEntry(entry)
        }
    }

    // Digital Tasbih State
    val totalLifetimeDhikr: StateFlow<Int> = repository.totalDhikrCount.map { it ?: 0 }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        0
    )

    private val _currentTasbihCount = MutableStateFlow(0)
    val currentTasbihCount: StateFlow<Int> = _currentTasbihCount.asStateFlow()

    private val _currentTasbihTarget = MutableStateFlow(33)
    val currentTasbihTarget: StateFlow<Int> = _currentTasbihTarget.asStateFlow()

    private val _selectedDhikr = MutableStateFlow("سُبْحَانَ اللَّهِ")
    val selectedDhikr: StateFlow<String> = _selectedDhikr.asStateFlow()

    private val _completedRounds = MutableStateFlow(0)
    val completedRounds: StateFlow<Int> = _completedRounds.asStateFlow()

    fun setSelectedDhikr(dhikr: String) {
        _selectedDhikr.value = dhikr
        _currentTasbihCount.value = 0
    }

    fun setTasbihTarget(target: Int) {
        _currentTasbihTarget.value = target
        _currentTasbihCount.value = 0
    }

    fun incrementTasbih() {
        val nextCount = _currentTasbihCount.value + 1
        val target = _currentTasbihTarget.value

        if (target > 0 && nextCount >= target) {
            _currentTasbihCount.value = 0
            _completedRounds.value += 1
            // Save to room
            viewModelScope.launch {
                val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
                repository.addTasbihHistory(
                    TasbihHistoryEntity(
                        dhikrName = _selectedDhikr.value,
                        count = target,
                        dateString = sdf.format(Date())
                    )
                )
            }
        } else {
            _currentTasbihCount.value = nextCount
        }
    }

    fun resetTasbih() {
        if (_currentTasbihCount.value > 0) {
            val count = _currentTasbihCount.value
            viewModelScope.launch {
                val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
                repository.addTasbihHistory(
                    TasbihHistoryEntity(
                        dhikrName = _selectedDhikr.value,
                        count = count,
                        dateString = sdf.format(Date())
                    )
                )
            }
        }
        _currentTasbihCount.value = 0
    }

    // Adhkar Tab state
    private val _selectedAdhkarCategory = MutableStateFlow(AdhkarRepositoryData.categories[0])
    val selectedAdhkarCategory: StateFlow<AdhkarCategory> = _selectedAdhkarCategory.asStateFlow()

    private val _adhkarProgress = MutableStateFlow<Map<Int, Int>>(emptyMap())
    val adhkarProgress: StateFlow<Map<Int, Int>> = _adhkarProgress.asStateFlow()

    fun selectAdhkarCategory(category: AdhkarCategory) {
        _selectedAdhkarCategory.value = category
    }

    fun incrementAdhkarItem(itemId: Int, maxCount: Int) {
        val current = _adhkarProgress.value[itemId] ?: 0
        if (current < maxCount) {
            val updated = _adhkarProgress.value.toMutableMap()
            updated[itemId] = current + 1
            _adhkarProgress.value = updated
        }
    }

    fun resetAdhkarProgress() {
        _adhkarProgress.value = emptyMap()
    }

    // Zakat Calculator State
    private val _goldPriceDzd = MutableStateFlow("14500")
    val goldPriceDzd: StateFlow<String> = _goldPriceDzd.asStateFlow()

    private val _savingsAmountDzd = MutableStateFlow("1200000")
    val savingsAmountDzd: StateFlow<String> = _savingsAmountDzd.asStateFlow()

    fun updateGoldPrice(price: String) {
        _goldPriceDzd.value = price.filter { it.isDigit() || it == '.' }
    }

    fun updateSavingsAmount(amount: String) {
        _savingsAmountDzd.value = amount.filter { it.isDigit() || it == '.' }
    }

    val zakatResult: StateFlow<Pair<Double, Double>> = combine(goldPriceDzd, savingsAmountDzd) { gold, savings ->
        val gPrice = gold.toDoubleOrNull() ?: 14500.0
        val sAmount = savings.toDoubleOrNull() ?: 0.0
        ConstantineDataRepository.calculateZakat(gPrice, sAmount)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        Pair(85.0 * 14500.0, 0.0)
    )
}
