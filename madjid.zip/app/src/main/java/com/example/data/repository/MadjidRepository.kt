package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.JournalEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.TasbihHistoryEntity
import kotlinx.coroutines.flow.Flow

class MadjidRepository(private val db: AppDatabase) {

    // Tasks
    val allTasks: Flow<List<TaskEntity>> = db.taskDao().getAllTasks()
    val pendingTasks: Flow<List<TaskEntity>> = db.taskDao().getPendingTasks()

    suspend fun addTask(task: TaskEntity): Long = db.taskDao().insertTask(task)
    suspend fun updateTask(task: TaskEntity) = db.taskDao().updateTask(task)
    suspend fun deleteTask(task: TaskEntity) = db.taskDao().deleteTask(task)
    suspend fun toggleTask(taskId: Long, isCompleted: Boolean) =
        db.taskDao().updateTaskCompletion(taskId, isCompleted)

    // Journal
    val allJournalEntries: Flow<List<JournalEntity>> = db.journalDao().getAllEntries()

    suspend fun addJournalEntry(entry: JournalEntity): Long = db.journalDao().insertEntry(entry)
    suspend fun updateJournalEntry(entry: JournalEntity) = db.journalDao().updateEntry(entry)
    suspend fun deleteJournalEntry(entry: JournalEntity) = db.journalDao().deleteEntry(entry)
    suspend fun togglePinEntry(entryId: Long, isPinned: Boolean) =
        db.journalDao().updatePinStatus(entryId, isPinned)

    // Tasbih
    val allTasbihHistory: Flow<List<TasbihHistoryEntity>> = db.tasbihDao().getAllHistory()
    val totalDhikrCount: Flow<Int?> = db.tasbihDao().getTotalDhikrCount()

    suspend fun addTasbihHistory(history: TasbihHistoryEntity): Long =
        db.tasbihDao().insertHistory(history)

    suspend fun clearTasbihHistory() = db.tasbihDao().clearHistory()
}
