package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: String, // "العبادة", "العمل", "الدراسة", "شخصي", "الصحة"
    val priority: String, // "عالية", "متوسطة", "عادية"
    val dueDate: String = "", // e.g. "اليوم", "غداً", "2026-09-01"
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
