package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasbih_history")
data class TasbihHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dhikrName: String,
    val count: Int,
    val dateString: String,
    val timestamp: Long = System.currentTimeMillis()
)
