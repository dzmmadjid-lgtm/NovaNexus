package com.example.data.model

data class AdhkarCategory(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val icon: String,
    val items: List<AdhkarItem>
)

data class AdhkarItem(
    val id: Int,
    val arabicText: String,
    val virtue: String,
    val targetCount: Int,
    val source: String = "حصن المسلم"
)

object AdhkarRepositoryData {
    val morningAdhkar = listOf(
        AdhkarItem(
            id = 1,
            arabicText = "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَـهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
            virtue = "من قالها حين يصبح حُفظ حتى يمسي",
            targetCount = 1
        ),
        AdhkarItem(
            id = 2,
            arabicText = "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ",
            virtue = "سيد الاستغفار: من قاله موقناً به فمات من يومه أو ليلته دخل الجنة",
            targetCount = 1
        ),
        AdhkarItem(
            id = 3,
            arabicText = "بِسْمِ اللَّهِ الَّذِي لاَ يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلاَ فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ",
            virtue = "لم يضره شيء في ذلك اليوم أو تلك الليلة",
            targetCount = 3
        ),
        AdhkarItem(
            id = 4,
            arabicText = "رَضِيتُ بِاللَّهِ رَبَّاً، وَبِالإِسْلاَمِ دِيناً، وَبِمُحَمَّدٍ صلى الله عليه وسلم نَبِيَّاً",
            virtue = "كان حقاً على الله أن يرضيه يوم القيامة",
            targetCount = 3
        ),
        AdhkarItem(
            id = 5,
            arabicText = "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ: عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ، وَمِدَادَ كَلِمَاتِهِ",
            virtue = "تعدل ساعات طويلة من الذكر والتسبيح",
            targetCount = 3
        ),
        AdhkarItem(
            id = 6,
            arabicText = "يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ أَصْلِحْ لِي شَأْنِي كُلَّهُ وَلاَ تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ",
            virtue = "دعاء جامع لتيسير الأمور وحفظ النفس",
            targetCount = 1
        ),
        AdhkarItem(
            id = 7,
            arabicText = "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
            virtue = "حُطت خطاياه وإن كانت مثل زبد البحر",
            targetCount = 100
        )
    )

    val eveningAdhkar = listOf(
        AdhkarItem(
            id = 101,
            arabicText = "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَـهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
            virtue = "حفظ ووقاية في المساء والليل",
            targetCount = 1
        ),
        AdhkarItem(
            id = 102,
            arabicText = "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ",
            virtue = "لم يضره شيء في ليلته",
            targetCount = 3
        ),
        AdhkarItem(
            id = 103,
            arabicText = "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ",
            virtue = "تحصين المساء وتجديد الإيمان",
            targetCount = 1
        ),
        AdhkarItem(
            id = 104,
            arabicText = "اللَّهُمَّ عَافِنِي فِي بَدَنِي، اللَّهُمَّ عَافِنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، لاَ إِلَهَ إِلاَّ أَنْتَ",
            virtue = "سؤال العافية والصحة في الجوارح",
            targetCount = 3
        )
    )

    val afterPrayerAdhkar = listOf(
        AdhkarItem(
            id = 201,
            arabicText = "أَسْتَغْفِرُ اللَّهَ (3 مرات)، اللَّهُمَّ أَنْتَ السَّلاَمُ وَمِنْكَ السَّلاَمُ تَبَارَكْتَ يَا ذَا الْجَلاَلِ وَالإِكْرَامِ",
            virtue = "أول ما يقال دبر كل صلاة مكتوبة",
            targetCount = 1
        ),
        AdhkarItem(
            id = 202,
            arabicText = "سُبْحَانَ اللَّهِ",
            virtue = "تسبيح دبر الصلاة",
            targetCount = 33
        ),
        AdhkarItem(
            id = 203,
            arabicText = "الْحَمْدُ لِلَّهِ",
            virtue = "تحميد دبر الصلاة",
            targetCount = 33
        ),
        AdhkarItem(
            id = 204,
            arabicText = "اللَّهُ أَكْبَرُ",
            virtue = "تكبير دبر الصلاة",
            targetCount = 33
        ),
        AdhkarItem(
            id = 205,
            arabicText = "لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
            virtue = "تمام المائة: غفرت خطاياه وإن كانت مثل زبد البحر",
            targetCount = 1
        )
    )

    val categories = listOf(
        AdhkarCategory("morning", "أذكار الصباح", "Morning Adhkar", "wb_sunny", morningAdhkar),
        AdhkarCategory("evening", "أذكار المساء", "Evening Adhkar", "nights_stay", eveningAdhkar),
        AdhkarCategory("after_prayer", "أذكار ما بعد الصلاة", "After Prayer", "mosque", afterPrayerAdhkar)
    )
}
