package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.JournalEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface JournalDao {
    @Query("SELECT * FROM journal_entries ORDER BY isPinned DESC, timestamp DESC")
    fun getAllEntries(): Flow<List<JournalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: JournalEntity): Long

    @Update
    suspend fun updateEntry(entry: JournalEntity)

    @Delete
    suspend fun deleteEntry(entry: JournalEntity)

    @Query("UPDATE journal_entries SET isPinned = :isPinned WHERE id = :entryId")
    suspend fun updatePinStatus(entryId: Long, isPinned: Boolean)
}
