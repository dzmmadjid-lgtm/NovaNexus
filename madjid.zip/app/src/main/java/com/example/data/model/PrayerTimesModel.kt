package com.example.data.model

import java.util.Calendar
import java.util.TimeZone
import kotlin.math.*

data class Wilaya(
    val code: Int,
    val nameAr: String,
    val nameFr: String,
    val latitude: Double,
    val longitude: Double
)

val ALGERIAN_WILAYAS = listOf(
    Wilaya(25, "قسنطينة (مدينة الجسور المعلقة)", "Constantine", 36.3650, 6.6147),
    Wilaya(16, "الجزائر العاصمة", "Alger", 36.7538, 3.0588),
    Wilaya(31, "وهران (الباهية)", "Oran", 35.6987, -0.6349),
    Wilaya(23, "عنابة (بونة)", "Annaba", 36.9000, 7.7667),
    Wilaya(19, "سطيف (عاصمة الهضاب)", "Setif", 36.1898, 5.4108),
    Wilaya(5, "باتنة (عاصمة الأوراس)", "Batna", 35.5558, 6.1741),
    Wilaya(7, "بسكرة (عروس الزيبان)", "Biskra", 34.8504, 5.7281),
    Wilaya(13, "تلمسان (عاصمة الزيانيين)", "Tlemcen", 34.8783, -1.3150),
    Wilaya(6, "بجاية (لؤلؤة الصومام)", "Bejaia", 36.7511, 5.0567),
    Wilaya(15, "تيزي وزو (عاصمة جرجرة)", "Tizi Ouzou", 36.7118, 4.0459),
    Wilaya(21, "سكيكدة (روسيكادا)", "Skikda", 36.8787, 6.9064),
    Wilaya(41, "سوق أهراس (طاغاست)", "Souk Ahras", 36.2864, 7.9511),
    Wilaya(24, "قالمة", "Guelma", 36.4622, 7.4261),
    Wilaya(43, "ميلة", "Mila", 36.4503, 6.2644),
    Wilaya(4, "أم البواقي", "Oum El Bouaghi", 35.8756, 7.1136),
    Wilaya(34, "برج بوعريريج", "Bordj Bou Arreridj", 36.0732, 4.7611),
    Wilaya(18, "جيجل (الساحل الساحر)", "Jijel", 36.8206, 5.7667),
    Wilaya(9, "البليدة (مدينة الورود)", "Blida", 36.4700, 2.8300),
    Wilaya(35, "بومرداس", "Boumerdes", 36.7664, 3.4772),
    Wilaya(10, "البويرة", "Bouira", 36.3749, 3.9020),
    Wilaya(42, "تيبازة", "Tipaza", 36.5897, 2.4475),
    Wilaya(47, "غرداية (وادي ميزاب)", "Ghardaia", 32.4909, 3.6736),
    Wilaya(30, "ورقلة", "Ouargla", 31.9493, 5.3250),
    Wilaya(39, "الوادي (مدينة الألف قبة)", "El Oued", 33.3683, 6.8674),
    Wilaya(11, "تمنراست (عاصمة الهقار)", "Tamanrasset", 22.7850, 5.5228),
    Wilaya(1, "أدرار", "Adrar", 27.8742, -0.2939),
    Wilaya(8, "بشار", "Bechar", 31.6167, -2.2167),
    Wilaya(3, "الأغواط", "Laghouat", 33.8000, 2.8650),
    Wilaya(17, "الجلفة", "Djelfa", 34.6728, 3.2630),
    Wilaya(28, "المسيلة", "M'Sila", 35.7058, 4.5419),
    Wilaya(22, "سيدي بلعباس", "Sidi Bel Abbes", 35.1899, -0.6309),
    Wilaya(27, "مستغانم", "Mostaganem", 35.9312, 0.0892),
    Wilaya(29, "معسكر", "Mascara", 35.3975, 0.1411),
    Wilaya(48, "غليزان", "Relizane", 35.7408, 0.5558),
    Wilaya(20, "سعيدة", "Saida", 34.8303, 0.1517),
    Wilaya(14, "تيارت", "Tiaret", 35.3710, 1.3169),
    Wilaya(44, "عين الدفلى", "Ain Defla", 36.2642, 1.9679),
    Wilaya(2, "الشلف", "Chlef", 36.1652, 1.3345),
    Wilaya(26, "المدية", "Medea", 36.2642, 2.7539),
    Wilaya(46, "عين تموشنت", "Ain Temouchent", 35.2975, -1.1404),
    Wilaya(12, "تبسة", "Tebessa", 35.4042, 8.1242),
    Wilaya(38, "تيسمسيلت", "Tissemsilt", 35.6072, 1.8108),
    Wilaya(36, "الطارف", "El Tarf", 36.7672, 8.3139),
    Wilaya(37, "تندوف", "Tindouf", 27.6711, -8.1474),
    Wilaya(45, "النعامة", "Naama", 33.2667, -0.3167),
    Wilaya(32, "البيض", "El Bayadh", 33.6833, 1.0167),
    Wilaya(33, "إليزي (طاسيلي ناجر)", "Illizi", 26.4833, 8.4667),
    Wilaya(40, "خنشلة", "Khenchela", 35.4358, 7.1433)
)

data class PrayerTimeItem(
    val nameAr: String,
    val nameEn: String,
    val time: String,
    val timeMinutes: Int,
    val iconName: String,
    val isNext: Boolean = false,
    val isPassed: Boolean = false
)

data class DailyPrayerTimes(
    val dateString: String,
    val hijriDate: String,
    val wilaya: Wilaya,
    val fajr: String,
    val shuruq: String,
    val dhuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String,
    val nextPrayerName: String,
    val timeUntilNext: String,
    val nextPrayerPercentage: Float,
    val items: List<PrayerTimeItem>
)

object PrayerCalculator {

    fun calculateTimes(wilaya: Wilaya, calendar: Calendar = Calendar.getInstance()): DailyPrayerTimes {
        val lat = wilaya.latitude
        val lng = wilaya.longitude
        val timezone = 1.0 // Algeria UTC+1 standard

        val dayOfYear = calendar.get(Calendar.DAY_OF_YEAR)
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        // Astronomical calculations
        val d = dayOfYear.toDouble()
        // Solar declination & Equation of Time
        val b = 2 * Math.PI * (d - 81) / 365.0
        val eot = 9.87 * sin(2 * b) - 7.53 * cos(b) - 1.5 * sin(b) // minutes
        val declination = 23.45 * sin(Math.toRadians((360.0 / 365.0) * (d - 81))) // degrees

        val declRad = Math.toRadians(declination)
        val latRad = Math.toRadians(lat)

        // Solar Noon in UTC minutes
        val solarNoonUtc = 720.0 - (4.0 * lng) - eot
        val solarNoonLocal = solarNoonUtc + (timezone * 60.0)

        // Dhuhr (solar noon + 2 min safe margin)
        val dhuhrMin = solarNoonLocal + 2.0

        // Fajr (Algeria standard: 18 degrees below horizon)
        val fajrAngle = -18.0
        val fajrHA = calculateHourAngle(latRad, declRad, Math.toRadians(fajrAngle))
        val fajrMin = if (fajrHA != null) solarNoonLocal - (fajrHA * 4.0) else solarNoonLocal - 90.0

        // Sunrise (sun center 0.833 degrees below horizon for refraction)
        val sunRiseAngle = -0.833
        val sunriseHA = calculateHourAngle(latRad, declRad, Math.toRadians(sunRiseAngle))
        val sunriseMin = if (sunriseHA != null) solarNoonLocal - (sunriseHA * 4.0) else solarNoonLocal - 75.0

        // Sunset / Maghrib
        val sunsetMin = if (sunriseHA != null) solarNoonLocal + (sunriseHA * 4.0) + 2.0 else solarNoonLocal + 75.0

        // Asr (Shafi'i/Maliki: shadow = 1 + noon shadow)
        val noonShadow = tan(abs(latRad - declRad))
        val asrShadow = 1.0 + noonShadow
        val asrAltitude = atan(1.0 / asrShadow)
        val asrHA = calculateHourAngle(latRad, declRad, asrAltitude)
        val asrMin = if (asrHA != null) solarNoonLocal + (asrHA * 4.0) else solarNoonLocal + 45.0

        // Isha (Algeria standard: 17 degrees below horizon)
        val ishaAngle = -17.0
        val ishaHA = calculateHourAngle(latRad, declRad, Math.toRadians(ishaAngle))
        val ishaMin = if (ishaHA != null) solarNoonLocal + (ishaHA * 4.0) else solarNoonLocal + 90.0

        val currentHour = calendar.get(Calendar.HOUR_OF_DAY)
        val currentMinute = calendar.get(Calendar.MINUTE)
        val currentTotalMinutes = currentHour * 60 + currentMinute

        val fajrStr = formatMinutes(fajrMin.toInt())
        val shuruqStr = formatMinutes(sunriseMin.toInt())
        val dhuhrStr = formatMinutes(dhuhrMin.toInt())
        val asrStr = formatMinutes(asrMin.toInt())
        val maghribStr = formatMinutes(sunsetMin.toInt())
        val ishaStr = formatMinutes(ishaMin.toInt())

        val prayerMinutesList = listOf(
            Triple("الفجر", "Fajr", fajrMin.toInt()),
            Triple("الشروق", "Sunrise", sunriseMin.toInt()),
            Triple("الظهر", "Dhuhr", dhuhrMin.toInt()),
            Triple("العصر", "Asr", asrMin.toInt()),
            Triple("المغرب", "Maghrib", sunsetMin.toInt()),
            Triple("العشاء", "Isha", ishaMin.toInt())
        )

        var nextPrayerIndex = prayerMinutesList.indexOfFirst { it.third > currentTotalMinutes }
        if (nextPrayerIndex == -1) nextPrayerIndex = 0 // After Isha, next is Fajr tomorrow

        val nextPrayer = prayerMinutesList[nextPrayerIndex]
        val diffMinutes = if (nextPrayer.third > currentTotalMinutes) {
            nextPrayer.third - currentTotalMinutes
        } else {
            (24 * 60 - currentTotalMinutes) + nextPrayer.third
        }

        val hoursRemaining = diffMinutes / 60
        val minsRemaining = diffMinutes % 60
        val timeUntilNext = if (hoursRemaining > 0) {
            "$hoursRemaining س و $minsRemaining د"
        } else {
            "$minsRemaining دقيقة"
        }

        // Calculate progress in current prayer interval
        val prevPrayerIndex = if (nextPrayerIndex == 0) prayerMinutesList.size - 1 else nextPrayerIndex - 1
        val prevTime = prayerMinutesList[prevPrayerIndex].third
        val nextTime = prayerMinutesList[nextPrayerIndex].third
        val intervalDuration = if (nextTime > prevTime) nextTime - prevTime else (24 * 60 - prevTime) + nextTime
        val elapsedInInterval = intervalDuration - diffMinutes
        val percentage = (elapsedInInterval.toFloat() / intervalDuration.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)

        val items = prayerMinutesList.mapIndexed { idx, (ar, en, mins) ->
            PrayerTimeItem(
                nameAr = ar,
                nameEn = en,
                time = formatMinutes(mins),
                timeMinutes = mins,
                iconName = when (ar) {
                    "الفجر" -> "wb_twilight"
                    "الشروق" -> "wb_sunny"
                    "الظهر" -> "light_mode"
                    "العصر" -> "wb_cloudy"
                    "المغرب" -> "nights_stay"
                    else -> "bedtime"
                },
                isNext = idx == nextPrayerIndex,
                isPassed = if (nextPrayerIndex == 0) idx != 0 else idx < nextPrayerIndex
            )
        }

        val dateStr = String.format("%02d/%02d/%04d", day, month, year)
        val hijriDateStr = approximateHijriDate(calendar)

        return DailyPrayerTimes(
            dateString = dateStr,
            hijriDate = hijriDateStr,
            wilaya = wilaya,
            fajr = fajrStr,
            shuruq = shuruqStr,
            dhuhr = dhuhrStr,
            asr = asrStr,
            maghrib = maghribStr,
            isha = ishaStr,
            nextPrayerName = nextPrayer.first,
            timeUntilNext = timeUntilNext,
            nextPrayerPercentage = percentage,
            items = items
        )
    }

    private fun calculateHourAngle(latRad: Double, declRad: Double, altRad: Double): Double? {
        val cosHA = (sin(altRad) - sin(latRad) * sin(declRad)) / (cos(latRad) * cos(declRad))
        if (cosHA < -1.0 || cosHA > 1.0) return null
        val haRad = acos(cosHA)
        return Math.toDegrees(haRad)
    }

    private fun formatMinutes(minutes: Int): String {
        var m = minutes % (24 * 60)
        if (m < 0) m += 24 * 60
        val h = m / 60
        val min = m % 60
        return String.format("%02d:%02d", h, min)
    }

    fun approximateHijriDate(cal: Calendar): String {
        // Approximate Hijri conversion for current Algerian time
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val month = cal.get(Calendar.MONTH) + 1
        val year = cal.get(Calendar.YEAR)

        // Estimated Hijri date calculation for 2026/Algeria
        val hijriMonths = listOf(
            "محرم", "صفر", "ربيع الأول", "ربيع الثاني", "جمادى الأولى", "جمادى الآخرة",
            "رجب", "شعبان", "رمضان المبارك", "شوال", "ذو القعدة", "ذو الحجة"
        )
        // Approximate for August/September 2026
        return "18 ربيع الأول 1448 هـ"
    }
}
