package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "journal_entries")
data class JournalEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val mood: String = "ممتن", // "ممتن", "سعيد", "هادئ", "طموح", "متأمل"
    val tags: String = "قسنطينة",
    val isPinned: Boolean = false,
    val dateString: String,
    val timestamp: Long = System.currentTimeMillis()
)
