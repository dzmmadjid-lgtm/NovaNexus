package com.example.data.model

data class ConstantineLandmark(
    val id: String,
    val titleAr: String,
    val titleFr: String,
    val descriptionAr: String,
    val yearBuilt: String,
    val category: String,
    val funFactAr: String
)

data class AlgerianIslamicHoliday(
    val nameAr: String,
    val dateDesc: String,
    val daysRemaining: Int,
    val category: String // "ديني", "وطني"
)

object ConstantineDataRepository {

    val bridgesAndLandmarks = listOf(
        ConstantineLandmark(
            id = "sidi_mcid",
            titleAr = "جسر سيدي مسيد المعلق",
            titleFr = "Pont Sidi M'Cid",
            descriptionAr = "أشهر وأعلى جسور قسنطينة وأيقونة المدينة. يرتفع 175 متراً فوق وادي الرمال العظيم، بطول 164 متراً، ويربط قصبة قسنطينة بمستشفى ابن باديس وجبل سيدي مسيد.",
            yearBuilt = "1912 م",
            category = "جسر معلق",
            funFactAr = "كان أعلى جسر معلق في العالم عند تدشينه عام 1912!"
        ),
        ConstantineLandmark(
            id = "salah_bey",
            titleAr = "جسر صالح باي (الاستقلال)",
            titleFr = "Pont Salah Bey (Trans-Rhumel)",
            descriptionAr = "تحفة هندسية حديثة كبرى بطول 1119 متراً، شُيد ليربط الهضاب الجنوبية بمركز المدينة عبر وادي الرمال بتصميم كابلي عصري بديع.",
            yearBuilt = "2014 م",
            category = "جسر معلق كابلي",
            funFactAr = "أكبر منشأة جسرية مشدودة بالكوابل في شمال إفريقيا."
        ),
        ConstantineLandmark(
            id = "sidi_rached",
            titleAr = "جسر سيدي راشد العملاق",
            titleFr = "Pont Sidi Rached",
            descriptionAr = "جسر حجري مهيب يضم 27 قوساً بارتفاع 105 أمتار وطول 447 متراً، يربط محطة القطار بوسط المدينة.",
            yearBuilt = "1912 م",
            category = "جسر قوسي حجري",
            funFactAr = "أطول جسر حجري في العالم وقت اكتمال بنائه."
        ),
        ConstantineLandmark(
            id = "emir_abdelkader",
            titleAr = "جامع الأمير عبد القادر وجامعته",
            titleFr = "Grande Mosquée Émir Abdelkader",
            descriptionAr = "أكبر وأفخم صرح إسلامي وعلمي في قسنطينة وثاني أكبر مسجد في الجزائر، يتسع لأكثر من 15,000 مصلٍ، ويتميز بمئذنتين شامختين بارتفاع 107 أمتار وزخارف أندلسية راقية.",
            yearBuilt = "1994 م",
            category = "صرح ديني وعلمي",
            funFactAr = "يضم أول جامعة إسلامية جزائرية حديثة."
        ),
        ConstantineLandmark(
            id = "ahmed_bey",
            titleAr = "قصر الحاج أحمد باي",
            titleFr = "Palais d'Ahmed Bey",
            descriptionAr = "جوهرة العمارة العثمانية والمغاربية في قلب قسنطينة القديمة، يتزين بأفنية داخلية وحدائق غرناطية ونقوش جدارية تحكي رحلات الحج والحروب التاريخية.",
            yearBuilt = "1835 م",
            category = "قصر تاريخي",
            funFactAr = "يضم 121 غرفة و500 باب ونافذة خشبية منحوتة يدوياً."
        ),
        ConstantineLandmark(
            id = "monument_morts",
            titleAr = "نصب الأموات بسيدي مسيد",
            titleFr = "Monument aux Morts",
            descriptionAr = "يشرف من قمة صخرة سيدي مسيد على ارتفاع 695 متراً، ويوفر إطلالة بانورامية ساحرة تمتد على كامل قسنطينة وسهول الحامة وهضاب الأوراس.",
            yearBuilt = "1930 م",
            category = "إطلالة بانورامية",
            funFactAr = "يعتلي قمة تمثال نصر برونزي مجنح تطل على وادي الرمال."
        )
    )

    val algerianUpcomingEvents = listOf(
        AlgerianIslamicHoliday("المولد النبوي الشريف", "12 ربيع الأول", 4, "ديني"),
        AlgerianIslamicHoliday("ذكرى اندلاع ثورة التحرير المجيدة", "1 نوفمبر", 62, "وطني"),
        AlgerianIslamicHoliday("شهر رمضان المبارك", "1 رمضان 1448", 160, "ديني"),
        AlgerianIslamicHoliday("عيد الفطر المبارك", "1 شوال 1448", 190, "ديني"),
        AlgerianIslamicHoliday("عيد الأضحى المبارك", "10 ذو الحجة 1448", 260, "ديني"),
        AlgerianIslamicHoliday("عيد الاستقلال والشباب", "5 جويلية", 308, "وطني")
    )

    val dailyConstantineWisdom = listOf(
        "«العلم يبني بيوتاً لا عماد لها، والجهل يهدم بيت العز والشرف» — الإمام عبد الحميد بن باديس (ابن قسنطينة البار)",
        "«إنما الأمة الجزائرية المسلمة ليست فرنسا، ولا تستطيع أن تكون فرنسا» — جمعية العلماء المسلمين الجزائريين",
        "«استعن بالله ولا تعجز، واجعل يومك خطوة واثقة نحو هدفك وطاعتك»",
        "«قسنطينة.. عش الغراب فوق صخرة عتية تعانق السحاب وجسور تروي أمجاد قرون مضت»",
        "«اللهم اجعل هذا البلد آمناً مطمئناً وسائر بلاد المسلمين»"
    )

    fun calculateZakat(goldGramPriceDzd: Double = 14500.0, totalSavingsDzd: Double): Pair<Double, Double> {
        val nisab = 85.0 * goldGramPriceDzd // 85g gold
        val zakatAmount = if (totalSavingsDzd >= nisab) totalSavingsDzd * 0.025 else 0.0
        return Pair(nisab, zakatAmount)
    }
}
