package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.TasbihHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TasbihDao {
    @Query("SELECT * FROM tasbih_history ORDER BY timestamp DESC")
    fun getAllHistory(): Flow<List<TasbihHistoryEntity>>

    @Query("SELECT SUM(count) FROM tasbih_history")
    fun getTotalDhikrCount(): Flow<Int?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: TasbihHistoryEntity): Long

    @Query("DELETE FROM tasbih_history")
    suspend fun clearHistory()
}
