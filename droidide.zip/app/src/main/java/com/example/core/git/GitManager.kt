package com.example.core.git

import com.example.core.fs.ZipUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.concurrent.TimeUnit

data class GitCommit(
    val id: String,
    val message: String,
    val author: String,
    val timestamp: Long
)

data class GitStatus(
    val isGitRepo: Boolean,
    val currentBranch: String = "main",
    val modifiedFiles: List<String> = emptyList(),
    val untrackedFiles: List<String> = emptyList(),
    val recentCommits: List<GitCommit> = emptyList()
)

class GitManager {
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun isGitRepo(projectDir: File): Boolean {
        return File(projectDir, ".git").isDirectory
    }

    fun initRepo(projectDir: File, initialBranch: String = "main"): Boolean {
        try {
            val gitDir = File(projectDir, ".git")
            if (gitDir.exists()) return true
            gitDir.mkdirs()
            File(gitDir, "objects").mkdirs()
            File(gitDir, "refs/heads").mkdirs()
            File(gitDir, "logs").mkdirs()
            File(gitDir, "HEAD").writeText("ref: refs/heads/$initialBranch\n")
            File(gitDir, "config").writeText("""
                [core]
                    repositoryformatversion = 0
                    filemode = true
                    bare = false
                    logallrefupdates = true
            """.trimIndent())
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    fun getStatus(projectDir: File): GitStatus {
        if (!isGitRepo(projectDir)) {
            return GitStatus(isGitRepo = false)
        }
        val gitDir = File(projectDir, ".git")
        val headFile = File(gitDir, "HEAD")
        var currentBranch = "main"
        if (headFile.exists()) {
            val headContent = headFile.readText().trim()
            if (headContent.startsWith("ref: refs/heads/")) {
                currentBranch = headContent.removePrefix("ref: refs/heads/")
            }
        }
        val commits = getCommitHistory(projectDir)
        val files = projectDir.walkTopDown()
            .filter { it.isFile && !it.startsWith(gitDir) && !it.path.contains("/build/") && !it.path.contains("/.gradle/") }
            .map { it.relativeTo(projectDir).path }
            .take(20)
            .toList()

        return GitStatus(
            isGitRepo = true,
            currentBranch = currentBranch,
            modifiedFiles = files,
            untrackedFiles = emptyList(),
            recentCommits = commits
        )
    }

    fun commit(projectDir: File, message: String, author: String = "Developer"): Boolean {
        if (!isGitRepo(projectDir)) return false
        try {
            val gitDir = File(projectDir, ".git")
            val commitId = java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 7)
            val timestamp = System.currentTimeMillis()
            val logFile = File(gitDir, "logs/HEAD")
            logFile.parentFile?.mkdirs()
            val logLine = "$commitId $author <developer@example.com> $timestamp $message\n"
            logFile.appendText(logLine)
            return true
        } catch (e: Exception) {
            e.printStackTrace()
            return false
        }
    }

    fun getCommitHistory(projectDir: File): List<GitCommit> {
        val gitDir = File(projectDir, ".git")
        val logFile = File(gitDir, "logs/HEAD")
        if (!logFile.exists()) return emptyList()
        val list = mutableListOf<GitCommit>()
        try {
            logFile.readLines().forEach { line ->
                val parts = line.split(" ", limit = 5)
                if (parts.size >= 5) {
                    val id = parts[0]
                    val author = parts[1]
                    val time = parts[3].toLongOrNull() ?: System.currentTimeMillis()
                    val msg = parts[4]
                    list.add(0, GitCommit(id, msg, author, time))
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return list
    }

    suspend fun cloneGitHubRepo(
        repoUrl: String,
        targetDir: File,
        onProgress: (String) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            onProgress("Analyzing repository: $repoUrl")
            var cleanedUrl = repoUrl.trim().removeSuffix(".git")
            val match = Regex("github\\.com/([^/]+)/([^/]+)").find(cleanedUrl)
            if (match == null) {
                onProgress("Invalid GitHub repository URL. Expected https://github.com/owner/repo")
                return@withContext false
            }
            val owner = match.groupValues[1]
            val repo = match.groupValues[2]
            val zipUrl = "https://github.com/$owner/$repo/archive/refs/heads/main.zip"
            val fallbackZipUrl = "https://github.com/$owner/$repo/archive/refs/heads/master.zip"

            onProgress("Downloading archive from GitHub ($owner/$repo)...")
            var request = Request.Builder().url(zipUrl).build()
            var response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                onProgress("Main branch not found. Checking master branch...")
                response.close()
                request = Request.Builder().url(fallbackZipUrl).build()
                response = httpClient.newCall(request).execute()
            }
            if (!response.isSuccessful) {
                onProgress("Failed to download repository. HTTP ${response.code}")
                response.close()
                return@withContext false
            }
            val body = response.body
            if (body == null) {
                onProgress("Empty response from server.")
                return@withContext false
            }
            onProgress("Extracting project files into: ${targetDir.name}...")
            val inputStream = body.byteStream()
            ZipUtils.importProjectFromZip(inputStream, targetDir)
            response.close()

            initRepo(targetDir, "main")
            commit(targetDir, "Initial clone from $repoUrl", "GitHub")
            onProgress("Repository cloned successfully!")
            return@withContext true
        } catch (e: Exception) {
            onProgress("Clone error: ${e.localizedMessage}")
            return@withContext false
        }
    }
}
