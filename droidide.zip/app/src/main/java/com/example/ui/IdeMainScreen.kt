package com.example.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.ui.components.*
import java.io.File

@Composable
fun IdeMainScreen(viewModel: IdeViewModel) {
    val context = LocalContext.current

    val currentProject by viewModel.currentProject.collectAsState()
    val projectList by viewModel.projectList.collectAsState()
    val fileTreeRoot by viewModel.fileTreeRoot.collectAsState()
    val editorTabs by viewModel.editorTabs.collectAsState()
    val activeTabIndex by viewModel.activeTabIndex.collectAsState()
    val activeTab = viewModel.activeTab

    val buildStatus by viewModel.buildStatus.collectAsState()
    val buildLogs by viewModel.buildLogs.collectAsState()
    val buildResult by viewModel.buildResult.collectAsState()
    val problems by viewModel.problems.collectAsState()

    val activeToolWindow by viewModel.activeToolWindow.collectAsState()
    val isToolWindowExpanded by viewModel.isToolWindowExpanded.collectAsState()
    val isSidebarVisible by viewModel.isSidebarVisible.collectAsState()
    val themeMode by viewModel.themeMode.collectAsState()

    val targetEditorLine by viewModel.targetEditorLine.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()

    val terminalLines by viewModel.terminalEngine.output.collectAsState()
    val isTerminalRunning by viewModel.terminalEngine.isRunning.collectAsState()

    val gitStatus by viewModel.gitStatus.collectAsState()
    val aiMessages by viewModel.aiMessages.collectAsState()
    val isAiBusy by viewModel.isAiBusy.collectAsState()

    val jdkLocation by viewModel.jdkLocation.collectAsState()
    val javaVersionInfo by viewModel.javaVersionInfo.collectAsState()

    // Dialogs state
    var showNewProjectDialog by remember { mutableStateOf(false) }
    var showOpenProjectDialog by remember { mutableStateOf(false) }
    var showGlobalSearchDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showDeleteProjectTreeConfirm by remember { mutableStateOf(false) }

    var itemToCreateInDir by remember { mutableStateOf<Pair<File, Boolean>?>(null) } // File to parent, Boolean isFolder
    var fileToDelete by remember { mutableStateOf<File?>(null) }
    var fileToRename by remember { mutableStateOf<File?>(null) }

    // File Pickers for Export & Import ZIP
    val importZipLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                if (inputStream != null) {
                    val defaultName = "Imported_${System.currentTimeMillis() % 10000}"
                    viewModel.importProjectFromZip(inputStream, defaultName)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    val exportZipLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        if (uri != null && currentProject != null) {
            try {
                val tempZip = File(context.cacheDir, "${currentProject!!.name}.zip")
                viewModel.exportProjectToZip(tempZip)
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    tempZip.inputStream().use { input -> input.copyTo(output) }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    Scaffold(
        topBar = {
            IdeTopBar(
                currentProject = currentProject,
                buildStatus = buildStatus,
                themeMode = themeMode,
                onToggleSidebar = { viewModel.toggleSidebar() },
                onRunBuild = { viewModel.runBuild() },
                onStopBuild = { viewModel.stopBuild() },
                onNewProject = { showNewProjectDialog = true },
                onOpenProject = { showOpenProjectDialog = true },
                onExportProject = { exportZipLauncher.launch("${currentProject?.name ?: "project"}.zip") },
                onImportProject = { importZipLauncher.launch("application/zip") },
                onGlobalSearch = { showGlobalSearchDialog = true },
                onToggleTheme = { viewModel.toggleTheme() },
                onOpenSettings = { showSettingsDialog = true }
            )
        },
        bottomBar = {
            BottomToolWindows(
                activeWindow = activeToolWindow,
                isExpanded = isToolWindowExpanded,
                onTabSelected = { viewModel.setActiveToolWindow(it) },
                onToggleExpanded = { viewModel.toggleToolWindowExpanded() },
                buildResult = buildResult,
                buildLogs = buildLogs,
                buildStatus = buildStatus,
                onClearLogs = { viewModel.clearBuildLogs() },
                problems = problems,
                onJumpToProblem = { file, line -> viewModel.jumpToProblem(file, line) },
                terminalLines = terminalLines,
                isTerminalRunning = isTerminalRunning,
                onExecuteCommand = { cmd ->
                    val dir = currentProject?.rootDir ?: context.filesDir
                    viewModel.terminalEngine.executeCommand(cmd, dir)
                },
                onStopTerminal = { viewModel.terminalEngine.stop() },
                onClearTerminal = { viewModel.terminalEngine.clear() },
                gitStatus = gitStatus,
                onCommit = { viewModel.commitGit(it) },
                onCloneRepo = { viewModel.cloneGitHubRepo(it) },
                aiMessages = aiMessages,
                isAiBusy = isAiBusy,
                onSendAiPrompt = { viewModel.sendAiPrompt(it) },
                onApplyAiFix = { viewModel.applyAiFix(it) }
            )
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Project Explorer Sidebar
            if (isSidebarVisible) {
                ProjectExplorer(
                    rootNode = fileTreeRoot,
                    selectedFile = activeTab?.file,
                    onFileSelected = { viewModel.openFile(it) },
                    onNewFileClicked = { parent -> itemToCreateInDir = Pair(parent, false) },
                    onNewFolderClicked = { parent -> itemToCreateInDir = Pair(parent, true) },
                    onDeleteFileClicked = { fileToDelete = it },
                    onRenameFileClicked = { fileToRename = it },
                    onRefresh = { viewModel.refreshFileTree() },
                    onDeleteProjectTreeClicked = if (currentProject != null) {
                        { showDeleteProjectTreeConfirm = true }
                    } else null
                )

                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(1.dp)
                        .background(MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                )
            }

            // Editor Work Area
            Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                EditorTabsRow(
                    tabs = editorTabs,
                    activeTabIndex = activeTabIndex,
                    onTabSelected = { viewModel.selectTab(it) },
                    onTabClosed = { viewModel.closeTab(it) }
                )

                if (activeTab != null) {
                    CodeEditorView(
                        tab = activeTab,
                        themeMode = themeMode,
                        onContentChange = { viewModel.updateActiveTabContent(it) },
                        onCursorChange = { line, col -> viewModel.updateActiveTabCursor(line, col) },
                        onSave = { viewModel.saveActiveFile() },
                        onUndo = { viewModel.undo() },
                        onRedo = { viewModel.redo() },
                        targetLine = targetEditorLine
                    )
                    LaunchedEffect(targetEditorLine) {
                        if (targetEditorLine != null) {
                            viewModel.clearTargetLine()
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (currentProject != null) "Select a file from the explorer to view & edit" else "No Project Open",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (currentProject == null) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(onClick = { showNewProjectDialog = true }) {
                                    Text("Create Project")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // New Project Dialog
    if (showNewProjectDialog) {
        NewProjectDialog(
            onDismiss = { showNewProjectDialog = false },
            onCreate = { name, pkg, minSdk, targetSdk, template ->
                viewModel.createNewProject(name, pkg, minSdk, targetSdk, template)
                showNewProjectDialog = false
            }
        )
    }

    // Open Project Dialog
    if (showOpenProjectDialog) {
        OpenProjectDialog(
            projects = projectList,
            onDismiss = { showOpenProjectDialog = false },
            onSelectProject = { proj ->
                viewModel.selectProject(proj)
                showOpenProjectDialog = false
            },
            onDeleteProject = { proj ->
                viewModel.deleteProject(proj)
            }
        )
    }

    // Delete entire project tree confirmation
    if (showDeleteProjectTreeConfirm && currentProject != null) {
        ConfirmationDialog(
            title = "Delete Entire Project?",
            message = "Are you sure you want to permanently delete '${currentProject!!.name}' and all its source files and directories? This action cannot be undone.",
            confirmText = "Delete Entire Project Tree",
            isDestructive = true,
            onDismiss = { showDeleteProjectTreeConfirm = false },
            onConfirm = {
                showDeleteProjectTreeConfirm = false
                viewModel.deleteCurrentProjectTree()
            }
        )
    }

    // Global Search Dialog
    if (showGlobalSearchDialog) {
        GlobalSearchDialog(
            results = searchResults,
            isSearching = isSearching,
            onSearch = { viewModel.searchAcrossProject(it) },
            onSelectResult = { file, line ->
                viewModel.jumpToProblem(file, line)
                showGlobalSearchDialog = false
            },
            onDismiss = { showGlobalSearchDialog = false }
        )
    }

    // Settings Dialog
    if (showSettingsDialog) {
        IdeSettingsDialog(
            jdkLocation = jdkLocation,
            javaVersion = javaVersionInfo,
            onDismiss = { showSettingsDialog = false }
        )
    }

    // New File or Directory Dialog
    itemToCreateInDir?.let { (parent, isFolder) ->
        TextInputDialog(
            title = if (isFolder) "Create Directory in ${parent.name}" else "Create File in ${parent.name}",
            label = if (isFolder) "Directory Name" else "File Name (e.g. MyComponent.kt)",
            onDismiss = { itemToCreateInDir = null },
            onConfirm = { name ->
                if (isFolder) {
                    viewModel.createDirectoryInTree(parent, name)
                } else {
                    viewModel.createFileInTree(parent, name)
                }
                itemToCreateInDir = null
            }
        )
    }

    // Delete confirmation dialog for single file/directory
    fileToDelete?.let { file ->
        ConfirmationDialog(
            title = if (file.isDirectory) "Delete Directory?" else "Delete File?",
            message = "Are you sure you want to delete '${file.name}'?",
            confirmText = "Delete",
            isDestructive = true,
            onDismiss = { fileToDelete = null },
            onConfirm = {
                viewModel.deleteFileInTree(file)
                fileToDelete = null
            }
        )
    }

    // Rename dialog
    fileToRename?.let { file ->
        TextInputDialog(
            title = "Rename '${file.name}'",
            label = "New Name",
            initialValue = file.name,
            onDismiss = { fileToRename = null },
            onConfirm = { newName ->
                viewModel.renameFileInTree(file, newName)
                fileToRename = null
            }
        )
    }
}
