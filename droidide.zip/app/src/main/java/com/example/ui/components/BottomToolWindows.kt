package com.example.ui.components

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.core.ai.AiChatMessage
import com.example.core.ai.AiFixProposal
import com.example.core.git.GitStatus
import com.example.core.terminal.TerminalLine
import com.example.data.model.*
import java.io.File

@Composable
fun BottomToolWindows(
    activeWindow: BottomToolWindow,
    isExpanded: Boolean,
    onTabSelected: (BottomToolWindow) -> Unit,
    onToggleExpanded: () -> Unit,
    // Build Output params
    buildResult: BuildResult?,
    buildLogs: List<BuildLogEntry>,
    buildStatus: BuildStatus,
    onClearLogs: () -> Unit,
    // Problems params
    problems: List<ProblemItem>,
    onJumpToProblem: (File?, Int) -> Unit,
    // Terminal params
    terminalLines: List<TerminalLine>,
    isTerminalRunning: Boolean,
    onExecuteCommand: (String) -> Unit,
    onStopTerminal: () -> Unit,
    onClearTerminal: () -> Unit,
    // Git params
    gitStatus: GitStatus?,
    onCommit: (String) -> Unit,
    onCloneRepo: (String) -> Unit,
    // AI Agent params
    aiMessages: List<AiChatMessage>,
    isAiBusy: Boolean,
    onSendAiPrompt: (String) -> Unit,
    onApplyAiFix: (AiFixProposal) -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
    ) {
        // Tool window tabs header strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ToolTabButton(
                    title = "Build Output",
                    icon = Icons.Default.Build,
                    isSelected = activeWindow == BottomToolWindow.BUILD_OUTPUT,
                    badgeCount = if (buildStatus == BuildStatus.RUNNING) -1 else 0,
                    onClick = { onTabSelected(BottomToolWindow.BUILD_OUTPUT) }
                )
                ToolTabButton(
                    title = "Problems",
                    icon = Icons.Default.Warning,
                    isSelected = activeWindow == BottomToolWindow.PROBLEMS,
                    badgeCount = problems.size,
                    onClick = { onTabSelected(BottomToolWindow.PROBLEMS) }
                )
                ToolTabButton(
                    title = "Terminal",
                    icon = Icons.Default.Terminal,
                    isSelected = activeWindow == BottomToolWindow.TERMINAL,
                    badgeCount = 0,
                    onClick = { onTabSelected(BottomToolWindow.TERMINAL) }
                )
                ToolTabButton(
                    title = "Git",
                    icon = Icons.Default.Commit,
                    isSelected = activeWindow == BottomToolWindow.GIT,
                    badgeCount = gitStatus?.modifiedFiles?.size ?: 0,
                    onClick = { onTabSelected(BottomToolWindow.GIT) }
                )
                ToolTabButton(
                    title = "AI Assistant",
                    icon = Icons.Default.AutoAwesome,
                    isSelected = activeWindow == BottomToolWindow.AI_ASSISTANT,
                    badgeCount = 0,
                    onClick = { onTabSelected(BottomToolWindow.AI_ASSISTANT) }
                )
            }
            IconButton(
                onClick = onToggleExpanded,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = if (isExpanded) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowUp,
                    contentDescription = if (isExpanded) "Collapse" else "Expand",
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

        if (isExpanded) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(250.dp)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                when (activeWindow) {
                    BottomToolWindow.BUILD_OUTPUT -> {
                        BuildOutputContent(
                            buildResult = buildResult,
                            buildLogs = buildLogs,
                            buildStatus = buildStatus,
                            onClearLogs = onClearLogs,
                            context = context
                        )
                    }
                    BottomToolWindow.PROBLEMS -> {
                        ProblemsContent(
                            problems = problems,
                            onJumpToProblem = onJumpToProblem
                        )
                    }
                    BottomToolWindow.TERMINAL -> {
                        TerminalContent(
                            terminalLines = terminalLines,
                            isTerminalRunning = isTerminalRunning,
                            onExecuteCommand = onExecuteCommand,
                            onStopTerminal = onStopTerminal,
                            onClearTerminal = onClearTerminal
                        )
                    }
                    BottomToolWindow.GIT -> {
                        GitContent(
                            gitStatus = gitStatus,
                            onCommit = onCommit,
                            onCloneRepo = onCloneRepo
                        )
                    }
                    BottomToolWindow.AI_ASSISTANT -> {
                        AiAssistantContent(
                            messages = aiMessages,
                            isBusy = isAiBusy,
                            onSendMessage = onSendAiPrompt,
                            onApplyFix = onApplyAiFix
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolTabButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    badgeCount: Int,
    onClick: () -> Unit
) {
    val color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(15.dp),
            tint = color
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = color,
            fontSize = 11.sp
        )
        if (badgeCount > 0) {
            Spacer(modifier = Modifier.width(4.dp))
            Surface(
                shape = MaterialTheme.shapes.extraSmall,
                color = MaterialTheme.colorScheme.error
            ) {
                Text(
                    text = "$badgeCount",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                )
            }
        } else if (badgeCount == -1) {
            Spacer(modifier = Modifier.width(4.dp))
            CircularProgressIndicator(
                modifier = Modifier.size(10.dp),
                strokeWidth = 1.5.dp,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

@Composable
private fun BuildOutputContent(
    buildResult: BuildResult?,
    buildLogs: List<BuildLogEntry>,
    buildStatus: BuildStatus,
    onClearLogs: () -> Unit,
    context: Context
) {
    val listState = rememberLazyListState()
    val horizontalScrollState = rememberScrollState()
    val clipboardManager = LocalClipboardManager.current
    var isFullScreen by remember { mutableStateOf(false) }

    LaunchedEffect(buildLogs.size) {
        if (buildLogs.isNotEmpty()) {
            listState.animateScrollToItem(buildLogs.size - 1)
        }
    }

    val content = @Composable {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Status and full action toolbar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    val statusColor = when (buildStatus) {
                        BuildStatus.RUNNING -> MaterialTheme.colorScheme.primary
                        BuildStatus.SUCCESS -> Color(0xFF59A869)
                        BuildStatus.FAILED -> MaterialTheme.colorScheme.error
                        BuildStatus.CANCELLED -> MaterialTheme.colorScheme.outline
                        BuildStatus.IDLE -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(statusColor, shape = androidx.compose.foundation.shape.CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Status: $buildStatus",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = statusColor
                    )
                    if (buildResult != null && buildResult.durationMs > 0) {
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Time: ${buildResult.durationMs / 1000}s",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "(${buildLogs.size} lines)",
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Copy All action
                    TextButton(
                        onClick = {
                            val fullLogText = buildLogs.joinToString("\n") { it.message }
                            if (fullLogText.isNotEmpty()) {
                                clipboardManager.setText(AnnotatedString(fullLogText))
                                android.widget.Toast.makeText(context, "All logs copied to clipboard", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        },
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                        modifier = Modifier.height(28.dp).testTag("copy_logs_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy all logs",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Copy Logs", fontSize = 11.sp)
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Full Screen toggle
                    IconButton(
                        onClick = { isFullScreen = !isFullScreen },
                        modifier = Modifier.size(28.dp).testTag("fullscreen_logs_btn")
                    ) {
                        Icon(
                            imageVector = if (isFullScreen) Icons.Default.FullscreenExit else Icons.Default.Fullscreen,
                            contentDescription = if (isFullScreen) "Exit full screen" else "Full screen",
                            modifier = Modifier.size(18.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Clear logs
                    IconButton(
                        onClick = onClearLogs,
                        modifier = Modifier.size(28.dp).testTag("clear_logs_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Clear logs",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // APK Details Banner with Open / Share / Install
            if (buildResult?.apkFile != null && buildResult.apkFile.exists()) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E3A24)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(6.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "APK Ready: ${buildResult.apkFile.name}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF81C784)
                            )
                            Text(
                                text = "Path: ${buildResult.apkFile.absolutePath}  (${buildResult.apkSize / 1024} KB)",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 10.sp,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }
                        Row {
                            Button(
                                onClick = { installApk(context, buildResult.apkFile) },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(Icons.Default.Android, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Install", fontSize = 11.sp)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            FilledTonalButton(
                                onClick = { shareApk(context, buildResult.apkFile) },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Share", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }

            // Full, non-truncated, selectable log viewer with dual-axis scroll
            SelectionContainer(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .horizontalScroll(horizontalScrollState)
                ) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        items(buildLogs) { entry ->
                            val textColor = when {
                                entry.isError -> Color(0xFFE05252)
                                entry.message.contains("BUILD SUCCESSFUL", ignoreCase = true) -> Color(0xFF59A869)
                                entry.message.startsWith(">") -> MaterialTheme.colorScheme.primary
                                else -> MaterialTheme.colorScheme.onBackground
                            }
                            Text(
                                text = entry.message,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 16.sp,
                                color = textColor,
                                softWrap = false
                            )
                        }
                    }
                }
            }
        }
    }

    if (isFullScreen) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { isFullScreen = false },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                content()
            }
        }
    } else {
        content()
    }
}

@Composable
private fun ProblemsContent(
    problems: List<ProblemItem>,
    onJumpToProblem: (File?, Int) -> Unit
) {
    if (problems.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF59A869),
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "No problems detected in the project.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    } else {
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(problems) { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onJumpToProblem(item.file, item.line) }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = if (item.isError) Icons.Default.Error else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (item.isError) Color(0xFFE05252) else Color(0xFFE5A800),
                        modifier = Modifier.size(16.dp).padding(top = 2.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = item.relativePath,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "line ${item.line}:${item.column}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = item.message,
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
                HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))
            }
        }
    }
}

@Composable
private fun TerminalContent(
    terminalLines: List<TerminalLine>,
    isTerminalRunning: Boolean,
    onExecuteCommand: (String) -> Unit,
    onStopTerminal: () -> Unit,
    onClearTerminal: () -> Unit
) {
    var cmdText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(terminalLines.size) {
        if (terminalLines.isNotEmpty()) {
            listState.animateScrollToItem(terminalLines.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            items(terminalLines) { line ->
                val color = when {
                    line.isCommand -> MaterialTheme.colorScheme.primary
                    line.isError -> Color(0xFFE05252)
                    else -> MaterialTheme.colorScheme.onBackground
                }
                Text(
                    text = line.text,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    lineHeight = 16.sp,
                    color = color
                )
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$",
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            OutlinedTextField(
                value = cmdText,
                onValueChange = { cmdText = it },
                placeholder = { Text("Enter command (e.g. ./gradlew assembleDebug, java -version)...", fontSize = 11.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (cmdText.isNotBlank()) {
                        onExecuteCommand(cmdText)
                        cmdText = ""
                    }
                }),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp, fontFamily = FontFamily.Monospace),
                modifier = Modifier.weight(1f).height(44.dp).testTag("terminal_input_field")
            )
            Spacer(modifier = Modifier.width(6.dp))
            if (isTerminalRunning) {
                IconButton(onClick = onStopTerminal, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Stop, contentDescription = "Stop", tint = MaterialTheme.colorScheme.error)
                }
            } else {
                IconButton(
                    onClick = {
                        if (cmdText.isNotBlank()) {
                            onExecuteCommand(cmdText)
                            cmdText = ""
                        }
                    },
                    modifier = Modifier.size(36.dp).testTag("terminal_send_btn")
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Run", tint = MaterialTheme.colorScheme.primary)
                }
            }
            IconButton(onClick = onClearTerminal, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.ClearAll, contentDescription = "Clear")
            }
        }
    }
}

@Composable
private fun GitContent(
    gitStatus: GitStatus?,
    onCommit: (String) -> Unit,
    onCloneRepo: (String) -> Unit
) {
    var commitMessage by remember { mutableStateOf("") }
    var showCloneDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CallSplit, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Branch: ${gitStatus?.currentBranch ?: "main"}",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            FilledTonalButton(
                onClick = { showCloneDialog = true },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Clone GitHub Repo", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = commitMessage,
                onValueChange = { commitMessage = it },
                placeholder = { Text("Commit message...", fontSize = 11.sp) },
                singleLine = true,
                modifier = Modifier.weight(1f).height(44.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Button(
                onClick = {
                    if (commitMessage.isNotBlank()) {
                        onCommit(commitMessage)
                        commitMessage = ""
                    }
                },
                modifier = Modifier.height(44.dp)
            ) {
                Text("Commit", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Recent Commits:",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        val commits = gitStatus?.recentCommits ?: emptyList()
        if (commits.isEmpty()) {
            Text(
                text = "No commits recorded yet.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(top = 4.dp)) {
                items(commits) { c ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = c.id,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 10.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = c.message,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }

    if (showCloneDialog) {
        var cloneUrl by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCloneDialog = false },
            title = { Text("Clone GitHub Repository") },
            text = {
                Column {
                    Text("Enter repository URL:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = cloneUrl,
                        onValueChange = { cloneUrl = it },
                        placeholder = { Text("https://github.com/owner/repo") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (cloneUrl.isNotBlank()) {
                            onCloneRepo(cloneUrl)
                            showCloneDialog = false
                        }
                    }
                ) {
                    Text("Clone")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCloneDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun AiAssistantContent(
    messages: List<AiChatMessage>,
    isBusy: Boolean,
    onSendMessage: (String) -> Unit,
    onApplyFix: (AiFixProposal) -> Unit
) {
    var promptInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SuggestionChip(
                onClick = { onSendMessage("Analyze recent build problems and suggest fixes") },
                label = { Text("Fix Errors", fontSize = 10.sp) },
                icon = { Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(12.dp)) }
            )
            SuggestionChip(
                onClick = { onSendMessage("Explain active code file") },
                label = { Text("Explain Code", fontSize = 10.sp) },
                icon = { Icon(Icons.Default.HelpOutline, contentDescription = null, modifier = Modifier.size(12.dp)) }
            )
            SuggestionChip(
                onClick = { onSendMessage("Show project file structure") },
                label = { Text("Files", fontSize = 10.sp) },
                icon = { Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(12.dp)) }
            )
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            items(messages) { msg ->
                val isUser = msg.sender == "user"
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                ) {
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.widthIn(max = 300.dp)
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(text = msg.text, style = MaterialTheme.typography.bodySmall, fontSize = 11.sp)
                            if (msg.proposal != null) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                    Column(modifier = Modifier.padding(6.dp)) {
                                        Text(text = msg.proposal.title, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                                        Text(text = msg.proposal.description, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Button(
                                            onClick = { onApplyFix(msg.proposal) },
                                            modifier = Modifier.fillMaxWidth().height(30.dp),
                                            contentPadding = PaddingValues(0.dp)
                                        ) {
                                            Text("Apply Fix to File", fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (isBusy) {
                item {
                    Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 1.5.dp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("AI Agent analyzing...", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = promptInput,
                onValueChange = { promptInput = it },
                placeholder = { Text("Ask AI Assistant...", fontSize = 11.sp) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (promptInput.isNotBlank() && !isBusy) {
                        onSendMessage(promptInput)
                        promptInput = ""
                    }
                }),
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp),
                modifier = Modifier.weight(1f).height(44.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            IconButton(
                onClick = {
                    if (promptInput.isNotBlank() && !isBusy) {
                        onSendMessage(promptInput)
                        promptInput = ""
                    }
                },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

private fun installApk(context: Context, apkFile: File) {
    try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", apkFile)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

private fun shareApk(context: Context, apkFile: File) {
    try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", apkFile)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_STREAM, uri)
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        context.startActivity(Intent.createChooser(intent, "Share APK"))
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
