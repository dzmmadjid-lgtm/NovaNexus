package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.ai.AiChatMessage
import com.example.core.ai.AiFixProposal
import com.example.core.ai.IdeAiAgent
import com.example.core.build.BuildEngine
import com.example.core.build.JdkProvisioner
import com.example.core.build.LocalProcessBuildEngine
import com.example.core.build.ProblemsParser
import com.example.core.fs.ProjectManager
import com.example.core.fs.ZipUtils
import com.example.core.git.GitManager
import com.example.core.git.GitStatus
import com.example.core.terminal.TerminalEngine
import com.example.core.terminal.TerminalLine
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream

class IdeViewModel(application: Application) : AndroidViewModel(application) {
    val projectManager = ProjectManager(application)
    private val buildEngine: BuildEngine = LocalProcessBuildEngine()
    private val gitManager = GitManager()
    val terminalEngine = TerminalEngine(viewModelScope)
    val aiAgent = IdeAiAgent(projectManager)

    // Current Project & Explorer State
    private val _currentProject = MutableStateFlow<Project?>(null)
    val currentProject: StateFlow<Project?> = _currentProject.asStateFlow()

    private val _projectList = MutableStateFlow<List<Project>>(emptyList())
    val projectList: StateFlow<List<Project>> = _projectList.asStateFlow()

    private val _fileTreeRoot = MutableStateFlow<FileNode?>(null)
    val fileTreeRoot: StateFlow<FileNode?> = _fileTreeRoot.asStateFlow()

    // Editor Tabs & State
    private val _editorTabs = MutableStateFlow<List<EditorTab>>(emptyList())
    val editorTabs: StateFlow<List<EditorTab>> = _editorTabs.asStateFlow()

    private val _activeTabIndex = MutableStateFlow(-1)
    val activeTabIndex: StateFlow<Int> = _activeTabIndex.asStateFlow()

    val activeTab: EditorTab?
        get() {
            val tabs = _editorTabs.value
            val idx = _activeTabIndex.value
            return if (idx in tabs.indices) tabs[idx] else null
        }

    // Build State
    private val _buildStatus = MutableStateFlow(BuildStatus.IDLE)
    val buildStatus: StateFlow<BuildStatus> = _buildStatus.asStateFlow()

    private val _buildLogs = MutableStateFlow<List<BuildLogEntry>>(emptyList())
    val buildLogs: StateFlow<List<BuildLogEntry>> = _buildLogs.asStateFlow()

    private val _buildResult = MutableStateFlow<BuildResult?>(null)
    val buildResult: StateFlow<BuildResult?> = _buildResult.asStateFlow()

    private val _problems = MutableStateFlow<List<ProblemItem>>(emptyList())
    val problems: StateFlow<List<ProblemItem>> = _problems.asStateFlow()

    // UI Navigation State
    private val _activeToolWindow = MutableStateFlow(BottomToolWindow.BUILD_OUTPUT)
    val activeToolWindow: StateFlow<BottomToolWindow> = _activeToolWindow.asStateFlow()

    private val _isToolWindowExpanded = MutableStateFlow(false)
    val isToolWindowExpanded: StateFlow<Boolean> = _isToolWindowExpanded.asStateFlow()

    private val _isSidebarVisible = MutableStateFlow(true)
    val isSidebarVisible: StateFlow<Boolean> = _isSidebarVisible.asStateFlow()

    private val _themeMode = MutableStateFlow(ThemeMode.DARK)
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    // Jump to Line in Editor
    private val _targetEditorLine = MutableStateFlow<Int?>(null)
    val targetEditorLine: StateFlow<Int?> = _targetEditorLine.asStateFlow()

    // Search Results
    private val _searchResults = MutableStateFlow<List<SearchResult>>(emptyList())
    val searchResults: StateFlow<List<SearchResult>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    // Git Status
    private val _gitStatus = MutableStateFlow<GitStatus?>(null)
    val gitStatus: StateFlow<GitStatus?> = _gitStatus.asStateFlow()

    // AI Messages
    private val _aiMessages = MutableStateFlow<List<AiChatMessage>>(emptyList())
    val aiMessages: StateFlow<List<AiChatMessage>> = _aiMessages.asStateFlow()

    private val _isAiBusy = MutableStateFlow(false)
    val isAiBusy: StateFlow<Boolean> = _isAiBusy.asStateFlow()

    // JDK Info
    private val _jdkLocation = MutableStateFlow("")
    val jdkLocation: StateFlow<String> = _jdkLocation.asStateFlow()

    private val _javaVersionInfo = MutableStateFlow("")
    val javaVersionInfo: StateFlow<String> = _javaVersionInfo.asStateFlow()

    private var buildJob: Job? = null

    init {
        loadProjects()
        initJdk()
    }

    private fun initJdk() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val res = JdkProvisioner.ensureJdkInstalled(getApplication())
                if (res.isSuccess) {
                    val jdkHome = res.getOrNull()
                    if (jdkHome != null) {
                        _jdkLocation.value = jdkHome.absolutePath
                        val ver = JdkProvisioner.verifyJdk(jdkHome)
                        _javaVersionInfo.value = ver.getOrNull() ?: "Verified"
                    }
                } else {
                    _javaVersionInfo.value = "Provisioning error: ${res.exceptionOrNull()?.message}"
                }
            } catch (e: Exception) {
                _javaVersionInfo.value = "JDK Init error: ${e.message}"
            }
        }
    }

    fun loadProjects() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = projectManager.listProjects()
            _projectList.value = list
            if (_currentProject.value == null && list.isNotEmpty()) {
                selectProject(list.first())
            }
        }
    }

    fun selectProject(project: Project) {
        _currentProject.value = project
        refreshFileTree()
        _editorTabs.value = emptyList()
        _activeTabIndex.value = -1
        _buildLogs.value = emptyList()
        _buildResult.value = null
        _problems.value = emptyList()

        // Open MainActivity by default if exists
        viewModelScope.launch(Dispatchers.IO) {
            val mainActivity = project.rootDir.walkTopDown()
                .firstOrNull { it.name == "MainActivity.kt" || it.name == "MainActivity.java" }
            if (mainActivity != null) {
                openFile(mainActivity)
            }
            refreshGitStatus()
        }
    }

    fun createNewProject(
        name: String,
        packageName: String,
        minSdk: Int,
        targetSdk: Int,
        template: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val newProj = projectManager.createProject(name, packageName, minSdk, targetSdk, template)
            loadProjects()
            selectProject(newProj)
        }
    }

    fun deleteProject(project: Project) {
        viewModelScope.launch(Dispatchers.IO) {
            projectManager.deleteProject(project)
            if (_currentProject.value?.rootDir?.absolutePath == project.rootDir.absolutePath) {
                _currentProject.value = null
                _fileTreeRoot.value = null
                _editorTabs.value = emptyList()
                _activeTabIndex.value = -1
            }
            loadProjects()
        }
    }

    fun deleteCurrentProjectTree() {
        val proj = _currentProject.value ?: return
        deleteProject(proj)
    }

    fun refreshFileTree() {
        val proj = _currentProject.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            _fileTreeRoot.value = projectManager.buildFileTree(proj.rootDir)
        }
    }

    fun openFile(file: File) {
        if (file.isDirectory) return
        val currentTabs = _editorTabs.value.toMutableList()
        val existingIndex = currentTabs.indexOfFirst { it.file.absolutePath == file.absolutePath }
        if (existingIndex != -1) {
            _activeTabIndex.value = existingIndex
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            val content = projectManager.readFileContent(file)
            val newTab = EditorTab(
                file = file,
                title = file.name,
                content = content
            )
            val updated = currentTabs + newTab
            _editorTabs.value = updated
            _activeTabIndex.value = updated.size - 1
        }
    }

    fun selectTab(index: Int) {
        if (index in _editorTabs.value.indices) {
            _activeTabIndex.value = index
        }
    }

    fun closeTab(index: Int) {
        val currentTabs = _editorTabs.value.toMutableList()
        if (index in currentTabs.indices) {
            val tab = currentTabs[index]
            if (tab.isDirty) {
                projectManager.saveFileContent(tab.file, tab.content)
            }
            currentTabs.removeAt(index)
            _editorTabs.value = currentTabs
            _activeTabIndex.value = if (currentTabs.isEmpty()) -1 else (index - 1).coerceAtLeast(0)
        }
    }

    fun updateActiveTabContent(newContent: String) {
        val idx = _activeTabIndex.value
        val tabs = _editorTabs.value.toMutableList()
        if (idx in tabs.indices) {
            val tab = tabs[idx]
            val undo = tab.undoStack.toMutableList()
            if (undo.size > 50) undo.removeAt(0)
            undo.add(tab.content)

            tabs[idx] = tab.copy(
                content = newContent,
                isDirty = true,
                undoStack = undo,
                redoStack = emptyList()
            )
            _editorTabs.value = tabs
        }
    }

    fun updateActiveTabCursor(line: Int, col: Int) {
        val idx = _activeTabIndex.value
        val tabs = _editorTabs.value.toMutableList()
        if (idx in tabs.indices) {
            tabs[idx] = tabs[idx].copy(cursorLine = line, cursorCol = col)
            _editorTabs.value = tabs
        }
    }

    fun saveActiveFile() {
        val tab = activeTab ?: return
        viewModelScope.launch(Dispatchers.IO) {
            projectManager.saveFileContent(tab.file, tab.content)
            val idx = _activeTabIndex.value
            val tabs = _editorTabs.value.toMutableList()
            if (idx in tabs.indices) {
                tabs[idx] = tabs[idx].copy(isDirty = false)
                _editorTabs.value = tabs
            }
        }
    }

    fun undo() {
        val idx = _activeTabIndex.value
        val tabs = _editorTabs.value.toMutableList()
        if (idx in tabs.indices) {
            val tab = tabs[idx]
            if (tab.undoStack.isNotEmpty()) {
                val undo = tab.undoStack.toMutableList()
                val prevContent = undo.removeAt(undo.size - 1)
                val redo = tab.redoStack.toMutableList()
                redo.add(tab.content)
                tabs[idx] = tab.copy(
                    content = prevContent,
                    isDirty = true,
                    undoStack = undo,
                    redoStack = redo
                )
                _editorTabs.value = tabs
            }
        }
    }

    fun redo() {
        val idx = _activeTabIndex.value
        val tabs = _editorTabs.value.toMutableList()
        if (idx in tabs.indices) {
            val tab = tabs[idx]
            if (tab.redoStack.isNotEmpty()) {
                val redo = tab.redoStack.toMutableList()
                val nextContent = redo.removeAt(redo.size - 1)
                val undo = tab.undoStack.toMutableList()
                undo.add(tab.content)
                tabs[idx] = tab.copy(
                    content = nextContent,
                    isDirty = true,
                    undoStack = undo,
                    redoStack = redo
                )
                _editorTabs.value = tabs
            }
        }
    }

    fun createFileInTree(parentDir: File, fileName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val file = projectManager.createFile(parentDir, fileName)
            refreshFileTree()
            openFile(file)
        }
    }

    fun createDirectoryInTree(parentDir: File, dirName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            projectManager.createDirectory(parentDir, dirName)
            refreshFileTree()
        }
    }

    fun deleteFileInTree(file: File) {
        viewModelScope.launch(Dispatchers.IO) {
            projectManager.deleteFileOrDirectory(file)
            val openIdx = _editorTabs.value.indexOfFirst { it.file.absolutePath == file.absolutePath }
            if (openIdx != -1) {
                closeTab(openIdx)
            }
            refreshFileTree()
        }
    }

    fun renameFileInTree(file: File, newName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val renamed = projectManager.renameFileOrDirectory(file, newName)
            if (renamed != null) {
                val openIdx = _editorTabs.value.indexOfFirst { it.file.absolutePath == file.absolutePath }
                if (openIdx != -1) {
                    val tabs = _editorTabs.value.toMutableList()
                    tabs[openIdx] = tabs[openIdx].copy(file = renamed, title = renamed.name)
                    _editorTabs.value = tabs
                }
            }
            refreshFileTree()
        }
    }

    fun runBuild(tasks: List<String> = listOf("assembleDebug")) {
        val proj = _currentProject.value ?: return
        if (_buildStatus.value == BuildStatus.RUNNING) return

        // Save all open files first
        _editorTabs.value.forEach { tab ->
            if (tab.isDirty) {
                projectManager.saveFileContent(tab.file, tab.content)
            }
        }

        _buildStatus.value = BuildStatus.RUNNING
        _buildLogs.value = emptyList()
        _buildResult.value = null
        _problems.value = emptyList()
        _activeToolWindow.value = BottomToolWindow.BUILD_OUTPUT
        _isToolWindowExpanded.value = true

        buildJob?.cancel()
        buildJob = viewModelScope.launch(Dispatchers.IO) {
            val logLines = mutableListOf<String>()
            val result = buildEngine.build(
                projectRootDir = proj.rootDir,
                tasks = tasks,
                onLog = { entry ->
                    _buildLogs.value = _buildLogs.value + entry
                    logLines.add(entry.message)
                }
            )
            _buildStatus.value = result.status
            val parsedProblems = ProblemsParser.parse(logLines, proj.rootDir)
            _problems.value = parsedProblems
            _buildResult.value = result.copy(problems = parsedProblems)

            if (result.status == BuildStatus.FAILED && parsedProblems.isNotEmpty()) {
                _activeToolWindow.value = BottomToolWindow.PROBLEMS
            }
        }
    }

    fun stopBuild() {
        buildEngine.cancel()
        buildJob?.cancel()
        _buildStatus.value = BuildStatus.CANCELLED
    }

    fun clearBuildLogs() {
        _buildLogs.value = emptyList()
        _buildResult.value = null
    }

    fun jumpToProblem(file: File?, line: Int) {
        if (file != null && file.exists()) {
            openFile(file)
            _targetEditorLine.value = line
        }
    }

    fun clearTargetLine() {
        _targetEditorLine.value = null
    }

    fun setActiveToolWindow(window: BottomToolWindow) {
        _activeToolWindow.value = window
        _isToolWindowExpanded.value = true
    }

    fun toggleToolWindowExpanded() {
        _isToolWindowExpanded.value = !_isToolWindowExpanded.value
    }

    fun toggleSidebar() {
        _isSidebarVisible.value = !_isSidebarVisible.value
    }

    fun toggleTheme() {
        _themeMode.value = when (_themeMode.value) {
            ThemeMode.DARK -> ThemeMode.LIGHT
            ThemeMode.LIGHT -> ThemeMode.OLED
            ThemeMode.OLED -> ThemeMode.DARK
        }
    }

    fun searchAcrossProject(query: String) {
        val proj = _currentProject.value ?: return
        if (query.isBlank()) {
            _searchResults.value = emptyList()
            return
        }
        viewModelScope.launch(Dispatchers.IO) {
            _isSearching.value = true
            val results = mutableListOf<SearchResult>()
            proj.rootDir.walkTopDown()
                .filter { it.isFile && !it.path.contains("/build/") && !it.path.contains("/.gradle/") }
                .take(100)
                .forEach { f ->
                    try {
                        val lines = f.readLines()
                        lines.forEachIndexed { idx, line ->
                            if (line.contains(query, ignoreCase = true)) {
                                results.add(
                                    SearchResult(
                                        file = f,
                                        relativePath = f.relativeTo(proj.rootDir).path,
                                        lineNumber = idx + 1,
                                        lineContent = line
                                    )
                                )
                            }
                        }
                    } catch (_: Exception) {}
                }
            _searchResults.value = results
            _isSearching.value = false
        }
    }

    // Git Operations
    fun refreshGitStatus() {
        val proj = _currentProject.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            _gitStatus.value = gitManager.getStatus(proj.rootDir)
        }
    }

    fun commitGit(message: String) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            gitManager.initRepo(proj.rootDir)
            gitManager.commit(proj.rootDir, message)
            refreshGitStatus()
        }
    }

    fun cloneGitHubRepo(url: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val safeName = url.trim().removeSuffix(".git").split("/").lastOrNull() ?: "cloned_repo"
            val targetDir = File(projectManager.rootProjectsDir, safeName)
            terminalEngine.appendLine("Cloning GitHub repository: $url")
            val success = gitManager.cloneGitHubRepo(url, targetDir) { progress ->
                terminalEngine.appendLine(progress)
            }
            if (success) {
                loadProjects()
                val newProj = projectManager.listProjects().firstOrNull { it.rootDir.name == targetDir.name }
                if (newProj != null) {
                    selectProject(newProj)
                }
            }
        }
    }

    // AI Agent Operations
    fun sendAiPrompt(prompt: String) {
        val proj = _currentProject.value ?: return
        val userMsg = AiChatMessage("user", prompt)
        _aiMessages.value = _aiMessages.value + userMsg
        _isAiBusy.value = true

        viewModelScope.launch(Dispatchers.IO) {
            val responseText = aiAgent.queryAssistant(
                prompt = prompt,
                project = proj,
                activeFile = activeTab?.file,
                activeContent = activeTab?.content,
                recentProblems = _problems.value
            )
            val proposal = if (_problems.value.isNotEmpty()) {
                aiAgent.analyzeProblemAndSuggestFix(proj, _problems.value.first(), activeTab?.content)
            } else null

            val assistantMsg = AiChatMessage(
                sender = "assistant",
                text = responseText,
                proposal = proposal
            )
            _aiMessages.value = _aiMessages.value + assistantMsg
            _isAiBusy.value = false
        }
    }

    fun applyAiFix(proposal: AiFixProposal) {
        viewModelScope.launch(Dispatchers.IO) {
            aiAgent.applyFix(proposal)
            val openIdx = _editorTabs.value.indexOfFirst { it.file.absolutePath == proposal.targetFile.absolutePath }
            if (openIdx != -1) {
                val newContent = proposal.targetFile.readText()
                val tabs = _editorTabs.value.toMutableList()
                tabs[openIdx] = tabs[openIdx].copy(content = newContent, isDirty = false)
                _editorTabs.value = tabs
            }
            _aiMessages.value = _aiMessages.value + AiChatMessage("assistant", "Applied fix to ${proposal.targetFile.name}.")
        }
    }

    fun exportProjectToZip(destinationZip: File) {
        val proj = _currentProject.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            ZipUtils.exportProjectToZip(proj.rootDir, destinationZip)
        }
    }

    fun importProjectFromZip(inputStream: InputStream, projectName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val targetDir = File(projectManager.rootProjectsDir, projectName)
            ZipUtils.importProjectFromZip(inputStream, targetDir)
            loadProjects()
            val imported = projectManager.listProjects().firstOrNull { it.rootDir.name == targetDir.name }
            if (imported != null) {
                selectProject(imported)
            }
        }
    }
}
