package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BuildStatus
import com.example.data.model.Project
import com.example.data.model.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IdeTopBar(
    currentProject: Project?,
    buildStatus: BuildStatus,
    themeMode: ThemeMode,
    onToggleSidebar: () -> Unit,
    onRunBuild: () -> Unit,
    onStopBuild: () -> Unit,
    onNewProject: () -> Unit,
    onOpenProject: () -> Unit,
    onExportProject: () -> Unit,
    onImportProject: () -> Unit,
    onGlobalSearch: () -> Unit,
    onToggleTheme: () -> Unit,
    onOpenSettings: () -> Unit
) {
    var showMoreMenu by remember { mutableStateOf(false) }

    TopAppBar(
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onToggleSidebar, modifier = Modifier.size(36.dp).testTag("topbar_menu_btn")) {
                    Icon(imageVector = Icons.Default.Menu, contentDescription = "Toggle Explorer")
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = currentProject?.name ?: "DroidIDE",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (currentProject != null) {
                        Text(
                            text = currentProject.packageName,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        },
        actions = {
            // Global Search icon
            IconButton(onClick = onGlobalSearch, modifier = Modifier.size(36.dp).testTag("topbar_search_btn")) {
                Icon(Icons.Default.Search, contentDescription = "Search Across Project")
            }

            // Build action
            if (buildStatus == BuildStatus.RUNNING) {
                IconButton(onClick = onStopBuild, modifier = Modifier.size(36.dp).testTag("topbar_stop_build_btn")) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "Stop Build",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            } else {
                Button(
                    onClick = onRunBuild,
                    enabled = currentProject != null,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                    modifier = Modifier
                        .height(34.dp)
                        .padding(end = 4.dp)
                        .testTag("topbar_build_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Build APK",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Build APK",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            // Theme switch icon
            IconButton(onClick = onToggleTheme, modifier = Modifier.size(36.dp)) {
                Icon(
                    imageVector = when (themeMode) {
                        ThemeMode.LIGHT -> Icons.Default.DarkMode
                        ThemeMode.DARK -> Icons.Default.BrightnessAuto
                        ThemeMode.OLED -> Icons.Default.LightMode
                    },
                    contentDescription = "Theme: $themeMode"
                )
            }

            // More Menu
            Box {
                IconButton(onClick = { showMoreMenu = true }, modifier = Modifier.size(36.dp).testTag("topbar_more_menu_btn")) {
                    Icon(Icons.Default.MoreVert, contentDescription = "More")
                }
                DropdownMenu(
                    expanded = showMoreMenu,
                    onDismissRequest = { showMoreMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("New Project") },
                        leadingIcon = { Icon(Icons.Default.Add, contentDescription = null) },
                        onClick = {
                            showMoreMenu = false
                            onNewProject()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Open Project") },
                        leadingIcon = { Icon(Icons.Default.FolderOpen, contentDescription = null) },
                        onClick = {
                            showMoreMenu = false
                            onOpenProject()
                        }
                    )
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = { Text("Export to ZIP") },
                        leadingIcon = { Icon(Icons.Default.Archive, contentDescription = null) },
                        enabled = currentProject != null,
                        onClick = {
                            showMoreMenu = false
                            onExportProject()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Import from ZIP") },
                        leadingIcon = { Icon(Icons.Default.Unarchive, contentDescription = null) },
                        onClick = {
                            showMoreMenu = false
                            onImportProject()
                        }
                    )
                    HorizontalDivider()
                    DropdownMenuItem(
                        text = { Text("IDE Settings & JDK Info") },
                        leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        onClick = {
                            showMoreMenu = false
                            onOpenSettings()
                        }
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    )
}
