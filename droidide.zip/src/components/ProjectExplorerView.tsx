import React, { useState } from "react";
import {
  Folder,
  FolderOpen,
  FileCode,
  FileText,
  File,
  ChevronRight,
  ChevronDown,
  Plus,
  Trash2,
  Edit2,
  RefreshCw,
  FolderPlus,
  AlertTriangle
} from "lucide-react";
import { FileNodeDto } from "../types";

interface ProjectExplorerViewProps {
  tree: FileNodeDto | null;
  activeFilePath: string | null;
  onFileSelect: (path: string) => void;
  onCreateFile: (parentDir: string, isFolder: boolean) => void;
  onDeleteNode: (path: string) => void;
  onRenameNode: (path: string) => void;
  onDeleteEntireProjectTree: () => void;
  onRefresh: () => void;
}

export const ProjectExplorerView: React.FC<ProjectExplorerViewProps> = ({
  tree,
  activeFilePath,
  onFileSelect,
  onCreateFile,
  onDeleteNode,
  onRenameNode,
  onDeleteEntireProjectTree,
  onRefresh
}) => {
  const [expandedPaths, setExpandedPaths] = useState<Set<string>>(new Set([".", "app", "app/src", "app/src/main", "app/src/main/java"]));

  const toggleExpand = (path: string) => {
    setExpandedPaths((prev) => {
      const next = new Set(prev);
      if (next.has(path)) {
        next.delete(path);
      } else {
        next.add(path);
      }
      return next;
    });
  };

  const getFileIcon = (node: FileNodeDto, isExpanded: boolean) => {
    if (node.isDirectory) {
      return isExpanded ? (
        <FolderOpen className="w-4 h-4 text-amber-400 shrink-0" />
      ) : (
        <Folder className="w-4 h-4 text-amber-400 shrink-0" />
      );
    }
    const ext = node.extension;
    if (ext === "kt" || ext === "kts" || ext === "java") {
      return <FileCode className="w-4 h-4 text-indigo-400 shrink-0" />;
    }
    if (ext === "xml") {
      return <FileCode className="w-4 h-4 text-orange-400 shrink-0" />;
    }
    if (ext === "gradle") {
      return <FileCode className="w-4 h-4 text-teal-400 shrink-0" />;
    }
    if (ext === "json" || ext === "properties") {
      return <FileText className="w-4 h-4 text-emerald-400 shrink-0" />;
    }
    return <File className="w-4 h-4 text-neutral-400 shrink-0" />;
  };

  const renderNode = (node: FileNodeDto, depth: number = 0) => {
    const isExpanded = expandedPaths.has(node.path);
    const isSelected = activeFilePath === node.path;

    return (
      <div key={node.path} className="flex flex-col">
        <div
          className={`group flex items-center justify-between py-1 px-2 rounded cursor-pointer text-xs transition-colors ${
            isSelected
              ? "bg-neutral-800 text-emerald-400 font-medium"
              : "text-neutral-300 hover:bg-neutral-800/60"
          }`}
          style={{ paddingLeft: `${Math.max(depth * 14 + 8, 8)}px` }}
          onClick={() => {
            if (node.isDirectory) {
              toggleExpand(node.path);
            } else {
              onFileSelect(node.path);
            }
          }}
        >
          <div className="flex items-center gap-1.5 overflow-hidden">
            {node.isDirectory ? (
              <span className="text-neutral-500 hover:text-neutral-300 shrink-0">
                {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
              </span>
            ) : (
              <span className="w-3.5 shrink-0" />
            )}
            {getFileIcon(node, isExpanded)}
            <span className="truncate">{node.name}</span>
          </div>

          <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1 shrink-0 ml-2">
            {node.isDirectory && (
              <>
                <button
                  title="New File"
                  onClick={(e) => {
                    e.stopPropagation();
                    onCreateFile(node.path, false);
                  }}
                  className="p-1 hover:bg-neutral-700 rounded text-neutral-400 hover:text-neutral-200"
                >
                  <Plus className="w-3 h-3" />
                </button>
                <button
                  title="New Directory"
                  onClick={(e) => {
                    e.stopPropagation();
                    onCreateFile(node.path, true);
                  }}
                  className="p-1 hover:bg-neutral-700 rounded text-neutral-400 hover:text-neutral-200"
                >
                  <FolderPlus className="w-3 h-3" />
                </button>
              </>
            )}
            {node.path !== "." && (
              <>
                <button
                  title="Rename"
                  onClick={(e) => {
                    e.stopPropagation();
                    onRenameNode(node.path);
                  }}
                  className="p-1 hover:bg-neutral-700 rounded text-neutral-400 hover:text-neutral-200"
                >
                  <Edit2 className="w-3 h-3" />
                </button>
                <button
                  title="Delete"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDeleteNode(node.path);
                  }}
                  className="p-1 hover:bg-rose-900/60 rounded text-neutral-400 hover:text-rose-300"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </>
            )}
          </div>
        </div>

        {node.isDirectory && isExpanded && node.children && (
          <div className="flex flex-col">
            {node.children.map((child) => renderNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <aside className="w-64 h-full border-r border-neutral-800 bg-neutral-900/70 flex flex-col shrink-0 select-none overflow-hidden">
      {/* Explorer Header */}
      <div className="h-10 px-3 border-b border-neutral-800/80 flex items-center justify-between shrink-0">
        <span className="text-[11px] font-bold uppercase tracking-wider text-neutral-400">
          Project Explorer
        </span>
        <div className="flex items-center gap-1">
          <button
            onClick={() => onCreateFile(".", false)}
            title="New File in Root"
            className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onCreateFile(".", true)}
            title="New Directory in Root"
            className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
          >
            <FolderPlus className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onRefresh}
            title="Refresh Files"
            className="p-1 rounded hover:bg-neutral-800 text-neutral-400 hover:text-neutral-200"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={onDeleteEntireProjectTree}
            title="Delete Entire Project Tree"
            className="p-1 rounded hover:bg-rose-950 text-rose-400/80 hover:text-rose-300 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Tree Content */}
      <div className="flex-1 overflow-y-auto p-1 font-mono text-xs">
        {tree ? (
          renderNode(tree)
        ) : (
          <div className="p-4 text-center text-neutral-500 text-xs">
            Loading project tree...
          </div>
        )}
      </div>
    </aside>
  );
};
