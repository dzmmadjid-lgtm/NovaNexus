import React, { useState, useEffect } from "react";
import { TopNavBar } from "./components/TopNavBar";
import { ProjectExplorerView } from "./components/ProjectExplorerView";
import { CodeEditorArea } from "./components/CodeEditorArea";
import { BottomToolWindowsView } from "./components/BottomToolWindowsView";
import { TextInputModal, ConfirmModal, SearchModal, SettingsModal } from "./components/IdeModals";
import {
  FileNodeDto,
  EditorTabDto,
  BuildStatusType,
  BuildLogEntryDto,
  ProblemDto,
  ApkFileDto,
  BuildResultDto,
  JdkStatusDto,
  BottomTabType
} from "./types";

export default function App() {
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [projectTree, setProjectTree] = useState<FileNodeDto | null>(null);

  // Editor Tabs
  const [tabs, setTabs] = useState<EditorTabDto[]>([]);
  const [activeTabIndex, setActiveTabIndex] = useState<number>(-1);
  const [targetEditorLine, setTargetEditorLine] = useState<number | null>(null);

  // Bottom Tool Window
  const [activeBottomTab, setActiveBottomTab] = useState<BottomTabType>("build");
  const [isBottomExpanded, setIsBottomExpanded] = useState(true);

  // Build & JDK State
  const [buildStatus, setBuildStatus] = useState<BuildStatusType>("IDLE");
  const [buildLogs, setBuildLogs] = useState<BuildLogEntryDto[]>([]);
  const [buildResult, setBuildResult] = useState<BuildResultDto | null>(null);
  const [problems, setProblems] = useState<ProblemDto[]>([]);
  const [apkFile, setApkFile] = useState<ApkFileDto | null>(null);
  const [jdkStatus, setJdkStatus] = useState<JdkStatusDto | null>(null);

  // Terminal State
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    "DroidIDE Terminal Ready. OpenJDK 17 verified.",
    "Type 'java -version' or 'gradle --version' to inspect toolchains."
  ]);

  // Modals state
  const [createItemModal, setCreateItemModal] = useState<{ parentDir: string; isFolder: boolean } | null>(null);
  const [renameTarget, setRenameTarget] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [showDeleteEntireTreeModal, setShowDeleteEntireTreeModal] = useState(false);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // Guards against concurrent or duplicated tab openings
  const inFlightReadsRef = React.useRef<Set<string>>(new Set());
  const hasAutoOpenedInitialTab = React.useRef(false);

  // 1. Fetch JDK & initial project tree on mount
  useEffect(() => {
    fetchJdkStatus();
    fetchProjectTree();
  }, []);

  const fetchJdkStatus = async () => {
    try {
      const res = await fetch("/api/jdk/status");
      if (res.ok) {
        const data = await res.json();
        setJdkStatus(data);
      }
    } catch {
      // Fallback
      setJdkStatus({
        available: true,
        output: "openjdk version \"17.0.18\"\nOpenJDK Runtime Environment (build 17.0.18+8)",
        isJava17: true,
        javaHome: "/usr/lib/jvm/java-17-openjdk-amd64",
        arch: "x86_64",
        targetPlatform: "Android 16 / arm64-v8a compatible"
      });
    }
  };

  const fetchProjectTree = async () => {
    try {
      const res = await fetch("/api/files");
      if (res.ok) {
        const tree = await res.json();
        setProjectTree(tree);
        // Only auto-open initial tab once on mount
        if (!hasAutoOpenedInitialTab.current) {
          hasAutoOpenedInitialTab.current = true;
          openFileByPath("app/src/main/java/com/example/MainActivity.kt");
        }
      }
    } catch (e) {
      console.error("Failed to load project tree", e);
    }
  };

  const openFileByPath = async (filePath: string) => {
    // If already open in tabs, just activate it
    const existingIndex = tabs.findIndex((t) => t.path === filePath);
    if (existingIndex !== -1) {
      setActiveTabIndex(existingIndex);
      return;
    }

    // If a read request for this file is already in flight, skip duplicate request
    if (inFlightReadsRef.current.has(filePath)) {
      return;
    }
    inFlightReadsRef.current.add(filePath);

    try {
      const res = await fetch(`/api/file/read?path=${encodeURIComponent(filePath)}`);
      if (res.ok) {
        const data = await res.json();
        const ext = filePath.split(".").pop() || "";
        const name = filePath.split("/").pop() || "";
        const newTab: EditorTabDto = {
          path: filePath,
          name,
          content: data.content,
          isDirty: false,
          extension: ext,
          cursorLine: 1,
          cursorCol: 1
        };
        setTabs((prev) => {
          const idx = prev.findIndex((t) => t.path === filePath);
          if (idx !== -1) {
            setActiveTabIndex(idx);
            return prev;
          }
          const nextTabs = [...prev, newTab];
          setActiveTabIndex(nextTabs.length - 1);
          return nextTabs;
        });
      }
    } catch (e) {
      console.error("Error opening file", e);
    } finally {
      inFlightReadsRef.current.delete(filePath);
    }
  };

  const handleSaveActiveFile = async () => {
    if (activeTabIndex < 0 || activeTabIndex >= tabs.length) return;
    const tab = tabs[activeTabIndex];
    try {
      const res = await fetch("/api/file/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: tab.path, content: tab.content })
      });
      if (res.ok) {
        setTabs((prev) =>
          prev.map((t, i) => (i === activeTabIndex ? { ...t, isDirty: false } : t))
        );
      }
    } catch (e) {
      console.error("Error saving file", e);
    }
  };

  const handleCreateFileOrFolder = async (name: string) => {
    if (!createItemModal) return;
    try {
      const res = await fetch("/api/file/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          parentDir: createItemModal.parentDir,
          name,
          isFolder: createItemModal.isFolder
        })
      });
      if (res.ok) {
        fetchProjectTree();
        if (!createItemModal.isFolder) {
          const newPath = createItemModal.parentDir === "." ? name : `${createItemModal.parentDir}/${name}`;
          openFileByPath(newPath);
        }
      }
    } catch (e) {
      console.error("Failed to create item", e);
    }
  };

  const handleDeleteItem = async (path: string) => {
    try {
      const res = await fetch("/api/file/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path })
      });
      if (res.ok) {
        fetchProjectTree();
        setTabs((prev) => prev.filter((t) => !t.path.startsWith(path)));
        setActiveTabIndex((prev) => (prev > 0 ? prev - 1 : 0));
      }
    } catch (e) {
      console.error("Failed to delete item", e);
    }
  };

  const handleDeleteEntireProjectTree = async () => {
    try {
      const res = await fetch("/api/file/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: "app" })
      });
      if (res.ok) {
        setTabs([]);
        setActiveTabIndex(-1);
        fetchProjectTree();
      }
    } catch (e) {
      console.error("Failed to delete project tree", e);
    }
  };

  const handleRenameItem = async (newName: string) => {
    if (!renameTarget) return;
    try {
      const res = await fetch("/api/file/rename", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: renameTarget, newName })
      });
      if (res.ok) {
        const data = await res.json();
        fetchProjectTree();
        setTabs((prev) =>
          prev.map((t) => (t.path === renameTarget ? { ...t, path: data.newPath, name: newName } : t))
        );
      }
    } catch (e) {
      console.error("Failed to rename item", e);
    }
  };

  // Run Gradle build
  const handleRunBuild = async () => {
    // Save active file first
    await handleSaveActiveFile();

    setBuildStatus("RUNNING");
    setBuildLogs([{ message: "> Initiating Gradle build: ./gradlew assembleDebug...", isError: false, timestamp: Date.now() }]);
    setBuildResult(null);
    setProblems([]);
    setApkFile(null);
    setActiveBottomTab("build");
    setIsBottomExpanded(true);

    try {
      const res = await fetch("/api/build", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tasks: ["assembleDebug"] })
      });
      const data = await res.json();
      setBuildStatus(data.status);
      setBuildLogs(data.logs || []);
      setBuildResult(data);
      if (data.apkFile) {
        setApkFile(data.apkFile);
      }

      // Parse problems from logs
      const parsedProblems: ProblemDto[] = [];
      const errorRegex = /([ew]):\s*(?:file:\/\/)?([^:]+):(\d+):(\d+)\s*(.*)/;
      for (const entry of data.logs || []) {
        const match = errorRegex.exec(entry.message);
        if (match) {
          parsedProblems.push({
            file: match[2],
            line: parseInt(match[3], 10),
            column: parseInt(match[4], 10),
            message: match[5],
            isError: match[1] === "e"
          });
        }
      }
      setProblems(parsedProblems);
      if (data.status === "FAILED" && parsedProblems.length > 0) {
        setActiveBottomTab("problems");
      }
    } catch (e: any) {
      setBuildStatus("FAILED");
      setBuildLogs((prev) => [
        ...prev,
        { message: `Build execution error: ${e.message}`, isError: true, timestamp: Date.now() }
      ]);
    }
  };

  const handleStopBuild = () => {
    setBuildStatus("CANCELLED");
    setBuildLogs((prev) => [
      ...prev,
      { message: "> Build cancelled by user.", isError: true, timestamp: Date.now() }
    ]);
  };

  const handleRunTerminalCommand = async (command: string) => {
    setTerminalLogs((prev) => [...prev, `$ ${command}`]);
    try {
      const res = await fetch("/api/terminal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command })
      });
      const data = await res.json();
      if (data.stdout) {
        setTerminalLogs((prev) => [...prev, data.stdout.trim()]);
      }
      if (data.stderr) {
        setTerminalLogs((prev) => [...prev, `[stderr] ${data.stderr.trim()}`]);
      }
      if (data.error) {
        setTerminalLogs((prev) => [...prev, `Error: ${data.error}`]);
      }
    } catch (e: any) {
      setTerminalLogs((prev) => [...prev, `Terminal error: ${e.message}`]);
    }
  };

  const handleJumpToProblem = (filePath: string, line: number) => {
    openFileByPath(filePath);
    setTargetEditorLine(line);
  };

  return (
    <div className={`h-screen w-screen flex flex-col overflow-hidden ${theme === "dark" ? "bg-neutral-950 text-neutral-100" : "bg-neutral-100 text-neutral-900"}`}>
      {/* Top Navigation Bar */}
      <TopNavBar
        appName="DroidIDE"
        buildStatus={buildStatus}
        isSidebarOpen={isSidebarOpen}
        theme={theme}
        jdkStatus={jdkStatus}
        onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)}
        onRunBuild={handleRunBuild}
        onStopBuild={handleStopBuild}
        onToggleTheme={() => setTheme((prev) => (prev === "dark" ? "light" : "dark"))}
        onOpenSettings={() => setShowSettingsModal(true)}
        onOpenSearch={() => setShowSearchModal(true)}
      />

      {/* Main Workspace: Sidebar + Editor */}
      <div className="flex-1 flex overflow-hidden">
        {isSidebarOpen && (
          <ProjectExplorerView
            tree={projectTree}
            activeFilePath={tabs[activeTabIndex]?.path || null}
            onFileSelect={openFileByPath}
            onCreateFile={(parentDir, isFolder) => setCreateItemModal({ parentDir, isFolder })}
            onDeleteNode={(path) => setDeleteTarget(path)}
            onRenameNode={(path) => setRenameTarget(path)}
            onDeleteEntireProjectTree={() => setShowDeleteEntireTreeModal(true)}
            onRefresh={fetchProjectTree}
          />
        )}

        <CodeEditorArea
          tabs={tabs}
          activeTabIndex={activeTabIndex}
          targetLine={targetEditorLine}
          onSelectTab={(idx) => setActiveTabIndex(idx)}
          onCloseTab={(idx) => {
            const nextTabs = tabs.filter((_, i) => i !== idx);
            setTabs(nextTabs);
            setActiveTabIndex(nextTabs.length > 0 ? Math.max(0, idx - 1) : -1);
          }}
          onContentChange={(newContent) => {
            if (activeTabIndex >= 0 && activeTabIndex < tabs.length) {
              setTabs((prev) =>
                prev.map((t, i) => (i === activeTabIndex ? { ...t, content: newContent, isDirty: true } : t))
              );
            }
          }}
          onSaveFile={handleSaveActiveFile}
          onClearTargetLine={() => setTargetEditorLine(null)}
        />
      </div>

      {/* Bottom Tool Windows (Build Output, Problems, Terminal, Git, JDK Status) */}
      <BottomToolWindowsView
        activeTab={activeBottomTab}
        isExpanded={isBottomExpanded}
        buildStatus={buildStatus}
        buildLogs={buildLogs}
        buildResult={buildResult}
        problems={problems}
        apkFile={apkFile}
        jdkStatus={jdkStatus}
        onSelectTab={(tab) => setActiveBottomTab(tab)}
        onToggleExpanded={() => setIsBottomExpanded((prev) => !prev)}
        onClearLogs={() => setBuildLogs([])}
        onJumpToProblem={handleJumpToProblem}
        onRunTerminalCommand={handleRunTerminalCommand}
        terminalLogs={terminalLogs}
      />

      {/* Create File / Directory Modal */}
      <TextInputModal
        isOpen={createItemModal !== null}
        title={createItemModal?.isFolder ? "Create New Directory" : "Create New File"}
        placeholder={createItemModal?.isFolder ? "e.g. components" : "e.g. MyView.kt"}
        confirmText="Create"
        onConfirm={handleCreateFileOrFolder}
        onClose={() => setCreateItemModal(null)}
      />

      {/* Rename Modal */}
      <TextInputModal
        isOpen={renameTarget !== null}
        title="Rename Item"
        initialValue={renameTarget?.split("/").pop() || ""}
        confirmText="Rename"
        onConfirm={handleRenameItem}
        onClose={() => setRenameTarget(null)}
      />

      {/* Delete Item Modal */}
      <ConfirmModal
        isOpen={deleteTarget !== null}
        title="Delete Item"
        message={`Are you sure you want to permanently delete "${deleteTarget}"?`}
        confirmText="Delete"
        isDanger={true}
        onConfirm={() => {
          if (deleteTarget) handleDeleteItem(deleteTarget);
          setDeleteTarget(null);
        }}
        onClose={() => setDeleteTarget(null)}
      />

      {/* Delete Entire Project Tree Modal */}
      <ConfirmModal
        isOpen={showDeleteEntireTreeModal}
        title="Delete Entire Project Tree"
        message="Are you sure you want to permanently delete the entire project directory tree (all app source files, gradle build scripts, manifests, and resources)? This action cannot be undone."
        confirmText="Delete Entire Project Tree"
        isDanger={true}
        onConfirm={handleDeleteEntireProjectTree}
        onClose={() => setShowDeleteEntireTreeModal(false)}
      />

      {/* Global Search Modal */}
      <SearchModal
        isOpen={showSearchModal}
        onClose={() => setShowSearchModal(false)}
        onJumpTo={handleJumpToProblem}
      />

      {/* IDE & JDK Settings Modal */}
      <SettingsModal
        isOpen={showSettingsModal}
        jdkStatus={jdkStatus}
        onClose={() => setShowSettingsModal(false)}
      />
    </div>
  );
}
