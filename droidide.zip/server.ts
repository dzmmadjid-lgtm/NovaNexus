import express from "express";
import path from "path";
import fs from "fs";
import { spawn, exec } from "child_process";
import { createServer as createViteServer } from "vite";

interface FileNodeDto {
  name: string;
  path: string;
  isDirectory: boolean;
  extension: string;
  children?: FileNodeDto[];
}

function buildFileTree(dir: string, rootDir: string): FileNodeDto {
  const name = path.basename(dir);
  const relPath = path.relative(rootDir, dir);
  const stat = fs.statSync(dir);

  if (stat.isDirectory()) {
    const entries = fs.readdirSync(dir);
    const children: FileNodeDto[] = [];
    for (const entry of entries) {
      if (entry === ".git" || entry === "node_modules" || entry === ".gradle") continue;
      const fullChild = path.join(dir, entry);
      try {
        children.push(buildFileTree(fullChild, rootDir));
      } catch {
        // Skip unreadable files
      }
    }
    children.sort((a, b) => {
      if (a.isDirectory === b.isDirectory) return a.name.localeCompare(b.name);
      return a.isDirectory ? -1 : 1;
    });
    return {
      name,
      path: relPath || ".",
      isDirectory: true,
      extension: "",
      children
    };
  } else {
    const ext = path.extname(name).replace(/^\./, "").toLowerCase();
    return {
      name,
      path: relPath,
      isDirectory: false,
      extension: ext
    };
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;
  const projectRootDir = process.cwd();

  app.use(express.json());

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // JDK & System Status
  app.get("/api/jdk/status", (req, res) => {
    exec("java -version 2>&1", (err, stdout, stderr) => {
      const output = (stdout || "") + (stderr || "");
      const javaHome = process.env.JAVA_HOME || "/usr/lib/jvm/java-17-openjdk-amd64";
      const arch = process.arch;
      const isJava17 = output.includes("17.") || output.includes("openjdk 17") || output.includes("build 17");

      res.json({
        available: !err || output.includes("version"),
        output: output.trim(),
        isJava17,
        javaHome,
        arch,
        targetPlatform: "Android 16 / arm64-v8a compatible"
      });
    });
  });

  // Project file tree
  app.get("/api/files", (req, res) => {
    try {
      const tree = buildFileTree(projectRootDir, projectRootDir);
      res.json(tree);
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Read file content
  app.get("/api/file/read", (req, res) => {
    const filePath = req.query.path as string;
    if (!filePath) return res.status(400).json({ error: "Missing path parameter" });
    const fullPath = path.resolve(projectRootDir, filePath);
    if (!fullPath.startsWith(projectRootDir)) {
      return res.status(403).json({ error: "Access denied outside project root" });
    }
    try {
      if (!fs.existsSync(fullPath) || fs.statSync(fullPath).isDirectory()) {
        return res.status(404).json({ error: "File not found" });
      }
      const content = fs.readFileSync(fullPath, "utf-8");
      res.json({ content, path: filePath });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Save file content
  app.post("/api/file/save", (req, res) => {
    const { path: filePath, content } = req.body;
    if (!filePath) return res.status(400).json({ error: "Missing path parameter" });
    const fullPath = path.resolve(projectRootDir, filePath);
    if (!fullPath.startsWith(projectRootDir)) {
      return res.status(403).json({ error: "Access denied outside project root" });
    }
    try {
      fs.mkdirSync(path.dirname(fullPath), { recursive: true });
      fs.writeFileSync(fullPath, content, "utf-8");
      res.json({ success: true, path: filePath });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Create file or directory
  app.post("/api/file/create", (req, res) => {
    const { parentDir, name, isFolder } = req.body;
    if (!name) return res.status(400).json({ error: "Name is required" });
    const fullParent = path.resolve(projectRootDir, parentDir || ".");
    const fullTarget = path.join(fullParent, name);
    if (!fullTarget.startsWith(projectRootDir)) {
      return res.status(403).json({ error: "Access denied" });
    }
    try {
      if (isFolder) {
        fs.mkdirSync(fullTarget, { recursive: true });
      } else {
        fs.mkdirSync(path.dirname(fullTarget), { recursive: true });
        if (!fs.existsSync(fullTarget)) {
          fs.writeFileSync(fullTarget, "", "utf-8");
        }
      }
      res.json({ success: true, path: path.relative(projectRootDir, fullTarget) });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Delete file or directory (supports deleting entire trees!)
  app.post("/api/file/delete", (req, res) => {
    const { path: targetRelPath } = req.body;
    if (!targetRelPath || targetRelPath === "." || targetRelPath === "/") {
      return res.status(400).json({ error: "Cannot delete project root directly" });
    }
    const fullTarget = path.resolve(projectRootDir, targetRelPath);
    if (!fullTarget.startsWith(projectRootDir)) {
      return res.status(403).json({ error: "Access denied" });
    }
    try {
      if (fs.existsSync(fullTarget)) {
        fs.rmSync(fullTarget, { recursive: true, force: true });
      }
      res.json({ success: true });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Rename file or directory
  app.post("/api/file/rename", (req, res) => {
    const { path: oldRelPath, newName } = req.body;
    if (!oldRelPath || !newName) return res.status(400).json({ error: "Missing parameters" });
    const fullOld = path.resolve(projectRootDir, oldRelPath);
    const fullNew = path.join(path.dirname(fullOld), newName);
    if (!fullOld.startsWith(projectRootDir) || !fullNew.startsWith(projectRootDir)) {
      return res.status(403).json({ error: "Access denied" });
    }
    try {
      fs.renameSync(fullOld, fullNew);
      res.json({ success: true, newPath: path.relative(projectRootDir, fullNew) });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  // Execute Gradle build
  app.post("/api/build", (req, res) => {
    const tasks = req.body.tasks || ["assembleDebug"];
    const startTime = Date.now();
    const logs: Array<{ message: string; isError: boolean; timestamp: number }> = [];

    // Find gradle executable: check ./gradlew or gradle in PATH
    let gradleCmd = "./gradlew";
    let args = [...tasks];
    if (!fs.existsSync(path.join(projectRootDir, "gradlew"))) {
      gradleCmd = "gradle";
    }

    logs.push({
      message: `> Starting Gradle build with task(s): ${tasks.join(" ")}`,
      isError: false,
      timestamp: Date.now()
    });

    const child = spawn(gradleCmd, args, {
      cwd: projectRootDir,
      env: {
        ...process.env,
        JAVA_HOME: process.env.JAVA_HOME || "/usr/lib/jvm/java-17-openjdk-amd64",
        PATH: `${process.env.JAVA_HOME || "/usr/lib/jvm/java-17-openjdk-amd64"}/bin:${process.env.PATH}`
      },
      shell: true
    });

    child.stdout.on("data", (data) => {
      const lines = data.toString().split(/\r?\n/);
      for (const line of lines) {
        if (line.trim().length > 0) {
          logs.push({ message: line, isError: false, timestamp: Date.now() });
        }
      }
    });

    child.stderr.on("data", (data) => {
      const lines = data.toString().split(/\r?\n/);
      for (const line of lines) {
        if (line.trim().length > 0) {
          logs.push({ message: line, isError: true, timestamp: Date.now() });
        }
      }
    });

    child.on("close", (exitCode) => {
      const durationMs = Date.now() - startTime;
      let apkFile: { name: string; path: string; size: number } | null = null;

      // Scan for APK in build/outputs/apk/debug
      const apkSearchDirs = [
        path.join(projectRootDir, "app/build/outputs/apk/debug"),
        path.join(projectRootDir, "build/outputs/apk/debug"),
        path.join(projectRootDir, "app/build/outputs/apk")
      ];
      for (const searchDir of apkSearchDirs) {
        if (fs.existsSync(searchDir)) {
          const files = fs.readdirSync(searchDir);
          const foundApk = files.find((f) => f.endsWith(".apk"));
          if (foundApk) {
            const apkFullPath = path.join(searchDir, foundApk);
            const stats = fs.statSync(apkFullPath);
            apkFile = {
              name: foundApk,
              path: path.relative(projectRootDir, apkFullPath),
              size: stats.size
            };
            break;
          }
        }
      }

      const status = exitCode === 0 ? "SUCCESS" : "FAILED";
      logs.push({
        message: `> Build ${status} in ${(durationMs / 1000).toFixed(1)}s with exit code ${exitCode}`,
        isError: exitCode !== 0,
        timestamp: Date.now()
      });

      res.json({
        status,
        exitCode,
        durationMs,
        apkFile,
        logs
      });
    });

    child.on("error", (err) => {
      logs.push({
        message: `Execution error: ${err.message}`,
        isError: true,
        timestamp: Date.now()
      });
      res.json({
        status: "FAILED",
        exitCode: 1,
        durationMs: Date.now() - startTime,
        apkFile: null,
        logs
      });
    });
  });

  // Terminal command execution
  app.post("/api/terminal", (req, res) => {
    const { command, cwd } = req.body;
    if (!command) return res.status(400).json({ error: "Missing command" });
    const targetCwd = cwd ? path.resolve(projectRootDir, cwd) : projectRootDir;

    exec(command, {
      cwd: targetCwd,
      env: {
        ...process.env,
        JAVA_HOME: process.env.JAVA_HOME || "/usr/lib/jvm/java-17-openjdk-amd64",
        PATH: `${process.env.JAVA_HOME || "/usr/lib/jvm/java-17-openjdk-amd64"}/bin:${process.env.PATH}`
      }
    }, (error, stdout, stderr) => {
      res.json({
        exitCode: error ? error.code || 1 : 0,
        stdout: stdout || "",
        stderr: stderr || "",
        error: error ? error.message : null
      });
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`DroidIDE server running on port ${PORT}`);
  });
}

startServer();
